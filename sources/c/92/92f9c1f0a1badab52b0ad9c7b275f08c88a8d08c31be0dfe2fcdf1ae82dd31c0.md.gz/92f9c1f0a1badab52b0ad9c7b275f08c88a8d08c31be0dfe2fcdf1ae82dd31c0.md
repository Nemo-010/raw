Two first-party clients targeting the Bee OpenAI-compatible `/chat/completions` surface. Pick the one that matches your runtime - the wire format is the same on either side.

## API contract

The public OpenAPI contract is versioned with the gateway and describes the supported Bee developer surface. Use it to generate internal clients or validate integrations.

[OpenAPI 3.1 contract](https://api.bee.heossi.com/openapi.json)[Postman collection](https://api.bee.heossi.com/postman.json)

### HTTP quickstart

```
curl https://api.bee.heossi.com/bee/chat/completions \
  -H "Authorization: Bearer $BEE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "bee-cell",
    "messages": [{"role": "user", "content": "Hello, Bee."}],
    "stream": false
  }'
```

## TypeScript / JavaScript

Pure ESM, zero runtime dependencies, native fetch. Works in Node 18+, Deno, Bun, and every modern browser.

Live on npm

```
npm install @heossihq/bee
# or pnpm add @heossihq/bee
# or yarn add @heossihq/bee
```

### Quickstart

```
import { BeeClient } from "@heossihq/bee";

const bee = new BeeClient({ apiKey: process.env.BEE_API_KEY! });

const out = await bee.chat.completions.create({
  model: "bee-cell",
  domain: "cryptography_pqc", // optional; omit for governed automatic routing
  messages: [
    { role: "user", content: "Summarise the SOLID principles in 2 lines." },
  ],
});

console.log(out.choices[0].message.content);
```

### Streaming

```
const stream = await bee.chat.completions.create({
  model: "bee-cell",
  messages: [{ role: "user", content: "Write a haiku about bees." }],
  stream: true,
});

for await (const chunk of stream) {
  process.stdout.write(chunk.choices[0]?.delta?.content ?? "");
}
```

[View on npm](https://www.npmjs.com/package/@heossihq/bee)[Working examples](https://github.com/heossihq/bee-public/tree/main/examples/typescript)

## Python

Stdlib-only sync client. Optional `httpx`-backed async client behind `bee-sdk[async]`.

Live on PyPI

Install from PyPI (canonical). Full SDK docs: [bee.heossi.com/docs](https://bee.heossi.com/docs/).

```
pip install bee-sdk          # sync, zero deps
pip install bee-sdk[async]   # adds httpx for the async client
```

### Quickstart

```
from bee_sdk import Bee

bee = Bee()  # reads BEE_API_URL + BEE_API_KEY from env

print(bee.chat(
    "Explain Shor's algorithm at NISQ depth",
    domain="quantum",
))
```

### Streaming

```
for chunk in bee.chat_stream(
    "Write a fibonacci function",
    domain="programming",
):
    print(chunk, end="", flush=True)
```

### Async

```
import asyncio
from bee_sdk import Bee

async def main():
    client = Bee.async_client()  # requires bee-sdk[async]
    result = await client.chat(
        "Audit this code for SQL injection",
        domain="cybersecurity",
    )
    print(result)

asyncio.run(main())
```

[Source on GitHub](https://github.com/heossihq/bee-public/tree/main/sdks/python)[Working examples](https://github.com/heossihq/bee-public/tree/main/examples/python)

## Use Bee in OpenCode today

[OpenCode custom-provider docs](https://opencode.ai/docs/providers/#custom-provider)

Bee is listed in the models.dev catalog used by OpenCode. Connect the Bee provider with your Bee API key using `/connect`, or set the local `BEE_API_KEY` environment variable. Then select a Bee model using `/models`.

```
opencode models bee --refresh
```

For clients with an older catalog, Bee also supports a custom-provider configuration. Set your key in the local `BEE_API_KEY` environment variable, then add this configuration to `opencode.json`. The key is read from your environment and is not stored in the configuration.

```
{
  "$schema": "https://opencode.ai/config.json",
  "model": "bee/bee-cell",
  "provider": {
    "bee": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "Bee: Quantum Intelligence",
      "options": {
        "baseURL": "https://api.bee.heossi.com/bee",
        "apiKey": "{env:BEE_API_KEY}"
      },
      "models": {
        "bee-cell": {
          "name": "Bee Cell 1.0",
          "limit": {
            "context": 131072,
            "output": 8192
          }
        },
        "bee-brood": {
          "name": "Bee Brood 1.0",
          "reasoning": true,
          "limit": {
            "context": 262144,
            "output": 16384
          }
        },
        "bee-comb": {
          "name": "Bee Comb 2.0",
          "reasoning": true,
          "limit": {
            "context": 262144,
            "output": 16384
          }
        },
        "bee-buzz": {
          "name": "Bee Buzz 1.0",
          "reasoning": true,
          "limit": {
            "context": 262144,
            "output": 24576
          }
        },
        "bee-hive": {
          "name": "Bee Hive 1.0",
          "reasoning": true,
          "limit": {
            "context": 262144,
            "output": 32768
          }
        },
        "bee-swarm": {
          "name": "Bee Swarm 1.0",
          "reasoning": true,
          "limit": {
            "context": 1000000,
            "output": 64000
          }
        }
      }
    }
  }
}
```

If Bee does not appear, configure your provider credential and refresh the catalog. The model-list command does not generate content or consume inference allowance. Third-party clients negotiate their own transport; connecting to Bee does not certify every client device or connection as post-quantum protected.

[Open the machine-readable Bee configuration](https://bee.heossi.com/opencode.json)

## Already using the OpenAI SDK? Just point it at Bee.

Because Bee speaks the OpenAI Chat Completions wire format, the official `openai` packages work against Bee with a base-URL change - useful for migration trials before adopting `@heossihq/bee` or `bee-sdk` properly.

```
import OpenAI from "openai";

const bee = new OpenAI({
  apiKey: process.env.BEE_API_KEY,
  baseURL: "https://api.bee.heossi.com/bee",
});
```

Looking for the MCP integration with Claude Desktop / Cursor / VS Code? [See /docs/mcp](https://bee.heossi.com/docs/mcp). Need an API key? [Issue one in the workspace](https://workspace.bee.heossi.com/account/api-keys). SDK source mirrored at [heossihq/bee-public](https://github.com/heossihq/bee-public).

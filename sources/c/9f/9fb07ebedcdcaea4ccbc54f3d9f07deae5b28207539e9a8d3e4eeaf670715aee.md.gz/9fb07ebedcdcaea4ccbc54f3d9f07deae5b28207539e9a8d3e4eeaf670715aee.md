
The snapshot is the complete OpenAlex database as downloadable files. It’s stored in [Amazon S3](https://aws.amazon.com/s3/) in the [`openalex`](https://openalex.s3.amazonaws.com/browse.html) bucket, under the `data/` prefix — free to download, no AWS account needed (see [Access & authentication](#access--authentication) below). For step-by-step download commands, see the [download recipe](https://help.openalex.org/tutorials/download-the-snapshot/).

## Two formats

The snapshot is published in two formats, each a complete copy of the same data:

| Format | Compression | One record per | Prefix |
| --- | --- | --- | --- |
| [JSON Lines](https://jsonlines.org/) | gzip (`.gz`) | line | `/data/jsonl/` |
| [Apache Parquet](https://parquet.apache.org/) | snappy (`.parquet`) | row | `/data/parquet/` |

## Size

Check the current size before downloading — it changes with every release. As of the September 2026 release, each format holds about **626 million records**:

|  | Compressed size |
| --- | --- |
| JSON Lines (`/data/jsonl/`) | \~745 GB (works alone: \~615 GB) |
| Parquet (`/data/parquet/`) | \~770 GB |

Decompressed, the JSON Lines data runs to several terabytes. The two formats are separate complete copies, so downloading both roughly doubles the transfer — most users want [a single format prefix](https://help.openalex.org/tutorials/download-the-snapshot/#download-a-single-format-or-entity-type). Live totals are always in each format’s `manifest.json` (`content_length`, per entity and overall).

## Bucket structure

The bucket root holds the license and release notes; the data lives under `data/`, with one folder per entity type under each format prefix, plus a combined `manifest.json`:

```plaintext
s3://openalex/
├── LICENSE.txt
├── RELEASE_NOTES.txt          # what changed in each release
├── browse.html                # in-browser bucket explorer
├── legacy-data/               # pre-2026 flat layout + merged_ids/ (frozen, not updated)
└── data/
    ├── jsonl/
    │   ├── manifest.json      # all entities, this format
    │   ├── works/
    │   │   ├── manifest.json  # works only
    │   │   ├── deleted_ids.csv.gz  # works deletion log (gzip CSV)
    │   │   └── updated_date=2026-06-24/
    │   │       ├── part_0000.gz
    │   │       └── part_0001.gz
    │   ├── authors/
    │   └── ...
    └── parquet/
        ├── manifest.json
        ├── works/
        │   ├── manifest.json
        │   ├── deleted_ids.csv.gz
        │   └── updated_date=2026-06-24/
        │       ├── part_0000.parquet
        │       └── part_0001.parquet
        └── ...
```

The entity folders under each format are:

| Core entities | Topic hierarchy | Lookup / aggregation entities |
| --- | --- | --- |
| `works` | `topics` | `keywords`, `concepts` |
| `authors` | `subfields` | `continents`, `countries` |
| `institutions` | `fields` | `institution-types`, `source-types`, `work-types` |
| `sources` | `domains` | `languages`, `licenses`, `sdgs` |
| `publishers`, `funders`, `awards` |  | |

You can browse the bucket at [openalex.s3.amazonaws.com/browse.html](https://openalex.s3.amazonaws.com/browse.html#data/).

Records are partitioned by `updated_date`: each partition holds the records that **last changed** on that date, in part files (`part_0000.*`, `part_0001.*`, …) of up to 400,000 records each. This is what makes incremental updates cheap — see [Sync](https://help.openalex.org/access/sync/) for how partitions move between releases and how to keep a copy current.

The works folder additionally carries `deleted_ids.csv.gz`, a gzip-compressed log of deleted work IDs and their deletion dates — see [Deletions and merged entities](https://help.openalex.org/access/sync/#deletions-and-merged-entities) for the format, its size, and how to apply it. Works is the first entity type with a deletion log; it ships in every [daily snapshot](#the-daily-snapshot-bucket-paid-plans) (since 2026-08-15) and has been in this public bucket since the 2026-09-23 release.

The works, authors and sources folders carry `merged_ids.csv.gz`, every merged-away ID with the ID it now resolves to — see [Merged IDs](https://help.openalex.org/access/sync/#merged-ids-merged_idscsvgz). It ships in every daily snapshot from 2026-10-27 and reaches this public bucket with the next quarterly release.

> **Note:** Pre-2026 snapshots used a flat `data/{entity}/` layout (JSON Lines only) with no `jsonl/`/`parquet/` split. That older layout, along with the `merged_ids/` directory, is preserved under the `legacy-data/` prefix.

## The manifest files

Every format has a combined `manifest.json` listing all data files across all entities (`/data/{format}/manifest.json`), and every entity has its own (`/data/{format}/{entity}/manifest.json`). The manifest is written last, after all data files are uploaded — **if the manifest is present, the data for that format is complete.**

A per-entity manifest looks like this:

```json
{
  "date": "2026-06-25",
  "format": "jsonl",
  "entity": "works",
  "record_count": 510372821,
  "content_length": 665688383258,
  "files": [
    {
      "url": "s3://openalex/data/jsonl/works/updated_date=2026-06-24/part_0000.gz",
      "meta": { "content_length": 936733, "record_count": 499 }
    }
  ]
}
```

The combined manifest has the same shape but nests one entry per entity under an `entities` array, with a top-level `meta` carrying the totals. The manifest drives the [incremental-update workflow](https://help.openalex.org/access/sync/#keeping-in-sync-with-openalex).

## Entity schemas

Each record is a complete entity object in the same shape the API returns — the field dictionaries on the [Entities](https://help.openalex.org/data/) tab apply directly:

- **[Works](https://help.openalex.org/data/works/)** · **[Authors](https://help.openalex.org/data/authors/)** · **[Sources](https://help.openalex.org/data/sources/)** · **[Institutions](https://help.openalex.org/data/institutions/)** · **[Topics](https://help.openalex.org/data/topics/)** · **[Publishers](https://help.openalex.org/data/publishers/)**

## Reading the JSONL files

Each data file is [JSON Lines](https://jsonlines.org/) (JSONL): every line is one JSON object representing a single record. Because the decompressed snapshot runs to terabytes, this lets you process one record at a time without loading a whole file into memory. The catch: a JSONL file *as a whole* isn’t valid JSON, so tools expecting one big JSON document choke on it. Treat each **line**, not the file, as the JSON object.

Read gzipped part files directly, one line at a time — in Python:

```python
import gzip, json

with gzip.open("part_0000.gz", "rt") as f:
    for line in f:
        work = json.loads(line)
        print(work["id"], work["display_name"])
```

…or in R with `jsonlite` and `gzfile`. From there, load records into pandas, DuckDB, or whatever suits. DuckDB can query `.gz` JSONL directly (`read_json_auto('part_*.gz')`) — and if you’d rather skip JSONL entirely, the snapshot’s [Parquet copy](#two-formats) loads straight into DuckDB, Spark, or BigQuery.

## How the snapshot differs from the API

People often compare counts or fields between their snapshot copy and the live API and worry when they differ. The known, expected differences:

| Difference | Why |
| --- | --- |
| **Works count: snapshot vs API default** | The snapshot contains **all** works, including the [expansion (XPAC) corpus](https://help.openalex.org/data/works/corpus/). The API **excludes XPAC works by default** — as of September 2026 that’s \~327M works by default vs \~476M with `corpus=all`. Add `corpus=all` to match the snapshot’s total. Filter locally on the [`is_xpac`](https://help.openalex.org/data/works/attributes/#is_xpac) field to reproduce the API’s default view. |
| **Freshness** | The snapshot is a point-in-time release (quarterly for the free public snapshot, on the second Wednesday of January, April, July and October — see [release dates](https://help.openalex.org/access/sync/#public-release-dates); daily on [paid plans](https://help.openalex.org/access/pricing/)); the API updates continuously. Counts and records drift between releases — see [Sync](https://help.openalex.org/access/sync/). |
| **`content_urls` is absent** | It’s generated at serve time, API-only. The snapshot has [`has_content`](https://help.openalex.org/data/works/attributes/#has_content); build download URLs via the [content archive](https://help.openalex.org/access/fulltext/) with work IDs. |
| **`sustainable_development_goals_aurora` is absent** | It is [deprecated](https://help.openalex.org/api/deprecations/) and leaves the API in November 2026, so it was never added to the snapshot. Use [`sustainable_development_goals`](https://help.openalex.org/data/works/attributes/#sustainable_development_goals). |
| **`authors_count` and `locations[].provenance` are snapshot-only** | Two extra fields: `authors_count` is the number of authorships (up to 5,000), and `provenance` says which pipeline delivered each location, with the same values as on [`/locations` rows](https://help.openalex.org/data/locations/#extra-attributes-on-locations-rows). |
| **Releases before 27 October 2026: bare location ids, empty `best_oa_location` objects** | Snapshots written before 27 October 2026, including the public release of 14 October 2026, hold each location’s [`id`](https://help.openalex.org/data/locations/#id) without its namespace (`10.7717/peerj.4375`, not `doi:10.7717/peerj.4375`), and give every work with no open copy a `best_oa_location` object whose fields are all null instead of `null`. Daily snapshots from 27 October 2026 and public releases from January 2027 match the API. In an older file, treat an all-null `best_oa_location` as `null`. |
| **Some works have `abstract_inverted_index: null`** | Not every work has an abstract (availability and publisher restrictions) — same as the API. |
| **No n-grams** | The old n-grams dataset is retired and was never part of this snapshot layout. |

Otherwise the snapshot work schema matches the API’s — including `fwci`, `topics`, `citation_normalized_percentile`, and `is_xpac`.

## Access & authentication

Bulk data lives in several buckets with different access rules. This is the map:

| What | Where | Auth |
| --- | --- | --- |
| Public snapshot (this page) | `s3://openalex` (S3, `data/` prefix) | **None** — free, anonymous |
| [Daily snapshot](https://help.openalex.org/access/sync/#the-daily-snapshot-paid-plans) (paid) | `s3://openalex-snapshots` (staging bucket, dated folders under `full/`) | API key via `credential_process` |
| [Content archive](https://help.openalex.org/access/fulltext/) per-file | `content.openalex.org/works/...` | API key ($0.01/file) |
| Content archive full sync ([PDF sync service](https://help.openalex.org/access/fulltext/#option-3-complete-archive-sync)) | Cloudflare R2 (S3-compatible) | Read-only R2 credentials issued by us, valid for your subscription year |

### The public snapshot bucket: free, no account

The `openalex` bucket is free to download and needs **no AWS account**. Use the AWS CLI with `--no-sign-request` for anonymous access:

```bash
aws s3 sync "s3://openalex/data/jsonl" "openalex-snapshot/data/jsonl" --no-sign-request
```

You can also browse it in a browser: [openalex.s3.amazonaws.com/browse.html](https://openalex.s3.amazonaws.com/browse.html). Many thanks to the [AWS Open Data program](https://aws.amazon.com/opendata/), which covers the data-transfer fees (about $70 per download) so users don’t have to.

### The daily snapshot bucket (paid plans)

Subscribers get a full snapshot rebuilt **every day**, published to dated folders in the `openalex-snapshots` staging bucket in both formats. Access is via your OpenAlex API key, exchanged automatically for temporary AWS credentials.

Add this to `~/.aws/config` (replace `YOUR_KEY` with your API key):

```ini
[profile openalex]
credential_process = curl -sf -X POST "https://api.openalex.org/snapshots/credentials?api_key=YOUR_KEY"
```

The AWS CLI fetches and refreshes credentials automatically. Then:

```bash
aws s3 ls s3://openalex-snapshots/full/ --profile openalex
aws s3 sync s3://openalex-snapshots/full/YYYY-MM-DD/jsonl/ ./openalex-snapshot-jsonl --profile openalex   # pick a dated folder from the ls above
```

See [Sync](https://help.openalex.org/access/sync/#the-daily-snapshot-paid-plans) for what the daily snapshot is and the sync workflows it enables.

### Content archive

Per-file downloads use your API key directly ($0.01/file): `https://content.openalex.org/works/W2741809807.pdf?api_key=YOUR_KEY`. For full-archive sync, the **PDF sync service** (an add-on to the [Member+ or Partner plan](https://help.openalex.org/access/pricing/#the-pdf-sync-add-on)) gives you read-only Cloudflare R2 credentials that last for your subscription year, so you can sync the complete archive and keep receiving new files as they arrive. Details on the [content archive page](https://help.openalex.org/access/fulltext/).

### Where’s my API key?

Sign up free at [openalex.org](https://openalex.org/signup) and find your key in [Settings → API key](https://openalex.org/me/api). See [API authentication](https://help.openalex.org/api/authentication/) for how keys, credits, and plans work.

### Common access problems

| Symptom | Likely cause & fix |
| --- | --- |
| `AccessDenied` / `403` on `s3://openalex` | You’re making a *signed* request with your own AWS credentials. Add `--no-sign-request`. |
| `credential_process` errors for the staging bucket | Test the curl command by itself — if it returns nothing, the API key is wrong or your plan doesn’t include the daily snapshot. `curl` must be on the PATH the AWS CLI uses. |
| Sync re-downloads or duplicates records | Re-syncing into an old copy without `--delete`; see [Sync](https://help.openalex.org/access/sync/). |
| Download is slow or flaky | Each format is \~750 GB — use `aws s3 sync` (it parallelizes and resumes) rather than single `cp` streams, and re-run it to pick up where it left off. |

Still stuck? [Contact support](https://openalex.org/contact) with the exact command and error.

## Related pages

- [Sync](https://help.openalex.org/access/sync/) — release cadence, partition semantics, deletions & merged entities
- [Download to your machine](https://help.openalex.org/tutorials/download-the-snapshot/) — step-by-step recipe

Last updated October 27, 2026

[View as Markdown](https://help.openalex.org/access/snapshot.md)

On this page
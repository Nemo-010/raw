[![Zade Servers](https://my.zadeservers.net/assets/img/logo.png)](https://my.zadeservers.net/index.php)

- [0 Shopping Cart](https://my.zadeservers.net/cart.php?a=view)
-

- [Home](https://my.zadeservers.net/index.php)
- [Store](#)
  - [Browse All](https://my.zadeservers.net/store)
  - [Compute Optimized NVMe KVM VPS \[Germany\]](https://my.zadeservers.net/store/compute-optimized-nvme-kvm-de)
  - [Memory Optimized NVMe KVM VPS \[Germany\]](https://my.zadeservers.net/store/memory-optimized-nvme-kvm-de)
  - [Storage KVM VPS \[Germany\]](https://my.zadeservers.net/store/storage-kvm-de)
  - [Register a New Domain](https://my.zadeservers.net/cart.php?a=add&domain=register)
  - [Transfer Domains to Us](https://my.zadeservers.net/cart.php?a=add&domain=transfer)
- [Announcements](https://my.zadeservers.net/announcements)
- [Knowledgebase](https://my.zadeservers.net/knowledgebase)
- [Affiliates](https://my.zadeservers.net/affiliates.php)
- [Contact Us](https://my.zadeservers.net/submitticket.php)
- [More](#)

- [Account](#)
  - [Login](https://my.zadeservers.net/clientarea.php)
  - [Register](https://my.zadeservers.net/register.php)
  - [Forgot Password?](https://my.zadeservers.net/password/reset)

1. Shopping Cart

###   Categories

[Compute Optimized NVMe KVM VPS \[Germany\]](https://my.zadeservers.net/store/compute-optimized-nvme-kvm-de) [Memory Optimized NVMe KVM VPS \[Germany\]](https://my.zadeservers.net/store/memory-optimized-nvme-kvm-de) [Storage KVM VPS \[Germany\]](https://my.zadeservers.net/store/storage-kvm-de)

###   Actions

[  Register a New Domain](https://my.zadeservers.net/cart.php?a=add&domain=register) [  Transfer in a Domain](https://my.zadeservers.net/cart.php?a=add&domain=transfer) [  View Cart](https://my.zadeservers.net/cart.php?a=view)

###   Choose Currency

USD EUR GBP INR PLN

# Configure

###   Categories

Compute Optimized NVMe KVM VPS \[Germany] Memory Optimized NVMe KVM VPS \[Germany] Storage KVM VPS \[Germany] - Choose Another Category -

###   Actions

Register a New Domain Transfer in a Domain View Cart - Choose Another Category -

###   Choose Currency

\- Choose Another Category -

Choose Currency USD GBP EUR INR PLN

Configure your desired options and continue to checkout.

DE-MEM-KVM-NVMe-2

1 vCore @ 3.40+ GHz  
 2 GB DDR4 RAM  
 20 GB NVMe SSD Storage  
 Unmetered Bandwidth @ 1 Gbit/s (shared)  
 1 IPv4 Address

Please correct the following errors before continuing:

Choose Billing Cycle  
1 Month Price - $3.50 USD 3 Month Price - $3.50 USD 6 Month Price - $3.50 USD 12 Month Price - $3.50 USD

Configure Server

Hostname

Root Password

Configurable Options

Operating System Debian 13 Debian 12 Ubuntu 26.04 LTS Ubuntu 24.04 LTS Ubuntu 22.04 LTS AlmaLinux 10 AlmaLinux 9 AlmaLinux 8 Rocky Linux 10 Rocky Linux 9 Rocky Linux 8 Not listed, and need a custom ISO install?

Management None Basic Management $7.50 USD Semi Managed $20.00 USD Fully Managed $40.00 USD

Additional IPv4 Addresses

0253000063126190253

Have questions? Contact our sales team for assistance. [Click here](https://my.zadeservers.net/contact.php)

## Order Summary

DE-MEM-KVM-NVMe-2 Memory Optimized NVMe KVM VPS \[Germany]

DE-MEM-KVM-NVMe-2 $3.50 USD

 » Operating System: Debian 13 $0.00 USD

 » Management: None $0.00 USD

 » Additional IPv4 Addresses: 0 $0.00 USD

Setup Fees: $0.00 USD

Monthly: $3.50 USD

$3.50 USD Total Due Today

Continue

#### Added to Cart

×

Based on this product, we recommend:

[ Continue](#)

FREE!  Setup Fee

Add to Cart

A description (tagline) is not available for this product.

Powered by [WHMCompleteSolution](https://www.whmcs.com/)

- English / $ USD

- [Contact Us](https://my.zadeservers.net/contact.php)
- [Terms of Service](https://my.zadeservers.net/knowledgebase/9/Terms-and-Conditions.html)

Copyright © 2026 Zade Servers. All Rights Reserved.

![](https://my.zadeservers.net/assets/img/overlay-spinner.svg)  

#####

× Close

Loading...

Loading...

Close Submit

×

##### Choose language

[العربية](#)

[Azerbaijani](#)

[Català](#)

[中文](#)

[Hrvatski](#)

[Čeština](#)

[Dansk](#)

[Nederlands](#)

[English](#)

[Estonian](#)

[Persian](#)

[Français](#)

[Deutsch](#)

[עברית](#)

[Magyar](#)

[Italiano](#)

[Macedonian](#)

[Norwegian](#)

[Português](#)

[Português](#)

[Română](#)

[Русский](#)

[Español](#)

[Svenska](#)

[Türkçe](#)

[Українська](#)

Choose Currency

[$ USD](#)

[£ GBP](#)

[€ EUR](#)

[₹ INR](#)

[zł PLN](#)

Apply

#### Generate Password

×

Please enter a number between 8 and 64 for the password length

Password Length

Generated Password

Generate new password ![Copy to clipboard](https://my.zadeservers.net/assets/img/clippy.svg) Copy

Close Copy to clipboard and Insert

![]()
What is Token Harbor?

Token Harbor is a unified AI gateway that gives developers and teams access to frontier AI models through a single API and dashboard.

Rather than maintaining the largest possible model catalog, Token Harbor focuses on curated frontier models from leading AI providers, helping users access the latest and highest-performing models without managing multiple accounts, API keys, billing systems, or provider integrations.

Token Harbor provides:

- frontier AI model access
- TH-Rudder automatic model routing in Webchat
- free model access programs
- usage tracking
- unified billing
- provider failover
- API key management
- AI agent integrations

TH-Rudder, available in Webchat, reads each request and picks a suitable model for it — writing, reasoning, web tasks, image generation and more — so you don't have to choose or switch models yourself.

We also prioritize trusted infrastructure and reliable providers. Whenever possible, Token Harbor works with established AI and cloud platforms to deliver stable, secure, and high-availability access to frontier models.

Who is Token Harbor for?

Token Harbor is designed for:

- Developers building AI applications
- Startups using multiple AI models
- AI agents and automation workflows
- Teams managing AI usage across projects
- Non-technical users who want easier AI access

Why use Token Harbor instead of connecting directly to providers?

Managing multiple AI providers separately becomes complicated as your usage grows.

Token Harbor simplifies:

- access to frontier AI models through a single API
- unified billing and wallet management
- model discovery and comparison
- provider failover and reliability
- usage monitoring and analytics
- AI agent and workflow integrations

You can access models from multiple providers without managing separate accounts, API keys, payment methods, or integrations.

If you would rather not pick a model at all, TH-Rudder in Webchat picks a suitable one for each request automatically.

What makes Token Harbor different?

We focus heavily on:

Transparency — users should understand which model handled a request, which provider served it, how costs are calculated, and how billing is tracked. We believe AI infrastructure should be observable, predictable, and transparent.

Direct Model Access — when you select a model, your request is sent directly to that model. No hidden model switching, no surprise substitutions. What you choose is what you use.

TH-Rudder — for Webchat users who would rather not pick a model, it reads each request and routes it to a suitable model from a curated pool. Selecting a model directly is always still available.

Frontier Models — we focus on a curated set of frontier AI models rather than maintaining the largest possible catalog. Our goal is to provide access to the latest and highest-performing models from leading AI providers.

Trusted Infrastructure — Token Harbor prioritizes reliability and long-term stability. We work with established AI and cloud providers whenever possible and maintain provider redundancy for many popular models. If one provider experiences issues, requests can automatically fail over to another provider serving the same model.

Built for Agents and Developers — Token Harbor is designed to work seamlessly with Claude Code, OpenHands, AutoGen, CrewAI, LangChain, and custom AI agents, as well as traditional AI applications and developer workflows.

## Models & Providers

Which models are supported?

Token Harbor focuses on frontier AI models from leading providers. Our catalog is intentionally curated to include the latest and highest-performing models rather than every model available on the market.

Current model families include Claude, GPT, Gemini, DeepSeek and Qwen.

New frontier models are added regularly as they become available. The latest supported models, pricing, context limits, and capabilities are always available on the Models page.

Some models may also be offered for free as part of promotional programs. Free model availability and usage limits are shown on the Models page.

What happens if a provider goes down?

Token Harbor continuously monitors provider health and availability through internal health checks. If one provider becomes unavailable, Token Harbor can automatically route requests to another available provider serving the same model.

This helps improve:

- uptime
- reliability
- request success rates

In most cases, users continue using the same model without needing to take any action. With TH-Rudder, the choice of model and provider is handled automatically.

Do you offer any free models?

Yes. Token Harbor may provide free access to selected frontier models as part of promotional programs and community initiatives.

Models on permanent free routes carry an explicit:free model ID and are listed under Free on the Models page. That set changes as models are added or retired, so the Models page is the current list rather than this answer. Limited-time campaigns may add further:free routes with an end date; each one either carries its own allowance or draws on your free-tier allowance, and the dashboard card for that campaign says which.

Free model availability may change over time as new models are added and promotional programs evolve. Usage limits and eligibility requirements depend on account status and are described in the Billing & Usage section.

## TH-Rudder

What is TH-Rudder?

TH-Rudder is Token Harbor's intelligent model-routing system.

Instead of relying on a single model, TH-Rudder analyzes each request and routes it to a suitable model from a curated, dynamically managed pool. This allows it to use different models for writing, reasoning, web tasks, image generation, and other capabilities — without requiring you to choose or switch models yourself.

The model pool is continuously evaluated and updated based on quality, reliability, and performance.

Is TH-Rudder free?

Yes. TH-Rudder is currently available to everyone for free as part of a limited-time campaign in [Token Harbor Webchat](https://tokenharbor.ai/chat).

Requests made through the campaign route:

- Are never billed
- Do not use any Pass allowance
- Do not use your rolling 7-day free-model allowance
- Do not use your wallet balance
- Follow Token Harbor's paid-route policy: never used for training, and not stored apart from a short-lived cache and safety-check excerpts

Is TH-Rudder unlimited?

Text conversations with TH-Rudder are unlimited during the campaign. Standard speed and acceptable-use limits still apply.

Other Webchat features — including web searches, image generation, voice messages, file creation, uploads, and storage — have their own limits. See [Web chat limits](https://tokenharbor.ai/docs/web-chat/limits) for the current rules, or open Settings → Usage to check what you have left.

Does TH-Rudder use any of my allowances or wallet balance?

No. TH-Rudder campaign usage does not consume any Pass allowance, your rolling 7-day free-model allowance, or your wallet balance.

Your allowances and wallet balance remain available for other eligible models and routes.

Where can I use TH-Rudder?

The free TH-Rudder campaign is available exclusively in [Token Harbor Webchat](https://tokenharbor.ai/chat).

TH-Rudder is not offered on the Token Harbor API or other interfaces.

Which models does TH-Rudder use?

TH-Rudder uses a curated and evolving pool of models. The exact model depends on the request, and different models may be used for text, reasoning, web tasks, image generation, and other capabilities.

Because the pool is continuously evaluated and updated, Token Harbor does not publish a fixed model list.

Can I choose the underlying model?

Not within TH-Rudder. It selects an appropriate model automatically based on the request.

If you prefer a specific model, you can select it separately where available. Its usual pricing and allowance rules will apply.

Is every underlying model free outside TH-Rudder?

No. Free access applies specifically to the TH-Rudder campaign route in Webchat.

A model used by TH-Rudder may remain paid when selected directly or accessed outside the campaign.

How does TH-Rudder handle my data?

TH-Rudder follows Token Harbor's paid-route policy. Paid routes are never used for training and are not stored, apart from a cache of up to five minutes and short excerpts kept when an automated safety check flags a request.

Any limited account, security, and operational data required to provide and protect the service is handled in accordance with Token Harbor's applicable privacy policies.

## API & Developer Experience

Is Token Harbor compatible with the OpenAI SDK?

Yes. Token Harbor uses an OpenAI-compatible API format, making migration simple for most applications.

Example:

```
from openai import OpenAI

client = OpenAI(
    base_url="https://tokenharbor.ai/v1",
    api_key="YOUR_API_KEY"
)
```

Do you support streaming responses?

Yes. Streaming is supported using OpenAI-compatible APIs.

Can I use Token Harbor with AI agents?

Yes. Token Harbor is designed for AI agent workflows and multi-model orchestration.

Compatible tools may include:

- Claude Code
- OpenHands
- LangChain
- AutoGen
- CrewAI
- OpenDevin
- custom agent frameworks

Can I create multiple API keys with different rules?

Yes. Users can create multiple API keys for separate projects, environments, AI agents, team usage, and different spending policies.

Each key can have its own daily, weekly and monthly spend limits in USD, set on the API keys page of your dashboard. Each limit covers a rolling window — the last 24 hours, 7 days or 30 days — and once a key reaches one, calls with that key are refused until enough of that spend falls out of the window or you raise the limit. Other keys on the account keep working.

Not every call is checked against these limits yet — see [Per-key limits](https://tokenharbor.ai/docs/getting-started/universal-key#per-key-limits) for which ones are.

Are there request-rate or concurrency limits?

Paid accounts — an active Pass, or any account that has topped up its wallet — have no requests-per-minute or requests-per-hour limit on the API.

There is no limit on concurrent requests, on any plan.

Free accounts have these API limits:

- 60 requests/minute and 1,800 requests/hour per account, shared across all your API keys and all models
- 100 requests/minute and 3,000 requests/hour per IP address
- image generation: 10 requests/minute and 150 requests/hour
- no extra per-model limit on the free promotional models

Going over a limit returns HTTP 429 with a Retry-After header; wait that many seconds and retry. In agent tools, each tool-call round trip counts as one request.

The limits you set on an API key are spending caps in USD, not request-rate limits.

Web chat has its own limits, listed on the [web chat limits page](https://tokenharbor.ai/docs/web-chat/limits).

How large can a single request be?

It depends on whether the account has ever paid:

- Free accounts: up to 4 MB per request
- Accounts that have topped up their wallet or bought a Pass: up to 100 MB per request

Only long agent sessions get anywhere near this — a conversation carrying screenshots, pasted files or a lot of earlier tool output.

A free account that sends more than 4 MB gets HTTP 413 (request_too_large). To send it anyway, shorten the conversation, remove screenshots and large files, or top up and send it again. If a large request answers 503, wait a few seconds and send it again.

The full list of API limits is on the [rate limits page](https://tokenharbor.ai/docs/api/rate-limits).

Do you support embeddings and multimodal models?

Planned / partial support may include:

- embeddings
- image input
- vision models
- PDF processing
- audio models

Availability depends on the model; each model's page lists the input types it accepts.

## Billing & Usage

How is Token Harbor priced?

Token Harbor supports pay-per-token wallet billing and optional Passes.

You do not need a subscription. Every model listed on the /models page includes input pricing, output pricing, context limits, and provider information, priced in USD per 1M tokens — top up your wallet and usage is deducted automatically based on actual token consumption, with no monthly minimum and no commitment.

Passes are optional and bundle included usage for selected paid models. They suit regular use of the models a Pass covers; see the Subscriptions section below, or the Plans page for the current lineup and pricing.

Where can I view my usage and billing history?

The dashboard is divided into two main sections.

Usage — a complete view of your account activity, including model usage, usage trends, request history and logs, request costs, and status and cache information. This lets you monitor both overall usage and individual request activity in one place.

Billing — your wallet and payment activity, including current balance, top-up history, spending history, and promotional credits such as the first top-up match. You can also manage wallet top-ups and review your complete billing history.

How does wallet billing work?

Token Harbor uses a prepaid wallet system. When requests are processed:

1. 1.token usage is calculated
2. 2.pricing is determined based on the routed model/provider
3. 3.usage costs are deducted from your wallet balance

Balances update automatically after each request.

Can I set spending limits or usage controls?

Yes. Each API key can have its own daily, weekly and monthly spend limits in USD, set on the API keys page of your dashboard, and your account has a hard spending cap in Dashboard → Billing. A limit has to be more than $0 (leave it empty for no limit; to stop a key, revoke it), and the monthly cap starts at $1.

These controls are especially useful for teams, AI agents, automation systems, and shared environments.

Can wallet top-ups be refunded?

Yes — unused wallet balance is refundable. To request a refund, email billing@tokenharbor.ai within 30 days of the original top-up.

Refund policy:

- unused balance → refundable in full
- consumed balance → non-refundable once API usage has occurred
- promotional / reward credits → non-refundable and non-withdrawable

## Subscriptions

What is a Token Harbor Pass, and do I need one?

A Token Harbor Pass is an optional plan that includes usage for selected paid models. You buy it for a month or a year; it renews only if you turn on auto-renew at checkout.

You do not need a Pass to use Token Harbor. You can continue to use available free models, or top up your wallet and pay per token. A Pass is useful if you regularly use the models included in Agent, Office, or Frontier and want an included allowance that refreshes every four weeks.

Does a Pass renew automatically?

Only if you turn it on. The Auto-renew switch at checkout is off by default: a Pass bought that way is one payment for one month, or one year if you chose yearly. Nothing is charged again and there is nothing to cancel. It ends on the date shown in Dashboard → Billing, and we email you three days before.

With Auto-renew on, the Pass is a card subscription that renews every month or year at the renewal price shown at checkout, until you cancel it in the billing portal.

Dashboard → Billing always says which kind you have.

Which Pass should I choose?

Agent Pass suits agents and scripts that call the API regularly. Office Pass suits everyday writing, research, coding, and desktop-agent work. Frontier Pass suits heavy usage, frontier models, and professional workflows. The price and included allowance for each Pass are on the [Plans page](https://tokenharbor.ai/pricing).

Higher tiers include the models available in the tiers below them.

Which models are included with each Pass?

Agent Pass adds DeepSeek V4.1 Flash 1017 Fast, DeepSeek V4.1 Flash 1017, Minimax M3.1 Flash, GLM 5.3 Flash, GPT-6 Luna, Claude Haiku 5.5 and Qwen3.8 Flash.

Office Pass includes everything in Agent Pass and adds models such as Claude Sonnet 5.5, Qwen3.8 Max, Grok 4.7, GLM-5.3, DeepSeek V4 Pro, Gemini 3.8 Flash, Qwen3.8 27B, Mistral Large 4, GLM-5.3 Flashx Legal, Ling 3.1 Flash, Ling 3.1 Flash 1019 and MiMo V2.6 Pro.

Frontier Pass includes everything in Office Pass and adds models such as Claude Fable 5.1, GPT-6 Astra, Claude Opus 5.5, Muse Wonder 1.0, GPT-6.1 Sol, Gemini 4 Argon, Kimi K3.1 Pro, GPT-6.1 Terra Fast and GPT-6.1 Terra.

Named models are the headline inclusions rather than the complete list: each Pass also covers every model priced at or below its own band, so coverage grows on its own as cheaper models are added. A model is named here only when the Pass covers it on every route that serves it. Check the Plans page for the current list.

How does included usage work?

Pass allowance is usage value, not wallet credit. It is consumed automatically when you use models covered by your Pass, and is metered at each model's list price — so an allowance spent on an expensive model runs out sooner than the same allowance spent on a cheap one. The ceiling is in dollars, not in requests.

Each four-week allowance is divided into four 7-day windows, and each window contains one quarter of the four-week allowance. Pass allowance cannot be withdrawn or transferred to your wallet balance.

In Request Logs, a request covered by your Pass shows a cost of $0: nothing was taken from your wallet. It still used your allowance, at the model's price — including its cache-hit price for cached input.

What is Model Boost?

Selected models are boosted. A boosted model bills against your Pass allowance at a reduced rate rather than at its list price, so the same allowance covers more usage on it. It is a discount on the rate, not a second balance and not extra allowance — there is still one allowance, shared across every model your Pass reaches.

A higher Pass keeps every boost the Passes below it have and may add more, so moving up never makes a model you already used worse value.

Which models are boosted, and by how much, is marked on the [Plans page](https://tokenharbor.ai/pricing) beside each Pass. Boosts can change as the model catalogue changes.

How many requests does a Pass actually cover?

Based on a typical agent request of about 10K input (8K served from cache) and 1K output tokens. On Agent Pass, that is about: DeepSeek V4.1 Flash 4.9k+; Minimax M3.1 Flash 9.8k+; Qwen3.8 Flash 10k+; DeepSeek V4.1 Flash 1017 10.8k+ at its 2x promo rate; Claude Haiku 5.5 12k+; GPT-6 Luna 12k+; MiMo V2.6 Flash 17.1k+; GLM 5.3 Flash 19.2k+ with its 2× Model Boost — each a month, and each a floor rather than a cap.

Office Pass covers roughly 3× those figures, and Frontier Pass covers roughly 18× those figures, across a wider set of models. The [Plans page](https://tokenharbor.ai/pricing) shows which models each Pass reaches.

Your own mileage moves with prompt length: short prompts go further, long documents and long conversations go less far. An agent that makes several tool round-trips counts each round-trip as a request, so an agent loop consumes an allowance faster than the same amount of typing would.

Does unused Pass allowance roll over?

No. Unused allowance in a 7-day window does not carry into the next window.

Your next allowance becomes available when the next 7-day window begins. You can view the current period and usage progress in your dashboard.

What is the difference between Pass allowance and wallet balance?

Pass allowance covers eligible usage included with your Pass. Wallet balance is credit funded through top-ups or promotions and is used for pay-as-you-go model calls.

Eligible calls consume the available Pass allowance. If that allowance runs out and pay-as-you-go continuation is enabled, further usage is deducted from your wallet balance at the rate applicable to your Pass.

Pass payments do not add funds to your wallet, and Pass allowance cannot be withdrawn as cash or wallet credit.

Does subscribing reset or replace my free allowance?

No. Free allowance and Pass allowance are separate.

Buying a Pass does not reset, increase, or restore the current free allowance. If you have already used the current free allowance, it will become available again at the start of your next free-access period. You can use eligible paid routes covered by your Pass in the meantime.

Your free-model access remains available alongside the Pass and continues to use the free-model rules and settings selected in your dashboard.

What happens when my Pass allowance runs out?

Go to Dashboard → Billing and use the setting Keep working after my pass allowance runs out to control what happens next.

When this setting is enabled, eligible calls continue and additional usage is deducted from your Token Harbor wallet balance at the pay-as-you-go rate applicable to your Pass. Your available balance and hard spending cap still apply.

When the setting is disabled, the Pass acts as a hard limit. Covered calls stop when the allowance runs out and can resume when the next allowance window begins.

How do monthly and yearly subscriptions work?

Monthly subscriptions are charged each month. Yearly subscriptions are charged once per year and offer a lower effective monthly price.

The yearly price shown on the Plans page includes both the annual total and its monthly equivalent. Choosing yearly billing changes the payment schedule, but included usage continues to refresh on the same four-week schedule.

What happens when I upgrade my Pass?

An upgrade takes effect immediately. The new Pass's models become available straight away, and your usage window restarts: a fresh full allowance at the new tier, rather than whatever was left of the old one.

If you are switching from a Pass you are still paying for, the unused value of the current one is credited against the upgrade. The amount is shown before you confirm.

What happens when I downgrade my Pass?

Moving to a smaller Pass is not done from the Plans page: buying it would end the bigger Pass early, days and all.

Let the current Pass run to the end of the period you have already paid for. If it renews by card, cancel it first in the billing portal so no further charge is taken. Once it ends you can buy the smaller Pass.

Your wallet balance, free allowance and API keys are unaffected either way.

How do I manage or cancel my subscription?

Open Dashboard → Billing. It shows which kind of Pass you have.

If it says the Pass doesn't renew, you bought it once: nothing will be charged again, so there is nothing to cancel. It ends on the date shown there, and your account moves to the free tier.

If your Pass renews automatically by card, select Open billing portal. There you can cancel, change the card, and download invoices. A cancelled Pass stays active until the end of the period you have already paid for.

## Rewards & Promotions

What rewards and promotions are available?

Token Harbor offers free model access on selected models, a first top-up match for new accounts, spend milestones, and limited-time promotional programs. There is currently no sign-up credit and no cash referral reward. Available rewards and promotions may change over time.

What free model access do I get?

Token Harbor provides free access to selected models through explicit:free model IDs. Your first free request starts a personal rolling 7-day period. The allowance is value-based rather than a fixed request count, because different models and requests have different costs. Your dashboard shows usage as a percentage.

- No separate per-minute cap on free models — only the free-account API limit of 60 requests/minute and 1,800/hour applies
- The progress bar reaches 100% at the advertised allowance
- Free routes stop accepting new requests when the period allowance is exhausted
- Each period lasts 7×24 hours from that user's own start time

The models currently on free routes are listed under Free on the [Models page](https://tokenharbor.ai/models?category=free).

Free routes never charge your balance. Their paid base-model counterparts remain available under the normal paid-route policy. Available models and limits may change over time.

Do new accounts get free credit?

There is no sign-up or welcome credit. Creating an account is free and no credit card is required, but the account starts with a $0 balance.

You can still start without paying: the free tier gives you access to selected models through their:free model IDs, described in the question above. When you are ready for the paid catalog, top up your wallet — the first top-up is matched (see below).

How does the First Top-Up Match work?

New users can receive a 100% bonus on their first wallet top-up. For example: top up $10 → receive $10 bonus; top up $50 → receive $50 bonus; top up $100 → receive $100 bonus.

The offer is available for 14 days after account registration. Maximum bonus is $100 per account.

The bonus is credited locked and unlocks $1 for every $1 you spend from your paid balance.

How do invites and referrals work?

Every account has a permanent invite code and invite link on the dashboard's Invites page. Share it and your friends can sign up through it — your dashboard shows how many people have joined on your invite.

There is no cash referral reward at the moment. Inviting a friend does not add credit to your balance. Referrals that were already pending before the reward ended still settle at the amount they were created under, and any creator or partner links that carry their own reward continue to pay under their own terms.

Invites remain subject to activity verification and anti-fraud checks. Sign-ups that share an address or device with the inviter, and batches of accounts created on disposable mailboxes, are not counted.

How does the $500 lifetime incentive cap work?

All promotional and incentive credits combined are capped at $500 lifetime per account. This includes top-up match bonuses, spend milestone credits, and future promotional incentives.

Once the lifetime cap is reached, wallet balances can only increase through direct top-ups.

Do rewards or promotional credits expire?

Some rewards, promotional credits, and limited-time offers may include expiration periods depending on the campaign. Examples may include top-up match bonuses and seasonal promotions.

Specific expiration details are shown in the dashboard or promotion details when applicable.

## Security & Privacy

Does Token Harbor store prompts or responses?

For paid models, Token Harbor does not use your prompts or responses for training and does not persistently store them, apart from three exceptions: a short-lived cache, short excerpts kept when an automated safety check flags a request, and web chat history in your account. We believe users should have access to frontier AI models without sacrificing privacy.

Paid models — no training on customer data. Answers to identical requests may be served from a shared cache for up to five minutes and are deleted within 24 hours. If an automated safety check flags a request, a short excerpt is kept for 30 days. A deleted web chat is permanently erased within 30 days.

Permanent free routes — Token Harbor may retain prompts and responses sent through explicit free routes after you opt in. Free routes are disabled by default; your consent covers the free models offered when you agree and any permanent free model we add later, which we announce on the Models page. Our staff may read these conversations and may use third-party AI tools to help analyze them. Token Harbor does not train models on them itself, but the providers that serve free routes may use them under their own terms, including to train their own models. Turning free models off stops future collection under the program and disables free routes, while data already collected during consent may be retained. A limited-time campaign can instead expressly follow the paid-route policy. The models currently on free routes are listed on the Models page; see Privacy for the full policy.

Are provider API keys exposed to users?

No. Provider keys are stored securely on the backend and are never exposed publicly.

How does Token Harbor improve transparency?

We believe transparency is critical for AI infrastructure. Token Harbor provides visibility into request logs, model usage, token consumption, request costs, and usage analytics.

Our goal is to help users understand what they are using, how much it costs, and how requests are processed.

How does Token Harbor ensure reliability?

Token Harbor works with trusted model and infrastructure providers and continuously monitors service health. For many models, more than one provider can serve the same model. If one provider experiences issues, requests can automatically fail over to another provider serving the same model.

This helps improve uptime, reliability, and request success rates while maintaining a consistent model experience for users.

## Support

How do I get support?

We currently provide support through our Discord community (discord.gg/uBTckEReb5), email support (support@tokenharbor.ai), and documentation.

For technical issues, billing questions, API integration help, feature requests, or general feedback, users are encouraged to join our Discord community or contact the Token Harbor team directly.

Where can I report bugs or request features?

We welcome feedback from users and developers. Report a bug from the Support page (Submit a ticket, with screenshots if you have them) or email support@tokenharbor.ai. Feature requests and product feedback are welcome there too, or in our Discord community (discord.gg/uBTckEReb5).

Our Discord community is typically the fastest way to reach the team and discuss new ideas with other users.

## Supported regions

Where is Token Harbor available?

Token Harbor is available outside these restricted regions: Afghanistan, Belarus, Mainland China, Cuba, Hong Kong, Iran, North Korea, Myanmar (Burma), Macau, Russia, Syria, Venezuela, and Crimea, Donetsk and Luhansk.

A paid plan does not bypass regional restrictions. We see the country your connection exits from. If you use a VPN or proxy, turn it off and try again.

Unsure before paying? [Contact support](mailto:support@tokenharbor.ai).

Still have questions?

Join the Discord or email us — we usually reply fast.

Last updated · October 29, 2026

## What changed on October 29, 2026

- Answers about stored prompts and responses now list what is kept on paid routes (a short-lived cache and safety-check excerpts) and what free routes allow (staff reading, and the providers that serve free models).
- The model list names model families, not providers.

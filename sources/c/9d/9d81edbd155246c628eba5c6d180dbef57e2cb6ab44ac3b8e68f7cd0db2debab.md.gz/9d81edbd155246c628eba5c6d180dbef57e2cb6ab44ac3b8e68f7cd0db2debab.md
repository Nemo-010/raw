# NFT.Storage Classic has changed

NFT.Storage Classic is the home of free decentralized storage and bandwidth for NFTs on IPFS and Filecoin.  
  
**As of 30 June 2024, the the free Classic upload and pinning products are decommissioned.   
  
All data you've uploaded will continue to be safely stored and accessible via IPFS and the Filecoin Network. Over time, latency and availability may degrade.**

Trusted by over 165,000 users and these top companies

### **New partnerships with Pinata and Lighthouse**

We are excited to announce our new partnerships with Pinata and Lighthouse for hot storage solutions. As an NFT.Storage user, you support our platform when you choose Pinata and Lighthouse and use our referral links, helping to sustain our valuable public goods.

#### How using Pinata and Lighthouse support NFT.Storage

For new customers who sign up with the NFT.Storage referral links, Pinata and Lighthouse give NFT.Storage referral fees. These funds help support our mission.   
  
[Learn more >>](https://nft.storage/blog/announcing-our-new-partnerships-with-pinata-and-lighthouse)

#### We’re thrilled to partner with Pinata

Pinata offers flexible plans and powerful, easy to use tools for managing your data on IPFS.   
  
Use code NFTSTORAGE50 at checkout to enjoy 50% off your first month.  
  
[Sign up today >>](https://www.pinata.cloud/nft-storage-pinata)

#### We’re excited to partner withLighthouse

Lighthouse is an IPFS provider with unique payment options for NFT longevity. They offer affordability and flexibility for all your IPFS needs, including a pay once and store forever option.   
  
[Sign up today >>](https://files.lighthouse.storage/?referby=NFTStorage)

### **Keeping Your Data Safe**

Your NFT data's safety is our top priority. Here's a guide on how to keep your data secure.

[Get started](https://storacha.network/)

- #### Multiple storage solutions

  Diversify your storage solutions as a best practice. Use the tools Pinata or Lighthouse provide to easily copy your Classic data.   
  [Learn more >>](https://nft.storage/blog/why-copy-your-nft-storage-classic-data-and-how-to-do-it)
- #### **Long-term backups**

  Ensure you have backups of your data by uploading to our endowment-backed Filecoin storage by using the new version of NFT.Storage. Sign up today >>
- #### **Stay Informed**

  Keep up with the latest updates from NFT.Storage. [Follow us on twitter >>](https://x.com/NFTdotStorage)
- #### Want to have your say?

  Join the NFT.Storage community to have your say in the future of NFT.Storage Classic.

  [Join today!](https://nft.storage/community)

Developers

[Classic Docs](https://classic-app.nft.storage/docs/)[Status](https://status.nft.storage/)

Resources

[Blog](https://nft.storage/blog)[FAQ](https://nft.storage/faq)[Litepaper](https://nft.storage/faq)

Company

[Terms of Service](https://classic.nft.storage/terms)[Privacy Policy](https://classic.nft.storage/privacy-policy)[Contact us](https://classic.nft.storage/contact-us)

© 2024 NFT.Storage Ltd. All rights reserved.

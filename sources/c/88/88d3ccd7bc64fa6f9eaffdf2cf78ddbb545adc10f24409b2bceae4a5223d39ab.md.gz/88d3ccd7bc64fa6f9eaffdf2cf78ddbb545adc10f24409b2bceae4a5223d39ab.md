# Plans & Pricing

Fast, reliable, and secure software starts here.

## Free Plan

* * *

### Free

![bandwidth icon](https://blog.packagecloud.io/assets/images/pricing/pc-pricing-bandwidth.svg)

10 GB bandwidth

![storage icon](https://blog.packagecloud.io/assets/images/pricing/pc-pricing-storage.svg)

2 GB storage

Unlimited CI/CD Minutes

[Start Free Trial](https://packagecloud.io/users/new)

## Starter Plan

* * *

### 89  PER MONTH

![bandwidth icon](https://blog.packagecloud.io/assets/images/pricing/pc-pricing-bandwidth.svg)

20 GB bandwidth

![storage icon](https://blog.packagecloud.io/assets/images/pricing/pc-pricing-storage.svg)

5 GB storage

Unlimited CI/CD Minutes

[Start Free Trial](https://packagecloud.io/users/new)

## Pro Plan

* * *

### 150  PER MONTH

![bandwidth icon](https://blog.packagecloud.io/assets/images/pricing/pc-pricing-bandwidth.svg)

50 GB bandwidth

![storage icon](https://blog.packagecloud.io/assets/images/pricing/pc-pricing-storage.svg)

15 GB storage

Unlimited CI/CD Minutes

[Start Free Trial](https://packagecloud.io/users/new)

## Enterprise Plan

* * *

### 699  PER MONTH

![bandwidth icon](https://blog.packagecloud.io/assets/images/pricing/pc-pricing-bandwidth.svg)

250 GB bandwidth

![storage icon](https://blog.packagecloud.io/assets/images/pricing/pc-pricing-storage.svg)

150 GB storage

Unlimited CI/CD Minutes

[Start Free Trial](https://packagecloud.io/users/new)

## Enterprise+ Plan

* * *

### Custom Offer

![bandwidth icon](https://blog.packagecloud.io/assets/images/pricing/pc-pricing-bandwidth.svg)

CUSTOM bandwidth

![storage icon](https://blog.packagecloud.io/assets/images/pricing/pc-pricing-storage.svg)

CUSTOM storage

Unlimited CI/CD Minutes

[Contact Us](mailto:enterprise@packagecloud.io?subject=Enterprise+%20Plan&body=Dear%20Packagecloud%20team,%0D%0A%0D%0ACan%20we%20please%20organize%20a%20call%20to%20discuss%20our%20enterprise%20needs?)

Full Plan Comparison

### Free

[Start Free Trial](https://packagecloud.io/users/new)

### Starter

[Start Free Trial](https://packagecloud.io/users/new)

### Pro

[Start Free Trial](https://packagecloud.io/users/new)

### Enterprise

[Start Free Trial](https://packagecloud.io/users/new)

### Enterprise+

[Contact Us](mailto:enterprise@packagecloud.io?subject=Enterprise+%20Plan&body=Dear%20Packagecloud%20team,%0D%0A%0D%0ACan%20we%20please%20organize%20a%20call%20to%20discuss%20our%20enterprise%20needs?)

Full Plan Comparison

Free

Starter

Pro

Enterprise

Enterprise+

Unlimited number of users

Unlimited repositories

Universal asset management

CI/CD pipeline orchestration

Public repositories

Private repositories

API access

Custom domains

Arbitrary files

EULA

Package sizes > 2.6 GB

24/7 support

SSO/SAML

SLA

SLSA audit

Slack channel & high-touch support

Dependency Mirroring/Proxy Support

Open source contributor lineage

Scanning

License checks

Multi-region

Federated repositories

Federated access

Threat scanning

[Start Free Trial](https://packagecloud.io/users/new)

[Start Free Trial](https://packagecloud.io/users/new)

[Start Free Trial](https://packagecloud.io/users/new)

[Start Free Trial](https://packagecloud.io/users/new)

[Contact Us](mailto:enterprise@packagecloud.io?subject=Enterprise+%20Plan&body=Dear%20Packagecloud%20team,%0D%0A%0D%0ACan%20we%20please%20organize%20a%20call%20to%20discuss%20our%20enterprise%20needs?)

![GitLab icon](https://blog.packagecloud.io/assets/images/clients/pc-logo-gitlab.svg)![Heroku icon](https://blog.packagecloud.io/assets/images/clients/pc-logo-heroku.svg)![GitHub icon](https://blog.packagecloud.io/assets/images/clients/pc-logo-github.svg)![Helium icon](https://blog.packagecloud.io/assets/images/clients/pc-logo-helium.svg)![DigitalOcean icon](https://blog.packagecloud.io/assets/images/clients/pc-logo-digital-ocean.svg)![Slack icon](https://blog.packagecloud.io/assets/images/clients/pc-logo-slack.svg)![500px icon](https://blog.packagecloud.io/assets/images/clients/pc-logo-500px.svg)![CircleCI icon](https://blog.packagecloud.io/assets/images/clients/pc-logo-circleci.svg)![Nvidia icon](https://blog.packagecloud.io/assets/images/clients/pc-logo-nvidia.svg)![CrowdSec icon](https://blog.packagecloud.io/assets/images/clients/pc-logo-crowdsec.svg)![StackStorm icon](https://blog.packagecloud.io/assets/images/clients/pc-logo-stackstorm.svg)

## Frequently Asked Questions

When and how am I billed?


You are billed the price for your plan at the start of the month. At the end of the month, your bandwidth and storage watermark calculated. Any overage amounts will be added to the bill that you receive at the start of the next month.


How can I view my current or previous usage information?


Your current bandwidth usage and storage watermark is available in the [usage](https://packagecloud.io/usage) section of account settings. You'll also find previous months' usage underneath, sorted by date.


Will I get notified when I'm nearing my limits?


Yes. We'll notify you when you've reached 50%, 90% and 99% of either your bandwidth, storage or maximum overage amount. You can turn these off in [usage](https://packagecloud.io/usage) under account settings.


How exactly is bandwidth usage calculated?


Uploads to Packagecloud are free.

Bandwidth usage for downloads is updated every 5 minutes. We examine our request logs and attribute any bytes sent from Packagecloud to the corresponding repository owner for the requested object. [Conditional GET's](https://en.wikipedia.org/wiki/Hypertext_Transfer_Protocol#Request_methods), [HEAD requests](https://en.wikipedia.org/wiki/Hypertext_Transfer_Protocol#Request_methods) or cancelled requests aren't counted. You are only charged for any outgoing bytes.


What is a 'storage watermark' and how is it calculated?


Every time a package is pushed to, or yanked from Packagecloud, we credit or debit a storage usages table for that user and repository, with the time that action took place. Then, we sum up all the bytes that were pushed and come up with a high watermark for any given [billing period](https://packagecloud.io/pricing/#faq11). Thus, if you upload 100GB of packages, and delete 90GB of them, you'll still have used 100GB for that billing period, and 10G for the next.


How can I control my usage/overage cost?


In the [usage](https://packagecloud.io/usage) section of account settings, you can put the maximum overage amount you'd like to pay before the [account gets disabled](https://packagecloud.io/pricing/#faq6).

Note: Due to how [bandwidth is calculated](https://packagecloud.io/pricing/#faq3), there is a small window of about an hour between exceeding your maximum overage and us disabling the account. For high traffic repositories, you might need to budget accordingly. For example: if you send 10GB of bandwidth an hour, on a plan with 30cents/GB for overage and have set $1 as your maximum overage, you might end up paying $3. (30 cents/GB \* 10GB).


My account just got disabled! How do I re-enable it?


Accounts are automatically re-enabled when: you have entered a new [billing period](https://packagecloud.io/pricing/#faq11), you have [upgraded your plan](https://packagecloud.io/pricing/#faq12), or you have increased the maximum overage allowed for your account.


Can I use packagecloud for free?


Yes, we offer a limited [Free Plan](https://packagecloud.io/users/new?plan=free_usage_plan) and also offer 14 day trials of any of our paid plans.


Do your prices include taxes?


No, any applicable local taxes are added to your invoice as a separate line item. Currently, only billing addresses in the state of Texas or New York are taxed.


We can't pay by credit card. Can you invoice my company?


Sorry, paying by invoice is not supported at this time.


I think my usage will be way above your largest plan, can we get on custom plan?


Absolutely. Please contact [support@packagecloud.io](mailto:support@packagecloud.io) and we'll get you going.


What are the paid plan overage prices?


The following are the overage prices for the paid plans on packagecloud.io.


| $89/month | $150/month | $699/month |
| --- | --- | --- |
| $2 per GB of Storage | 80¢ per GB of Storage | 80¢ per GB of Storage |
| $1.50 per GB of Bandwidth | 60¢ per GB of Bandwidth | 60¢ per GB of Bandwidth |

How do plan upgrades work with different overage prices?


Overage rates for usage are calculated at the end of your billing cycle. This means that it's possible to get cheaper overages (or no overages at all) by upgrading to a larger plan before your billing cycle ends.


More questions? [Contact us](https://packagecloud.io/contact/).
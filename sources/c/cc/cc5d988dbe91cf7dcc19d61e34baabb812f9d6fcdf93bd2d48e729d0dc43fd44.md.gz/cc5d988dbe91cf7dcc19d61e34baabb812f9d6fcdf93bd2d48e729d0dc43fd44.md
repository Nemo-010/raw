[Skip to main content](#main)

Create a free account and start using Forgejo.

 [Try Forgejo free](/register) [Read the docs](https://docs.fjord.sh/guide/getting-started)

Already have an account? [Sign in](/login?next=%2Fcommons) and join Commons from here.

## What a free account gets

 Repositories Up to 25 repositories, public or private Storage 5 GB per account; Git LFS is not enabled CI Actions on public repositories, drawing on a shared pool of 2,000 minutes a month for all of Commons; 20 minutes per job Collaboration Issues, pull requests, reviews, wikis, releases, orgs Access Git over HTTPS and SSH, the public API, webhooks, the Fjord app Infrastructure One shared box on Hetzner in our EU Central region, in Nuremberg, Germany, behind Cloudflare Backups The box is backed up nightly, off-site and encrypted, on a 90-day retention window; this is disaster recovery, not per-account restore Support Community support; Commons is shared infrastructure

Private repositories work on Commons. What does not is CI on them: Actions run on public repositories only, because the runners behind Commons are shared with everyone else using it. The CI minutes are a pool for all of Commons rather than an allowance each, so a heavy month for one project is a slower queue for the rest.

Commons is shared infrastructure, and we say so plainly: your repositories sit alongside everyone else's, on hardware nobody has to themselves. Anything you would not put on a machine you share belongs on your own instance.

## The questions people actually ask

Free hosting usually comes with something unsaid. Here is everything we would want to know before putting a repository somewhere.

### Is this a free trial?

No. There is no clock, no expiry date, and no point where Commons stops working unless you pay. It is free because it is shared, and it stays free. If you later buy a Fjord instance and then cancel it, your Commons account is still there.

### Do I need a credit card?

No. Creating a Fjord account and joining Commons never asks for a payment method, and there is no card on file to forget about. Payment details only exist once you provision a dedicated instance.

### How many CI minutes do I get?

2,000 minutes a month, and that figure is for the whole of Commons rather than for each account. We would rather say that plainly than print a per-account number we do not meter. Jobs on Commons queue one at a time, 20 minutes maximum per job, and no scheduled workflows: those three keep one project from taking the pool while everyone else waits.

### What happens when the 2,000 minutes run out?

CI stops admitting new jobs until the pool resets at the start of the next month. Nothing else changes: your repositories stay up, git keeps working, issues and pull requests keep working, and no bill appears. There is no way to buy extra minutes on Commons today, so if your CI has to run every month regardless, that is the point at which a dedicated instance with a CI allowance of its own is the honest answer.

### Which repositories can be private?

Any of them. Commons has no rule about what you may publish and no requirement that your code carry an open-source licence. Private repositories count against the same limit of 25 and CI does not run on them. Bear in mind that private on a shared forge means private from other users, not private from the people who operate the box.

### Where does it run?

On one shared server hosted by Hetzner in Nuremberg, Germany, in our EU Central region, fronted by Cloudflare. That is the same provider and the same region we run dedicated instances in; the difference is that a dedicated instance is a box of your own, and you choose its region.

### Is Commons backed up?

The box is, nightly, to encrypted off-site storage with a 90-day retention window, on the same schedule as our top dedicated tier. Be clear about what that is for: it is how we recover Commons if the server is lost, not a service that restores one person's repository. Nobody should treat a free shared forge as their only copy, and with git nobody has to.

### Can I get my data out?

Always, and without asking us. Every repository is an ordinary git repository you can clone; Forgejo's own export covers issues, pull requests, wikis and releases; the API and the [fj CLI](https://docs.fjord.sh/cli) work against Commons like any other Forgejo. Moving in works the same way, through Forgejo's migration tool. There is no proprietary format anywhere in this, which is the whole reason we build on Forgejo.

### What counts as abuse?

The predictable list: unlawful or infringing content, malware, mining cryptocurrency or scraping third parties on the runners, and anything aimed at degrading the box for everyone else. We can suspend or remove a Commons account for it, with notice where that is practicable and immediately where it is not. Ordinary heavy use is not abuse; it is a signal you have outgrown a shared forge, and we would rather sell you an instance than throttle you. That is how we run the place, and this page is where we say so.

### Do you train AI models on my code?

No, and that is a commitment we operate by rather than a default we might quietly revisit. We do not use anything you store on Fjord, Commons included, to train or improve any machine-learning model, and we do not sell or hand it to anyone who does. We do not read the contents of your repositories or CI jobs except where running, securing or supporting the service requires it. Public repositories on Commons are public to the internet, so third-party crawlers can reach them exactly as they can reach any public git host; that is a property of publishing, not something we do with your code.

### How is this different from a paid Fjord?

Commons is one server shared by everybody on it. A Fjord instance is a server that is yours: single-tenant, private by default, on your own domain, with CI on private repositories against an allowance of your own, storage sized to the tier, SSO, admin rights over the forge, and a support response target instead of community goodwill. Same Forgejo either way. What you are buying is the isolation and the operations.

### How is this different from Codeberg?

Codeberg is a registered non-profit association in Berlin, funded by donations and membership fees, and its terms require public repository content to carry a licence granting everyone the right to use and redistribute it. Free software is the point of the place. Commons is run by a company, funded by the people who buy dedicated instances, and asks nothing about your licence: put a closed-source side project on it if you want. It also has somewhere to go when you outgrow it, which a non-profit deliberately does not. If what you want is a community-governed home for a free-software project, Codeberg is a good answer and we would not pretend otherwise.

## When to move to your own Fjord

Nothing here expires, so there is no deadline to move by. A Fjord instance is what you buy when you need CI on private repositories, or when a shared box stops being enough.

- Ownership and isolation. A dedicated, single-tenant instance, private by default, on hardware serving nobody else.
 - Capacity. CI on private repositories with a monthly allowance of your own, and storage sized to the tier. A dedicated runner is an add-on at $29/mo.
 - Operations and support. Backups, updates and restores handled, with a named response target rather than community goodwill.
 - Identity and control. Your own domain, SSO, and the administration of a forge that answers to you.

 [See instance pricing](/pricing)

From $49/mo, per instance, not per seat.

Leaving works in both directions. Cancel a Fjord instance and your Commons account stays; you land back where you started rather than locked out.

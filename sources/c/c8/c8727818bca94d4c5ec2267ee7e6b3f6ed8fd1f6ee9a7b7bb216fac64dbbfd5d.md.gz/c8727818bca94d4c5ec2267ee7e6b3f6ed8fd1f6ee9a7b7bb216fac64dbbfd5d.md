# Plans and pricing

Back up your files to Ulož.to Disk and access them from any location and device.

Monthly

**FREE**

Storage size

**1 GB**

Price for month

** 0 USD **

[Get for free](https://uloz.to/registrace)

A non-binding start into the world of cloud services.

- 150 GB for data transfer/month

**FREE25**

Storage size

**25 GB**

Price for month

** 0 USD **

[Get for free](https://uloz.to/registrace)

More space for your memories, files, and your first projects.

- 150 GB for data transfer/month

**PREMIUM**

Storage size

**3 TB**

Price for month

** 6,50 USD **

[Order](https://uloz.to/koupit-disk/1m-30tb-usd-premium)

Space for all your data with access from anywhere.

- 30 TB for data transfer/month

**MAX**

Storage size

**12 TB**

Price for month

** 16 USD **

[Order](https://uloz.to/koupit-disk/1m-150tb-usd-max)

For those who need unlimited freedom for work and leisure.

- 150 TB for data transfer/month

**ULTRA**

Storage size

**25 TB**

Price for month

** 32 USD **

[Order](https://uloz.to/koupit-disk/1m-300tb-usd-ultra)

Exclusively for the demanding. Your projects - your rules.

- 300 TB for data transfer/month

**ULTIMATE**

Storage size

**50 TB**

Price for month

** 64 USD **

[Order](https://uloz.to/koupit-disk/1m-600tb-usd-ultimate)

For those who want to have the cloud in their hands.

- 600 TB for data transfer/month

[Learn more about Ulož.to Disk](https://uloz.to/disk)

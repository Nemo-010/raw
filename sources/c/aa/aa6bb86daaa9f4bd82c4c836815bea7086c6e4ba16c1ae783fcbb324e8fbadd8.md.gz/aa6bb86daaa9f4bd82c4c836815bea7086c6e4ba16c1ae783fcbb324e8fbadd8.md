# Networking

## IPv4 Configuration

We support both dynamic (DHCP) and static IPv4 configuration. It will automatically be set to DHCP if you install your server with one of our templates. However, you may change this to static configuration if you prefer to not rely on the DHCP server. The necessary details (gateway, netmask) are available in the control panel under the network management section.

## IPv6 Configuration

We do not support automatic (SLAAC) or dynamic (DHCPv6) IPv6 assignment, it needs to be configured statically. If you choose to enable IPv6 when you first create your server, it will automatically be configured via cloud-init. However, manual configuration is needed if you choose to enable it after your server has been created, or if you install your OS via ISO.

You will be assigned a public /64 IP block. You may configure any IP address in this block on your primary network interface `eth0`. Please see the configuration examples below. In the examples we use the `::1` IP address in the example block `2a0e:dc0:d0d0:c0de::/64`. Make sure to change this accordingly.

Tip

The entire /64 subnet is **routed** towards your VM, so it's not necessary to configure additional addresses on the interface in order to receive traffic to them.

UbuntuDebianRHEL / AlmaLinux / Rocky

**Applies to:** 20.04, 22.04, 24.04 and 26.04 — all configured through netplan.

1. Identify the interface name: `ip -o link | grep 00:20`
2. Create a new netplan file for the IPv6 config. Replace `2a0e:dc0:d0d0:c0de::1/64` with your unique IPv6 and change `eth0` to your interface's name, if different.

  /etc/netplan/90-ipv6.yaml

  ```
  network:
      version: 2
      ethernets:
          eth0:
              addresses:
                  - 2a0e:dc0:d0d0:c0de::1/64
              routes:
                  - to: default
                    via: fe80::1
  ```
3. Tighten the file permissions — from 24.04 on, netplan warns about world-readable configuration: `sudo chmod 600 /etc/netplan/90-ipv6.yaml`
4. Enable the new config: `sudo netplan apply`
5. Confirm it's configured: `ip -6 a`

Version notes

On 20.04, if `netplan apply` rejects the `routes:` block, replace it with `gateway6: fe80::1` — netplan releases older than 0.103 do not understand `to: default`. Releases before 18.04 predate netplan altogether; use the Debian instructions instead.

**Applies to:** 11, 12 and 13 — all configured through `ifupdown`.

1. Identify the interface name: `ip -o link | grep 00:20`
2. Create a new interfaces.d file for the IPv6 config. Replace `2a0e:dc0:d0d0:c0de::1/64` with your unique IPv6 and change `eth0` to your interface's name, if different.

  /etc/network/interfaces.d/90-ipv6

  ```
  iface eth0 inet6 static
      address 2a0e:dc0:d0d0:c0de::1/64
      gateway fe80::1
  ```
3. Enable the new config: `sudo systemctl restart networking`
4. Confirm it's configured: `ip -6 a`

Version notes

Our Debian images are the official generic cloud images, which use `ifupdown` on every release — the existing IPv4 setup lives in `/etc/network/interfaces.d/50-cloud-init`. Leave that file alone and add yours alongside it. If your image has an `/etc/netplan/` directory instead, follow the Ubuntu tab.

**Applies to:** EL8, EL9 and EL10.

NetworkManager is the default on all three, and `nmcli` writes the right format for each — `ifcfg` files on EL8, keyfiles on EL9 and EL10. If you manage your interfaces with `network-scripts`, see *Using ifcfg files instead* below.

1. Identify the interface and the NetworkManager connection attached to it — on cloud images the connection is often named something other than the device:

  ```
  ip -o link | grep 00:20
  nmcli -g NAME,DEVICE connection show
  ```
2. Add the IPv6 configuration to that connection. Replace `System eth0` with your connection name and `2a0e:dc0:d0d0:c0de::1/64` with your unique IPv6 block.

  ```
  sudo nmcli connection modify "System eth0" \
      ipv6.method manual \
      ipv6.addresses 2a0e:dc0:d0d0:c0de::1/64 \
      ipv6.gateway fe80::1
  ```
3. Enable the new configuration: `sudo nmcli connection up "System eth0"`
4. Confirm it's configured: `ip -6 a`

Using ifcfg files instead

Append the IPv6 settings to your existing interface file, keeping the current contents. The file name depends on your interface name.

/etc/sysconfig/network-scripts/ifcfg-eth0

```
IPV6INIT=yes
IPV6ADDR=2a0e:dc0:d0d0:c0de::1/64
IPV6_DEFAULTGW=fe80::1%eth0
```

How you apply it depends on the release:

- **EL8** — `sudo systemctl restart network`. This needs the `network-scripts` package, which is not installed by default.
- **EL9** — the `network` service no longer exists, but NetworkManager still reads `ifcfg` files. Apply with `sudo nmcli connection reload`, then `sudo nmcli connection up "System eth0"`.
- **EL10** — `ifcfg` support has been dropped. Use the `nmcli` steps above.

## Private Networking

Info

If you enable private networking on your server after it has been setup, you must reboot it by clicking the reboot button in the control panel in order to attach the interface. You must have at least two active VMs in the same location in order to enable private networking

If you enable Private Networking on your VM you will get an additional network interface that you can use for traffic between your own VMs in the same region. You cannot access any external networks through this interface. It is isolated with its own unique VLAN/VXLAN and you can assign any IPv4/IPv6 address to it. We do not offer any automated address assignment or DHCP on these networks. If you configure all your servers to the same subnet/broadcast domain you don't have to set any manual routes or gateway, e.g `192.168.10.1/24`, `192.168.10.2/24` etc. See below for configuration examples.

If you add it upon creation of your VM, or if you reinstall your VM once it is enabled, the interface will automatically be named `eth1`. You can also identify it by its MAC address, it always starts with `00:22`. You can use jumbo frames (MTU 9000) on this interface for maximum throughput.

Bandwidth is unlimited and not counted towards your server's monthly bandwidth usage. Following is a general configuration guide. Note that your configuration may be different, depending on your OS and its version.

Warning

Do not set a gateway on the private interface. It cannot reach anything outside the private network, so a default route via `eth1` will black-hole your server's internet traffic.

UbuntuDebianRHEL / AlmaLinux / Rocky

**Applies to:** 20.04, 22.04, 24.04 and 26.04 — all configured through netplan.

1. Identify the interface name and MAC address: `ip -o link | grep 00:22`
2. Create a new netplan file with your `00:22` MAC address. Change `eth1` to your interface's name, if different.

  /etc/netplan/90-private.yaml

  ```
  network:
      version: 2
      ethernets:
          eth1:
              match:
                  macaddress: "00:22:xx:xx:xx:xx"
              addresses:
                  - 192.168.10.1/24
              mtu: 9000
  ```
3. Tighten the file permissions: `sudo chmod 600 /etc/netplan/90-private.yaml`
4. Enable the new config: `sudo netplan apply`

Version notes

Releases before 18.04 predate netplan; use the Debian instructions instead.

**Applies to:** 11, 12 and 13 — all configured through `ifupdown`.

1. Identify the interface name and MAC address: `ip -o link | grep 00:22`
2. Create a new interfaces.d file. Change `eth1` to your interface's name, if different.

  /etc/network/interfaces.d/90-private

  ```
  auto eth1
  iface eth1 inet static
      address 192.168.10.1/24
      mtu 9000
  ```
3. Bring the interface up: `sudo ifup eth1`

**Applies to:** EL8, EL9 and EL10.

1. Identify the interface name and MAC address: `ip -o link | grep 00:22`
2. Add a new NetworkManager connection for it. Change `eth1` to your interface's name, if different.

  ```
  sudo nmcli connection add type ethernet con-name private ifname eth1 \
      ipv4.method manual \
      ipv4.addresses 192.168.10.1/24 \
      ipv4.never-default yes \
      ipv6.method disabled \
      802-3-ethernet.mtu 9000
  ```
3. Bring the connection up: `sudo nmcli connection up private`

`ipv4.never-default yes` is what keeps the private interface off your default route, so leave it in.

Using ifcfg files instead

Create a new interface file. Note that it has no `GATEWAY` line — that is deliberate.

/etc/sysconfig/network-scripts/ifcfg-eth1

```
TYPE=Ethernet
DEVICE=eth1
HWADDR=00:22:xx:xx:xx:xx
BOOTPROTO=static
ONBOOT=yes
IPADDR=192.168.10.1
NETMASK=255.255.255.0
MTU=9000
```

Apply it as above: `sudo systemctl restart network` on EL8, or `sudo nmcli connection reload` followed by `sudo nmcli connection up eth1` on EL9. EL10 has dropped `ifcfg` support — use `nmcli`.

## BGP

Info

Please note that this is under active development and may not be available in all locations yet. You should only try to configure this if you have been in contact with our support team to have it enabled.

Setup a BGP session using a router software such as Bird using the details below.

#### Our side

- ASN: 65473
- IPv4: 169.254.169.254
- IPv6: 2605:4840:ffff::179

#### Your side

- IPv4: The main IP address of your server
- IPv6: The ::179 address of your server's /64 subnet
- eBGP multihop 2
- Password provided by our support team

We are advertising default route for both v4 and v6.

Tip

You can announce more specific subnets within your allowed prefixes up to /32 (IPv4) or /128 (IPv6). This means you can use IPs from one prefix on multiple servers in same location. Please make sure to also announce the full subnet (as per your LOA) from at least one server so that it gets announced out on the internet.

## Bandwidth Usage

Both incoming and outgoing traffic is counted towards the bandwidth usage of your VM (traffic on the private network interface is not counted). You can see the limit in the control panel (cloud.hosthatch.com). The counter resets on the 1st day of each calendar month, no matter what your billing period is.

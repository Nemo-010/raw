Ocean Network features

## Four ways to use the network, one account

Serve a model, run a job from your editor, give a coding agent its own machine, or earn from the GPUs you already own.

### Inference

Long running models and AI apps on network GPUs, billed for the runtime you book.

Explore Inference →

### [Compute jobs](https://oncompute.ai/compute)

Containerised jobs with a start and an end, launched straight from VS Code, Cursor or Windsurf.

Run a job →

### [Ocean MCP](https://oncompute.ai/compute#mcp)

Give a coding agent its own machine. It picks the hardware, runs the work and reports back.

See Ocean MCP →

### [Run a node](https://oncompute.ai/compute#nodes)

Put idle GPUs to work and get paid for the minutes somebody else uses them.

Become an operator →

Inference

## Pick a model and it runs until your window ends

Chat, images and video on a card that is yours for the hours you booked, with no swapping underneath you.

Text generation

$ curl $ONC/v1/chat/completions

-d '{"model":"Qwen3.8-27B","stream":true}'

live · H200 · stops at the end of your window

**Any model on the Hub**, behind an OpenAI-compatible endpoint. vLLM on a GPU, or llama.cpp on CPU.

Image generation

ComfyUI — E-commerce studio

**Turn one product photo** into scene shots, relights, a 360, an ad creative and a clip.

Video generation

**Templates with the weights already in place**, so the first run is not spent downloading hundreds of gigabytes.

Comparison

## What you get here that you do not get elsewhere

| What you get | Ocean Network | Serverless APIs | Managed endpoints | Raw GPU rental |
| --- | --- | --- | --- | --- |
| The model you name is the model that loads | Yes | Pooled, provider not pinned | Yes | Yes, if you build it |
| A card nobody else is sharing | Yes | No | Yes | Yes |
| Price agreed before anything starts | Hourly, shown upfront | Per token, after the fact | Hourly | Hourly |
| Run a job straight from your editor | VS Code, Cursor, Windsurf | No | No | Usually a console or CLI |
| Running without configuring anything | Templates, services and curated models, one click | Yes | Some setup | You build the image |
| Earn from hardware you already own | Yes | No | No | Some marketplaces |

Pricing

## H200, per hour, per card

Same hardware, same hour, four different bills. Published on-demand rates, read on the dates shown.

Ocean Network read 19 Aug 2026

$2.16

RunPod Secure Cloud read 26 Aug 2026

$4.39

RunPod H200 SXM 141 GB VRAM, 276 GB RAM, 24 vCPU

$4.59

Hugging Face Endpoints read 30 Jul 2026

$5.00

Together dedicated cluster read 30 Jul 2026

$5.99

You pay for the window you book and nothing once it ends. Instance specifications differ between providers, so compare the card and the memory alongside the rate.

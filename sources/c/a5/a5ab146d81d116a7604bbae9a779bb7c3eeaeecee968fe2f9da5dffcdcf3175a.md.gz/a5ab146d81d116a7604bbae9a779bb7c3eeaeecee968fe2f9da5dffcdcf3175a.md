## Repository navigation

- [Code](https://github.com/rclone/rclone)
- [Issues (977)](https://github.com/rclone/rclone/issues)
- [Pull requests (360)](https://github.com/rclone/rclone/pulls)
- [Actions](https://github.com/rclone/rclone/actions)
- [Projects](https://github.com/rclone/rclone/projects)
- [Wiki](https://github.com/rclone/rclone/wiki)
- [Security and quality (51)](https://github.com/rclone/rclone/security)
- [Insights](https://github.com/rclone/rclone/insights)

# [backend] add Telegram #5829

[New issue](https://github.com/login?return_to=https://github.com/rclone/rclone/issues/5829)

[New issue](https://github.com/login?return_to=https://github.com/rclone/rclone/issues/5829)

Open

Open

[[backend] add Telegram](https://github.com/rclone/rclone/issues/5829#top)#5829

Labels

[new backend](https://github.com/rclone/rclone/issues?q=state%3Aopen%20label%3A%22new%20backend%22)

Milestone

[Help Wanted](https://github.com/rclone/rclone/milestone/13)

## Description

[@Kcchouette](https://github.com/Kcchouette)

[Kcchouette](https://github.com/Kcchouette)

opened

[on Nov 19, 2021](https://github.com/rclone/rclone/issues/5829#issue-1058506671)

#### What is your current rclone version (output from `rclone version`)?

rclone v1.53.3-DEV

#### What problem are you are trying to solve?

Adding a new backend (telegram): [https://core.telegram.org/method/upload.saveBigFilePart](https://core.telegram.org/method/upload.saveBigFilePart) and [https://core.telegram.org/method/upload.getFile](https://core.telegram.org/method/upload.getFile)

Reacted by hista, Atílio, Raul P., Akhil Rana, Joseph, footlooseboss, Akash Jain, Martin, Filippo Pesavento, nikitabuida and 31 more

Reacted by Sebastian Bünger, userqq and Paul

## Activity

1. [ivandeex](https://github.com/ivandeex)

  added this to the [Help Wanted](https://github.com/rclone/rclone/milestone/13) milestone

  [on Nov 19, 2021](https://github.com/rclone/rclone/issues/5829#event-5646268393)
2. [ivandeex](https://github.com/ivandeex)

  added

  [new backend](https://github.com/rclone/rclone/issues?q=state%3Aopen%20label%3A%22new%20backend%22)

  [on Nov 19, 2021](https://github.com/rclone/rclone/issues/5829#event-5646269045)
3. ### akhil-rana commented on Dec 20, 2021

  [@akhil-rana](https://github.com/akhil-rana)

  [akhil-rana](https://github.com/akhil-rana)

  [on Dec 20, 2021](https://github.com/rclone/rclone/issues/5829#issuecomment-998259326)

  It would really be great if we can just add a aingle chat/channel/group or something as a remote where all the files/media in that chat can be treated as files in the remote.

  One more approach can be to have Chat Names as folder names and just let those folders have respective files inside them.
4. ### akhil-rana commented on Dec 20, 2021

  [@akhil-rana](https://github.com/akhil-rana)

  [akhil-rana](https://github.com/akhil-rana)

  [on Dec 20, 2021](https://github.com/rclone/rclone/issues/5829#issuecomment-998260588)

  Also "chunker" can be really great with telegram since there is a 2gb file limit. So using a private channel or something as a storage solution for all the files might be a nice idea

  Reacted by Dion, Lesmiscore, t-chab, TimeZlicer and みづな れい
5. ### DroneTechTI commented on Dec 24, 2021

  [@DroneTechTI](https://github.com/DroneTechTI)

  [DroneTechTI](https://github.com/DroneTechTI)

  [on Dec 24, 2021](https://github.com/rclone/rclone/issues/5829#issuecomment-1000900411)

  · Hidden as duplicate
6. ### uGeek commented on Dec 25, 2021

  [@uGeek](https://github.com/uGeek)

  [uGeek](https://github.com/uGeek)

  [on Dec 25, 2021](https://github.com/rclone/rclone/issues/5829#issuecomment-1001082233)

  · Hidden as duplicate
7. ### uGeek commented on Dec 25, 2021

  [@uGeek](https://github.com/uGeek)

  [uGeek](https://github.com/uGeek)

  [on Dec 25, 2021](https://github.com/rclone/rclone/issues/5829#issuecomment-1001082636)

  · Hidden as duplicate
8. ### DroneTechTI commented on Dec 25, 2021

  [@DroneTechTI](https://github.com/DroneTechTI)

  [DroneTechTI](https://github.com/DroneTechTI)

  [on Dec 25, 2021](https://github.com/rclone/rclone/issues/5829#issuecomment-1001083599)

  · Hidden as duplicate
9. ### nikitabuida commented on Jan 24, 2022

  [@nikitabuida](https://github.com/nikitabuida)

  [nikitabuida](https://github.com/nikitabuida)

  [on Jan 24, 2022](https://github.com/rclone/rclone/issues/5829#issuecomment-1019845744)

  Would be great to have Telegram storage in RClone. [https://github.com/SlavikMIPT/tgcloud](https://github.com/SlavikMIPT/tgcloud) - looks deserted but it allowed to mount tg storage directly into filesystem.
10. ### ElDavoo commented on Apr 13, 2022

  [@ElDavoo](https://github.com/ElDavoo)

  [ElDavoo](https://github.com/ElDavoo)

  [on Apr 13, 2022](https://github.com/rclone/rclone/issues/5829#issuecomment-1098517007)

  Contributor

  So people will start storing PB of data on TG servers and they will then be forced to introduce individual quota. Great!

  Reacted by fortemezzo, Paul, userqq, 0x08, Ashesh, Shrimadhav U K, Vincent, Arfian Adam, Muhammad Bayiz and Siyuan Chen
11. ### birdup000 commented on Jun 7, 2022

  [@birdup000](https://github.com/birdup000)

  [birdup000](https://github.com/birdup000)

  [on Jun 7, 2022](https://github.com/rclone/rclone/issues/5829#issuecomment-1149123536)

  Hello I'm a dev from Teledrive ready to start to integrate Rclone with the project. We're currently working on making this possible.  
   -Thank you everyone for your ideas and we'll be looking on integration

  Reacted by 0x08, chinchio, Oliver Sayers, farsighter and みづな れい
12. ### ElDavoo commented on Jun 7, 2022

  [@ElDavoo](https://github.com/ElDavoo)

  [ElDavoo](https://github.com/ElDavoo)

  [on Jun 7, 2022](https://github.com/rclone/rclone/issues/5829#issuecomment-1149167868)

  Contributor

  All of the rclone supported remotes are actual data storage solutions. Telegram is not a storage service but a messaging platform. I don't think ncw will approve it. You are of course allowed to develop code in your own fork but I don't think a pull request would be allowed.

  Reacted by userqq, Shrimadhav U K, Arfian Adam, Paul and Pieris

  Reacted by Dmitry Galenko, Markus Rambossek and Rosiel Victor
13. ### ncw commented on Jun 8, 2022

  [@ncw](https://github.com/ncw)

  [ncw](https://github.com/ncw)

  [on Jun 8, 2022](https://github.com/rclone/rclone/issues/5829#issuecomment-1149584119)

  Member

  @greengeckowizard Tell me more about your proposed integration? Would this call the telegram APIs directly?
14. ### birdup000 commented on Jun 8, 2022

  [@birdup000](https://github.com/birdup000)

  [birdup000](https://github.com/birdup000)

  [on Jun 8, 2022](https://github.com/rclone/rclone/issues/5829#issuecomment-1150125955)

  This would go to through existing Teledrive api for uploading and downloading

  Reacted by nikitabuida
15. ### birdup000 commented on Jun 8, 2022

  [@birdup000](https://github.com/birdup000)

  [birdup000](https://github.com/birdup000)

  [on Jun 8, 2022](https://github.com/rclone/rclone/issues/5829#issuecomment-1150490254)

  Only issue is how would creating backend be possible?
16. ### 32 remaining items
17. ### D4rk4 commented on Mar 14, 2023

  [@D4rk4](https://github.com/D4rk4)

  [D4rk4](https://github.com/D4rk4)

  [on Mar 14, 2023](https://github.com/rclone/rclone/issues/5829#issuecomment-1468445489)

  Any news?
18. ### birdup000 commented on Apr 17, 2023

  [@birdup000](https://github.com/birdup000)

  [birdup000](https://github.com/birdup000)

  [on Apr 17, 2023](https://github.com/rclone/rclone/issues/5829#issuecomment-1510604480)

  I've started a repository called RcloneTelegram I'm working on Rclone Support for Telegram

  Reacted by Asahi21, Jon Davis, Akhil Rana, t-chab and Oliver Sayers
19. ### birdup000 commented on Apr 24, 2023

  [@birdup000](https://github.com/birdup000)

  [birdup000](https://github.com/birdup000)

  [on Apr 24, 2023](https://github.com/rclone/rclone/issues/5829#issuecomment-1520761749)

  > If someone wants to make a backend for this, I don't have a problem provided
  >
  >     1. It uses only documented public APIs
  >     2. It doesn't allow or encourage breaking the terms of service of the provider
  >
  > I don't know whether an rclone backend would breach 2. above or not, some evidence either way would be nice.

  Hi in my Rclone to Telegram which is the backend. I include these listed. [https://github.com/greengeckowizard/RcloneTelegram](https://github.com/greengeckowizard/RcloneTelegram)
20. ### musahi0128 commented on Oct 1, 2023

  [@musahi0128](https://github.com/musahi0128)

  [musahi0128](https://github.com/musahi0128)

  [on Oct 1, 2023](https://github.com/rclone/rclone/issues/5829#issuecomment-1741940819)

  [@ncw](https://github.com/ncw) Please have a look at [this](https://core.telegram.org/bots/api#:~:text=Using%20a%20Local,a%20getFile%20request.) and [this](https://core.telegram.org/bots/faq#:~:text=How%20do%20I%20upload,changed%20in%20the%20future.)

  I am sure this telegram backend is better suited to run against a self-hosted telegram-bot-api. It's relatively easy to get one running using docker, for example:

  ```
  docker -p 8081:8081 ghcr.io/bots-house/docker-telegram-bot-api:latest --local --api-id="2496" --api-hash="8da85b0d5bfe62527e5b244c209159c3" --max-webhook-connections=100000
  ```

  I am no programmer but here is some of the public API I think relevant for this backend.

  Uploading files: [https://core.telegram.org/bots/api#senddocument](https://core.telegram.org/bots/api#senddocument)

  Downloading files: [https://core.telegram.org/bots/api#getfile](https://core.telegram.org/bots/api#getfile)

  We can use the `caption` to store the path information.  
   Since there is 2gb file size limit (4gb for premium account), rclone should split file larger than that (or anything specified in the config) when uploading and append some information to the caption, so it is possible to differentiate between a whole file and file parts in a message and treat the files accordingly.  
   Each API call require a bot, and one account is entitled to 20 bots max, that can be used in multi-threading.

  I imagine the config entry will look like this

  ```
  [telegram]
  host = localhost
  port = 8081
  chat_id = XXXXXXXXXXXXXX
  max_file_size = 2Gi
  bot_01 = XXXXXXXXXX:XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
  bot_02 = XXXXXXXXXX:XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
  bot_03 = XXXXXXXXXX:XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
  ...
  bot_20 = XXXXXXXXXX:XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
  ```

  There is [this](https://github.com/divyam234/teldrive) project that also utilize telegram unlimited storage and the dev also made a rclone version that work against its own API. The project is great, and I have been using it for a while. But I think using a direct API to Telegram will be much better and easier to manage for rclone, and this should require no database at all.

  Please also note that I am willing to sponsor this backend.

  Thanks!

  Reacted by Mehdi Nourollah, ShaGan, Tran Duc Thien, Niruchie, rexjohannes and aniel300

  Reacted by Niruchie

  Reacted by Mehdi Nourollah and Niruchie
21. ### kkm commented on Jul 21, 2024

  [@kkm](https://github.com/kkm)

  [kkm](https://github.com/kkm)

  [on Jul 21, 2024](https://github.com/rclone/rclone/issues/5829#issuecomment-2241455948)

  +1

  Reacted by Niruchie
22. [Niruchie](https://github.com/Niruchie)

  added a commit that references this issue

  [on Jan 1, 2025](https://github.com/rclone/rclone/issues/5829#event-15792598744)

  [telegram: implements directories via MTProto API, allowing mount into…](https://github.com/Niruchie/rclone/commit/726d17fd3c93a5b1a42d1541680a89d8a22bd9c0)

  [726d17f](https://github.com/Niruchie/rclone/commit/726d17fd3c93a5b1a42d1541680a89d8a22bd9c0)
23. ### renich commented on Apr 17, 2025

  [@renich](https://github.com/renich)

  [renich](https://github.com/renich)

  [on Apr 17, 2025](https://github.com/rclone/rclone/issues/5829#issuecomment-2812526179)

  This one seems abandoned. Too bad...

  Reacted by Niruchie

  Reacted by Niruchie

  Reacted by Niruchie
24. ### pazport commented on Aug 5, 2025

  [@pazport](https://github.com/pazport)

  [pazport](https://github.com/pazport)

  [on Aug 5, 2025](https://github.com/rclone/rclone/issues/5829#issuecomment-3154743997)

  was this ever implanted? would be great to use telgram own system rather then hosting local?

  Reacted by Renich Bon Ciric and Niruchie

  Reacted by Origami Official and Niruchie
25. ### kouhe3 commented on Aug 5, 2025

  [@kouhe3](https://github.com/kouhe3)

  [kouhe3](https://github.com/kouhe3)

  [on Aug 5, 2025](https://github.com/rclone/rclone/issues/5829#issuecomment-3155235654)

  use [https://github.com/iyear/tdl](https://github.com/iyear/tdl)

  > was this ever implanted? would be great to use telgram own system rather then hosting local?

  Reacted by Niruchie
26. ### keyang556 commented on Jul 10, 2026

  [@keyang556](https://github.com/keyang556)

  [keyang556](https://github.com/keyang556)

  [on Jul 10, 2026](https://github.com/rclone/rclone/issues/5829#issuecomment-4936060550)

  any news?
27. ### aniel300 commented on Jul 12, 2026

  [@aniel300](https://github.com/aniel300)

  [aniel300](https://github.com/aniel300)

  [on Jul 12, 2026](https://github.com/rclone/rclone/issues/5829#issuecomment-4950324019)

  i used to use this and I am planning to implement my own stuff from scratch using rclone and teldrive and all those other projects as reference. however this is time bomb because it doesn't make sense for tg from a storage point of view to support ppl uploading tbs and tbs to their servers where is all duplicate since parson a and person b will most likely be uploading the same file, etc. i think there has to be a better solution to this and i have one in mind and i will share more once i have something more concrete
28. ### elcuervo171234 commented on Oct 11, 2026

  [@elcuervo171234](https://github.com/elcuervo171234)

  [elcuervo171234](https://github.com/elcuervo171234)

  [on Oct 11, 2026](https://github.com/rclone/rclone/issues/5829#issuecomment-6109874118)

  Hi [@D4rk4](https://github.com/D4rk4), is your 250 USDT bounty still available for a new contributor? Before I assess implementation, could you confirm the remaining scope and acceptance tests, whether upstream merge is still the payment trigger, and the review/revision and payment timeframes?

  Would PayPal or USDC on Base be possible? If payment must be USDT, which network? I would scope only documented Telegram APIs and an approach approved by the maintainers that respects the provider's terms. I'll wait for these details before proposing a delivery date.

  Guanelfi

## Metadata

## Metadata

### Assignees

No one assigned

### Labels

[new backend](https://github.com/rclone/rclone/issues?q=state%3Aopen%20label%3A%22new%20backend%22)

### Type

No type

### Projects

No projects

### Milestone

- [Help WantedNo due date](https://github.com/rclone/rclone/milestone/13)

### Relationships

None yet

### Development

No branches or pull requests

## Issue actions

26 years of rates, one request away

## Historical Exchange Rate API

26+ years of daily exchange rate data for 166 currencies — query any date from 2000 to yesterday via a single REST call. Try it right here.

Live data from the /timeframe endpoint

## What is the Historical Exchange Rate API?

The Historical Exchange Rate API gives developers access to daily foreign exchange rates going back to January 1, 2000 — over 26 years of data for 166 ISO 4217 currencies, including fiat pairs, cryptocurrencies (from their respective launch dates), and precious metals.

Data is sourced from central banks and reputable financial institutions and delivered as clean JSON (or XML) with a simple REST interface. There is no SDK required — a single GET request returns everything you need.

Two dedicated endpoints cover every historical use case: [/api/v2/history](https://currencyapi.net/documentation/history/) retrieves rates for a single named date, while [/api/v2/timeframe](https://currencyapi.net/documentation/timeframe/) returns a date-keyed object for the entire range you specify.

**26+ years of data:** Daily rates from 2000-01-01 to yesterday, updated each day.

**166 currencies:** All major ISO 4217 fiat codes plus crypto and metals.

**Two endpoints:** Single-day (/history) and date-range (/timeframe) — choose what fits.

**JSON & XML:** Both output formats supported on all paid plans.

**Free plan available:** 500 requests/month, no card required to start.

## Two Endpoints for Every Historical Use Case

The /history endpoint returns rates for a single date. The /timeframe endpoint returns a full date-keyed object for a range — both from the same API, the same key.

#### /api/v2/history

SINGLE DAY

JUNE 2023 · ONE DATE

10

11

12

13

14

15

16

17

18

19

20

21

one day → the full rate set for that date

Pass a date and base currency; get back the full rate set for that specific day. Ideal for point-in-time lookups: invoice date rates, on-this-day widgets, spot audits. Available on Essential plans and above.

#### /api/v2/timeframe

DATE RANGE

JUNE 2023 · A RANGE OF DATES

10

11

12

13

14

15

16

17

18

19

20

21

start → end → one entry per day in the range

Pass start_date and end_date; get a single JSON object keyed by date, each containing the full rate set. Perfect for chart data, backtesting ranges, compliance exports. Available on StartUp plans and above.

## Explore Historical Data in Your Dashboard

Chart decades of exchange rate history, test /history and /timeframe calls, and monitor your usage — all from an intuitive dashboard, then turn any request into production code in minutes.

Historical Data & Analytics preview

### Dashboard Features

## Code Examples

Both historical endpoints in every supported language — /history for a single date, /timeframe for a date range.

```
import requests

url = "https://currencyapi.net/api/v2/history"

params = {
    "key": "YOUR_API_KEY",
    "date": "2026-01-01",
    "base": "USD",
    "output": "JSON"
}

response = requests.get(url, params=params)
data = response.json()

print(data)
```

## Use Cases for Historical Exchange Rate Data

#### Accounting & Financial Reporting

Lock in the exact exchange rate for an invoice or transaction date. Satisfy multi-currency accounting standards (IFRS, GAAP) with auditable, timestamped rate data.

USED BY ERP systems, Xero, QuickBooks

#### Backtesting & Quantitative Research

Replay decades of FX movements against trading strategies or models. The /timeframe endpoint returns a full date range in one request — no pagination needed.

USED BY Algorithmic trading, portfolio optimisation

#### Compliance & Audit Trails

Produce point-in-time rate evidence for tax filings, customs valuations, and regulatory audits. Data is sourced from central banks and financial institutions.

USED BY VAT/GST returns, customs declarations

#### Trend Analysis & Dashboards

Build interactive FX charts showing months or years of movement. Use the /timeframe endpoint to power line charts, candlesticks, or volatility indicators.

USED BY Financial media, research platforms

#### E-commerce & Pricing History

Reconstruct what a product cost in a customer's local currency on a specific purchase date. Useful for refunds, chargebacks, and loyalty programmes.

USED BY Shopify, WooCommerce, marketplaces

#### Travel & Expense Management

Reimburse international expenses at the mid-market rate on the expense date — eliminating manual lookups and policy disputes.

USED BY Expense platforms, corporate travel tools

## Historical Data — Plans & Pricing

Historical data isn't on the free tier. The /history endpoint starts on the Essential plan, and date-range /timeframe queries are included from StartUp and above.

### Historical rates on every paid plan

Access to the /history endpoint begins with the Essential plan; the date-range /timeframe endpoint is included from StartUp upwards. Choose the plan that matches your query volume.

- /history — any date back to 2000
- 166 currencies, crypto & precious metals
- JSON & XML output
- Commercial use included

#### Starting from

$9.99 /month

## Supported SDKs & Integrations

Use our official SDKs or copy a code example in your language — historical endpoints are supported in all of them.

## Historical Exchange Rate API — FAQs

Questions about historical exchange rate data? See below, or [get in touch](https://currencyapi.net/contact/).

How far back does the historical exchange rate data go?

Historical exchange rate data is available from January 1, 2000 — over 26 years of daily rates covering 166 ISO 4217 currencies, sourced from central banks and reputable financial institutions globally.

Cryptocurrency rates are available from their respective launch dates (e.g. Bitcoin from 2010). Precious metals are covered from 2000.

Historical data is accessible via two endpoints: [/api/v2/history](https://currencyapi.net/documentation/history/) for a single date and [/api/v2/timeframe](https://currencyapi.net/documentation/timeframe/) for a date range.

What is the difference between /history and /timeframe?

The [/api/v2/history](https://currencyapi.net/documentation/history/) returns rates for a single named date — pass date=YYYY-MM-DD and get the full rate set for that day. It is available on Essential plans and above.

The [/api/v2/timeframe](https://currencyapi.net/documentation/timeframe/) accepts start_date and end_date parameters and returns a single JSON object keyed by date, with each date containing the full rate set. It is available on StartUp plans and above.

Use /history for point-in-time lookups (invoices, audits). Use /timeframe for range-based data (charts, backtesting, compliance exports).

Is historical data free?

Historical data is not available on the Free plan. Access begins with the Essential plan ($9.99/month), which unlocks the /history endpoint.

The /timeframe endpoint (date-range queries) requires the StartUp plan ($34.99/month) or above.

There's no free trial for historical data, but we do offer a [free plan](https://currencyapi.net/free-exchange-rate-api/) for live rates (500 requests/month, no credit card required) if you'd like to try the API first.

How many currencies are covered in historical data?

The API covers 166 ISO 4217 currencies for all dates from 2000 onward (subject to each currency's existence on the given date). Cryptocurrencies and precious metals are also included.

You can view the full list of supported currencies on our [currency list](https://currencyapi.net/currency-list/) page.

Can I query historical rates for cryptocurrencies?

Yes. Bitcoin (BTC), Ethereum (ETH), XRP, and other major cryptocurrencies are included in the historical dataset from their respective launch dates. The same /history and /timeframe endpoints and parameters apply.

Explore our full [Cryptocurrency Exchange Rate API](https://currencyapi.net/cryptocurrency-exchange-rate-api/) for details on all supported crypto assets and their update frequency.

What format does the historical API return?

By default, the API returns JSON. You can request XML by adding output=XML to any request. Both formats are supported on all paid plans.

The /history response includes valid (boolean), base, date, and a rates object mapping currency codes to exchange rate values relative to the base.

The /timeframe response wraps rates in a top-level object keyed by date — making it straightforward to iterate and build charts or tables.

Can I change the base currency for historical queries?

Yes. Add base=EUR (or any supported currency code) to your request and all rates in the response will be relative to that base. The default base is USD.

Changing the base is available on Essential plans and above.

[Back to all Usenet providers](https://www.usenet.org/providers)

NewsLeecher Logo

# NewsLeecher

3.2(1 Reviews)

NewsLeecher is a unique all-in-one provider by Crystal Art Software: alongside Usenet access, it bundles the proprietary NewsLeecher software, integrated SuperSearch indexer, and SuperLeech automation service. Nearly over 6,600 days retention, 500+ Mbps, unlimited downloads, 14-day free trial.

[Go to Provider →](https://newsleecher.com/)

Backbone

Omicron

Server

EU, USA

Retention

12+ Years

Trustpilot

3.2

Payment Methods

PayPal, CreditCard

Protection

Free Trial

Privacy & Jurisdiction

Limited

Abuse

Notice & Takedown

## Plans & Pricing Compared

NewsLeecher Logo

Pure Usenet

3.2(1)

$9.49monthly

Speed: Unlimited

Data: Unlimited Data

Connections: 30

Protection: Free Trial

[Go to Provider →](https://newsleecher.com/)

NewsLeecher Logo

Ready to Go (SW+Usenet)

3.2(1)

$12.49monthly

Speed: Unlimited

Data: Unlimited Data

Connections: 30

Protection: Free Trial

[Go to Provider →](https://newsleecher.com/)

## All About NewsLeecher

NewsLeecher is a provider with an unusual profile: the company Crystal Art Software (registration number 28861931) is both the developer of one of the best-known Windows Usenet newsreaders and the operator of its own Usenet access service. This dual role makes NewsLeecher a genuine all-in-one provider — one that supplies not just the server backbone but also the tool used to access it.

## Three Package Models

NewsLeecher structures its offering into three packages, differing in the scope of included services:

"Ready to Go" — The complete solution for €9.49/month

- Usenet access (full)
- NewsLeecher software (latest version)
- SuperSearch (premium search index)
- SuperLeech (automation service)

This package targets anyone who wants to get started immediately without setting up a separate newsreader, indexer, or automation tool.

"Client Plus" — For users with their own Usenet access

- NewsLeecher software
- SuperSearch
- SuperLeech
- No Usenet access included

This package targets users who already have access through another Usenet provider and only want the NewsLeecher software and complementary services.

"Pure Usenet" — Pure access without software

- Usenet access only
- No software, no search functions

For users who already use their own newsreader and indexer.

## The Core Components in Detail

NewsLeecher software: a proven Windows newsreader known for its stability, its deobfuscation support (from version 8.0 Beta), and its deep integration with SuperSearch. The software is regarded as one of the most capable Usenet clients on the market.

SuperSearch: a premium search index for Usenet content operated by NewsLeecher. SuperSearch lets users search and find newsgroup content directly from within the software — without external indexer websites.

SuperLeech: an automation service functioning similarly to Sonarr/Radarr — users can subscribe to RSS feeds, and SuperLeech automatically downloads new content as soon as it appears on Usenet.

## Technical Infrastructure

The technical specs of the NewsLeecher access service:

- Retention: nearly over 6,600 days — over 18 years of stored binary content
- Speed: 500+ Mbps download speed
- Data cap: none — unlimited downloads
- Speed limit: none — no throttling
- Encryption: 256-bit SSL on all connections
- Uptime: high availability

Retention of nearly over 6,600 days positions NewsLeecher in the industry's top segment — on par with leading tier-1 providers such as Newshosting or UsenetServer.

## 14-Day Trial

NewsLeecher offers a 14-day free trial — "no strings attached." This is one of the more generous trial periods compared to the typical 7-day trials or money-back guarantees offered by other providers.

## Strengths and Distinctive Features

- Unique all-in-one concept: newsreader + indexer + automation + access in one package
- Excellent retention: nearly over 6,600 days — competitive with the best providers
- No download or speed limits
- 14-day trial — more generous than the industry standard
- Modular offering: those wanting only software or only access have suitable options

## Limitations

- Windows only: the NewsLeecher software is restricted to Windows. Mac and Linux users can use plain Usenet access with their own client, but won't benefit from the software integration.
- No VPN integration in the packages
- Past technical issues: reports of payment problems (April 2022) and SuperSearch indexing issues (January 2023) point to occasional operational disruptions, not unusual for a small independent company.

## Who is NewsLeecher for?

NewsLeecher is ideal for:

- Windows users seeking a fully integrated, single-source solution
- Beginners who want to get started immediately without configuration effort
- Users who want to use SuperSearch functionality directly within their newsreader
- Automation enthusiasts who want to use SuperLeech for RSS-based downloads

## Frequently Asked Questions

### What does NewsLeecher's "Ready to Go" package include?

The "Ready to Go" package (€9.49/month) includes full Usenet access, NewsLeecher software, the SuperSearch search index, and the SuperLeech automation service — all in one package.

### What is NewsLeecher's retention?

Binary retention is nearly over 6,600 days, equivalent to over 18 years of stored binary content.

### Is there a trial at NewsLeecher?

Yes. NewsLeecher offers a 14-day free trial with no strings attached.

### What is SuperLeech?

SuperLeech is a NewsLeecher automation service that works similarly to Sonarr or Radarr: it subscribes to RSS feeds and automatically downloads new Usenet content.

### Can I use NewsLeecher without the software packages?

Yes. The "Pure Usenet" package offers only Usenet access, without NewsLeecher software or search functions.

## Others also viewed these providers

XS News LogoXS News12 Plans

Backbone

Abavia

Trustpilot

4.8

Server

EU, USA

Retention

10+ Years

[More Details](https://www.usenet.org/providers/xsnews)

EasyUsenet LogoEasyUsenet7 Plans

Backbone

Abavia

Trustpilot

4.7

Server

EU, USA

Retention

10+ Years

[More Details](https://www.usenet.org/providers/easyusenet)

USENEXT LogoUSENEXT6 Plans

Backbone

Abavia

Trustpilot

4.6

Server

EU

Retention

12+ Years

[More Details](https://www.usenet.org/providers/usenext)

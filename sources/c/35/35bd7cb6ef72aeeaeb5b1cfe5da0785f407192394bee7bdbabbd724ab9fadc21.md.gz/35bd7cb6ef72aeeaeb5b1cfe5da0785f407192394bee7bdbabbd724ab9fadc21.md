> ## Documentation Index
> Fetch the complete documentation index at: https://docs.llm7.io/llms.txt
> Use this file to discover all available pages before exploring further.

# Limits

> Rate, token-usage, image, and video endpoint limits by plan.

Limits vary by access type, plan, endpoint, and model availability.

## Text generation (/v1/chat/completions)

| Access type | 1 second | 1 minute | 1 hour |
| - | - | - | - |
| Free token | 1 | 60 | 250 |
| Pro (\$12/mo) | 25 | 1,500 | 15,000 |

## Token usage availability

Token usage is counted as input tokens plus output tokens.

| Access type | Token availability |
| - | - |
| Free token | 100,000 tokens per 24 hours |
| Pro (\$12/mo) | Higher dynamically managed token limits than the free tier |

For Pro accounts, token availability is calculated across the monthly billing period based on your usage relative to the percentage of the billing period that has elapsed. You can check current allowance in the [dashboard](https://dash.llm7.io/). After the Pro allowance is reached, requests can continue from a topped-up balance and are billed from the live model pricing.

Pro token availability remains subject to model availability, service capacity, fair-use calculations, and abuse-prevention controls.

Free-token quotas are provided at no charge and may be reduced without notice based on demand, service capacity, model availability, fair-use calculations, abuse-prevention controls, and other operational factors.

Note: Maximum input sizes also depend on your access tier and the specific model context window.

## Image API (/v1/images/generations, /v1/images/edits)

Image requests require a valid LLM7 API token and are billed from available allowance or balance.

| Limit | Value |
| - | - |
| Generated images per request | `1` |
| URL image output | Not supported |
| Edit mask field | Not supported |
| `gpt-image-2` reference images | Up to 3 images |
| `gpt-image-2` reference image size | Up to 8 MB per image |

Image model metadata controls supported sizes, reference-image limits, and availability. Successful image responses include `usage.cost_usd` when billed cost is available.

## Video API (/v1/videos)

Video requests require a valid LLM7 API token and are billed asynchronously from available allowance or balance.

| Limit | Source |
| - | - |
| Allowed duration values | `capabilities.supported_seconds` |
| Allowed output sizes | `capabilities.supported_sizes` |
| Reference image count | `capabilities.max_reference_images` |
| Reference image size | `capabilities.max_reference_image_bytes` |
| Required reference image | `capabilities.requires_reference_image` |

On task creation, the full estimated cost is reserved as a hold. For route-priced video models, select the route that matches the submitted model and request type, then use the route-level public price:

```text theme={null}
seconds * selected_route.public_price_usd_per_second
```

Fall back to `seconds * pricing.price` only when the model does not expose `pricing.route_prices_usd_per_second`.

The hold is consumed when the task completes successfully and released when upstream generation fails or task creation is not accepted.

> [!NOTE]
>
> Use the [Models API](https://docs.llm7.io/guides/models-api.md) to inspect live model tiers, pricing, context windows, and capability flags. Get a free token at [dash.llm7.io](https://dash.llm7.io) or upgrade to Pro for higher caps.


This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.
# Plans & pricing

Everything you run (browsers, sandboxes, VMs, proxies, and captcha solves) draws from one credit balance. Choose a plan, then pay by the hour for what you use. Switch anytime.

## Plans

|  | Free | Starter | Professional | Team | Enterprise |
| --- | --- | --- | --- | --- | --- |
| **Monthly fee** | $0 | $20 | $200 | Custom [Contact sales](https://www.getsolari.com/contact) | Custom [Contact sales](https://www.getsolari.com/contact) |
| **Monthly credits** | $3 | $20 | $200 | Custom | Custom |
| **Max session time** | 1 hour | 5 hours | 24 hours | Unlimited | Unlimited |
| **HIPAA compliance** | No | No | No | Included | Included |
| **Volume pricing** | No | No | No | Available | Available |

Credits refill each month and don't roll over. When your balance reaches zero, new sandboxes and desktops stop launching until you [top up](https://console.getsolari.com/billing) or your next month's credits arrive. That is the same on every plan: we don't bill past your balance, so there is no end-of-month overage charge. Credit you top up yourself doesn't expire, and the month's included credits are spent first.

## Browsers

Billed per hour while a session is open.

|  | Free | Starter | Professional | Team | Enterprise |
| --- | --- | --- | --- | --- | --- |
| **Rate** | $0.15 / hour | $0.10 / hour | $0.07 / hour | $0.05 / hour | $0.005 / hour |
| **Concurrent browsers** | 3 | 20 | 150 | 150+ | 100,000 |
| **Profiles** | 3 | 20 | 500 | Unlimited | Unlimited |
| **Replay retention** | 1 day | 7 days | 30 days | 90 days | 90 days |
| **Stealth mode** | No | Included | Included | Included | Included |
| **Concurrent stealth sessions** | — | 10 | 50 | 75 | 75 |
| **Captcha solving** | No | $0.01 / solve | $0.005 / solve | $0.005 / solve | $0.005 / solve |
| **Proxies** | No | $6.00 / GB | $4.00 / GB | $4.00 / GB | $4.00 / GB |

**Concurrent stealth sessions** is a separate, lower cap counted *in addition to* concurrent browsers, not instead of it — stealth sessions also count against your plan’s overall concurrent-browsers limit above. A Starter customer running 10 stealth sessions (the stealth cap) still gets a `429` on an 11th concurrent stealth session, even though 10 more slots are free on the 20-browser main cap. Enterprise’s 100,000 concurrent browsers applies to standard sessions; its stealth cap is the same as Team’s.

Team and Enterprise captcha and proxy bill at the rates shown unless your contract sets different ones; volume pricing is agreed with sales.

## Sandboxes & VMs

Billed by size (vCPUs and memory), so a small machine costs a fraction of a large one. VMs add $0.02 / hour for the live screen ($0.002 / hour on Enterprise).

|  | Free | Starter | Professional | Team | Enterprise |
| --- | --- | --- | --- | --- | --- |
| **Per vCPU-hour** | $0.0525 | $0.035 | $0.0245 | $0.0175 | $0.00175 |
| **Per GB-hour** | $0.0165 | $0.011 | $0.0077 | $0.0055 | $0.00055 |
| **Concurrent** | 1 sandbox | 2 | 10 | 50+ | 100,000 |

Team and Enterprise compute bills at the rates shown unless your contract sets different ones; volume pricing is agreed with sales.

Common sandbox sizes work out to (VMs add $0.02 / hour, or $0.002 on Enterprise):

| Machine size | Free | Starter | Professional |
| --- | --- | --- | --- |
| 1 vCPU / 2 GB | $0.086 / hour | $0.057 / hour | $0.040 / hour |
| 2 vCPU / 3 GB | $0.155 / hour | $0.103 / hour | $0.072 / hour |
| 2 vCPU / 4 GB | $0.171 / hour | $0.114 / hour | $0.080 / hour |
| 4 vCPU / 8 GB | $0.342 / hour | $0.228 / hour | $0.160 / hour |

## Snapshot storage

Stored [snapshots](https://docs.getsolari.com/snapshots) of sandboxes and VMs bill at $0.05 per GB-month, pro-rated daily, on every plan. The first 10 GB across your organization are free — only the excess bills, from your same credit balance. Snapshots you promote to templates count toward the total; Solari's built-in templates don't. Billing began October 1, 2026 (nothing was charged for storage held before then). Deleting a snapshot stops its charges the same day.

## What your credits buy

- **$20 on Starter** buys 200 browser-hours, or about 350 hours on a small (1 vCPU / 2 GB) sandbox.
- **$200 on Professional** buys about 2,850 browser-hours, or about 5,000 hours on a small sandbox.

One balance, so mix them however you like.

## Manage your plan

Choose a plan or upgrade anytime in [the console](https://console.getsolari.com/billing). For Team or Enterprise pricing, HIPAA, or specific regions, email [hello@getsolari.com](mailto:hello@getsolari.com).

[PreviousOrganizations](https://docs.getsolari.com/organizations)

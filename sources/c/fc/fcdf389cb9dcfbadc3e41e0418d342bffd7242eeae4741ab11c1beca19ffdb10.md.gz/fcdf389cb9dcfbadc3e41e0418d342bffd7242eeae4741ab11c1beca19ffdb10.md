## Why Avrea costs less

67% lower compute cost than GitHub Actions at list prices, with 2x faster builds.

### Lower per-minute cost

Pay less per minute than GitHub-hosted runners, before savings from faster builds and caching.

### Faster builds

High-performance hardware shortens build and test times, reducing billed runtime.

### Less work repeated

Reuse cached dependencies, build outputs and Docker layers across runs.

## Runner and sandbox pricing

Prices per minute · runners billed by the second, sandboxes for reserved time

### Linux x86

Ubuntu 22.04 · 24.04 · 26.04 · x86-64

| vCPUs | Memory (GB) | Price/min |
| --- | --- | --- |
| 1 | 4 | $0.002 |
| 2 | 8 | $0.004 |
| 4 | 8 | $0.006 |
| 4 | 16 | $0.008 |
| 8 | 16 | $0.012 |
| 8 | 32 | $0.016 |
| 16 | 64 | $0.032 |
| 32 | 128 | $0.064 |

### macOS

macOS 26 · 27 · ARM64 · Apple M5 Max

| vCPUs | Memory (GB) | Price/min |
| --- | --- | --- |
| 8 | 24 | $0.08 |
| 16 | 48 | $0.16 |

### Linux ARM

Ubuntu 24.04 · 26.04 · ARM64 · Apple M5 Max

| vCPUs | Memory (GB) | Price/min |
| --- | --- | --- |
| 1 | 4 | $0.006 |
| 2 | 8 | $0.012 |
| 4 | 8 | $0.018 |
| 4 | 16 | $0.024 |
| 8 | 16 | $0.036 |
| 8 | 32 | $0.048 |
| 16 | 64 | $0.096 |

### Windows

Windows 2025 · x86-64

| vCPUs | Memory (GB) | Price/min |
| --- | --- | --- |
| 2 | 8 | $0.008 |
| 4 | 16 | $0.016 |
| 8 | 32 | $0.032 |
| 16 | 64 | $0.064 |

## Sandboxes

Isolated development environments on the same machines as your runners.

Compute

Same rates as runners

Billed for

Reserved time

Platforms

Linux x86 / ARM · macOS · Windows

macOS has a 24-hour minimum reservation, then the same per-minute rate.

[Explore Sandboxes](https://avrea.com/sandboxes)

## Git Mirroring

Faster clones and fetches from repository copies close to your workloads. Your Git provider remains the source of truth.

Repository storage

$3.50 /GB/month

Inbound · push, write

$0.06 /GB

Outbound · clone, fetch

$0.15 /GB

Storage and data transfer billed monthly.

[How mirroring works](https://avrea.com/git-mirroring)

## Add-ons

### Static IP

$100 /IP/month

Fixed outbound IPs for firewall rules and IP-restricted services.

Billed per allocated address.

[Set up a static IP](https://docs.avrea.com/static-ip/)

### Persistent Disk

$0.50 /GB/month

Keep build outputs, dependencies and toolchains between jobs.

Billed for provisioned storage, prorated.

[Set up a persistent disk](https://docs.avrea.com/persistent-disks/)

### Extra cache storage

~$0.50 /GB/month

25 GB included per repository. Expand your cache as your builds grow.

$0.0007/GB/hour, billed for hourly peak usage above the included storage.

[Manage cache storage](https://docs.avrea.com/cache/storage/)

## Estimate your CI savings

Compare your monthly compute costs on GitHub Actions and Avrea.

How the estimate works

Example for Linux x86 · 4 vCPU runners: 100,000 GitHub Actions minutes at $0.012/minute cost $1,200. At an assumed 2x speedup, the same work takes 50,000 Avrea minutes at $0.008/minute, costing $400. These are USD list prices before credits, included GitHub minutes and discounts. Your runtime depends on the workload and cache state.

## Avrea loves open source

Maintain an active public repository? Apply for free credits for your project.

The Avrea capybara riding a rocket along a path of nodes, from a sprouting seedling to a planet

## Startup program

Eligible startups receive free credits to build and test on Avrea.

To be eligible, your startup must meet all of the following:

- Backed by a VC or accelerator in the Avrea startup program
- Less than $5M in funding
- Less than $5M in ARR
- Less than 3 years old

Check with your VC or accelerator that they participate. If they don’t, they can apply at [startups@avrea.com](mailto:startups@avrea.com).

## Frequently asked questions

What can I try for free?

Pay as you go includes $12 in credit each month per organization. That covers 3,000 minutes on a 2-vCPU Linux x86 runner; other sizes use credit at their listed rates. The credit renews monthly.

What do I pay for?

You pay for compute, Git Mirroring storage and data transfer at the listed rates. Observability and 25 GB of cache storage per repository are included. Extra cache storage, static IPs and persistent disks have separate charges.

Are there subscription or per-seat fees?

Pay as you go has no monthly subscription or per-seat fees. Enterprise pricing is agreed separately.

How is usage billed?

Runners are billed by the second at the per-minute rates above. Sandboxes are billed for reserved time, with a 24-hour minimum for macOS. Git Mirroring storage and data transfer are metered and billed monthly. Extra cache storage is billed hourly for peak usage above 25 GB per repository. Static IPs are billed monthly per allocated address. Persistent disks are billed for provisioned storage, prorated for partial months.

How do I access Avrea CI and Avrea AI?

Both are available by request during beta and are included in Pay as you go. The listed usage charges still apply.

[Request access](https://avrea.com/request-access)

Do you offer custom pricing?

Yes. Enterprise offers custom pricing, capacity and support. Contact us to discuss your usage and requirements.

[Discuss Enterprise pricing](https://avrea.com/contact)

How do I try Avrea with my existing workflows?

Install the Avrea GitHub App, copy a GitHub Actions workflow and change its runner label to an Avrea runner. Run both workflows to compare the results.

[Read the setup guide](https://docs.avrea.com/getting-started/)

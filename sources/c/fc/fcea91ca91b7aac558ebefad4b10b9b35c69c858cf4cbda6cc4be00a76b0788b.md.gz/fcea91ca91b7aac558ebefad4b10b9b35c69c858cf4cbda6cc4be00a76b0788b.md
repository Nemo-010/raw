##### Migre a sua empresa para a Cloud Privada ELENDE — Mais Segurança, Performance e Controlo

# Configurar

###### Por favor corrija os seguintes erros para continuar:

## VPS Linux 1

- **1** vCPU
- **2 GB** RAM
- **20 GB** DISCO
- **Tráfego** Ilimitado
- **Sistema Operativo** Linux
- **1** IP Público
- **Virtualização** KVM

## Escolher Ciclo de Pagamentos

### Mensalmente      8.625,00 Kz

-

### Trimestralmente      24.600,00 Kz

Poupança 5%

25.875,00 Kz

### Semestralmente      46.560,00 Kz

Poupança 10%

51.750,00 Kz

### Anualmente      87.975,00 Kz

Poupança 15%

103.500,00 Kz

## Extra vCPU's

03200008162432

## Extra Disk (GB)

05000000125250375500

## Extra IPv4

0253000063126190253

## Configurar Servidor

Hostname

Password

Senha Segura: pelo menos 5 caracteres

pelo menos 5 caracteres

Gerar senha


NS1 Prefixo

NS2 Prefixo

## Informação adicional  _(os campos obrigatórios estão marcados com \*)_

OS \*noneAlmalinux 8.10Almalinux 9.7Almalinux 10.1CentOS 8.10Centos 9.6Centos 10.0Debian 11Debian 12Debian 13Fedora 42Rocky-8.10Rocky Linux 9.7Rocky Linux 10.1Suse 15.1Ubuntu 22.04Ubuntu 24.04

## Resumo da configuração

SERVIDORES VIRTUAIS KVM -
VPS Linux 1
8.625,00 Kz/mês

- Extra vCPU's: 0Grátis0,00 Kz
- Extra Disk (GB): 0Grátis0,00 Kz
- Extra IPv4: 0Grátis0,00 Kz

Total a pagar hoje

8.625,00 Kz


Continuar

Continuar

Direitos autorais © 2026 ELENDE - TECNOLOGIAS DE INFORMACAO, LDA.. Todos os direitos reservados.

_![](https://elende.ao/templates/lagom2/assets/img/page-manager/express.webp)_

- [Termos de Serviço](https://elende.ao/legal/terms-of-services)
- [Politica de Privacidade](https://elende.ao/legal/privacy-policy)
- [Voltar ao topo](https://elende.ao/cart.php?a=confproduct&i=0#)

![](https://elende.ao/assets/img/overlay-spinner.svg)
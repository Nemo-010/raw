## Build and deploy modern apps and microservices using serverless containers

Azure Container Apps is a fully managed serverless container service that scales dynamically based on HTTP traffic or events.

## Explore pricing options

- ### Pay as you go

  Pay for compute capacity by the second, with no long-term commitments or upfront payments. Increase or decrease consumption on demand.

  [Learn more](https://azure.microsoft.com/en-us/pricing/purchase-options/pay-as-you-go/)
- ### Azure savings plan for compute

  Save money across select compute services globally by committing to spend a fixed hourly amount for 1 or 3 years, unlocking lower prices until you reach your hourly commitment. Suited for dynamic workloads while accommodating for planned or unplanned changes.

  [Learn more](https://azure.microsoft.com/en-us/pricing/offers/savings-plan-compute/)

Apply filters to customize pricing options to your needs.

Prices are estimates only and are not intended as actual price quotes. Actual pricing may vary depending on the type of agreement entered with Microsoft, date of purchase, and the currency exchange rate. Prices are calculated based on US dollars and converted using London closing spot rates that are captured in the two business days prior to the last business day of the previous month end. If the two business days prior to the end of the month fall on a bank holiday in major markets, the rate setting day is generally the day immediately preceding the two business days. This rate applies to all transactions during the upcoming month. Sign in to the [Azure pricing calculator](https://azure.microsoft.com/en-us/pricing/calculator/) to see pricing based on your current program/offer with Microsoft. Contact an [Azure sales specialist](https://azure.microsoft.com/en-us/contact/pricing/) for more information on pricing or to request a price quote. See [frequently asked questions](https://azure.microsoft.com/en-us/pricing/) about Azure pricing.

Region:

Currency:

US government entities are eligible to purchase Azure Government services from a licensing solution provider with no upfront financial commitment, or directly through a pay-as-you-go online subscription.

[Learn more](https://azure.microsoft.com/en-us/explore/global-infrastructure/government/)

Important—The price in R$ is merely a reference; this is an international transaction and the final price is subject to exchange rates and the inclusion of IOF taxes. An eNF will not be issued.

US government entities are eligible to purchase Azure Government services from a licensing solution provider with no upfront financial commitment, or directly through a pay-as-you-go online subscription.

[Learn more](https://azure.microsoft.com/en-us/explore/global-infrastructure/government/)

Important—The price in R$ is merely a reference; this is an international transaction and the final price is subject to exchange rates and the inclusion of IOF taxes. An eNF will not be issued.

# Consumption plan

Azure Container Apps consumption plan is billed based on per-second resource allocation and requests. The first 180,000 vCPU-seconds, 360,000 GiB-seconds, and 2 million requests per subscription per month are free. Beyond that, you pay for what you use on a per second basis based on the number of vCPU-s and GiB-s your applications are allocated.

Applications scale on-demand based on requests and events. Container Apps replicas are billed for active usage when they are running. An application can be configured to scale to zero replicas when there are no requests or events to process. No usage charges apply when an application is scaled to zero.

You can optionally configure Container Apps with a minimum number of replicas to be always running in idle mode. When an application scales down to its minimum number of replicas, usage is charged at a reduced idle rate when a replica is inactive. A replica enters active mode and is charged at the active rate when it is starting up, when it is processing requests, or when its vCPU or bandwidth usage are above the active billing thresholds1.

For Container Apps jobs, resources consumed by each execution are billed at the active rate from its start to completion. No usage charges apply when a job is not running executions.

Resources consumed by managed Java components are billed at the active/idle rates. You may delete components that are no longer in use to stop incurring charges related to those components.

Azure Container Apps Express and Sandboxes follow the same pay-per-second pricing as Consumption Plan.

## Resource consumption

### Active usage

1A replica is active when vCPU usage is above 0.01 cores or when data received is above 1,000 bytes per second.

| Meter | Pay as you go Price* | 1-year Savings Plan Price* | 3-year Savings Plan Price* |
| --- | --- | --- | --- |
| vCPU (seconds) | $- per second | $- per second | $- per second |
| Memory (GiB-Seconds) | $- per second | $- per second | $- per second |

### Serverless GPU

Consumption-based serverless GPUs allow near real-time inferencing for custom models, SLM fine-tuning and other machine learning tasks with instant serverless scale that goes down to zero when not in use.

| Meter | Pay as you go Price* | 1-year Savings Plan Price* | 3-year Savings Plan Price* |
| --- | --- | --- | --- |
| NC T4 v3 | $- per second | $- per second | $- per second |
| NC A100 v4 | $- per second | $- per second | $- per second |

### Idle usage

| Meter | Pay as you go Price* | 1-year Savings Plan Price* | 3-year Savings Plan Price* |
| --- | --- | --- | --- |
| vCPU (seconds) | $- per second | $- per second | $- per second |
| Memory (GiB-Seconds) | $- per second | $- per second | $- per second |

## Requests

Container Apps are billed based on the total number of requests2 processed each month. The first two million requests are included free per subscription per month.

| Meter | Pay as you go price | 1 year savings plan | 3 year savings plan |
| --- | --- | --- | --- |
| Requests | $- per million | $- per million | $- per million |

## Dynamic sessions

Dynamic sessions in Azure Container Apps enable you to run untrusted code securely at scale.

| Meter | Pay as you go price | 1 year savings plan | 3 year savings plan |
| --- | --- | --- | --- |
| Platform-managed built-in container (Python, Node.js, Shell) | $- per session-hour | $- per session-hour | $- per session-hour |

# Dedicated plan

Azure Container Apps Dedicated plan provides a single tenancy guarantee, access to specialized hardware, and more predictable pricing. Billing for the Dedicated plan is based on the number of vCPU seconds and gibibyte (GiB) seconds allocated across instances. In addition, you are billed a base price for the Dedicated plan management.

When creating apps in the Dedicated plan you can choose from several workload profiles, each with different amounts of vCPUs and GiBs of memory. You will be billed for the total number of vCPUs and memory provisioned in this workload profile, per second that each instance is running. More than one app can run in a single workload profile depending on how many resources each app requires and the resources available in the workload profile. These workload profiles can automatically scale out to multiple instances as needed.

| Meter | Pay as you go price | 1 year savings plan | 3 year savings plan |
| --- | --- | --- | --- |
| Management (hour)* | $- per hour | $- per hour | $- per hour |
| vCPU (hour) | $- per hour | $- per hour | $- per hour |
| Memory (GiB-hour) | $- per hour | $- per hour | $- per hour |
| GPU (hour) | $- per hour | $- per hour | $- per hour |

*vCPU and memory prices do not apply to GPU workload profiles.*

*Dynamic sessions in Azure Container Apps dedicated plan has no premium or additional charges outside of the Azure Container Apps charges.*

## Azure pricing and purchasing options

### Connect with us directly

Get a walkthrough of Azure pricing. Understand pricing for your cloud solution, learn about cost optimization and request a custom proposal.

[Talk to a sales specialist](https://azure.microsoft.com/en-us/contact/pricing/)

### See ways to purchase

Purchase Azure services through the Azure website, a Microsoft representative, or an Azure partner.

[Explore your options](https://azure.microsoft.com/en-us/pricing/purchase-options/)

## Additional resources

### [Azure Container Apps](https://azure.microsoft.com/en-us/products/container-apps/)

Learn more about Azure Container Apps features and capabilities.

### [Pricing calculator](https://azure.microsoft.com/en-us/pricing/calculator/?service=container-apps)

Estimate your expected monthly costs for using any combination of Azure products.

### [SLA](https://azure.microsoft.com/en-us/support/legal/sla/container-apps/)

Review the Service Level Agreement for Azure Container Apps.

### [Documentation](https://aka.ms/containerapps/docs)

Review technical tutorials, videos, and more Azure Container Apps resources.

## Frequently asked questions

[Frequently asked questions about Azure pricing](https://azure.microsoft.com/en-us/pricing/)

- Yes. You can scale to zero and only pay for when your app is active in response to events and/or requests. You can also optionally choose to keep a minimum capacity always running in idle mode to optimize response times based on your needs. This capacity is charged at a reduced rate when you are not processing any requests.
- The first 180,000 vCPU-seconds, 360,000 GiB-seconds, and 2 million requests each month are free. Beyond that, you pay for what you use on a per second basis based on the number of vCPU-s and GiB-s your applications consume.
- Active usage occurs while your container is starting or while there is at least one request being processed by the application. By default, applications scale to zero. You can also configure Container Apps with a minimum number of instances so they’re always running in idle mode. Idle usage is charged at a reduced rate when the application isn’t processing any requests.

Talk to a sales specialist for a walk-through of Azure pricing. Understand pricing for your cloud solution.

[Request a pricing quote](https://azure.microsoft.com/en-us/contact/pricing/#contact-sales)

Get free cloud services and a $200 credit to explore Azure for 30 days.

[Try Azure for free](https://azure.microsoft.com/en-us/free/)

# Accounts

Sign up, manage sign-in methods, update your profile and security settings, and delete your account.

An account is your individual identity on the Speechmatics platform. Accounts belong to one or more [workspaces](/administration/workspaces-concepts.md), where you act as either an Admin or a Member.

## Sign up and verification[​](#sign-up-and-verification "Direct link to Sign up and verification")

1. Go to [portal.speechmatics.com/signup](https://portal.speechmatics.com/signup).
2. Sign up with email and password, or with a supported OAuth provider (Google or GitHub).
3. If you signed up with email, verify your email address using the link sent to your inbox.

If your email address matches a [verified domain](/administration/domain-verification.md), you join that workspace automatically. Otherwise, a new workspace is created for you.

## Sign-in methods[​](#sign-in-methods "Direct link to Sign-in methods")

You can sign in with email and password, or with a connected OAuth account. Speechmatics supports Google and GitHub. Manage connected accounts under **[Settings > Profile > User](https://portal.speechmatics.com/settings/profile/user)**.

The available sign-in methods are determined by your workspace. If your workspace has [SSO](/administration/sso.md) enabled, sign in through your identity provider instead.

## Profile and security[​](#profile-and-security "Direct link to Profile and security")

Go to **Settings > Profile** in the portal to manage your account.

* **User**: update your name, view your email address, and manage connected OAuth accounts.
* **Security**: change your password and manage multi-factor authentication (MFA).
* **Signed-in devices**: view active sessions and sign out of individual devices or all other devices at once.

## Delete your account[​](#delete-your-account "Direct link to Delete your account")

Deleting your account is permanent. You will no longer be able to create an account with the same email address.

1. Go to **Settings > Profile > User**.
2. In the **Delete account** section, click **Delete account**.
3. Confirm the deletion.

You cannot delete your account while you are an Admin in multiple workspaces. Transfer Admin access to another member first, or contact <support@speechmatics.com>.

## Next steps[​](#next-steps "Direct link to Next steps")

* [Workspaces concepts](/administration/workspaces-concepts.md): how workspaces organize members, projects, and billing.
* [Single sign-on (SSO)](/administration/sso.md): sign in through your organization's identity provider.

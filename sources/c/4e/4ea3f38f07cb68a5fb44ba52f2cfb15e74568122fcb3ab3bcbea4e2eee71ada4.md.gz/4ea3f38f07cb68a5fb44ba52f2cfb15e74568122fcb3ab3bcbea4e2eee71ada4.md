13,000+ game sessions launched

# Port forwarding  
 for game servers

Launch Minecraft, CS 1.6, CS2, Valheim, Rust, and other games. Use a ready-made preset or your own TCP/UDP ports — no public IP, router setup, or Hamachi.

Any TCP/UDP port Ready-made presets Minecraft with plugins

[Download free](https://portplay.net/latest/portplay-windows-setup.exe) How it works

Windows 10/11 · 6.8 MB · Your friends install nothing

1,500+

active gamers

TCP + UDP

custom ports

<10 ms

added latency

PortPlay

PortPlay

Connected

Minecraft + Simple Voice Chat

25565/TCP • 24454/UDP • 3 players online

Server address

play.portplay.net:25565

App Screenshots (click to view)

Features

## Everything you need  
to play with friends

No router headaches, no public IP, no complicated setup

### Instant launch

Download the app, sign in, and click connect. Your server is ready to share in minutes, without touching your router.

### Secure connection

Encrypted tunnels protect traffic in transit. Players connect through a PortPlay address instead of seeing your home network directly.

### Low added latency

Designed for responsive online play. Latency depends on your location and selected node, with a setup optimized for smooth sessions with friends.

### Windows app

Native Windows app with tray support. It stays out of the way and automatically reconnects if the link drops.

### Custom TCP/UDP ports

Set the ports you need. Simple Voice Chat, Geyser, and other plugins that require an extra TCP or UDP port work too.

### Traffic stats

Track current usage in real time and review your tunnel history, sessions and active connections.

How it works

## Four simple steps  
to your own server

No advanced networking knowledge required

### Download the app

Get the PortPlay installer for Windows. Setup takes less than a minute.

### Sign in

Create an account or continue with Google. Getting started is fast and free.

### Choose a game or port

Use a ready-made game preset or enter your own TCP/UDP ports. PortPlay creates the tunnel for you.

### Invite your friends

Copy the address and share it. Your friends join just like they would on a regular public server.

Available now

## Ready-made game presets.  
Custom ports for everything else

Choose a game from the list or forward any TCP/UDP port manually

Available

Minecraft

Java, Bedrock, plugins

Multiple ports

Minecraft plugins

Voice Chat, Geyser, and more

Available

CS2

Counter-Strike 2

Available

CS 1.6

Counter-Strike 1.6

Available

Terraria

2D Survival

Available

Valheim

Survival & Co-op

Available

Rust

Game and RCON ports

Any game

Your game

Any TCP/UDP port

Community

## How PortPlay  
helps players

Reviews from people who have hosted a server with PortPlay

"Finally a tool that actually works. Hamachi was too complicated for my friends, and my ISP has CGNAT so I couldn't port forward. PortPlay got our Minecraft server up in literally 2 minutes. Highly recommend!"

Oops

"Valve killed local servers in CS2, so practicing with my team was impossible. We found this tool, and now I just host a dedicated server on my PC and give my friends the IP. Latency is amazing!"

Birzaliffa

Works as advertised. Used it to forward my local Minecraft server. Low latency, stable connection. Simple interface - server detected automatically. Launched it, got an IP, and my buddies were online in seconds. Reliable tool for quick gaming with friends. Will use again.

Ducalis

"I used to spend hours trying to bypass my router's firewall for Terraria. With PortPlay, I literally just clicked connect and sent the IP to my friends on Discord. Way better than Ngrok."

O_OFox

"Works exactly as advertised. Got tired of network errors and VPNs. This is much cleaner and doesn't require my friends to sign up or download anything."

CoopFox

Kurdik

"My university blocks port forwarding on their campus network. With PortPlay I can finally host a dedicated server straight from my dorm room without tweaking any settings. Absolute game changer!"

DormHost

kolombo

Pricing

## Simple plans,  
no surprises

Start free and scale up whenever you need more performance

Free

€0

free forever

- Session 24h
- Max players 10
- Server selection No
- Ports 1
- Speed 10 Mbps
- Latency Standard

[Start free](https://portplay.net/latest/portplay-windows-setup.exe)

POPULAR

Pro

€1.49

per month

- Session 6 months
- Max players 50
- Server selection Yes
- Ports 3
- Speed 50 Mbps
- Latency Low

[Install and choose Pro](https://portplay.net/latest/portplay-windows-setup.exe)

Activate the plan inside PortPlay after installation.

Pro Max

€4.99

per month

- Session Unlimited
- Max players Unlimited
- Location selection Yes
- Ports 10
- Speed 100+ Mbps
- Latency Lowest

[Install and choose Pro Max](https://portplay.net/latest/portplay-windows-setup.exe)

Activate the plan inside PortPlay after installation.

FAQ

## Frequently asked questions

If you cannot find the answer, contact us

Port forwarding lets players outside your home network connect to your game server. Normally this requires router changes or a public IP. PortPlay creates a secure tunnel and gives you a stable public endpoint without the usual setup hassle.

No. That is exactly what PortPlay is designed for. You do not need a public IP, and you do not need to configure your router manually. The app establishes an outbound connection that works behind NAT and CGNAT.

Added latency depends on your region, ISP and the selected server location. In many cases it is small enough to stay comfortable for casual and co-op play.

No. Only the person hosting the server needs PortPlay. Friends join through a regular server address with no account, extra software, or network setup.

Yes. Java usually uses TCP port 25565, Bedrock and Geyser use UDP port 19132, and Simple Voice Chat uses UDP port 24454 by default. PortPlay can open the linked ports automatically through a preset.

The practical limit depends on your PC performance, game server settings and internet connection. PortPlay controls tunnel capacity, but your hardware still matters for the final experience.

Yes. Minecraft, CS 1.6, CS2, Valheim, Rust, and Terraria have ready-made options, but the list does not limit you. Choose custom setup, enter the local port and TCP or UDP, and connect almost any dedicated server.

[Message us on Telegram](https://t.me/portplay) [Email: [email protected]](https://portplay.net/cdn-cgi/l/email-protection#34474144445b464074445b46404458554d1a5a5140)

Free forever

## Ready to play  
 with friends?

Choose a ready-made game or enter your own TCP/UDP ports. No public IP, router setup, or software for your friends.

[Download for Windows](https://portplay.net/latest/portplay-windows-setup.exe) [Telegram community](https://t.me/portplay)

Windows 10/11 · 6.8 MB · Your friends install nothing

Compute type

Price as

New accounts add one month of credit up front; servers then bill by the hour from that credit.

## General Compute

9 sizes from 512 MB to 128 GB.

Xeon Scalable CPUs

Instance vCPU Memory Storage Network TransferTransfer is pro-rated by the time each server is provisioned. The 2 TB base pool is included once per account. Monthly Hourly Deploy

gc.pico 1 vCPU · 512 MB RAM · 20 GB disk · 2.5 Gbps · 2 TB transfer The lightest bots, probes, and tiny Linux services.

1

512 MB

20 GB

2.5 Gbps

2 TB

$2.50/mo

$0.0034 / hr

[Deploy](https://layeronecloud.com/client/order/layerone-pico/?cadence=hourly)

gc.nano 1 vCPU · 1 GB RAM · 20 GB disk · 2.5 Gbps · 3 TB transfer Bots, personal VPN, and light Linux services.

1

1 GB

20 GB

2.5 Gbps

3 TB

$3.00/mo

$0.0041 / hr

[Deploy](https://layeronecloud.com/client/order/layerone-nano/?cadence=hourly)

gc.micro 1 vCPU · 2 GB RAM · 40 GB disk · 2.5 Gbps · 4 TB transfer Websites, small apps, and private services.

1

2 GB

40 GB

2.5 Gbps

4 TB

$5.00/mo

$0.0068 / hr

[Deploy](https://layeronecloud.com/client/order/layerone-starter/?cadence=hourly)

gc.small 2 vCPU · 4 GB RAM · 60 GB disk · 2.5 Gbps · 5 TB transfer Small production apps, panels, and busier sites.

2

4 GB

60 GB

2.5 Gbps

5 TB

$8.00/mo

$0.0109 / hr

[Deploy](https://layeronecloud.com/client/order/layerone-4g/?cadence=hourly)

gc.medium Popular 4 vCPU · 8 GB RAM · 160 GB disk · 2.5 Gbps · 6 TB transfer Production apps, panels, and modded game servers.

4

8 GB

160 GB

2.5 Gbps

6 TB

$15.00/mo

$0.0205 / hr

[Deploy](https://layeronecloud.com/client/order/layerone-pro/?cadence=hourly)

gc.large 6 vCPU · 16 GB RAM · 320 GB disk · 2.5 Gbps · 10 TB transfer Databases, game networks, and multi-service hosts.

6

16 GB

320 GB

2.5 Gbps

10 TB

$25.00/mo

$0.0342 / hr

[Deploy](https://layeronecloud.com/client/order/layerone-16g/?cadence=hourly)

gc.xlarge 8 vCPU · 32 GB RAM · 500 GB disk · 2.5 Gbps · 12 TB transfer Heavier production workloads and priority support.

8

32 GB

500 GB

2.5 Gbps

12 TB

$45.00/mo

$0.0616 / hr

[Deploy](https://layeronecloud.com/client/order/layerone-enterprise/?cadence=hourly)

gc.2xlarge 16 vCPU · 64 GB RAM · 1000 GB disk · 2.5 Gbps · 14 TB transfer Large databases, CI fleets, and busy game networks.

16

64 GB

1000 GB

2.5 Gbps

14 TB

$85.00/mo

$0.1164 / hr

[Deploy](https://layeronecloud.com/client/order/layerone-64g/?cadence=hourly)

gc.4xlarge 24 vCPU · 128 GB RAM · 2000 GB disk · 2.5 Gbps · 16 TB transfer Heaviest public workloads short of a custom build.

24

128 GB

2000 GB

2.5 Gbps

16 TB

$160.00/mo

$0.2191 / hr

[Deploy](https://layeronecloud.com/client/order/layerone-128g/?cadence=hourly)

### Prepaid credit billing

Plans bill hourly from account credit. Cancel anytime to stop future charges. Credit never expires, and new accounts can refund unused credit within 7 days of signing up.

### Instant deployment

After ordering, your VPS provisions automatically and SSH details are sent as soon as it is ready.

### OS templates available

Choose Debian, Ubuntu, Rocky Linux, AlmaLinux, Alpine Linux, FreeBSD, Windows (BYOL), or pfSense during checkout.

Debian Ubuntu AlmaLinux Rocky Linux Alpine Linux FreeBSD Windows pfSense

Need a custom build?

Public plans go to 24 vCPU and 128 GB RAM. Larger nodes with up to 32 vCPU and 256 GB RAM are available on request.

[Talk to sales](https://layeronecloud.com/contact/?subject=custom-quote)

Cards, wallets, USD stablecoins, and bank transfer.

Visa Mastercard American Express Discover Apple Pay Google Pay Cash App Pay Amazon Pay Alipay USDC USDP USDG ACH bank transfer

Add-ons

## Optional extras for any plan.

2 TB transfer is included per account, plus each server's plan transfer allowance per UTC calendar month, prorated by time provisioned and shared across every server. Add extra TB, IPs, or managed services from the client area at any time. No long-term contract.

### Backup storage

Organization-wide pool for QEMU snapshots and vzdump backups. $1.00 per 10 GB, billed hourly from account credit. Upgrade any time.

+$1.00 /10 GB mo

[Buy backup storage](https://layeronecloud.com/client/services/isos/)

### Additional IPv4

Extra dedicated IPv4 address billed hourly while reserved.

+$0.0041 /hr

[Manage in client area](https://layeronecloud.com/client/network/floating-ips/)

### Extra Bandwidth

2 TB included per account, plus each server's plan allowance, shared across the pool. Add more TB whenever you need it; it renews monthly until you cancel.

$3.00 /TB per month

Transfer beyond your pool bills at the same $3.00/TB.

### Managed Services

We handle OS patches, security hardening, and monitoring so you can focus on your app.

+$25 /mo

[Enable on a server](https://layeronecloud.com/client/services/)

Included

## The same platform on every plan.

vCPU, RAM, and disk change with the size. Port speed is 2.5 Gbps on General Compute and 10 Gbps on Network Optimized. Every plan includes DDoS, root access, and the 99.9% SLA. The account transfer pool starts at 2 TB, with each VPS adding its plan's transfer allowance each month, prorated by time provisioned. Backup storage is an optional organization-wide pool at $1.00 per 10 GB per month.

- Skylake-SP or better
- 2.5 Gbps General Compute · 10 Gbps Network Optimized
- Dedicated IPv4
- 2 TB transfer included per account, plus each server's plan transfer allowance per month, prorated by time provisioned
- DDoS protection
- Hypervisor firewall
- Full root access
- Browser VNC console
- 99.9% uptime SLA
- Instant deployment after ordering
- Debian, Ubuntu, Rocky Linux, AlmaLinux, Alpine Linux, FreeBSD, Windows (BYOL), pfSense
- Priority support on gc.xlarge and larger

FAQ

## Frequently asked questions.

[Full FAQ](https://layeronecloud.com/faq/)

### Can I upgrade my plan later?

Yes. Upgrade to a larger plan any time from the client area. Billing moves to the new rate straight away, and because we meter by the hour there is no pro-rata invoice to settle. The extra vCPU, memory and disk are applied on your next restart, so nothing goes offline until you choose to reboot, and you can cancel a scheduled upgrade before it is applied. Downgrades are not self-serve; contact support.

### Do you offer refunds?

Once, for new accounts. Within 7 days of signing up you can refund unused credit you paid by card from Billing in the client portal; it goes back to the original payment method. Delete your servers first. Credit you have used, and bonus or promotional credit, is not refunded. After the first 7 days all payments are final and account credit is non-refundable, except where a refund is required by applicable law. Credit does not expire. See Section 6 of our [Terms of Service](https://layeronecloud.com/terms/).

### Which operating systems are available?

Debian, Ubuntu, AlmaLinux, Rocky Linux, Alpine Linux, FreeBSD, Windows, and pfSense are available during checkout. You can also open a ticket if you need a specific template version or custom ISO path.

### Is DDoS protection really included for free?

Yes. Every LayerOne VPS sits behind always-on layer 3 / 4 DDoS mitigation at no extra cost. There's no per-attack fee and no surprise bills if you're targeted.

### How quickly will my server be ready?

Under 60 seconds in almost every case. Once your order completes, the VPS provisions automatically and you get root SSH credentials immediately. No manual approval, no waiting on a human.

### What payment methods do you accept?

Visa, Mastercard, American Express, Discover, Apple Pay, Google Pay, Cash App Pay, Amazon Pay, Alipay, and USD stablecoins: USDC on Ethereum, Solana, Polygon, Base, and Tempo; USDP for US-based transactions on Ethereum and Solana; and USDG for US-based transactions on Ethereum. US bank transfer (ACH) is available for account credit top-ups. PayPal is available for one-time credit purchases and monthly credit subscriptions.

### How does bandwidth work?

General Compute includes a 2.5 Gbps port. Network Optimized includes a 10 Gbps port. Transfer starts with 2 TB included per account each UTC calendar month. Each server then earns its plan's transfer allowance over the month, prorated by time provisioned and shared across every server. Stopped servers keep earning; destroying one stops new credits, and earned transfer stays until the monthly reset. Extra transfer is $3.00/TB per calendar month, whether you add Extra Bandwidth blocks in advance or usage goes beyond the pool. Resize for CPU and RAM; buy transfer when traffic spikes.

### Do you offer IPv6?

IPv6 is on the roadmap and is not available yet. Every VPS includes a dedicated IPv4 address by default. Private-only deploy is optional and has no internet path.

### Do you offer private virtual networks?

Yes. Create isolated virtual networks from Networking in the client portal. Members on the same network can talk to each other. The platform blocks traffic entering or leaving the network, and there is no platform NAT. An account can create 10 virtual networks by default; contact support if you need more. A VM may attach to more than one virtual network. The platform does not route between them. [How to set up a virtual network](https://layeronecloud.com/blog/set-up-a-virtual-network-layerone/).

### Can I run game servers or a personal VPN?

Game servers, personal VPNs, development tooling, and most legitimate uses are fine. We do not allow spam, phishing, malware distribution, or anything illegal in our jurisdiction. Full details are in our Acceptable Use Policy.

## Pick a plan. Launch in 60 seconds.

No setup fees and no minimum contract. Plans meter hourly from prepaid account credit, and your VPS deploys automatically after ordering.

[Get started](https://layeronecloud.com/client/order/layerone-nano/) [Talk to sales](https://layeronecloud.com/contact/)

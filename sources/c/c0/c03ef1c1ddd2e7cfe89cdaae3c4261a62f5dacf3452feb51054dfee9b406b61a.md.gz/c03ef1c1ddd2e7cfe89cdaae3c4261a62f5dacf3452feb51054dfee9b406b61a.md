- Hospedagem de sites a partir de R$ 29 /mês [→](https://ayoocloud.com.br/Hospedagem-directadmin)
- VPS Canadá a partir de R$ 39,90 /mês* [→](https://ayoocloud.com.br/Vps)
- Servidor GTA a partir de R$ 4,90 /mês [→](https://ayoocloud.com.br/GTA-Samp)
- VPS OtServ a partir de R$ 43,90 /mês* [→](https://ayoocloud.com.br/Vps-Otserv)

* Com 20% de desconto nos 3 primeiros meses usando o cupom AYOO20 no carrinho. Depois, VPS Canadá a partir de R$ 49,90 e OtServ a partir de R$ 54,90.

1. 01

  ### VPS Canadá

  Windows ou Linux com acesso root, IP dedicado e rede de 1 Gbps. Para sites, sistemas, bots e aplicações.

  CA R$ 39,90 * [Ver planos](https://ayoocloud.com.br/Vps)
2. 02

  ### VPS França — Oferta

  Mais vCPU e memória por menos. Poucas unidades por lote, com backup especial incluso.

  FR R$ 109,52 * [Ver ofertas](https://ayoocloud.com.br/Vps-Oferta)
3. 03

  ### VPS Trader

  MetaTrader 4 e 5, robôs e EAs ligados 24 horas, sem depender do seu computador.

  CA R$ 47,90 * [Ver planos](https://ayoocloud.com.br/Vps-Trader)
4. 04

  ### Servidores GTA

  SA-MP, OpenMP e MTA com MySQL, painel com console e SFTP. Você escolhe pela quantidade de slots.

  BR R$ 4,90 [Ver planos](https://ayoocloud.com.br/GTA-Samp)
5. 05

  ### VPS OtServ

  Para Baiak, Global e outros mapas, com IP dedicado, painel e backup incluso.

  CA R$ 43,90 * [Ver planos](https://ayoocloud.com.br/Vps-Otserv)
6. 06

  ### Hospedagem e Revenda

  cPanel no Brasil ou DirectAdmin, com SSL grátis, e-mails profissionais e backup diário. Revenda para vender com a sua marca.

  BR R$ 29 [Ver planos](https://ayoocloud.com.br/Hospedagem-directadmin)

* Valor com 20% de desconto nos 3 primeiros meses usando o cupom AYOO20 no carrinho. O valor normal aparece em cada plano.

| Plano | vCPU | RAM | SSD NVMe | 3 primeiros meses | Depois | Contratar |
| --- | --- | --- | --- | --- | --- | --- |
| Ayoo VPS I | 2 | 4 GB | 50 GB | R$ 39,90 | R$ 49,90 |  |
| Ayoo VPS II | 4 | 4 GB | 70 GB | R$ 63,90 | R$ 79,90 |  |
| Ayoo VPS III mais pedido | 4 | 6 GB | 100 GB | R$ 87,90 | R$ 109,90 |  |
| Ayoo VPS IV | 6 | 8 GB | 120 GB | R$ 119,90 | R$ 149,90 |  |
| Ayoo VPS V | 8 | 10 GB | 140 GB | R$ 159,90 | R$ 199,90 |  |
| Ayoo VPS VI | 8 | 16 GB | 160 GB | R$ 207,90 | R$ 260,00 |  |

Todos com transferência ilimitada, IP dedicado, rede de 1 Gbps, backup incluso e reinstalação ilimitada. Windows Server 2019/2022, Ubuntu 22/24 e Debian 12/13.

## Abre o servidor hoje,chama a galera à noite.

Servidores com ping BR, MySQL incluso e painel com console, SFTP e backups. Contratou, o servidor fica pronto pra subir o seu gamemode.

- Ping BR
- MySQL incluso
- Console em tempo real
- SFTP e backups

- [GTA SA-MP Pawn · 25 a 500 slots a partir de R$ 4,90](https://ayoocloud.com.br/GTA-Samp)
- [GTA OpenMP Pawn · 25 a 200 slots a partir de R$ 4,90](https://ayoocloud.com.br/GTA-OpenMP)
- [GTA MTA Lua · 25 a 200 slots a partir de R$ 6,90](https://ayoocloud.com.br/GTA-MTA)
- [OtServer Baiak · Global · outros a partir de R$ 43,90*](https://ayoocloud.com.br/Vps-Otserv)

Tela de backup do painel AyooCloud com franquia de 60 GB e pontos de restauração

Tela de backup do painel AyooCloud com franquia de 60 GB e pontos de restauração

## Você resolve sozinho.Sem esperar ticket.

O painel das VPS foi feito por nós, então ele faz exatamente o que você precisa no dia a dia.

Liga, desliga e reinicia

Com stop forçado quando a máquina trava.

Reinstalação ilimitada

Troque de sistema quantas vezes quiser.

Backup com 60 GB grátis

Agendamento diário e pontos de restauração.

Console VNC e troca de senha

Acesso mesmo se o SSH ou o RDP cair.

Alertas no Telegram ou e-mail

Aviso quando o servidor fica online ou offline.

Migração de outra empresa

Envie seu backup e a gente sobe aqui.

BR

### Brasil

Hospedagem e revenda cPanel e servidores GTA.

CA

### Canadá

VPS, VPS Trader, VPS OtServ e VPS para bots.

FR

### França

VPS em oferta com Intel Xeon e proteção DDoS.

Tem taxa de ativação?

Não. Você paga só o plano. A ativação acontece logo depois da confirmação do pagamento.

O preço muda depois?

Os planos de VPS, Trader, OtServ e das ofertas têm 20% de desconto nos 3 primeiros meses usando o cupom AYOO20 no carrinho. Depois disso vale o valor normal, que já aparece do lado de cada plano. Os servidores GTA e a hospedagem não têm essa promoção, então o valor é sempre o mesmo.

A VPS fica no Brasil?

As VPS ficam no Canadá e as ofertas ficam na França. A hospedagem cPanel, a revenda cPanel e os servidores GTA ficam no Brasil.

Posso usar Windows?

Sim. As VPS aceitam Windows Server 2019 e 2022, além de Ubuntu e Debian. Você pode reinstalar pelo painel quando quiser.

A VPS Trader serve para MetaTrader?

Sim. Ela é indicada para MetaTrader 4 e 5, robôs e EAs que precisam ficar ligados 24 horas.

Quais formas de pagamento vocês aceitam?

Pix, boleto e cartão de crédito ou débito.

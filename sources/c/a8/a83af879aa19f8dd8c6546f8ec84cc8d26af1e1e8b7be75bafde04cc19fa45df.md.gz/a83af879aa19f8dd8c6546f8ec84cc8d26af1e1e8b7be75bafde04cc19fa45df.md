**Notice:** The English version of all legal agreements and policies is the sole official and binding version of this document. Translations may be provided solely for convenience to assist with reading and understanding, but they have no legal effect. In case of any inconsistency or conflict between a translation and the English version, the English version shall take precedence.

**Effective date:** [2025.06.11]

**Contracting entity:** LumaDock Ltd., trading as “**LumaDock**” (“**LumaDock**”, “we”, “us”, “our”), company no. 15844051. Registered office: DNS House, 382 Kenton Road, Harrow, Greater London, United Kingdom, HA3 8DP. Business address: 13 Hanover Square, W1S 1HN London, United Kingdom. LumaDock Ltd designs, owns or leases, and operates infrastructure and Services made available under the LumaDock brand via a global network of data centres and network locations in the United Kingdom, the European Union and other regions worldwide. The specific regions and availability zones applicable to a given Service are those indicated in the relevant Service description, Order form and/or control panel.

---

## Table of Contents

1. Definitions
2. Scope, Acceptance, Entire Agreement
3. Eligibility, Account Registration & Security
4. Ordering, Billing, Currency, Taxes, Renewal
5. Delivery, Postponement, Suspension, Reactivation
6. Non-Payment & Data Deletion
7. Upgrade / Downgrade & Plan Changes
8. Refunds & Money-Back Guarantee
9. Tariff / Price Changes
10. Payment Processing, Saved Cards & Recurring Payments
11. Credit / Deposit
12. Promotions & Promotional Codes
13. Liability; Indemnity
14. Data Integrity, Security of Applications & Devices
15. Support: Identification, Channels, Scope & Limits
16. Managed VPS vs. Unmanaged / IaaS
17. Compromise & Security Incidents
18. Data Migration & Transfers
19. Support Hours Accounting
20. Rules for Resellers & VPS Owners
21. Content Policy
22. Acceptable Use & Email Policies (Overview)
23. Dedicated IP Policy
24. Resources, Fair Use, “Unlimited/Unmetered”
25. Service Level Agreement (SLA)
26. Privacy; GDPR; DPA
27. General Legal: Force Majeure, Assignment, Notices, Severability, Waiver, Survival
28. Governing Law & Jurisdiction
29. Language of the Agreement
30. Changes to these Terms

---

## 1. Definitions

**“Account”** means the Customer’s LumaDock account used to order and manage Services via the control panel, API, or any other interface made available by LumaDock.

**“Customer”** means the individual or legal entity purchasing or using the Services. Where the Customer is a legal entity, the person accepting these Terms represents that they are authorised to bind that entity.

**“Services”** means hosting and cloud services provided by LumaDock, including (without limitation) Virtual Private Servers (VPS), high-performance VPS, GPU servers, virtual datacenter resources, bare-metal and dedicated servers, storage and backup services, network and security services (including DDoS mitigation and firewalls), managed hosting, licensing, monitoring, and ancillary professional services, as further detailed in the applicable Service descriptions and Orders.

**“Order”** means an electronic or written order, configuration, or signup submitted by the Customer (including through the control panel or order forms) and accepted by LumaDock.

**“Service Term”** means the initial service period selected by the Customer during ordering (for example, monthly or annually) plus any renewal periods, if applicable.

**“Control Panel”** means the online interface provided by LumaDock or its billing platform for management of the Account and Services.

**“Customer Data”** means any data, content, files, software, configurations, logs, personal data, or other information that Customer or its users upload to, run on, store in, or transmit via the Services.

**“AUP”** means the Acceptable Usage Policy.

**“Anti-Spam Policy”** means the policy governing email and bulk messaging.

**“SLA”** means the Service Level Agreement.

**“DPA”** means the GDPR Data Processing Agreement.

**“Sub-processor”** means any third party engaged by LumaDock to assist in providing the Services.

**“Third-Party Services”** means any third-party software, licenses, hardware, domains, SSL certificates or additional services provided through or in connection with LumaDock but not owned or controlled by LumaDock.

**“Business Day”** means Monday to Friday, excluding UK public holidays.

**“Applicable Law”** means all applicable laws, regulations, ordinances, rules, codes and orders of any competent governmental or regulatory authority.

**“Service Credits”** means credits (if any) issued under the SLA, which have no cash value and can only be applied against future invoices for the relevant Service.

## 2. Scope, Acceptance, Entire Agreement

These Terms govern the provision and use of the Services. By ordering, activating, or using the Services, Customer accepts these Terms and all documents incorporated by reference, including the [Acceptable Use Policy](https://lumadock.com/legal/acceptable-use-policy) (“AUP”), [Anti-Spam Policy](https://lumadock.com/legal/anti-spam-policy), [Refund Policy](https://lumadock.com/legal/refund-policy), [Privacy Policy & DPA](https://lumadock.com/legal/privacy-policy), and [Cookie Policy](https://lumadock.com/legal/cookie-policy) (collectively, the “Policies”). In the event of conflict, a Policy expressly addressing the subject matter shall prevail for that subject.

The parties acknowledge that these Terms, together with the Policies, the Order(s) and any mutually signed addenda constitute the entire agreement and supersede prior representations and agreements relating to the subject matter. Any Customer terms (including purchase order terms or procurement terms) that are inconsistent with or additional to this agreement are void unless expressly accepted in writing by LumaDock.

Customer acknowledges that descriptions of Services (including locations, technical specifications, limits and included features) are as set out in the relevant Service description, control panel and/or Order. LumaDock may evolve or improve Services (for example, by changing hardware platforms, implementing newer CPU generations, storage technologies or network topology) provided that such changes do not materially reduce the core functionality purchased by Customer, unless required by Applicable Law, security considerations, end-of-life of components or third-party licensing changes.

These Terms are primarily intended for business users. Where Customer is a consumer under Applicable Law, mandatory consumer rights are not excluded and shall prevail in the event of conflict.

Customer is responsible for ensuring that its use of the Services and its choice of region comply with all laws and regulatory obligations applicable to Customer, its content and its end-users (including, where relevant, sector-specific rules, data localisation rules and export controls).

## 3. Eligibility, Account Registration & Security

- Customer must have legal capacity to contract. Individuals must be at least 18 years old and legally able to enter binding agreements under Applicable Law.
- Customer is responsible for accurate registration information and for maintaining the confidentiality of credentials, MFA factors, API keys, SSH keys and any other authentication mechanism.
- Customer remains responsible for all activity under the Account, whether authorised or unauthorised. Customer shall notify LumaDock without undue delay of suspected compromise of the Account or any security breach.
- LumaDock may conduct fraud screening, KYC/AML checks and sanctions screening and may refuse, suspend, or terminate an Account for non-compliance or reasonable suspicion of fraud, abuse or sanction violations.
- Customer must ensure that its contact details (including billing, technical and abuse/security contacts) remain accurate and up to date in the Account. Notices sent to the email address on file are deemed received.
- Customer is responsible for ensuring that users with access to the Account or Services comply with these Terms and the Policies. Actions taken by such users are deemed actions of the Customer.
- Customer may not create or maintain more than one Account for the same individual, legal entity, organisation, business, household, billing identity, tax/VAT identity, payment method, beneficial owner, project, or substantially related use without LumaDock’s prior written approval.
- Multiple, duplicate, related, or commonly controlled Accounts must not be used to avoid or bypass these Terms, the Policies, payment obligations, usage limits, resource limits, verification checks, fraud screening, KYC/AML checks, sanctions screening, abuse handling, service restrictions, prior suspension or termination, promotional eligibility, free trials, credits, coupons, referral rewards, affiliate rewards, refunds, or other LumaDock controls.
- LumaDock may treat Accounts as duplicate, related, associated, or commonly controlled based on account details, identity or company information, beneficial ownership, billing or tax details, payment instruments, contact details, domains, IP addresses, network ranges, device or browser signals, cookies or sessions, login patterns, API usage, SSH keys, order patterns, support interactions, referral or affiliate activity, abuse history, chargeback history, fraud indicators, sanctions indicators, security indicators, or other risk signals.
- If LumaDock determines or reasonably suspects duplicate Accounts, related Accounts, circumvention, abuse, fraud, non-payment, sanctions evasion, chargeback risk, promotional abuse, referral abuse, affiliate abuse, or other risk, LumaDock may require verification, refuse or cancel Orders, remove discounts, credits, refunds, rewards, or commissions, adjust invoices to standard pricing, link or merge Accounts for billing or enforcement, suspend or terminate Accounts or Services, disable trial or promotional resources, refuse future Orders or promotions, and apply outstanding amounts or enforcement history across all related Accounts.
- Legitimate separate Accounts for distinct legal entities, subsidiaries, resellers, business units, teams, or customer environments may be permitted where the separation is genuine, accurate, non-deceptive, and not used to obtain duplicate benefits or evade LumaDock controls.
- Use of another person’s details, identity, company, payment method, address, device, network, affiliate relationship, referral relationship, or customer account to disguise common control, avoid detection, obtain duplicate benefits, or bypass these Terms is prohibited and constitutes a material breach of these Terms.
- LumaDock may require identity, business, payment, address, ownership, or other verification before or after accepting an Order where required by law, requested by a payment provider or upstream provider, or where LumaDock reasonably suspects fraud, abuse, sanctions risk, payment risk, chargeback risk, refund abuse, duplicate Accounts, related Accounts, or circumvention of these Terms or the Policies.
- Failure or refusal to complete requested verification, or providing false, misleading, incomplete, inconsistent, or unverifiable information, may result in refusal of Orders, suspension or termination of Accounts or Services, cancellation of discounts or promotions, denial of refund eligibility, and refusal of future Orders.
- Customer may not create, maintain, use, control, fund, or benefit from multiple, duplicate, related, or commonly controlled Accounts to obtain repeated new-customer benefits, free trials, refunds, credits, coupons, promotions, referral rewards, affiliate rewards, or to bypass verification checks, fraud controls, abuse enforcement, payment restrictions, service limits, prior suspension, or prior termination.
- LumaDock may treat Accounts as duplicate, related, or commonly controlled based on account details, contact details, billing details, payment instruments, tax/VAT details, IP addresses, network information, device or browser signals, login patterns, order patterns, service usage, support history, abuse history, chargeback history, refund history, referral or affiliate activity, or other fraud, security, compliance, or risk indicators.

## 4. Ordering, Billing, Currency, Taxes, Renewal

- Services are billed in advance on monthly, annual or other cycles (as stated on the Order or in the control panel), unless a Service explicitly uses usage-based or post-paid billing.
- Unless otherwise specified, prices are exclusive of VAT and applicable taxes. Customer is responsible for paying all taxes, duties, and government charges associated with the Services, except taxes based on LumaDock’s net income.
- Currency is typically GBP or EUR; displays in other currencies are for convenience. If conversion applies, the rate used is the payment processor’s or our banking partner’s rate on the date of charge.
- Invoices are issued electronically to the email address on file and are also available in the control panel.
- Services set to auto-renew will renew at the then-current price unless Customer disables auto-renew or cancels prior to renewal, in line with any notice periods displayed at order or in the control panel.
- LumaDock reserves the right to accept or decline Orders at its discretion (for example, where risk, sanctions, technical constraints or previous abuse make an Order inappropriate or infeasible).
- Customer is responsible for all charges incurred through the Account, including any usage-based or overage charges that may apply to specific Services (for example, additional backups, IPv4 addresses, bandwidth surcharges where applicable).
- Invoice disputes must be raised in writing without undue delay and no later than 30 calendar days from the invoice date. Undisputed portions remain payable on the original due date. Failure to raise a dispute within this period constitutes acceptance of the invoice.

## 5. Delivery, Postponement, Suspension, Reactivation

- **Delivery & Activation.** Provisioning of Services occurs after payment confirmation and completion of any required verification checks. Provisioning time depends on the Service type. Third-party mediated services (e.g., domains, SSLs, licenses) are purchased/renewed only after full payment is received.
- **Service Term & Cancellation by Customer.** Unless otherwise stated, Services are provided for the billing period selected at order and renew automatically until cancelled. Customer may request cancellation via the control panel or ticket in accordance with the notice periods shown. Cancellation stops future renewals; fees already paid remain non-refundable except as set out in the Refund Policy.
- **Postponement.** Customer may request invoice postponement or short-term extensions for LumaDock-hosted services; approval is at LumaDock’s discretion and may be subject to conditions and additional fees.
- **Suspension & Reactivation.** Services may be suspended for non-payment, AUP breaches, security issues, legal requests, or other material breaches of these Terms. Reactivation occurs after the cause is remedied and all outstanding amounts, fees and restoration charges are paid. Additional fees (e.g., restoration, administrative or reactivation fees) may apply.
- To protect the platform and other customers, LumaDock may apply traffic filters, routing changes, rate limits, blackhole routing, or temporary blocks (for example, during DDoS attacks) in addition to or instead of suspension.
- LumaDock may terminate a Service or Account in case of severe or repeated violations, non-cooperation regarding abuse/security incidents, or where continuing the relationship would expose LumaDock to unacceptable operational, legal or reputational risk.

## 6. Non-Payment & Data Deletion

- **Unpaid invoices & grace period:** If an invoice remains unpaid after the due date, LumaDock may suspend the affected Service(s) immediately or after a brief grace period shown on the invoice or in the control panel.
- **Service suspension after 1 day:** If payment is not received within 1 calendar day after the due date, the affected Service(s) may be automatically suspended. Suspended Services are powered off or disabled but Customer Data remains stored during this suspension period.
- **Permanent deletion after 5 days:** If non-payment continues for more than 5 calendar days after the due date, LumaDock may permanently terminate the affected Service(s) and delete all Customer Data stored on them. This deletion is **automatic, irreversible, and unrecoverable**. No recovery or restore is possible once the deletion process has occurred.
- **Scope:** This policy applies to all LumaDock Services, including but not limited to VPS instances, backups, snapshots, images, firewalls, monitoring checks, private networks, and any add-ons or dependent resources. Termination of a primary Service may automatically remove its associated components.
- **Data Loss.** Without limiting the foregoing, LumaDock shall not be liable for any loss, corruption, or inability to recover Customer Data, including where caused by hardware failure, storage faults, or infrastructure defects, and no compensation, damages or refunds shall be owed in respect of such data loss. Customer acknowledges that maintaining independent, off-site or local backups is its sole responsibility.
- **Customer responsibility for backups:** Because data deletion after non-payment is final, Customer must maintain independent, off-site backups of critical data at all times. LumaDock strongly recommends keeping at least one external backup copy outside our infrastructure.
- **Restoration (before deletion only):** If the Service has not yet been deleted, reactivation may be possible once all overdue invoices and any applicable restoration fees are paid. LumaDock cannot guarantee the availability or integrity of suspended or expired resources.
- **Chargebacks and disputes:** Chargebacks, payment reversals, or disputed transactions are treated as non-payment and may result in immediate suspension or termination of Services. Administrative fees may apply.
- **Outstanding amounts:** Customer remains responsible for all fees accrued up to the effective termination date, including reasonable costs of collection such as legal or agency fees where permitted by law.

## 7. Upgrade / Downgrade & Plan Changes

- Downgrade credits (if any) are calculated only for full unused months paid in advance and only where the plan permits, in accordance with the Refund Policy and any specific Service rules.
- One free plan change (upgrade/downgrade) may be allowed every 30 days; additional changes in the same period may be charged as support time or incur a reconfiguration fee.
- Plan changes involving control panel, account merges, changes between virtualisation types, or cross-datacenter migrations may require paid support time.
- Where a plan change involves migration between nodes, zones, virtualisation stacks or hardware generations, Customer is responsible for validating applications, DNS, SSL and mail settings after the change.

## 8. Refunds & Money-Back Guarantee

Refunds are governed by the [Refund Policy](https://lumadock.com/legal/refund-policy) (incorporated by reference). In summary (without limitation):

- A money-back guarantee may apply to a new customer's first order, subject to the eligibility rules, refund windows and exclusions set out in the Refund Policy.
- Non-refundable items include (without limitation): domains (registration/transfer/renewal), third-party software licenses (e.g., cPanel/Plesk/Microsoft), SSL certificates, additional IPs, third-party DDoS add-ons, and other third-party mediated services.
- Where an order included free or discounted items (e.g., free domain, SSL, license), their retail value may be deducted from any refund.
- Accounts suspended or terminated for breach of these Terms or the Policies are not eligible for refunds.
- Refund processing timelines and method are described in the Refund Policy; banking and payment network timelines are outside LumaDock’s control.

In the event of any inconsistency between this Section and the Refund Policy, the Refund Policy shall prevail.

## 9. Tariff / Price Changes

- For active Services, LumaDock will provide at least 30 calendar days’ notice prior to recurring price changes taking effect, unless a shorter period is required by exceptional circumstances (for example, sudden changes in third-party licensing, taxes or energy costs).
- Prepaid periods are not affected until renewal.
- Changes to pricing for new Services may take effect upon publication on the website and in the order flow.
- Promotional or introductory pricing may apply only to the initial billing period or as explicitly stated and will revert to standard pricing thereafter.

## 10. Payment Processing, Saved Cards & Recurring Payments

- Invoices for card payments are issued in accordance with applicable accounting rules; month-end cut-off timing may apply.
- Upon enabling saved card(s) and/or recurring payments, Customer authorizes LumaDock or its payment processor to charge renewal fees and other amounts due for designated Services automatically upon invoice issuance.
- Recurring payments are subject to the Refund Policy.
- Where a payment attempt fails, LumaDock may retry using the same or any authorised backup payment method. If all attempts fail, Services may be suspended or terminated as described in Section 6.
- Customer must ensure that payment instruments used are authorised and valid. Customer is responsible for any fees arising from rejected or reversed payments (for example, chargeback fees or bank return fees).

## 11. Credit / Deposit

- Customer may add credit/deposit in the control panel. Applicable VAT/tax rules depend on the Customer’s tax status and jurisdiction.
- Credit application to invoices is manual unless otherwise stated. Partial application may be restricted; where allowed, the rules shown in the control panel apply.
- LumaDock may apply available credit to overdue invoices for Services already renewed or consumed.
- Minimum/maximum deposit thresholds are those displayed in the control panel or Order flow.
- Account credit is not a bank deposit, does not accrue interest, and is generally non-refundable except as required by Applicable Law or the Refund Policy.

## 12. Promotions & Promotional Codes

- Promotional codes are available to individuals and businesses, apply only to new hosting orders (unless explicitly stated otherwise), and cannot be combined or applied retroactively.
- Coupons typically apply to the first billing period only and only to eligible Services specified in the promotion. Recurring discounts or lifetime discounts, where offered, are subject to any explicit conditions stated in the promotion.
- Free bundled items are bound to the LumaDock infrastructure; transfer away may forfeit the free benefit and/or incur standard fees.
- LumaDock may modify or discontinue promotions at any time. Where required by law or by the specific terms of a promotion, notice will be provided.
- Promotional abuse includes creating, maintaining, using, controlling, funding, referring, or benefiting from multiple, duplicate, related, or associated Accounts to obtain, reuse, extend, transfer, stack, or bypass eligibility for promotional codes, introductory pricing, “new customer” offers, free trials, credits, referral rewards, affiliate rewards, money-back guarantees, or other limited benefits.
- LumaDock may cancel or reverse affected discounts, credits, rewards, refunds, commissions, or promotions; adjust invoices to standard pricing; reject or cancel Orders; suspend or terminate Services or Accounts; refuse future promotions or Orders; and recover any amounts improperly avoided, discounted, credited, refunded, or paid.

## 13. Liability; Indemnity

- **Exclusion.** To the maximum extent permitted by Applicable Law, LumaDock shall not be liable for indirect, incidental, special, consequential, exemplary, or punitive damages, including but not limited to loss of profit, revenue, savings, data, goodwill, business interruption, or replacement costs, even if advised of the possibility of such damages.
- **Cap.** LumaDock’s aggregate liability arising out of or related to the Services (whether in contract, tort, negligence or otherwise) shall not exceed the fees paid by Customer for the affected Service during the twelve (12) months preceding the event giving rise to the claim.
- **High-Risk Use.** The Services are not designed, authorised or warranted for use in high-risk environments requiring fail-safe performance (such as life support, nuclear facilities, air traffic control, critical medical devices or weapons systems). Customer uses the Services in such contexts at its own risk and shall indemnify LumaDock for resulting claims.
- **Indemnity.** Customer shall indemnify and hold harmless LumaDock, its affiliates, officers, employees and contractors from claims, damages, penalties and costs (including reasonable legal fees) arising from (i) Customer’s content or use of the Services, (ii) breach of these Terms or the Policies, (iii) violation of law or third-party rights, or (iv) disputes between Customer and Customer’s own customers or users.
- **Third-Party Services & Software.** Certain Services may rely on or include Third-Party Services (for example, control panels, operating systems, backup software, SSLs, domain registrars). Customer’s use of Third-Party Services is subject to the relevant third-party terms. LumaDock is not responsible for availability, bugs, vulnerabilities or licensing changes in Third-Party Services and provides them “as is”, except where explicitly warranted by the third party.
- **Disclaimer of Warranties.** Except as expressly stated in these Terms or an applicable SLA, the Services are provided “as is” and “as available”, without warranties of any kind, whether express, implied or statutory, including but not limited to implied warranties of merchantability, fitness for a particular purpose, and non-infringement. LumaDock does not warrant that the Services will be error-free, uninterrupted, completely secure or compatible with every application or configuration.

## 14. Data Integrity, Security of Applications & Devices

- Customer is solely responsible for the security, maintenance and integrity of its applications, code, configurations and data hosted on or transmitted via the Services.
- Customer is responsible for securing end-user devices used to access the Services and for implementing appropriate access controls, encryption, logging and hardening measures.
- Backups: Unless otherwise stated for a specific Service, backups are Customer’s responsibility. Where LumaDock provides backup functionality, snapshot slots or backup add-ons, such features are provided on a best-effort basis; Customer must verify backup integrity, retention, and perform restores as needed.
- Customer acknowledges that resource failures, hardware faults, software bugs, user error and malicious activity can lead to data loss. The primary protection against such risks remains Customer’s own backup strategy.
- LumaDock may generate and retain system logs and telemetry (for example, for performance, security and abuse detection). Such logs are LumaDock’s data but may contain Customer-related metadata; processing is governed by the Privacy Policy and DPA.

## 15. Support: Identification, Channels, Scope & Limits

### 15.1 Identification

- **Phone:** verification via Account information and support PIN or equivalent.
- **Chat:** login to the Account is required for account-specific requests.
- **Email/Ticket:** requests must originate from the Account email or an authorised contact designated in the Account.

### 15.2 Channels & Response

- Support is available 24/7 via ticket/email. Live chat and phone may be available but are not guaranteed real-time troubleshooting channels.
- Complex requests, root-cause analysis and configuration changes may require escalation to ticket for proper handling and audit trail.
- Indicative response and resolution targets may be published in documentation or SLAs but are not guarantees unless explicitly marked as such.

### 15.3 Telephone Assistance

- Requests requiring more than a short initial assessment via phone or chat will be redirected to ticket so that technical work is tracked and accounted for.

### 15.4 Abuse & Conduct

- Abusive, threatening or harassing behaviour towards staff is prohibited. LumaDock may suspend support in such cases and/or suspend or terminate Services for continued abuse. For detailed provisions and consequences, see Section 15.6 (Unacceptable Customer Behaviour).

### 15.5 Scope

- Standard support covers infrastructure availability, hypervisor-level issues, network connectivity, hardware faults, control panel functionality, and other platform issues under LumaDock's control.
- Standard support does not include customer application development, debugging of custom code, optimisation of business logic, or configuration of third-party software outside default templates, unless otherwise stated for a specific managed Service.
- Requests outside standard scope may require purchase of managed services or support hours and may be accepted or declined at LumaDock's discretion.

### 15.6 Unacceptable Customer Behaviour

Customers must interact with LumaDock staff and representatives in a courteous and professional manner at all times. The following conduct is strictly prohibited and constitutes a material breach of these Terms:

- Abusive, offensive, derogatory, discriminatory, or insulting language, whether verbal, written, or electronic.
- Threats of harm, violence, intimidation, or retaliation against staff, the company, or third parties.
- Persistent unreasonable demands, excessive contact, or refusal to accept reasonable decisions after due process has been followed.

Upon detection of prohibited conduct:

- Staff may immediately cease engagement and escalate to management. No member of staff is required to continue communication with a Customer engaging in prohibited conduct.
- LumaDock may, at its sole discretion and without prior notice, suspend or terminate support, Services, and/or the Account.
- In cases of severe or repeated prohibited conduct, LumaDock will permanently terminate all Services and the Account in accordance with Section 5. Such termination is final: no reactivation, refund (per Section 8), or data recovery (per Section 6) will be available. LumaDock reserves the right to refuse all future Orders from the individual or entity concerned.

This policy reflects LumaDock's obligations under the Equality Act 2010 (as amended by the Worker Protection (Amendment of Equality Act 2010) Act 2023) and the general common law duty of care owed by employers to their employees.

## 16. Managed VPS vs. Unmanaged / IaaS

### 16.1 Managed VPS

- Administrative access: under managed service, Customer will typically not receive root/superuser credentials unless explicitly agreed, to allow LumaDock to maintain and support the environment.
- Covered items (illustrative): control panel installation/configuration; web/mail/database services; firewall configuration; periodic updates; 24/7 monitoring and intervention; baseline performance tuning; server-level automation related to the panel stack.
- Requests to install or configure software beyond the standard managed stack may be accepted or refused at LumaDock’s discretion and may consume support hours or incur additional fees.

### 16.2 Unmanaged / IaaS

- LumaDock is responsible for infrastructure operation (hardware, hypervisor, power, cooling, network edge) and connectivity only.
- Customer is solely responsible for OS, services, applications, security hardening, patching, software licensing (where self-licensed) and compliance with security best practices.
- Additional assistance may be available as paid support hours or as a separate managed service upgrade.

## 17. Compromise & Security Incidents

- Where LumaDock detects compromised resources (for example via abnormal network indicators, abuse reports, malware signatures, or participation in attacks), Customer will be notified via ticket or email. Based on severity, LumaDock may temporarily block public connectivity, disable specific ports, apply filters or shut down the instance.
- Customer is responsible for identifying and removing the cause of compromise, backdoors, web shells and associated tools, and for restoring secure operation. Alternatively, Customer may provision a fresh instance and migrate clean data.
- Failure to remediate in a reasonable timeframe, repeated compromise or non-cooperation with abuse/security teams may result in further restrictions, suspension or termination to protect the platform and third parties.
- LumaDock may cooperate with Computer Security Incident Response Teams (CSIRTs), CERTs, network operators, registries and law enforcement agencies in the investigation of serious abuse, subject to Applicable Law and the Privacy Policy.

## 18. Data Migration & Transfers

- Initial, reasonable migration assistance may be provided at no cost for Shared Hosting, Reseller and Managed VPS at the time of service onboarding, or for intra-LumaDock moves related to approved upgrades/downgrades where explicitly offered.
- Transfers to unmanaged VPS or complex migrations, re-runs due to Customer action/inaction (for example, DNS changes mid-migration), or manual/custom work are billed as support hours or professional services.
- LumaDock is not responsible for application-specific adjustments post-migration. The Customer must validate websites/applications, rebuild caches, check cron jobs, and (where relevant) reconfigure mail clients and DNS.

## 19. Support Hours Accounting

- “Included” support hours (if any) are allocated per monthly billing period and do not roll over, unless the Service description explicitly states otherwise.
- Purchased support hours may roll over in accordance with the terms displayed in the control panel or purchase confirmation.
- Time is measured based on actual technician effort to analyse and fulfil the request, regardless of contact channel, and may include investigation, documentation and communication.
- Purchase of support hours does not guarantee acceptance of any specific request, particularly where the request conflicts with security, licensing or operational constraints.

## 20. Rules for Resellers & VPS Owners

- Resellers and VPS owners remain LumaDock’s primary contractual counterpart and are responsible for their downstream users, customers and end-clients, including passing through these Terms and the Policies.
- Resellers/VPS owners must cooperate with LumaDock requests and, where permissible under data protection law, provide contact details of downstream users to facilitate compliance, security or abuse actions.
- Resellers/VPS owners shall indemnify LumaDock for violations by their clients, including but not limited to spam, abuse, infringement and other AUP breaches.
- For the avoidance of doubt, LumaDock has no direct contractual relationship with the reseller’s end-customers, and shall not be liable for disputes between reseller and such end-customers.

## 21. Content Policy

Customer is responsible for ensuring that all content and activity complies with Applicable Law and third-party rights. Prohibited content includes (without limitation):

- Material infringing copyrights, trademarks, or other intellectual property rights; pirated software; warez; unauthorised distribution of licensed content.
- Nudity/pornography in violation of law; child sexual abuse material (CSAM) or any sexualisation of minors; content encouraging or facilitating such conduct.
- Threats, harassment, defamatory or libellous statements; incitement to violence; hate speech or content targeting protected characteristics contrary to Applicable Law.
- Fraudulent, misleading, or deceptive content; phishing; identity theft; privacy violations; illegal surveillance or stalking.
- Viruses, trojans, ransomware, botnet controllers or content primarily intended to compromise systems or participate in attacks.
- Operation of services clearly intended to facilitate criminal activity (for example, “bulletproof” hosting specifically marketed for abuse, carding forums, or illegal marketplaces).

LumaDock may remove or disable content and suspend or terminate Services for violations, and may report serious offences to law enforcement or relevant authorities where legally required or justified.

### 21.1 Intellectual Property, Notice-and-Takedown & DMCA

LumaDock respects the intellectual property rights of others and expects Customers to do the same. Customer shall not use the Services to infringe upon the copyright, trademark or other intellectual property rights of any third party.

- Where LumaDock hosts or transmits content that is alleged to infringe intellectual property rights, LumaDock may apply a notice-and-takedown procedure consistent with Applicable Law. This may include disabling access to or removing the allegedly infringing content, notifying the Customer, and in appropriate cases terminating repeat infringers.
- For operations subject to the United States Digital Millennium Copyright Act (DMCA), LumaDock will follow procedures broadly aligned with the DMCA safe-harbour framework, including acting on valid notices and, where appropriate, counter-notices. Details of the applicable contact channel for copyright complaints are published on our website or in the relevant policy pages.
- Intellectual property complaints (including alleged copyright, trademark and related infringements) should include sufficient information to identify the content in question, the rights allegedly infringed, the basis of the claim, and contact details of the complainant. LumaDock may require additional information before taking action.
- LumaDock does not act as arbitrator between Customer and third parties. Any decision to remove or restrict content is taken to reduce legal and operational risk, without prejudice to the parties’ rights to resolve disputes in court or through other mechanisms.

## 22. Acceptable Use & Email Policies (Overview)

Customer must comply with the [Acceptable Use Policy](https://lumadock.com/legal/acceptable-use-policy) and [Anti-Spam Policy](https://lumadock.com/legal/anti-spam-policy). Highlights (non-exhaustive):

### 22.1 General AUP

- No continuously running background programs on shared hosting environments; no cron timers < 5 minutes on shared platforms where such limits are specified; and no CGI on services where it is explicitly prohibited in the relevant service description or in the AUP. These limits do not apply to VPS or dedicated environments unless stated otherwise.
- No DoS/DDoS, flooding, reflection/amplification attacks, mail bombing, or falsifying TCP/IP headers.
- No proxy/IRC scripts, open resolvers, open relays, FormMail/PhpShell-type scripts with known vulnerabilities, torrent trackers, topsites, IRC bots, or online games on plans where such usage is prohibited or where it poses a material stability risk.
- No unauthorised access attempts, scanning, sniffing, spoofing, brute-force attacks or similar activities against third parties or LumaDock infrastructure.
- No cryptocurrency mining, game bots or similar resource-intensive activities on shared hosting plans, or on other plans where explicitly prohibited in the Service description.
- Scripts or processes posing a security risk or degrading performance may be disabled or removed without prior notice if necessary to protect the platform.

### 22.2 Email, Anti-Spam & Bulk Messaging

- Commercial email requires prior, provable consent (opt-in). Double opt-in is strongly recommended.
- Every email must include clear identification of the sender and an easy, effective unsubscribe mechanism processed without undue delay (no later than 5 days).
- Recommended bulk sending windows: off-peak hours (before 09:00 or after 22:00) and a reasonable sending rate (for example, a few dozen emails per minute) appropriate to the plan and infrastructure.
- Operational limits typically include: attachment size limits, maximum recipients per message, and rate limits designed to protect IP reputation; excessive CC/BCC usage is discouraged.
- **SMTP port 25 is not guaranteed and may be restricted.** To protect network reputation and deliverability, LumaDock may block outbound SMTP on TCP port 25 by default and may grant access only as an exception upon request and approval, in accordance with the AUP and Anti-Spam Policy.
- **Approval is discretionary and may be limited or revoked.** Any exception for SMTP port 25 may be rate-limited, time-limited, or withdrawn at any time if abuse is detected, reputation is impacted, or if required to protect the platform, upstream relationships, or other customers.
- LumaDock monitors SMTP traffic patterns and reputation indicators for abuse and may intervene, filter, block ports or rate-limit to protect network reputation and other customers.
- Email delivery is not guaranteed; factors such as mailbox quotas, blacklists, recipient filtering, greylisting, and oversized attachments can affect delivery.
- Serious or repeated spam or abuse incidents may lead to immediate suspension or termination of the relevant Service or Account. LumaDock may charge reasonable administrative fees in connection with investigating and mitigating spam incidents, where permitted by law and stated in the applicable price list or policies.

For detailed rules, consult the complete AUP and Anti-Spam Policy published on our website.

## 23. Dedicated IP Policy

- Before allocation, IPs may be checked for reputation and RBL status. Allocation is at LumaDock’s discretion and may require justification under regional IP policies.
- Subsequent IP changes are only for well-founded reasons (for example, persistent RBL issues not caused by Customer) and may be refused or subject to a change fee as listed on the website or in the control panel.
- Where a Service includes a single dedicated IP, it may be assigned to all domains/subdomains running under that Service unless otherwise configured.
- IPv6 may be assigned alongside IPv4 where available; removal upon Customer request is possible, but may impact functionality.
- Customer is responsible for IP reputation arising from its usage and must respond promptly to abuse reports concerning its IPs.

## 24. Resources, Fair Use, “Unlimited/Unmetered”

### 24.1 Shared Hosting / Shared VPS Nodes

- Each account has specific resource allocations (CPU, RAM, disk, I/O, inodes, processes, etc.). Exceeding these limits may cause throttling, temporary restrictions or recommendations to upgrade.
- Storing files > 500 MB solely as archives/media (not part of the website/application) is prohibited on shared plans (except account backups, where permitted).
- LumaDock may contact the Customer to recommend upgrades or optimisations if sustained resource saturation is detected.
- To protect data integrity, LumaDock may halt a VPS if available storage falls below a critical threshold (for example, 1% or 1 GB) and Customer does not act after notification.
- Streaming audio/video at scale, file or image hosting/sharing, and use as a general storage repository are prohibited on plans where so stated in the Service description.

### 24.2 Managed VPS License Limits

- Control panel licenses may limit the number of accounts/domains. Adjustments require license tier changes (upgrade/downgrade), which may change the price.
- Of total disk space, a portion is consumed by OS, swap and control panel; remaining capacity is available for Customer data.
- Customers will be notified when disk usage approaches critical thresholds and may be asked to clean up or upgrade.

### 24.3 “Unlimited/Unmetered” Clarification

- “Unlimited/Unmetered” describes generous allocations subject to fair use and technical constraints; it does not imply infinite resources.
- Numerical configuration thresholds (for example, number of mailboxes, subdomains or databases) may be capped at high but finite levels to protect stability.
- Traffic and bandwidth are inherently bounded by assigned port speeds, network capacity and physical constraints. Excessive or abusive patterns (for example, sustained saturation harming others) may lead to rate limiting or recommendations to move to a more suitable plan.

### 24.4 CPU & Utilization

- **Shared VPS / shared nodes:** sustained 100% CPU for more than 30 minutes may trigger a notice and an optimisation or upgrade recommendation. LumaDock may throttle CPU to preserve node stability.
- **Dedicated VPS / bare metal:** Customer may utilise assigned resources fully, but LumaDock may restrict network patterns or operations that adversely affect network stability, security or other customers.

### 24.5 Beta, Trial & Evaluation Features

- LumaDock may make beta, preview or trial features or zones available. Such features are provided “as-is” without SLA or warranty and may be modified or withdrawn at any time.
- Customer should not rely on beta or trial features for production or mission-critical workloads unless explicitly stated otherwise in the relevant Service description.
- Free trial credits, test VPSs or temporary resources may be terminated without renewal at the end of the evaluation period and data may be deleted.

## 25. Service Level Agreement (SLA)

- LumaDock targets 99.9% monthly uptime for core infrastructure and network at the datacenter edge for eligible Services, as further detailed in the SLA documentation where applicable.
- Exclusions include: scheduled maintenance (with prior notice), emergency maintenance, events outside LumaDock’s reasonable control (force majeure), Customer-caused incidents, misconfigurations by Customer, third-party software faults, upstream provider issues beyond LumaDock’s control, and abuse-related suspensions or security interventions.
- Remedy: where the SLA applies and is breached, the sole remedy is Service Credits against future invoices, calculated proportionally to downtime, capped at 100% of the monthly fee for the affected Service. Credits have no cash value and are non-transferable.
- Procedure: Customer must submit an SLA claim via ticket within 10 Business Days of the alleged event with supporting logs and timestamps. Claims submitted late or without sufficient evidence may be rejected.

## 26. Privacy; GDPR; DPA

- LumaDock processes personal data in accordance with the [Privacy Policy](https://lumadock.com/legal/privacy-policy) and the [Customer Data Processing Agreement (DPA)](https://lumadock.com/legal/privacy-policy#dpa), which are incorporated by reference.
- Customer remains Controller for Customer Data; LumaDock acts as Processor except where LumaDock determines processing of its own data (for example, billing, security logging, fraud prevention, account management) as Controller.
- International transfers (where applicable) are safeguarded by appropriate mechanisms (for example, standard contractual clauses or equivalent). Customer is responsible for ensuring that its use of the Services and choice of data region meet its own regulatory, contractual and compliance obligations.
- Details of Sub-processors and technical and organisational measures are available as described in the Privacy Policy and DPA and may be updated as the infrastructure and vendor landscape evolves.

## 27. General Legal

### 27.1 Force Majeure

Neither party is liable for delay or failure to perform due to events beyond reasonable control, including natural disasters, war, terrorism, civil disturbance, labour disputes, governmental actions, utility or Internet failures, pandemics, or major supplier outages. The affected party shall use reasonable efforts to mitigate the impact.

### 27.2 Assignment

Customer may not assign or transfer rights or obligations without LumaDock’s prior written consent. LumaDock may assign or transfer its rights and obligations to an affiliate or in connection with a merger, acquisition, corporate reorganisation or sale of assets.

### 27.3 Notices

Notices to LumaDock must be sent via the channels indicated on the contact page or in the control panel and are deemed delivered upon confirmation by LumaDock. Notices to Customer are sent to the Account email and/or posted in the control panel and are deemed delivered upon sending or posting.

### 27.4 Severability

If any provision is held invalid or unenforceable, the remaining provisions remain in full force and effect. The invalid provision will be replaced by an enforceable provision that most closely reflects the parties’ original intent under Applicable Law.

### 27.5 Waiver

No failure or delay by either party in exercising any right shall constitute a waiver of that or any other right. A waiver must be in writing to be effective and shall apply only to the specific instance.

### 27.6 Survival

Provisions which by their nature should survive termination remain in effect, including but not limited to payment obligations, indemnities, liability limitations, intellectual property clauses, confidentiality, data protection, governing law and dispute resolution.

### 27.7 Export Control & Sanctions

Customer shall comply with all applicable export control, trade restriction and sanctions laws, including (where relevant) those of the United Kingdom, the European Union, the United States and other applicable jurisdictions. Customer represents that it is not a restricted party and will not use the Services in or for the benefit of any country, organisation or individual subject to relevant sanctions in a manner that would cause LumaDock to breach Applicable Law. LumaDock may suspend or terminate Services where required by export control or sanctions obligations.

### 27.8 No Third-Party Beneficiaries

Except where expressly stated, these Terms do not create rights in favour of any third party. No third party may enforce or rely on any provision of these Terms, subject to mandatory statutory rights.

### 27.9 Order of Precedence

In case of conflict: (i) a mutually signed addendum or data processing agreement (for its subject matter) prevails over these Terms; (ii) these Terms prevail over the Policies, unless a Policy explicitly states that it prevails for its subject matter; and (iii) the Policies prevail over marketing materials, FAQs or informal communications.

### 27.10 Data Retention After Termination

Upon termination or expiry of a Service, Customer is responsible for exporting or backing up Customer Data prior to shutdown. LumaDock may retain backups or logs for a limited period for legal, security or operational reasons, but has no obligation to store or provide copies of Customer Data beyond the time limits and mechanisms described in these Terms, the SLA and the Privacy Policy.

### 27.11 Intellectual Property

LumaDock (LumaDock Ltd) and its licensors retain all rights, title and interest in and to the infrastructure, software, documentation, trademarks and other materials used to provide the Services, excluding Customer Data. Customer retains all rights, title and interest in and to Customer Data. No rights are granted except as expressly stated in these Terms.

### 27.12 Legal Requests, Court Orders & Law Enforcement

LumaDock responds to valid legal requests (including court orders, subpoenas and comparable instruments) in accordance with Applicable Law. Unless prohibited by law or operationally impracticable, LumaDock will make reasonable efforts to notify Customer before disclosing Customer Data or taking action that affects Customer’s Service in response to such a request, so that Customer may seek protection where available.

LumaDock may charge reasonable cost-recovery fees for processing complex legal requests, particularly where extensive data retrieval, review or expert involvement is required, to the extent permitted by law. Legal requests must be served using the contact details published on our website or otherwise officially communicated by LumaDock.

### 27.13 Compliance With Local Law

The Services may be accessible from locations worldwide, but this does not imply that all content or Services are lawful or appropriate in every jurisdiction. Access to the Services from locations where their content or use is unlawful is prohibited. Customer is solely responsible for ensuring that its use of the Services complies with all laws, regulations and rules applicable to it, its content and its users in each relevant jurisdiction.

## 28. Governing Law & Jurisdiction

These Terms are governed by and construed in accordance with the laws of England and Wales. The courts located in London, United Kingdom, shall have exclusive jurisdiction over disputes arising out of or relating to these Terms or the Services, subject to any mandatory consumer rights under Applicable Law that require a different forum.

## 29. Language of the Agreement

**Binding English Version.** The English version of all legal agreements and policies is the sole official and binding version. Translations are provided solely for convenience and have no legal effect. In case of inconsistency or conflict, the English version shall prevail.

## 30. Changes to these Terms

LumaDock may amend these Terms and the incorporated Policies to reflect changes in law, security requirements, infrastructure, products or business practices. Material changes will be communicated by email, via the control panel and/or by notice on the website before they take effect where reasonably practicable. Continued use of the Services after changes take effect constitutes acceptance of the updated Terms. If Customer does not agree with material changes, Customer may cancel the affected Services in accordance with Section 5.

---

## Annexes & Cross-References

- [Acceptable Usage Policy](https://lumadock.com/legal/acceptable-use-policy)
- [Anti-Spam Policy](https://lumadock.com/legal/anti-spam-policy)
- [Refund Policy](https://lumadock.com/legal/refund-policy)
- [Privacy Policy & GDPR DPA](https://lumadock.com/legal/privacy-policy) (Annexes: Sub-processors; Security Measures – available as described therein)
- [Cookie Policy](https://lumadock.com/legal/cookie-policy)

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.sambanova.ai/docs/llms.txt
> Use this file to discover all available pages before exploring further.

# SambaCloud models overview and specifications

SambaCloud currently supports the following models for all developer accounts. For definitions of the **Production** and **Preview** designations, see the [Glossary](https://docs.sambanova.ai/docs/en/resources/glossary.md).

## Production models

Production models are intended for use in production environments and meet SambaNova's high standards for speed and quality.

| **Developer** | **Model ID** | **Context length** | **Supported modalities** | **View on Hugging Face** |
| :- | :- | :- | :- | :- |
| **DeepSeek** | `DeepSeek-V3.1` | 128k tokens | Text | [Model card](https://huggingface.co/deepseek-ai/DeepSeek-V3.1) |
| **Meta** | `Meta-Llama-3.3-70B-Instruct` | 128k tokens | Text | [Model card](https://huggingface.co/meta-llama/Llama-3.3-70B-Instruct) |
| **OpenAI** | `gpt-oss-120b` | 128k tokens | Text | [Model card](https://huggingface.co/openai/gpt-oss-120b) |

***

## Preview models

Preview models are intended for evaluation purposes and developer experimentation only, and should not be used in production environments. These models have limited capacity and may be removed at short notice.

| **Developer** | **Model ID** | **Context length** | **Supported modalities** | **View on Hugging Face** |
| :- | :- | :- | :- | :- |
| **MiniMax** | `MiniMax-M3.1-Flash` | 1M tokens | Text, Image | [Model card](https://huggingface.co/MiniMaxAI/MiniMax-M3.1-Flash) |
| **DeepSeek** | `DeepSeek-V3.2` | 32k tokens | Text | [Model card](https://huggingface.co/deepseek-ai/DeepSeek-V3.2) |
| **Google** | `gemma-4-31B-it` | 128k tokens | Text, Image, Video | [Model card](https://huggingface.co/google/gemma-4-31B-it) |

> [!NOTE]
>
> `gemma-4-31B-it` supports text, image, and video input. Audio input is **not** supported for this model.

### DISCOVER MORE ABOUT FED4FIRE+

**Fed4FIRE+** was a project under the European Union’s Programme Horizon 2020. Based on the legacy of the Fed4FIRE top Internet and Network-related experimentation federation, Fed4FIRE+ has enhanced the largest federation worldwide of Next Generation Internet (NGI) testbeds, providing open, accessible and reliable facilities to a wide variety of different research and innovation communities and initiatives in Europe, including the 5G PPP projects and initiatives. The Fed4FIRE+ project is the successor of the Fed4FIRE project.

Fed4FIRE+ reached its finish line in June 2022 after more than 5 years of operation. Its legacy will be taken by [SLICES-RI](https://slices-ri.eu/), the Scientific LargeScale Infrastructure for Computing/Communication Experimental Studies.

# DISCOVER OUR TESTBEDS

Click on the testbed name to be redirect on the page for more info.

# FED4FIRE+ EXPERIMENTERS VIDEOS

Video interviews with experimenters reveal the advantages of using FED4FIRE+ facilities to perform experiments and validate solutions. Experimentation was performed using the FED4FIRE+ testbeds throughout Europe. **Here experimenters gave their feedback.**

[WATCH THE FULL PLAYLIST HERE!](https://www.youtube.com/playlist?list=PLBqeBTWFIWEpWe37idI2bWakfhDVctBGd)

# LATEST NEWS

Fed4FIRE+ at IoTWeek 2022: a report

### [Fed4FIRE+ at IoTWeek 2022: a report](https://www.fed4fire.eu/news/fed4fire-partners-at-iotweek-2022/index.html)

[June 28, 2022](https://www.fed4fire.eu/2022/06/index.html)

Several Fed4FIRE+ partners participated in IoTWeek 2022 in Dublin, Ireland. Addressing leaders from SMEs and tech industry, Fed4FIRE+ hosted the workshop entitled “Experimenting Next Generation Internet Technologies: success stories, challenges […]

[Read More](https://www.fed4fire.eu/news/fed4fire-partners-at-iotweek-2022/index.html)

INNOVATION THROUGH THE FED4FIRE+ FEDERATED TESTEBDS

### [INNOVATION THROUGH THE FED4FIRE+ FEDERATED TESTEBDS](https://www.fed4fire.eu/news/innovation-through-the-fed4fire-federated-testebds/index.html)

[June 21, 2022](https://www.fed4fire.eu/2022/06/index.html)

The open use of the Fed4FIRE+ federated testbeds has proven to be a solid support for European innovators and researchers validating novel solutions in a number of technology domains. Read […]

[Read More](https://www.fed4fire.eu/news/innovation-through-the-fed4fire-federated-testebds/index.html)

New Testbeds Joins the Fed4FIRE+ Federation

### [New Testbeds Joins the Fed4FIRE+ Federation](https://www.fed4fire.eu/news/new-testbeds-joins-the-fed4fire-federation/index.html)

[June 9, 2022](https://www.fed4fire.eu/2022/06/index.html)

The largest European federation of Next Generation Internet testbeds expands with new facilities and hardware Three new testbeds will join the Fed4FIRE+ federation as a result of the selection of […]

[Read More](https://www.fed4fire.eu/news/new-testbeds-joins-the-fed4fire-federation/index.html)

# THE CONSORTIUM

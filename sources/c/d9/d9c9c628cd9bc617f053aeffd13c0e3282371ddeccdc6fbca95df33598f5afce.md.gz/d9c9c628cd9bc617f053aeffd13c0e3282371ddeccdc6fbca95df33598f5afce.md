# Hitting rate limits with Inference Providers

**URL:** <https://discuss.huggingface.co/t/hitting-rate-limits-with-inference-providers/168245>\
**Category:** Inference Endpoints on the Hub\
**Created:** [September 9, 2025, 5:46pm UTC](https://discuss.huggingface.co/t/hitting-rate-limits-with-inference-providers/168245 "2025-09-09T17:46:36Z")\
**Posts on this page:** 5\
**Page:** 1

<div class="post-metadata">

**Author:** ![simon29](https://avatars.discourse-cdn.com/v4/letter/s/a87d85/32.png) [@simon29](https://discuss.huggingface.co/u/simon29)\
**Post date:** [September 9, 2025, 5:46pm UTC](https://discuss.huggingface.co/t/hitting-rate-limits-with-inference-providers/168245/1 "2025-09-09T17:46:36Z")

</div>

Hi

We are using HuggingFace Inference Providers (with Novita AI) and getting “code”:429, “reason”:“RATE\_LIMIT\_EXCEEDED” API responses.

We’re calling the API ~300 times per minute but would like to call it 400 times per minute. Is it possible to increase our rate limits?

Thanks

---

<div class="post-metadata">

**Author:** ![John6666](https://sea2.discourse-cdn.com/hellohellohello/user_avatar/discuss.huggingface.co/john6666/32/27664_2.png) [@John6666](https://discuss.huggingface.co/u/John6666)\
**Post date:** [September 9, 2025, 9:59pm UTC](https://discuss.huggingface.co/t/hitting-rate-limits-with-inference-providers/168245/2 "2025-09-09T21:59:22Z")

</div>

> “reason”:“RATE\_LIMIT\_EXCEEDED” API responses.

Based on the error message, it seems to [be getting caught on an error on Novita’s side](https://novita.ai/docs/guides/error#error-code-429). In this case, it looks like the only option is to consult Novita’s support…

> To raise your rate limit, contact support or use a verified account.

---

<div class="post-metadata">

**Author:** ![simon29](https://avatars.discourse-cdn.com/v4/letter/s/a87d85/32.png) [@simon29](https://discuss.huggingface.co/u/simon29)\
**Post date:** [September 10, 2025, 7:54am UTC](https://discuss.huggingface.co/t/hitting-rate-limits-with-inference-providers/168245/3 "2025-09-10T07:54:38Z")

</div>

Thanks so much, I contacted them. It wasn’t clear though whether it was due to HuggingFace or Novita.

---

<div class="post-metadata">

**Author:** ![John6666](https://sea2.discourse-cdn.com/hellohellohello/user_avatar/discuss.huggingface.co/john6666/32/27664_2.png) [@John6666](https://discuss.huggingface.co/u/John6666)\
**Post date:** [September 10, 2025, 9:45am UTC](https://discuss.huggingface.co/t/hitting-rate-limits-with-inference-providers/168245/4 "2025-09-10T09:45:16Z")

</div>

There’s an [`Inference Providers` channel on the HF Discord](https://discord.com/channels/879548962464493619/1389546375695302747), so consulting there might be a good option. At the very least, your voice will reach the maintenance team.

---

<div class="post-metadata">

**Author:** ![simon29](https://avatars.discourse-cdn.com/v4/letter/s/a87d85/32.png) [@simon29](https://discuss.huggingface.co/u/simon29)\
**Post date:** [September 10, 2025, 3:14pm UTC](https://discuss.huggingface.co/t/hitting-rate-limits-with-inference-providers/168245/5 "2025-09-10T15:14:28Z")

</div>

Thanks @John6666 - You’re very helpful. I can’t manage to validate my account on Discord, it redirects me to the HF login page and says I’m not logged in (even though I am). I’ll send a direct message to lunarflu on Discord as you’ve advised in other threads.

Request · curl

```
curl --get 'https://earningsfeed.com/api/v1/filings' \
  --header 'Authorization: Bearer YOUR_API_KEY' \
  --data-urlencode 'ticker=AAPL' \
  --data-urlencode 'forms=10-K' \
  --data-urlencode 'limit=5'
```

Response · JSON

```
{
  "items": [
    {
      "accessionNumber": "0000320193-25-000079",
      "formType": "10-K",
      "filedAt": "2025-10-31T00:00:00.000Z"
    }
  ],
  "hasMore": true
}
```

Limits

## Rate limits and retries

Free accounts include 15 requests per minute and 5,000 requests per UTC calendar month. Pro includes 60/min and 250,000/month; Trader includes 300/min and 2,000,000/month. Tier-specific minute limits apply to API-key and MCP requests; interactive docs tokens retain a fixed 10/minute limit. The monthly quota is account-wide across API keys, interactive docs, and MCP.

For `X-RateLimit-Scope: minute`, wait for `Retry-After`, add jitter, and cap retries. A monthly response should not be retried in a loop: wait for the UTC reset, upgrade, or contact support. Monthly allowances are hard caps on Free, Pro, and Trader.

Response headers

- X-RateLimit-Limit
- X-RateLimit-Remaining
- X-RateLimit-Reset
- X-RateLimit-Monthly-Limit
- X-RateLimit-Monthly-Remaining
- X-RateLimit-Monthly-Reset
- X-RateLimit-Monthly-Policy
- X-RateLimit-Scope
- Retry-After

429 retry with jitter

```
async function fetchWithBackoff(url, options) {
  for (let attempt = 0; attempt < 3; attempt++) {
    const response = await fetch(url, options);
    if (response.status !== 429 || attempt === 2) return response;

    if (response.headers.get("X-RateLimit-Scope") === "monthly") {
      return response; // Upgrade, contact support, or wait for the UTC monthly reset.
    }

    const seconds = Number(response.headers.get("Retry-After") ?? "1");
    const jitterMs = Math.floor(Math.random() * 250);
    await sleep(seconds * 1000 + jitterMs);
  }
}
```

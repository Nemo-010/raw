## How to Migrate from SERP APIs to Linkup?

Linkup logo

Linkup Technical Staff

> Google is actively redesigning search around AI, and sued SerpApi for scraping it. SERP APIs return ranked links; AI systems need content. Linkup replaces SerpAPI with one authenticated call that returns extracted text directly - no proxy, no parser, no page fetcher.

At [Google I/O 2026](https://blog.google/products-and-platforms/products/search/search-io-2026/), Google announced the biggest upgrade to its search box in over 25 years. AI Mode has surpassed one billion monthly users, with AI Mode queries more than doubling every quarter since launch. Traditional "ten blue link" results are now accessible via a secondary "Web" tab requiring an extra click, while AI-generated summaries occupy the default view.

This is the same company that [filed a federal lawsuit against SerpApi](https://blog.google/innovation-and-ai/technology/safety-security/serpapi-lawsuit/) in December 2025, alleging circumvention of Google's SearchGuard anti-scraping protections under the DMCA (Digital Millennium Copyright Act, Section 1201). Whether or not SerpApi ultimately prevails, the lawsuit signals that Google is willing to litigate this question - and removes the plausible deniability that previously made SERP scraping a business-level decision rather than a legal one.

Together, these two developments describe the same trend. SERP APIs depend on an interface Google is actively redesigning around AI, defended through litigation, and not built for machine consumption in the first place. We covered the legal dimension in detail in [our previous post on the SerpApi lawsuit](https://www.linkup.so/blog/google-vs-serp-apis-why-linkup-users-stay-safe).

## Why the SERP Format Creates Problems for AI Pipelines

The "ten blue links" format was designed for human browsing. Search engines ranked pages by relevance, displayed them as clickable links, and optimized surrounding content for ads and SEO. [SERP APIs](https://www.linkup.so/blog/best-serp-apis-web-search) extracted that human-oriented output programmatically.

AI systems do not need links. They need context.

The data a SERP API returns - titles, URLs, snippets, rankings - is structured around the assumption that a human will click through and read. When you pass that output to an LLM, you are feeding a system built for human navigation into one that needs factual grounding. The LLM then has to reconstruct meaning from fragments designed for something else entirely.

This mismatch was always present. After Google I/O 2026, it is also becoming a structural problem: as Google moves the default search experience toward AI-generated responses, the link-based output that SERP APIs depend on becomes increasingly secondary.

One practical escape hatch developers sometimes raise: why not use Bing's API instead of SerpAPI? Bing's API is a legitimate option for structured link results. The issue is the same one as SerpAPI - it returns ranked links and snippets, not the content itself. You still need to fetch pages, parse them, and handle content extraction. The pipeline complexity and the fundamental mismatch between ranked links and LLM context remain. A [web search API](https://www.linkup.so/) that returns content directly removes those steps.

## What a Web Search API Does Instead

Traditional search was built to return links. AI systems need context, raw information, and current data.

A link is useless to an AI. It needs the text, the data, the context behind that link. Search engines were designed for human behavior: you enter a query, get a list of relevant pages, click through, skim headings, and decide what's useful. AI systems skip all of that. They need the information itself - extracted, structured, and ready to process.

[Linkup](https://www.linkup.so/) is built around this distinction. Instead of indexing web pages, Linkup extracts what it calls atoms of information: individual facts and discrete pieces of knowledge from across the web. A competitor's recent product update. A company's latest earnings. Yesterday's regulation change. Each becomes an atom in the index, complete with its source, timestamp, and credibility markers.

Linkup then generates embeddings - mathematical representations - of these information atoms. When your AI queries the platform, it does not receive a list of websites to visit. It receives precisely the information it needs, already extracted and structured for immediate use, retrieved not by matching keywords but by understanding the actual meaning of the query.

This is what makes Linkup the retrieval layer of an AI stack. It operates early in the pipeline: its role is to ensure that downstream systems - typically language models - have access to current, high-quality data inputs. Every result is traceable to a specific source URL. Output formats and retrieval depth are configurable. Domains can be whitelisted or blacklisted on demand.

Because this index is built through direct crawling - independent of Google's interface - the legal risks attached to SERP scraping do not transfer. Linkup respects [robots.txt](https://developers.google.com/search/docs/crawling-indexing/robots/intro), which means its index reflects what publishers have made available for crawling: a transparent and auditable scope.

## Migrating: What Actually Changes

Three things change: the package, the API call, and the response field you read.

### 1. Install

`pip install linkup-sdk`

### 2. Replace the call

`# Before - SerpAPI from serpapi import GoogleSearch results = GoogleSearch({"engine": "google", "q": query, "num": 10, "api_key": SERPAPI_KEY}).get_dict() content = [r["snippet"] for r in results["organic_results"]] # After - Linkup from linkup import LinkupClient response = LinkupClient(api_key=LINKUP_KEY).search(query=query, depth="standard", output_type="searchResults") content = [r.content for r in response.results]`

The key difference on the response side: SerpAPI returns `snippet` - a short extract designed for human reading. Linkup returns `content` - the full extracted text, ready to pass directly to an LLM.

### 3. Map your parameters

| **SerpAPI** | **Linkup** | **Notes** |
| --- | --- | --- |
| `q` | `query` |  |
| `num` | `max_results` | Default: 10 |
| `tbs` | `from_date / to_date` | ISO 8601 (YYYY-MM-DD) |
| `as_dt` | `include_domains` | Array of domains |
| `as_eq` | `exclude_domains` | Array of domains |
| - | `depth` | `"standard"` or `"deep"` |
| - | `output_type` | `"searchResults"`, `"sourcedAnswer"`, `"structured"` |

The [full migration guide](https://docs.linkup.so/pages/documentation/tutorials/migrating-from-serpapi) covers JavaScript, all response formats, and additional examples.

## What Changes After Migration

**No proxy infrastructure.** SERP scraping requires proxy rotation, CAPTCHA handling, and parsing logic that breaks when Google updates its interface. Linkup removes all of that. One authenticated API call returns usable content.

**Depth control.** The [`depth` parameter](https://docs.linkup.so/pages/documentation/endpoints/search/reference) lets you match retrieval depth to query complexity: `standard` for most queries, `deep` for multi-step research that requires synthesizing across many sources. SERP APIs return a fixed number of ranked links regardless of how complex the question is.

**Fresh content.** Linkup's index is updated in near real-time. For time-sensitive queries - breaking news, regulatory updates, live pricing - results reflect current information rather than a cached ranking snapshot.

**EU compliance.** Linkup is a European web search API, with [EU data residency](https://www.linkup.so/blog/what-is-ai-search-api-compliance-and-what-enterprise-teams-should-demand-in-2026), [GDPR compliance](https://www.linkup.so/blog/web-search-apis-in-europe), zero data retention, SOC 2 Type II certification, and signed DPA available for [enterprise deployments](https://www.linkup.so/product/enterprise). For teams in regulated industries or with data residency requirements, this removes a procurement friction point.

## FAQ

**How long does migration take?**

For most integrations, under a few hours all include. The main changes are: endpoint URL, authentication header, and a small set of parameter names. On the response side, map from `organic_results[].link` / `snippet` to `results[].url` / `content`. If your prompt passes snippet text to an LLM, it will now receive full content - prompts may need light adjustment. See the [quickstart guide](https://docs.linkup.so/pages/documentation/get-started/quickstart) to get up and running.

**Will I get the same results as SerpAPI?**

The results will be different because the sources are different. Linkup returns content from its own AI-native index rather than Google's ranked results. For AI pipelines, this generally means better grounding: full content instead of snippets, and relevance based on information retrieval rather than SEO rankings. No ads. No useless metadata. No noise.

**What if I just use the Brave API instead?**

Brave's API is a legitimate option for programmatic search without the legal risk of scraping Google. The core issue remains the same: it returns ranked links and snippets, not content. Your pipeline still needs to fetch each page, extract text, and handle parsing. Linkup skips those steps by returning content directly.

**Does Linkup work with LangChain, LlamaIndex, and other frameworks?**

Yes. Linkup integrates with [LangChain](https://python.langchain.com/docs/integrations/tools/linkup/), [LlamaIndex](https://docs.llamaindex.ai/en/stable/examples/tools/linkup/), [CrewAI](https://docs.linkup.so/pages/integrations/crewai), [n8n](https://docs.linkup.so/pages/integrations/n8n), [Zapier](https://docs.linkup.so/pages/integrations/zapier), and [Make](https://docs.linkup.so/pages/integrations/make), as well as direct API access via Python and JavaScript SDKs.

**Is there a [free tier](https://www.linkup.so/blog/best-web-search-api-in-2026-top-providers-compared)?**

Yes. New accounts start with $20 of free credit. No credit card required. [Create your account here](https://app.linkup.so/).

Ready to migrate? [Get your API key for free](https://app.linkup.so/) or [read the full migration guide in the docs](https://docs.linkup.so/pages/documentation/tutorials/migrating-from-serpapi).

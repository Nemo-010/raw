tunelo — Expose localhost to the internet

Expose anything to the internet — local ports, files, directories. One command, instant HTTPS tunnel. Built in Rust — single binary, 8 MB memory, zero-copy data plane. Star on GitHub.

`$ tunelo port 3000
 Tunnel is ready.

 Public URL: https://swift-fox-3847.tunelo.net
 Forwarding: http://localhost:3000`

`$ tunelo serve .
 Serving /Users/you/project on :51234
 Tunnel is ready.

 Public URL: https://calm-river-9012.tunelo.net
 Forwarding: http://127.0.0.1:51234`

Other tunnel tools need config files, accounts, or dashboards. Tunelo is a single binary that does two things: expose a local port, or serve files with a built-in web explorer. QUIC transport gives you multiplexed, encrypted, low-latency tunneling. By default, the client connects to the public relay at `tunelo.net` — or point it at your own with `--relay`.

# Install

macOS / Linux:

`curl -fsSL https://tunelo.net/install.sh | sh`

Windows (PowerShell):

`irm https://tunelo.net/install.ps1 | iex`

Supported platforms:

| OS | Architecture | Binary |
| --- | --- | --- |
| Linux | x86_64 / arm64 | tunelo-linux-amd64 / arm64 |
| macOS | x86_64 / arm64 | tunelo-macos-amd64 / arm64 |
| Windows | x86_64 | tunelo-windows-amd64.exe |

Or download directly from GitHub Releases.

# Quick start

Two terminals and you're sharing a local service with the world.

1. Start your local service:

1`python3 -m http.server 3000`

2. Expose it:

1`tunelo port 3000`

That's it — no flags needed. The client connects to the public relay at `tunelo.net` by default, assigns you a public URL like `https://swift-fox-3847.tunelo.net`, and starts relaying traffic to your localhost through an encrypted QUIC tunnel.

Or run a command and tunnel it in one step:

1`tunelo port 3000 -- pnpm dev`

Tunelo spawns `pnpm dev`, waits for port 3000 to be ready, then creates the tunnel. When either stops, the other is cleaned up.

Install the skill to teach your AI coding agent how to use tunelo:

`npx -y skills add tunelo/tunelo`

The skill teaches your agent the CLI, when to use tunnels, and handles setup automatically.

# File server

Run `tunelo serve .` or `tunelo serve ./dist` and tunelo starts a built-in file server with a React web explorer — embedded directly in the binary. Browse directories, preview files, share them through a public URL. No nginx, no Python server, no external dependencies.

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15`# Serve current directory through a tunnel
tunelo serve .

# Serve a specific directory
tunelo serve ./dist

# Serve a single file
tunelo serve README.md
tunelo serve index.html

# Local-only preview (no tunnel)
tunelo serve . --local

# Local preview on a specific port
tunelo serve . -l -p 8000`

The web explorer supports:

- Directory browsing — navigate folders with breadcrumbs, sorted listing
- Code viewer — syntax highlighting for source files
- Markdown — rendered with full formatting
- PDF viewer — embedded PDF rendering
- Media players — video, audio, image preview with seeking support
- Data tables — CSV and Excel file viewer
- Range requests — streaming for large files, seeking in media

The frontend is compiled into the binary at build time via `include_dir!`. One binary — client, file server, and relay all in one. The file server API is two endpoints: `/_api/ls` for directory listings and `/_api/raw` for file content. Everything else serves the SPA.

One binary. File server + web explorer + tunnel. No setup.

# How it works

The client opens a QUIC connection to the relay and gets a subdomain. When a browser hits that URL, the relay peeks at the Host header, finds the matching tunnel, opens a QUIC stream, and does `copy_bidirectional` between the TCP socket and the QUIC stream. Zero HTTP parsing on the data path. On reconnect, the client re-requests the same subdomain — your URL stays stable across network disruptions.

`Browser → HTTPS → Relay → QUIC stream → Client → localhost:3000
 (8 MB) (8 MB)

┌──────────┐ ┌────────────────┐ ┌───────────────┐ ┌───────────┐
│ Browser │──▶│ tunelo relay │◀──│ tunelo client │──▶│ localhost │
│ │ │ TLS + routing │ │ QUIC tunnel │ │ :3000 │
└──────────┘ └────────────────┘ └───────────────┘ └───────────┘
 Internet Your VPS Your machine Your app`

- Control stream — one persistent QUIC stream for registration + heartbeats (msgpack framing)
- Data streams — new bidirectional QUIC stream per HTTP request, zero-copy relay
- No buffering — `tokio::io::copy_bidirectional` between TCP and QUIC, no intermediate copies

Only the control stream uses serialization. Data streams are raw bytes.

# CLI reference

The client and relay are fully decoupled. The client defaults to the public relay at `tunelo.net:4433` — or use `--relay` to point at your own. No account, no signup.

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18`# Port mode — expose a local port
tunelo port 3000
tunelo port 3000 --relay my.server:4433
tunelo port 3000 -H 192.168.1.100
tunelo port 3000 --password
tunelo port 3000 --password mysecret

# Run a command and tunnel it
tunelo port 3000 -- pnpm dev
tunelo port 3000 -- next start
tunelo port 5173 -- vite

# File mode — serve files or directories
tunelo serve .
tunelo serve ./dist
tunelo serve README.md
tunelo serve . --local
tunelo serve . -l -p 8000`

Relay configuration:

1 2 3 4 5 6 7 8`# Start with defaults
tunelo relay

# Production deployment
tunelo relay --domain tunelo.net

# Custom addresses
tunelo relay --tunnel-addr 0.0.0.0:4433 --http-addr 0.0.0.0:80`

Client: one binary, one command. Relay: three flags.

# Self-hosting

Don't want to use the public relay? Run your own on any VPS. The client and relay are the same binary — just point `--relay` at your server. The deploy/ directory has everything: systemd service, nginx config, Let's Encrypt with Cloudflare DNS.

1 2 3 4 5 6 7 8`# Build the relay
cargo build --release --bin tunelo

# Run it
./target/release/tunelo relay --domain yourdomain.com

# Point your clients to it
tunelo port 3000 --relay yourdomain.com:4433`

You need:

- A domain with wildcard DNS (`*.yourdomain.com` → your VPS IP)
- A wildcard TLS certificate (Let's Encrypt + DNS-01 challenge)
- Nginx for TLS termination, proxying `*.yourdomain.com:443` → relay `:8080`
- UDP port 4433 open for QUIC tunnel connections

# Performance

Measured on localhost. Zero errors under 5,000 request stress test. The relay is a data-plane proxy — it copies bytes, not parses them.

| Metric | Value |
| --- | --- |
| Relay memory | 8 MB RSS |
| Client memory | 8 MB RSS |
| Binary size | ~4 MB (stripped, LTO) |
| Tunnel overhead vs direct | ~14% (0.56s vs 0.49s / 100 req) |
| Sequential latency | ~6ms/req (localhost) |
| Throughput (20 concurrent) | 670 req/s |
| Throughput (200 concurrent) | 672 req/s |
| Errors under stress (5000 req) | 0 |

No GC pauses. No runtime overhead. Just async Rust.

# AI skill

Tunelo ships with a SKILL.md that teaches any AI coding agent how to create tunnels. One command to install it:

`npx -y skills add tunelo/tunelo`

The skill tells your agent what tunelo does, when to use it, and all the CLI flags. After installing, your agent can run `tunelo port 3000` when you ask it to "share this locally" or "expose my dev server."

What the skill teaches:

- Expose ports with `tunelo port `
- Run commands and tunnel them with `tunelo port 3000 -- pnpm dev`
- Password protection with `--password`
- Serve files with `tunelo serve .`

Follows the same skill format as RunBrowser.

# Comparison

Why use tunelo over the alternatives.

vs ngrok

| | ngrok | tunelo |
| --- | --- | --- |
| Price | Free tier limited | Free & open source |
| Account required | Yes | No |
| Self-hostable | No | Yes |
| Transport | HTTP/2 | QUIC |
| Binary size | ~25 MB | ~4 MB |
| Memory | ~50 MB | 8 MB |

vs bore

| | bore | tunelo |
| --- | --- | --- |
| Routing | By TCP port | By subdomain (hostname) |
| Transport | TCP | QUIC (multiplexed) |
| TLS | No built-in | TLS at relay |
| Public URL | bore.pub:PORT | subdomain.tunelo.net |
| HTTP-aware | No | Yes (Host header routing) |

vs Cloudflare Tunnel

| | cloudflared | tunelo |
| --- | --- | --- |
| Self-hostable | No | Yes |
| Vendor lock-in | Cloudflare only | Any VPS |
| Transport | HTTP/2 (h2mux) | QUIC |
| Complexity | Named tunnels, DNS config | One command |
| Open source relay | No | Yes |

# Security

The tunnel is outbound-only — the client connects to the relay, not the other way around. No inbound ports needed on your machine.

- QUIC encryption — tunnel traffic is encrypted with TLS 1.3 (rustls)
- TLS termination — public HTTPS at the relay with Let's Encrypt certificates
- No data storage — the relay copies bytes, doesn't inspect or store them
- Password protection — optional `--password` with cookie-based auth
- Self-hostable — run your own relay, control your own data
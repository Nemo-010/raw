DNS

- [Overview](https://bunny.net/dns/)
- [Pricing](https://bunny.net/pricing/dns/)
- [Docs ➜](https://bunny.net/docs/dns)

# Bunny DNS

## Unlock the true power of DNS

## Unlock the true  
 power of DNS

Hop on an ultra-fast **DNS** platform designed to power the next generation of applications. By utilizing scriptable records, Bunny DNS helps you unlock the true power of DNS and turn complex issues into simple solutions.

[Start 14-Day FREE Trial](https://dash.bunny.net/auth/register?pk_buttonlocation=hero&pk_buttonurl=dns)

No credit card required. Complete setup in 2 minutes.

#### Join over 1.5 million websites already powered by bunny.net

Our dedication to quality has won the trust of many well-known brands in their industries.

[Trustpilot](https://www.trustpilot.com/review/bunny.net)

## Build faster. Hop faster.

Get started in less than 5 minutes and take your web presence to the next level.

bunny.net scriptable dns

bunny.net scriptable dns

#### Simplify CDN Integration

Connect your domains to Bunny CDN with the click of a button to supercharge and protect your applications in seconds.

bunny.net scriptable dns

#### Script Your Way Around Complexity

Simplify deployments, deliver complex global logic, or automate your infrastructure with scriptable DNS records.

bunny.net scriptable dns

#### Massive Scalability

Power projects at scale without worry with a DNS system that already backs one of the busiest CDN platforms on the planet.

## **DNS platform** for next-gen apps

Next-Generation Scriptable DNS

Make intelligent routing decisions and build smart network services with just a few lines of code. Interconnect your applications and get complete control of your network behavior.

- Load Balancing
- SEO Optimization
- Service Discovery
- Domain Mapping
- Multi-Cloud Solutions
- Geographical Routing

Next-Generation Scriptable DNS

## Stay online. Stay fast.

Leverage a massively redundant global infrastructure engineered for 100% uptime and lightning-fast performance.

Global Anycast

### Global Anycast

Keep latency to users below 20 ms in most regions worldwide, thanks to 36+ global DNS PoPs.

Redundant Networks

### Redundant Networks

Stay online thanks to a redundant network that prevents single points of failure.

Powerful DDoS Protection

### Powerful DDoS Protection

Keep peace of mind with built-in security features and DDoS protection.

## Key features designed to  
help you hop ahead

DNS packed with powerful solutions.

- Custom NameserversCustom Nameservers
- Advanced AnalyticsAdvanced Analytics
- Built-In MonitoringBuilt-In Monitoring
- Powerful Load BalancingPowerful Load Balancing

#### Keep your brand in  
 your own hands

Keep your brand in the spotlight at every step of your web presence. Easily set up custom nameservers on your own custom domain with just a few clicks at no extra cost. Unlock internal delegations for administrative benefits without having to manage your network.

Bunny DNS Custom Nameservers

### Custom Nameservers

#### Keep your brand in  
 your own hands

Bunny DNS Custom Nameservers

Keep your brand in the spotlight at every step of your web presence. Easily set up custom nameservers on your own custom domain with just a few clicks at no extra cost. Unlock internal delegations for administrative benefits without having to manage your network.

#### Gain full visibility  
 into your DNS

Get complete insight into your DNS traffic with advanced analytics and full raw logging. Monitor query traffic in real time and break it down in record time. Easily perform advanced analysis on the raw logs through the dashboard or API to spot security holes or debug integration issues.

Bunny DNS Advance Analytics

### Advanced Analytics

#### Gain full visibility  
 into your DNS

Bunny DNS Advance Analytics

Get complete insight into your DNS traffic with advanced analytics and full raw logging. Monitor query traffic in real time and break it down in record time. Easily perform advanced analysis on the raw logs through the dashboard or API to spot security holes or debug integration issues.

#### Take a look at the full picture with built-in monitoring

Get a clear picture of your system status with a built-in monitoring system. Any A records added to Bunny DNS are automatically monitored via ping or HTTP requests. Get an instant view of your system health straight from your DNS dashboard without using third-party services.

Bunny DNS Built-In Monitoring

### Built-In Monitoring

#### Take a look at the full picture with built-in monitoring

Bunny DNS Built-In Monitoring

Get a clear picture of your system status with a built-in monitoring system. Any A records added to Bunny DNS are automatically monitored via ping or HTTP requests. Get an instant view of your system health straight from your DNS dashboard without using third-party services.

#### Distribute load and balance your infrastructure

Steer your users over DNS or CDN with a smart load balancing system. With just a few clicks, activate health checks, weights, geographical or latency-based CDN origin routing to help you build and connect to your infrastructure stack without complex configurations or high costs.

Powerful Load Balancing DNS

### Powerful Load Balancing

#### Distribute load and balance your infrastructure

Powerful Load Balancing DNS

Steer your users over DNS or CDN with a smart load balancing system. With just a few clicks, activate health checks, weights, geographical or latency-based CDN origin routing to help you build and connect to your infrastructure stack without complex configurations or high costs.

## Take full control of your DNS

How does scriptable DNS work

## Trusted by 100,000+ Customers

MuslimCentral

### “We find the bunny.net service to be resplendent. The user interface is excellent, well priced, and supported by superb turnaround times. One of the best online service providers we've dealt with."

MuslimCentral

[Trustpilot](https://www.trustpilot.com/review/bunny.net)

## Start your 14-day FREE trial

Join thousands of happy customers already using bunny.net

[Start FREE Trial](https://panel.bunny.net/user/register)

No credit card required. Complete setup in 2 minutes.

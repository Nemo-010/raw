# 一款网盘分享链接云解析快速下载服务

QQ交流群：1017480890

[GitHub Stars](https://github.com/QAIU/netdisk-fast-download) [AtomGit](https://atomgit.com/QAIU/netdisk-fast-download)

[qaiu%2Fnetdisk-fast-download | Trendshift](https://trendshift.io/repositories/12101)

[alt text](https://github.com/qaiu/netdisk-fast-download/blob/main/web-front/img/image.png)

> 本平台所有音乐解析工具不再维护，请移步[Sonder播放器](https://sodecode.qaiu.top/)  
>  需要百度，迅雷，UC，夸克的完整支持请使用[专业版](https://189.qaiu.top/)

## 介绍

> netdisk-fast-download网盘直链解析可以把云盘分享链接转为直链，可广泛应用于各类下载站，资源站，个人博客，图床，APP下载更新，视频点播等领域。支持市面各大主流云盘的文件分享以及文件夹分享链接，已支持蓝奏云/蓝奏云优享/移动云云空间/小飞机盘/亿方云/123云盘/永硕E盘/Cloudreve等，支持加密分享，以及部分网盘文件夹分享。

[官方文档](https://nfd-parser.github.io/)  
 [API接入](https://nfdparser.apifox.cn/)  
 [公益解析，lz站](https://lz.qaiu.top/)  
 [公益解析，lz0站](https://lz0.qaiu.top/)  
 [专业版](https://189.qaiu.top/)

## 快速开始

以带提取码的分享链接为例（提取码 `1234`），链接中含 `#`、`&`，作为 `url` 参数传入前必须做 URL 编码：

`https://www.ecpan.cn/web/#/yunpanProxy?path=%2F%23%2Fdrive%2Foutside&data=70017ece572737b12b30709b7f029308eJD0&isShare=1`

**命令行下载**

```
# curl
curl -LOJ "https://lz.qaiu.top/parser?url=https%3A%2F%2Fwww.ecpan.cn%2Fweb%2F%23%2FyunpanProxy%3Fpath%3D%252F%2523%252Fdrive%252Foutside%26data%3D70017ece572737b12b30709b7f029308eJD0%26isShare%3D1&pwd=1234"

# wget
wget -O v01 "https://lz.qaiu.top/parser?url=https%3A%2F%2Fwww.ecpan.cn%2Fweb%2F%23%2FyunpanProxy%3Fpath%3D%252F%2523%252Fdrive%252Foutside%26data%3D70017ece572737b12b30709b7f029308eJD0%26isShare%3D1&pwd=1234"
```

**短链方式**（key 取分享链接的 `data` 参数，提取码用 `@` 拼接）

| 用途 | 地址 |
| --- | --- |
| 下载 | `https://lz.qaiu.top/ec/70017ece572737b12b30709b7f029308eJD0@1234` |
| 在线预览 | [点击访问](https://nfd-parser.github.io/nfd-preview/preview.html?src=https%3A%2F%2Flz.qaiu.top%2Fec%2F70017ece572737b12b30709b7f029308eJD0%401234&name=v01&ext=mp4) |

> 无提取码时去掉 `&pwd=1234` / `@1234` 即可；预览页 `src` 需编码（`@` → `%40`），用短链可避免二次编码。

**解析器模块文档：** [parser/README.md](https://github.com/qaiu/netdisk-fast-download/blob/main/parser/README.md)

**JavaScript解析器文档：** [JavaScript解析器开发指南](https://github.com/qaiu/netdisk-fast-download/blob/main/parser/doc/JAVASCRIPT_PARSER_GUIDE.md) | [自定义解析器扩展指南](https://github.com/qaiu/netdisk-fast-download/blob/main/parser/doc/CUSTOM_PARSER_GUIDE.md) | [快速开始](https://github.com/qaiu/netdisk-fast-download/blob/main/parser/doc/CUSTOM_PARSER_QUICKSTART.md)

**Playground功能：** [JS解析器演练场密码保护说明](https://github.com/qaiu/netdisk-fast-download/blob/main/web-service/doc/PLAYGROUND_PASSWORD_PROTECTION.md)

**注意⚠️小飞机解析有IP限制，多数云服务商的大陆IP会被拦截（可以自行配置代理），和本程序无关**  
 **注意⚠️收到很多用户反馈，小飞机近期封号频繁，请尽可能选择其他网盘分享**  
 **注意⚠️请不要过度依赖 lz.qaiu.top，建议本地搭建或者云服务器自行搭建。请求量过多的话服务器可能会被云盘厂商限制，遇到解析失败的分享链接不要着急提issues，请先检查分享是否有效。**

## 网盘支持情况:

> 20230824 123云盘解析大文件(>100MB)失效，需要登录  
>  20230722 UC网盘解析失效，需要登录

网盘名称-网盘标识:

- [蓝奏云-lz](https://pc.woozooo.com/)
- [蓝奏云优享-iz](https://www.ilanzou.com/)
- [移动云云空间-ec](https://www.ecpan.cn/web)
- [小飞机网盘-fj](https://www.feijipan.com/)
- [亿方云-fc](https://www.fangcloud.com/)
- [123云盘-ye](https://www.123pan.com/)

  ⚠️

  仅建议本地部署使用。公共云解析没有共享 123 账号；下载返回 5112 / 请登录后下载时，在本机配置 `auths.ye.authorization`（Windows 可直接用 run.bat）
- ~~[115网盘(失效)-p115](https://115.com/)~~
- [文叔叔-ws](https://www.wenshushu.cn/)
- [联想乐云-le](https://lecloud.lenovo.com/)
- [QQ邮箱云盘-qqw](https://mail.qq.com/)
- [QQ闪传-qqsc](https://nutty.qq.com/nutty/ssr/26797.html)
- [城通网盘-ct](https://www.ctfile.com/)
- [永硕E盘-ys](https://www.ysepan.com/)（空间分享，如 `https://xxx.ysepan.com/`，密码为空间访问密码；多文件请用文件列表接口）
- [网易云音乐分享链接-mnes](https://music.163.com/)
- [酷狗音乐分享链接-mkgs](https://www.kugou.com/)
- [酷我音乐分享链接-mkws](https://kuwo.cn/)
- [QQ音乐分享链接-mqqs](https://y.qq.com/)
- [Cloudreve自建网盘-ce](https://github.com/cloudreve/Cloudreve)
- ~~[微雨云存储-pvvy](https://www.vyuyun.com/)~~
- [超星云盘(需要referer: https://pan-yz.chaoxing.com)-pcx](https://pan-yz.chaoxing.com/)
- [飞书云盘-fs](https://www.feishu.cn/)
- [WPS云文档-pwps](https://www.kdocs.cn/)
- [汽水音乐-qishui_music](https://music.douyin.com/qishui/)
- [咪咕音乐-migu](https://music.migu.cn/)
- Google云盘-pgd
- Onedrive-pod
- Dropbox-pdp
- iCloud-pic

### 专业版提供

- 百度网盘开放平台-bd
- 迅雷云盘开放平台-xl
- [光鸭云盘开放平台-gy](https://www.guangyapan.com/)
- [夸克云盘-qk](https://pan.quark.cn/)
- [UC云盘-uc](https://fast.uc.cn/)
- [移动云盘-p139](https://yun.139.com/)
- [联通云盘-pwo](https://pan.wo.cn/)
- [天翼云盘-p189](https://cloud.189.cn/)

## API接口

[api接口文档](https://nfdparser.apifox.cn/)

### 服务端口

- **6400**: API 服务端口（建议使用 Nginx 代理）
- **6401**: 内置 Web 解析工具（个人使用可直接开放此端口）

### 接口说明

#### 1. 302 自动跳转下载

**通用接口**

```
GET /parser?url={分享链接}&pwd={密码}
```

**标志短链**

```
GET /d/{网盘标识}/{分享key}@{密码}
```

#### 2. 获取直链 JSON

**通用接口**

```
GET /json/parser?url={分享链接}&pwd={密码}
```

**标志短链**

```
GET /json/{网盘标识}/{分享key}@{密码}
```

注意： 移动云云空间的 `分享key` 取分享链接中的 `data` 参数值

#### 3. 文件夹解析（v0.1.8fixed3+）

```
GET /json/getFileList?url={分享链接}&pwd={密码}
```

### 使用规则

- `{分享链接}` 建议使用 URL 编码
- `{密码}` 无密码时省略 `&pwd=` 或 `@密码` 部分
- `{网盘标识}` 参考支持的网盘列表
- `your_host` 替换为您的域名或 IP

### 认证参数（v0.2.1+）

[可以使用在线认证参数加密](https://qaiu.top/nfd-auth.html) 部分网盘需要登录后的 Cookie 或 Authorization 才能下载。可通过 `auth` 参数传递认证信息：

**参数格式**：`auth` 参数值为 AES 加密后的 JSON 字符串，经过 Base64 编码和 URL 编码

**加密方式**：

- 算法：AES/ECB/PKCS5Padding
- 密钥：`nfd_auth_key2026`（16字节）
- 流程：JSON → AES加密 → Base64 → URL编码

**JSON 结构**：

```
{
  "authType": "cookie",        // 认证类型: cookie/accesstoken/authorization/password/custom
  "token": "your_cookie_here", // Cookie 或 Token 内容
  "username": "",              // 用户名（password 类型时使用）
  "password": "",              // 密码（password 类型时使用）
  "ext1": "",                  // 扩展字段1（custom 类型时使用）
  "ext2": ""                   // 扩展字段2（custom 类型时使用）
}
```

**网盘认证要求**：

| 网盘 | 认证要求 | 说明 |
| --- | --- | --- |
| 夸克网盘(QK) | 小文件可免登录 | 小文件走访客直链。文件夹会先列目录再进入。超过访客大小限制（上游 23018，本次核对约 90MB 失败、约 12MB–27MB 成功）必须配置 `auths.qk.cookie` 或请求 `auth`。未配置 Cookie 时不会转存 |
| UC网盘(UC) | **必须** | 不能免登录，必须配置 Cookie |
| 小飞机网盘(FJ) | 可选 | 大文件（>100MB）需要认证 |
| 蓝奏优享(IZ) | 可选 | 大文件需要认证 |
| 123网盘(YE) | 下载通常需要 | 分享列表经常可以不登录读取。下载接口常见 5112 / 请登录后下载 / 您需要注册登录或付费后下载，请在**本机**配置 `auths.ye.authorization`（与 `token` 等价）或账号密码。公共云解析没有共享 123 账号。约 10MB 小文件有时可以直链，大文件和风控必须用你自己的账号。短链：`ye:分享key@提取码`；`#` 片段会去掉；`yun.123pan.com`、`www.123pan.com`、`*.share.123pan.cn` 同一类 |

**使用示例**：

```
GET /parser?url={分享链接}&pwd={密码}&auth={加密后的认证参数}
```

> 💡 提示：Web 界面已内置认证配置功能，可自动处理加密过程，无需手动构造参数。 [可以使用在线认证参数加密](https://qaiu.top/nfd-auth.html)

#### 密钥作用说明

- `server.authEncryptKey`

    - 作用：用于 `auth` 参数的 AES 加解密
    - 要求：16位（AES-128）
- `server.donatedAccountFailureTokenSignKey`

    - 作用：用于“捐赠账号失败计数 token”的 HMAC 签名/验签
    - 目的：防止客户端伪造失败计数请求
    - 建议：使用高强度随机字符串，且不要与 `authEncryptKey` 相同

#### `auth` 临时认证参数 与 `auths` 静态配置认证 的区别

本项目存在两种互相独立的认证配置方式，作用范围不同，不要混淆：

| 方式 | 配置位置 | 生效范围 | 适用场景 |
| --- | --- | --- | --- |
| `auth` 临时认证参数 | 请求 URL 上的 `auth` 查询参数 | **仅当次请求**，优先级高于 app-dev.yml 中的静态配置 | 调用方按用户临时提供的账号/Cookie/token 解析，不同请求可携带不同认证信息 |
| `auths` 静态配置认证 | `app-dev.yml` 的 `auths.<网盘标识>` 节点 | **服务端长期生效**，所有未携带 `auth` 参数的请求都会复用 | 部署方自己长期配置一份账号，供所有请求默认使用 |

以 123网盘（`ye`）为例，`app-dev.yml` 中支持以下几种写法（三选一即可）：

```
auths:
  ye:
    username: 你的123网盘账号
    password: 你的123网盘密码
```

```
auths:
  ye:
    token: 已登录后获取的 Authorization/AccessToken
```

```
auths:
  ye:
    authorization: 已登录后获取的 Authorization/AccessToken   # 与 token 等价，二选一
```

> ⚠️ 注意：YAML 中 key 后面不写值（如 `authorization:` 空着）等同于没配置，不会生效，必须填入真实的账号密码或 token 内容。
>
> 若 123 云盘账号密码登录触发验证码或风控，解析会直接失败并提示改用 Authorization，不会尝试验证码。请改填上面的 `authorization` / `token`（浏览器 localStorage 的 `authorToken`，或请求头 `authorization` / Cookie `sso-token` 里的 JWT）。
>
> 公共解析站（例如别人搭的在线解析）不能替你登录 123。看到「请登录后下载」「5112」「您需要注册登录或付费后下载」时，把服务跑在自己的机器上并填入自己的 Authorization。这是 123 的登录和风控要求。链接写法：`/d/ye/分享key@提取码`；浏览器地址栏里 `#` 后面的片段不参与解析；`yun.123pan.com` 与 `www.123pan.com`、`数字.share.123pan.cn` 是同一种分享。

如果只是临时调用一次，不想改动服务端配置，也可以用上面提到的 `auth` 参数临时传递（`authType` 可选 `password`/`accesstoken`/`authorization`），无需重启服务，仅本次请求生效。

### 示例

```
# 302 跳转（通用接口 - 有密码）
http://your_host/parser?url=https%3A%2F%2Fwww.ilanzou.com%2Fs%2FlGFndCM&pwd=KMnv

# 302 跳转（标志短链 - 有密码）
http://your_host/d/iz/lGFndCM@KMnv

# 获取 JSON（通用接口 - 无密码）
http://your_host/json/parser?url=https%3A%2F%2Fwww.ilanzou.com%2Fs%2FLEBZySxF

# 获取 JSON（标志短链 - 无密码）
http://your_host/json/iz/LEBZySxF
```

---

### json接口详细说明

#### 1. 文件解析：/json/parser?url=分享链接&pwd=xxx

json返回数据格式示例:  
 `shareKey`: 全局分享key  
 `directLink`: 下载链接  
 `cacheHit`: 是否为缓存链接  
 `expires`: 缓存到期时间

```
{
  "code": 200,
  "msg": "success",
  "success": true,
  "count": 0,
  "data": {
    "shareKey": "lz:xxx",
    "directLink": "下载直链", 
    "cacheHit": true,
    "expires": "2024-09-18 01:48:02",
    "expiration": 1726638482825
  },
  "timestamp": 1726637151902
}
```

#### 2. 分享链接详情接口 /v2/linkInfo?url=分享链接

```
{
    "code": 200,
    "msg": "success",
    "success": true,
    "count": 0,
    "data": {
        "downLink": "https://lz.qaiu.top/d/fj/xx",
        "apiLink": "https://lz.qaiu.top/json/fj/xx",
        "cacheHitTotal": 5,
        "parserTotal": 2,
        "sumTotal": 7,
        "shareLinkInfo": {
            "shareKey": "xx",
            "panName": "小飞机网盘",
            "type": "fj",
            "sharePassword": "",
            "shareUrl": "https://share.feijipan.com/s/xx",
            "standardUrl": "https://www.feijix.com/s/xx",
            "otherParam": {
                "UA": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0"
            },
            "cacheKey": "fj:xx"
        }
    },
    "timestamp": 1736489219402
}
```

#### 3. 文件夹解析(支持蓝奏云/蓝奏优享/小飞机/永硕E盘等)

/v2/getFileList?url=分享链接&pwd=分享密码

永硕E盘（`ys`）空间链接先返回目录列表，再带 `dirId` 获取目录内文件： `/v2/getFileList?url=https://xxx.ysepan.com/&pwd=空间密码&dirId=目录编号`

```
{
  "code": 200,
  "msg": "success",
  "success": true,
  "data": [
    {
      "fileName": "xxx",
      "fileId": "xxx",
      "fileIcon": null,
      "size": 999,
      "sizeStr": "999 M",
      "fileType": "file/folder",
      "filePath": null,
      "createTime": "17 小时前",
      "updateTime": null,
      "createBy": null,
      "description": null,
      "downloadCount": "下载次数",
      "panType": "lz",
      "parserUrl": "下载链接/文件夹链接", 
      "extParameters": null
    }
}
```

#### 4. 解析次数统计接口 /v2/statisticsInfo

```
{
    "code": 200,
    "msg": "success",
    "success": true,
    "count": 0,
    "data": {
        "parserTotal": 320508,
        "cacheTotal": 5957910,
        "total": 6278418
    },
    "timestamp": 1736489378770
}
```

# 网盘对比

| 网盘名称 | 免登陆下载分享 | 加密分享 | 初始网盘空间 | 单文件大小限制 |
| --- | --- | --- | --- | --- |
| 蓝奏云 | √ | √ | 不限空间 | 100M |
| 移动云云空间(个人版) | √ | √(密码可忽略) | 5G(个人) | 不限大小 |
| 小飞机网盘 | √ | √ | 10G | 不限大小 |
| 360亿方云 | √ | √ | 100G(须实名) | 不限大小 |
| 123云盘 | 小文件有时可以 | √ | 2T | 大文件/风控需要本机登录 |
| 文叔叔 | √ | √ | 10G | 5GB |
| 永硕E盘 | √ | √(空间密码) | 视套餐 | 视套餐 |
| WPS云文档 | √ | X | 5G(免费) | 10M(免费)/2G(会员) |
| 夸克网盘 | 小文件 | √ | 10G | 访客有大小限制（23018） |
| UC网盘 | x | √ | 10G | 不限大小 |
| 飞书云盘 | √ | X | 15G | 不限大小 |

免登录边界（阈值由网盘决定，不是本项目写死的）：

- **夸克**：小文件可以不登录。本次核对约 12MB–27MB 的访客直链成功，约 90MB 返回 `23018`。分享根目录如果只是文件夹，解析会继续进入子目录。超过限制时配置 `auths.qk.cookie`。UC 不能免登录。百度大约 100MB 以内有直链，属于专业版，这次没有改解析器。
- **123**：分享目录经常可以不登录看。下载则经常要登录。请本机配置 Authorization，不要依赖公共云解析的共享账号。约 10MB 的小文件有时能直链。

# 打包部署

## JDK下载（lz.qaiu.top提供直链云解析服务）

- [阿里jdk17(Dragonwell17-windows-x86)](https://lz.qaiu.top/d/ec/e957acef36ce89e1053979672a90d219n)
- [阿里jdk17(Dragonwell17-linux-x86)](https://lz.qaiu.top/d/ec/6ebc9f2e0bbd53b4c4d5b11013f40a80NHvcYU)
- [阿里jdk17(Dragonwell17-linux-aarch64)](https://lz.qaiu.top/d/ec/d14c2d06296f61b52a876b525265e0f8tzxTc5)
- [解析有效性测试-移动云云空间-阿里jdk17-linux-x86](https://lz.qaiu.top/json/ec/6ebc9f2e0bbd53b4c4d5b11013f40a80NHvcYU)

## 开发和打包

```
# 环境要求: Jdk17 + maven;
mvn clean
mvn package -DskipTests
```

打包好的文件位于 web-service/target/netdisk-fast-download-bin.zip

## 🚀 快速部署

[通过雨云一键部署](https://app.rainyun.com/apps/rca/store/7273/ssl_?s=ndf)

## Linux服务部署

### Docker 部署（Main分支）

#### 海外服务器Docker部署

```
# 创建目录
mkdir -p netdisk-fast-download
cd netdisk-fast-download

# 拉取镜像
docker pull ghcr.io/qaiu/netdisk-fast-download:latest

# 复制配置文件（或下载仓库web-service\src\main\resources）
docker create --name netdisk-fast-download ghcr.io/qaiu/netdisk-fast-download:latest
docker cp netdisk-fast-download:/app/resources ./resources
docker rm netdisk-fast-download

# 启动容器
docker run -d -it --name netdisk-fast-download -p 6401:6401 --restart unless-stopped -e TZ=Asia/Shanghai -v ./resources:/app/resources -v ./db:/app/db -v ./logs:/app/logs ghcr.io/qaiu/netdisk-fast-download:latest

# 反代6401端口

# 升级容器
docker run --rm -v /var/run/docker.sock:/var/run/docker.sock containrrr/watchtower --cleanup --run-once netdisk-fast-download
```

#### 国内Docker部署

```
# 创建目录
mkdir -p netdisk-fast-download
cd netdisk-fast-download

# 拉取镜像
docker pull ghcr.nju.edu.cn/qaiu/netdisk-fast-download:latest

# 复制配置文件（或下载仓库web-service\src\main\resources）
docker create --name netdisk-fast-download ghcr.nju.edu.cn/qaiu/netdisk-fast-download:latest
docker cp netdisk-fast-download:/app/resources ./resources
docker rm netdisk-fast-download

# 启动容器
docker run -d -it --name netdisk-fast-download -p 6401:6401 --restart unless-stopped -e TZ=Asia/Shanghai -v ./resources:/app/resources -v ./db:/app/db -v ./logs:/app/logs ghcr.nju.edu.cn/qaiu/netdisk-fast-download:latest

# 反代6401端口

# 升级容器
docker run --rm -v /var/run/docker.sock:/var/run/docker.sock containrrr/watchtower --cleanup --run-once netdisk-fast-download
```

### 宝塔部署指引 -> [点击进入宝塔部署教程](https://blog.qaiu.top/archives/netdisk-fast-download-bao-ta-an-zhuang-jiao-cheng)

### Linux命令行部署

> 注意: netdisk-fast-download.service中的ExecStart的路径改为实际路径

```
cd ~
wget -O netdisk-fast-download.zip https://github.com/qaiu/netdisk-fast-download/releases/download/v0.4.8/netdisk-fast-download-linux-amd64.zip
unzip netdisk-fast-download.zip
cd netdisk-fast-download
bash service-install.sh
```

服务相关命令:

查看服务状态  
 `systemctl status netdisk-fast-download.service`

启动服务  
 `systemctl start netdisk-fast-download.service`

重启服务  
 `systemctl restart netdisk-fast-download.service`

停止服务  
 `systemctl stop netdisk-fast-download.service`

开机启动服务  
 `systemctl enable netdisk-fast-download.service`

停止开机启动  
 `systemctl disable netdisk-fast-download.service`

## Windows服务部署

1. 下载并解压releases版本netdisk-fast-download-bin.zip
2. 进入netdisk-fast-download下的bin目录
3. 使用管理员权限运行nfd-service-install.bat 如果不想使用服务运行可以直接运行run.bat

> 注意: 如果jdk环境变量的java版本不是17请修改nfd-service-template.xml中的java命令的路径改为实际路径

## 相关配置说明

resources目录下包含服务端配置文件 配置文件自带说明，具体请查看配置文件内容，  
 app-dev.yml 可以配置解析服务相关信息， 包括端口，域名，缓存时长等  
 server-proxy.yml 可以配置代理服务运行的相关信息， 包括前端反向代理端口，路径等

### ip代理配置说明

有时候解析量很大，IP容易被ban，这时候可以使用其他服务器搭建nfd-proxy代理服务。

修改配置文件： app-dev.yml

```
proxy:
  - panTypes: pgd,pdb,pod     # 网盘标识
    type: http                # 支持http/socks4/socks5
    host: 127.0.0.1           # 代理IP
    port: 7890                # 端口
    username:                 # 用户名
    password:                 # 密码
```

nfd-proxy搭建http代理服务器 参考[https://github.com/nfd-parser/nfd-proxy](https://github.com/nfd-parser/nfd-proxy)

### 认证信息配置说明

夸克小文件可以不登录；大文件要本机 Cookie。123 的下载在公共解析站上基本都要你自己的 Authorization，云端没有共用账号。

修改配置文件： app-dev.yml

```
### 解析认证相关
auths:
  # 夸克大文件：auths.qk.cookie
  # qk:
  #   cookie: 浏览器里夸克网盘的 Cookie
  # 123：优先填 authorization。账号密码若触发验证码会失败，本项目不处理验证码。
  ye:
    username: 你的用户名
    password: 你的密码
    # authorization: 浏览器登录后的 authorToken / sso-token
```

**技术栈:** Jdk17+Vert.x4 Core模块集成Vert.x实现类似spring的注解式路由API

## Star History

## **声明**

- 本项目**仅供个人学习与技术交流使用**，请勿用于商业用途或大规模滥用。
- 所用接口均来自各网盘**官方开放平台**、官方公开接口及**已知开源项目**，仅解析用户主动提供的分享链接，**不涉及破解或绕过版权保护**。
- 本项目**相当于自动化程序代替用户发起请求**，**不会提升或绕过任何会员权限**，也**不会突破网盘的限速策略**；我们**鼓励用户开通官方 VIP/SVIP**以获得更好的下载与加速体验。
- 使用者应遵守各网盘服务商的**用户协议与使用条款**，以及所在地区的**法律法规**，违反所产生的后果自行承担。
- **高频调用可能触发网盘风控**，导致**账号限流、封禁**或**来源 IP 被屏蔽**，请合理控制请求频率，避免高并发与批量请求。
- 网盘接口调整、风控策略变更等因素可能导致功能失效，本项目**不对可用性与稳定性作任何担保**。
- 开发者**不对**使用本项目产生的**任何直接或间接损失**（账号封禁、数据丢失、法律纠纷等）**承担责任**。
- 开发者保留**随时修改本免责声明**的权利，恕不另行通知。
- **下载、部署或使用本项目，即视为您已阅读并接受上述全部条款。**

## 赞助该项目

开源不易，用爱发电，本项目长期维护如果觉得有帮助, 可以请开发者[喝杯咖啡](https://blog.qaiu.top/archives/da-shang-zhuan-yong), 感谢支持。

本项目的服务器由林枫云提供赞助

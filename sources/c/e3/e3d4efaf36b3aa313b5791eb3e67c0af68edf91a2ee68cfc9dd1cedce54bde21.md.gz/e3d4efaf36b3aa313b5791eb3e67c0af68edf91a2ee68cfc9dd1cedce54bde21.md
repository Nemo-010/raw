
#### ENTERPRISE

# Build the Business. We’ll Handle the Rest.

Enterprise support, tailored solutions, and a team that’s invested in your success from day one. Because scaling a business takes more than software.

Learn how Pinata can accelerate your enterprise roadmap.

[Learn more](./enterprise)

#### Free

## $0

## /month

1GB storage

10GB bandwidth

1 gateway

[Select plan](https://app.pinata.cloud)

#### Most popular

#### Picnic

## $20

## /month

1TB storage

Extra storage @ $0.07 per GB

500GB bandwidth

Extra bandwidth @ $0.10 per GB

1 gateway + CDN

[Select plan](https://app.pinata.cloud/)

#### Fiesta

## $100

## /month

5TB storage

Extra storage @ $0.035 per GB

2\.5TB bandwidth

Extra bandwidth @ $0.08 per GB

3 gateways + CDN

[Select plan](https://app.pinata.cloud/)

# COMPARE PLANS

# Features built for your needs

**FREE PLAN**

$0 /month

[Select plan](https://app.pinata.cloud)

**PICNIC PLAN**

$20 /month

[Select plan](https://app.pinata.cloud/)

**FIESTA PLAN**

$100 /month

[Select plan](https://app.pinata.cloud/)

**ENTERPRISE****\
****PLAN**

Custom

[Contact sales](/cdn-cgi/l/email-protection#295a48454c5a69594047485d48074a45465c4d165a5c4b434c4a5d14794047485d480c1b194f465b0c1b196c475d4c5b595b405a4c)

# STORAGE & REQUESTS

STORAGE, FILE COUNT, BANDWIDTH, REQUESTS, 1GB, 500 files, 10GB, 10K, 1TB

Extra storage @ $0.07 per GB

5 Million

500GB

Extra bandwidth @ $0.10 per GB

1M

Extra requests @ $0.20 per 10k

5TB

Extra storage @ $0.035 per GB

10 Million

2\.5TB

Extra bandwidth @ $0.08 per GB

5M

Extra requests @ $0.15 per 10k

Custom

# FEATURES

GATEWAY + CDN, FILE GROUPS, FOLDER UPLOADS, RESUMABLE UPLOADS, QUERYING UPLOADS, CUSTOM KEY VALUES, PRESIGNED URLS, IMAGE OPTIMIZATION, WEB DASHBOARD, GATEWAY PLUGINS, ENHANCED NETWORK, DISCOVERY, PINATA NETWORK, ADVANTAGE, PRIVATE FILES, PIN BY CID, CAR FILE UPLOADS

CUSTOM GATEWAY\
DOMAINS

PLATFORM, WEBHOOKS, HLS VIDEO, STREAMING, 1 Gateway, Basic, 1 Gateway, Standard, 3 Gateways, Advanced, Custom, Custom

# ANALYTICS

# DEVELOPER TOOLING

PLATFORM API, TUS-PROTOCOL, SUPPORT, IPFS PINNING, SERVICES SPEC, IPFS DESKTOP, IPFS CLI

# ORGANIZATION & SECURITY

# AGENTS

AGENTS, 0 Agents, 1 Agent, 3 Agents, Custom

# SUPPORT

EMAIL SUPPORT

PRIORITY SUPPORT

UPTIME SLA

SLACK / DISCORD /\
TELEGRAM CONNECT

ON CALL SUPPORT, WHITE GLOVE, MIGRATION, 1 ON 1 ENGINEERING, GUIDANCE, CUSTOM FEATURE, REQUESTS, Custom, Custom

EVERYTHING YOU NEED TO SUCCEED. START BUILDING NOW!

[Get started](https://app.pinata.cloud/auth/sign-up)

[Read docs](https://docs.pinata.cloud/quickstart)

AUTONOMOUS FILE STORAGE

Copyright © 2025 Pinata | All rights reserved\
[Privacy policy](./terms#privacy-policy) | [Terms & conditions](./terms#terms-conditions) | [Acceptable use](./terms#acceptable-use) | [DMCA](./terms#dmca)

FEATURES

[PRIVATE IPFS STORAGE](./private-ipfs-storage)

[IPFS](./ipfs)

[KV STORAGE](./kv-storage)

[ACCESS CONTROL](./access-control)

[ANALYTICS](./analytics)

[WORKSPACES](./workspaces)

[GROUPS](./groups)

[DEDICATED IPFS GATEWAYS](./dedicated-ipfs-gateways)

[IMAGE OPTIMIZATION](./image-optimization)

[CDN](./cdn)

PRODUCT

[PRICING](./pricing)

[STATUS](https://pinata.statuspage.io/)

RESOURCES

[DOCUMENTATION](https://docs.pinata.cloud/quickstart)

COMPANY

[ABOUT](./about)

[CAREERS](./careers)

---

## Navigation

- [Pricing](./pricing)
- [About](./about)
- [Blog](https://pinata.cloud/blog/)
- [Case studies](https://pinata.cloud/blog/tag/case-study/)
- [Labs](./labs)
- [Docs](https://docs.pinata.cloud/quickstart)
- [Log in](https://app.pinata.cloud/login)
- [Get started](https://app.pinata.cloud/auth/sign-up)

There are several ways a New Relic user can log into a New Relic organization:

- Email and password: The default login method, which requires a user's email address and a password.
- Social login: You can use Google, Google Workplace, GitHub, and Bitbucket to sign up for and log into New Relic.
- Single sign-on: For identity provider login options, see [Introduction to SAML SSO and SCIM](https://docs.newrelic.com/docs/accounts/accounts-billing/new-relic-one-user-management/introduction-saml-scim/).

Having trouble logging in? See [Login troubleshooting](https://docs.newrelic.com/docs/accounts/accounts-billing/account-setup/troubleshoot-new-relics-password-email-address-login-problems/).

For managing how your users log in, see [Authentication domains](https://docs.newrelic.com/docs/accounts/accounts-billing/new-relic-one-user-management/authentication-domains-saml-sso-scim-more/).

## User counting and tracking

For details about how user records are tracked, see [User tracking](https://docs.newrelic.com/docs/accounts/accounts-billing/account-setup/multiple-logins-found/#user-records).

## Switch between user records

For users with access to more than one New Relic user record, see [Switch between users](https://docs.newrelic.com/docs/accounts/accounts-billing/account-setup/multiple-logins-found/).

### 1. Acceptance of Terms

By downloading, installing, or using the StarVPN Free Anonymous Service, you agree to be bound by these Terms. Your continued use constitutes your acceptance of any future changes to the Terms.

### 2. Residential Network Sharing Program

2.1 Agreement to Share Network Resources

- By using our free VPN software, you consent to participate in our network sharing program in exchange for a premium free VPN subscription. This means you agree to allow us to use a portion of your internet connection. This is not a p2p network sharing service, data routed via the background network service is initiated by the StarVPN intermediary servers, not clients themselves. Some of the data routed is used for Smart Streamer (Smart DNS) service.

2.2 Limited Usage

- There is only a 10% chance that your network will be used at any given time. When utilized, traffic routed through your network is carefully filtered and selectively managed to prevent abuse and ensure compliance with legal and ethical standards.

### 3. Subscription Service

3.1 Vetting Process

- Users subscribing to our premium Service are required to provide a valid government-issued photo ID and a legitimate use case. Approval is subject to our sole discretion.

3.2 Data Privacy

- Information provided during the subscription vetting process is used solely for verification purposes and handled in accordance with our Privacy Policy.

### 4. Prohibited Activities

You agree not to use the Service for any illegal or unauthorized purposes. Prohibited activities include but are not limited to:

- Illegal downloading or distribution of copyrighted materials.
- Conducting cyberattacks, fraud, or other malicious activities.
- Any activity that violates the laws of your jurisdiction.

We enforce a **zero-tolerance policy** regarding illegal activities. Any violation will result in immediate termination of the Service without warning or refund.

### 5. Termination of Service

We reserve the right to suspend or terminate your access to the Service at any time for violations of these Terms, illegal activities, or other misconduct. Refunds, if applicable, are granted at our sole discretion.

### 6. Liability and Disclaimers

6.1 No Warranty

- The Service is provided on an “as is” and “as available” basis. We do not guarantee 99.999% uptime, however you may contact our team for app feature request or technical support.

### 7. Changes to Terms

We may update these Terms from time to time. Continued use of the Service after changes constitutes your acceptance of the revised Terms.

### 8. Governing Law

These Terms are governed by and construed in accordance with the laws of Ontario Canada.

### 9. Contact Information

If you have any questions about these Terms, please contact us at: [[email protected]](https://www.starvpn.com/cdn-cgi/l/email-protection)

By installing and using the Service, you confirm that you have read, understood, and agree to these Terms of Service.

### 10. Notice

Any notice, communication or statement relating to these Terms of Service shall be in writing and deemed effective: (i) upon delivery when delivered in person; (ii) upon transmission when delivered by verified facsimile or other confirmed electronic transmission; (iii) when delivered by certified mail, postage prepaid, return receipt requested or by nationally-recognized overnight courier service (including but not limited to Federal Express) to the address of the respective party as recorded herein in the case of us, and as submitted by you in the Registration Information when registering for the Website; (iv) in the event of non- material changes to this Agreement, notice shall be deemed effective upon posting at our Website; (v) and in the event of material changes to this Agreement, notice shall be effective upon the sending of an email to your recorded email address as set out in the Registration Information. Copies of all notices to shall be sent to us at:

**STARVPN INC.**  
595 BAY ST.  
PO BOX 99900 UA 997 652  
RPO ATRIUM ON BAY  
TORONTO ON M5G 0B4

# Codefresh and Octopus

In February 2024, Octopus acquired Codefresh. Since then, we've brought together the best of both teams to tackle the hardest Continuous Delivery challenges for Kubernetes and Argo CD at enterprise scale.

## Links to Codefresh resources

While most of the Codefresh content has now migrated to the Octopus site, the links below will point you to some important Codefresh resources you may need.

### Login to Codefresh

Codefresh users can log in to the product by clicking the link below.

[Login to Codefresh](http://g.codefresh.io/)

### Codefresh documentation

All Codefresh docs, guides, and API references are still available and will continue to be maintained.

[View the docs](https://codefresh.io/docs/)

### Codefresh steps

The step template library is unchanged. Existing templates continue to work and new ones can still be submitted.

[View steps](https://codefresh.io/steps/)

### Contact Support

Raise and track support tickets through the Octopus Support channels. You’ll receive the same world-class support you’re used to.

[Contact Support](https://octopus.com/support)

### Contact Sales

If you have questions about your account, need to speak to Sales, or any other topic, reach out to the team directly.

[Contact Sales](https://octopus.com/company/contact)

### Codefresh CI

Codefresh CI remains available for customers. It continues to be developed and supported within the Octopus Deploy portfolio.

[Learn more about Codefresh CI](https://octopus.com/codefresh/continuous-integration)

### Common questions

Will my existing Codefresh pipelines keep working?

Yes. There are no breaking changes to existing pipelines. Codefresh CI continues to operate as normal throughout the transition.

Can I continue to use GitOps Cloud or sign up for a trial?

No. The GitOps Cloud product is no longer available. If you are considering deployment and release orchestration tooling, we recommend signing up for the free tier of Octopus, starting an enterprise trial to access all features, or requesting a demo of Octopus.

What happens to Codefresh documentation and step templates?

Both remain accessible at their current URLs. Documentation will continue to be updated. Step templates are unaffected.

How do I reach support during the transition?

Use the same support channels as before. Nothing has changed on that front - our Support team has been handling support requests for Codefresh and Octopus together for quite some time.

## Want to learn more about Codefresh CI?

Contact our team to find out more.

[Contact our team](https://octopus.com/company/contact)
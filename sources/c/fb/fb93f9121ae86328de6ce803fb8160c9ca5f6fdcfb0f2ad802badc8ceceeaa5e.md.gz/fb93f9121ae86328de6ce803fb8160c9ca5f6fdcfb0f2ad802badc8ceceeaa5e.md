## Daily API

The Daily microservice API returns time series analysis-ready data responses for solar and meteorological data to be used directly by applications.

Info

Additional Data Specifications: - Provides parameters by day with average, maximum, and/or minimum values. - All parameters are available in their original source spatial resolution.

Warning

If you are going to be using the Daily API to download the entire catalog, please remember that with the 0.5° x 0.5° global grid you only need to submit one request per cell. If your application persists in requesting the same relative location, it will potentially be blocked.

## Formats

| Formats | Availability | Notes |
| --- | --- | --- |
| NetCDF | Single Point and Regional |  |
| ASCII | Single Point and Regional |  |
| ICASA | Single Point | Only available for the AG Community. |
| JSON | Single Point and Regional |  |
| CSV | Single Point and Regional |  |

Tip

If you are requesting the ICASA format via the Data Access Viewer (DAV), you do not have to select any parameters as the DAV will autofill the required parameters. When using the Application Programming Interface (API) to request an ICASA format, you need to include at least one parameter, and the API will autofill the required parameters in the file response. For the monthly amplitude to be included in the file, please select a time period that covers at least two months. The ICASA file responds in Local Solar Time (LST). ICASA is only available for single point requests, not regional requests.

## Time Standards

POWER provides two different time standards:

- Universal Time Coordinated (UTC): The most commonly accepted time standard worldwide.
- Local Solar Time (LST): A 15-degree swath that represents solar noon at the middle longitude of the swath.

Info

- Daily UTC and LST time standards data are available from 1981/01/01 to Near Real Time (NRT)
- Daily API defaults to providing LST; use `time-standard=UTC` or `time-standard=LST` in the API request URL to specify the time standard.

## Limitations

Parameters

- A maximum of 20 parameters can currently be requested in one submission for a single point. Regional requests are limited to one parameter.
- These limits do not apply if more parameters are needed by the application to construct on the fly parameters.

Wind Elevation and Custom Surface

1. This parameter is only available under the "Point" spatial option.
2. Wind Elevation values in Meters are required to be between 10m and 300m.
3. If you provide a correct wind surface alias `wind-surface`, please include a surface elevation `wind-elevation` with the request.

Info

For a list of wind surface aliases, please use this [System API Request](https://power.larc.nasa.gov/api/system/manager/surface). For more information, please reference the [Manager Documentation](https://power.larc.nasa.gov/docs/services/api/system/manager/).

Site Elevation

If you wish to pass your own site elevation (in meters), you will receive a corrected atmospheric pressure value upon adjustment to the elevation you provided.

1. This parameter is only available under the "Point" spatial option.
2. Site Elevation `site-elevation` values are in Meters.

## Request Structure

Info

- The request arguments can be in any order after the question mark.
- A single parameter or a list of parameters can be selected with one of the following list separators: ',' or '%2C'.

### Examples

To help construct and test your API requests, please use the API Pages for the [POWER Daily API](https://power.larc.nasa.gov/api/pages/?urls.primaryName=Daily) and [POWER Manager API](https://power.larc.nasa.gov/api/pages/?urls.primaryName=Manager).

#### Point

```
1
```

```
1
```

```
1
```

```
1
```

```
1
```

```
1
```

Info

The International Consortium for Agricultural Systems Applications (ICASA) format is specifically tailored for agricultural crop modeling and simulation with tools such as DSSAT. It is only available for a single point, not a region.

When requesting ICASA format, the API automatically selects the required weather parameters, regardless of the parameters selected, and sets the community to Agroclimatology (AG). For the monthly amplitude to be included in the response, please select a time period that covers at least two months.

```
1
```

#### Regional

Below are examples to return daily data for a region on a 0.5 x 0.5 degree grid.

```
1
2
3
```

The word Adapter with a supercomputer in the background

### **NCI's Adapter Allocation Scheme provides quarterly resource allocations on our high-performance Gadi supercomputer, Nirin cloud and global filesystems.**

**The Adapter scheme is temporarily closed. It is scheduled to reopen in Q4 2026. **

NCI runs the merit-based Adapter Allocation Scheme to allow for more flexible access to high-performance computing, cloud and storage resources. The Adapter Scheme facilitates access to data, enables high-throughput computing, and supports other new and emerging ways of engaging with Tier-1 high-performance computing and high-performance data resources.

Adapter is designed to identify meritorious research projects which need flexible compute access over a short period. This scheme caters for those users who need smaller compute and data resources in short bursts, rather than those who need millions of compute hours over the course of a whole year. Early-career researchers, PhD students and applicants new to merit allocation schemes can benefit from the Adapter Scheme, either through applying on their own (if eligible), or alongside a research supervisor.

All fields of research are eligible and encouraged to apply to the Adapter Scheme.

#### Reminder:

Postdoctoral researchers are now eligible to apply as Lead CIs without needing direct funding directly attributable to them. We hope this makes access to HPC resources for Early Career Researchers much easier and simpler.

#### More information:

- Read the Frequently Asked Questions.
- See the list of Adapter Recipients for previous quarters.

### Information for Applicants – Latest Versions

Adapter Scheme Information for Applicants

| Dates | Event |  |  |  |
| --- | --- | --- | --- | --- |
| 24 July 2023 | Call for Applications Opens |  |  |  |
| 1 August 2023 | Online Information Session |  |  |  |
| 13 August 2023 | Application Submission Deadline (11pm AEST) |  |  |  |
| Early September 2023 | Allocations Announced |  |  |  |
| 1 October 2023 | Allocations Start |  |  |  |

## Previous Recipients

### Adapter Scheme Q4 2023

Key Information and Recipients

### Downloads

[Successful Adapter Applicants Q4 2023](https://nci.org.au/sites/default/files/documents/2023-09/Successful%20Adapter%20Applicants%20Q4%202023.pdf) [Adapter Scheme Q4 2023 Key Dates](https://nci.org.au/sites/default/files/documents/2023-09/Adapter%20Scheme%20Q4%202023%20Key%20Dates.pdf)

### Adapter Scheme Q3 2023

Key Information and Recipients

### Downloads

[Successful Adapter Applicants Q3 2023](https://nci.org.au/sites/default/files/documents/2023-06/Successful%20Adapter%20Applicants%20Q3%202023.pdf) [Adapter Scheme Q3 2023 Key Dates](https://nci.org.au/sites/default/files/documents/2023-04/Adapter%20Scheme%20Q3%202023%20Key%20Dates.pdf)

### Adapter Scheme Q2 2023

Key Information and Recipients

### Downloads

[Successful Adapter Applicants Q2 2023](https://nci.org.au/sites/default/files/documents/2023-03/Successful%20Adapter%20Applicants%20Q2%202023.pdf) [Adapter Scheme Q2 2023](https://nci.org.au/sites/default/files/documents/2023-01/Adapter%20Scheme%20Q2%202023.pdf)

### Adapter Scheme Q1 2023

Key Information and Recipients

### Downloads

[Successful Adapter Applicants Q1 2023](https://nci.org.au/sites/default/files/documents/2022-12/Successful%20Adapter%20Applicants%20Q1%202023.pdf) [Q1 2023 Key Dates and Information](https://nci.org.au/sites/default/files/documents/2022-09/Adapter%20Scheme%20Q1%202023.pdf)

### Adapter Scheme Q4 2022

Key Information and Recipients

### Downloads

[Successful Adapter Applicants Q4 2022](https://nci.org.au/sites/default/files/documents/2022-09/Successful%20Adapter%20Applicants%20Q4%202022%20v2.pdf) [Q4 Key Dates and Important Information](https://nci.org.au/sites/default/files/documents/2022-07/Adapter%20Scheme%20Q4.pdf)

### Adapter Scheme Q3 2022

Key Information and Recipients

### Downloads

[Successful Adapter Applicants Q3 2022](https://nci.org.au/sites/default/files/documents/2022-06/Successful%20Adapter%20Applicants%20Q3%202022.pdf) [Adapter Scheme Q3 Key Dates and Information](https://nci.org.au/sites/default/files/documents/2022-04/Adapter%20Scheme%20Q3.pdf)

## Frequently Asked Questions

*1. What are the eligibility requirements?*  
 To be eligible to apply, applicants must have support from an ARC or NHMRC grant, or a Fellowship from their university.

*2. How often will the Adapter scheme open to applications?*  
 The Adapter scheme will run on a quarter-by-quarter schedule, meaning that in each quarter a new call will open for the following quarter. This fast turnaround is intended to add to the flexibility of access as researchers can adjust their application based on short term goals and apply only when they need access.

*3. How much compute is available per quarter?*  
 Each quarter NCI is making 20 MSU available through the Adapter scheme. Individual allocations are a maximum of 250 KSU per quarter.

*4. Can new users apply?*  
 Yes! We encourage new users to apply to this scheme.

*5. Does it matter if I want to use GPUs or CPUs?*  
 No! Proposals utilising Gadi CPU or GPU (or both) capabilities will be accepted.

*6. Are there other access schemes that I can apply for?*  
 Adapter is NCI’s third merit-based access scheme, joining the annual Australasian Leadership Computing Grants (ALCG) and the National Computational Merit Allocation Scheme (NCMAS). ALCG is designed to support the largest and most ambitious computational research projects with allocations up to 50 MSU, while NCMAS caters for hundreds of leading research groups each year with resources ranging from 500 KSU to around 20 MSU.

*7. Are researchers from a Publicly Funded Research Agency (PFRA) eligible to apply?*  
 A researcher from a PFRA can be a CI on an Adapter application, but they cannot be a Lead CI.

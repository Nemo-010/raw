## Graphide does things differently

Graphide CI is a service, not a plan to pick. You get our runners, plus a team of AI agents that tunes each job and keeps it fast as your code changes. You pay one fixed monthly price, which we quote from what you run today.

It is built for companies whose CI is a real line on the bill, where a faster, cheaper pipeline is worth a team’s attention.

## What we aim for

10–20×

faster than GitHub’s hosted runners

70%+

lower CI bill

These are targets, not guarantees. Each depends on your repositories and the size of the deal, and larger deals get the most. If we fall short, [contact us](mailto:hello@graphide.com?subject=Graphide%20CI%20speed-up) and we will gladly agree a discount until we get your jobs there.

What hand tuning reached: ten long open-source CI jobs ran 10× to 47× faster than on GitHub’s hosted runners.[1]

## How it works

1. ### Start free

  Put in a card at checkout; nothing is charged. The trial lasts 7 days or $10 of CI usage, whichever comes first, or until we contact you. It is there so you, and we, get a sense of your CI.
2. ### We send you a quote

  One fixed monthly price for your CI, set from what you run today.
3. ### You pay that each month

  The price stays fixed unless your usage rises more than 60% over a month from where you started, counted with our speed-ups in place. Then it may change.

A large team? Skip the trial and we will quote you directly: [book a call](https://calendly.com/dan-graphide) or [email us](mailto:hello@graphide.com?subject=Graphide%20CI%20quote).

Graphide CI

## Your GitHub Actions jobs on our runners, kept fast by AI agents

- AI agents tune each job’s caches and machine, and split long test steps where a check shows it is safe.
- They keep every job fast as your code changes, on every repo.
- Each job runs on its own machine, destroyed when the job ends.

For repositories of GitHub organizations.

Graphide review

## A review on every pull request, each finding checked

26 of 36

known bugs caught on 74 real pull requests, judged blind, where Greptile caught 21[2]

0.02

false alarms per pull request with no known bug, where Greptile raised 0.11[2]

- It reads the code a change calls and is called by, and the rules you wrote.
- Each finding says how it was checked and how sure the review is.
- Whoever approves gets one page: what changed, what it reaches, what broke.
- The trial includes 10 free reviews. After that, $1 per pull request.

Works on personal GitHub accounts too. Holds a merge only if you make it a required check.

## Paying

- Bought per Graphide org: one trial and one price cover every GitHub account it connects.
- One free trial per person and per card.
- Nothing is ever charged automatically. When the trial ends, CI pauses until you accept your quote.
- PR review past the free 10: $1 per pull request.

To pay by invoice, [email us](mailto:hello@graphide.com?subject=Graphide%20CI%20by%20invoice).

## Security

- Each job runs in its own fresh micro-VM (the largest runners get a whole VM), destroyed when the job ends.
- Machines can’t reach each other or our private network.
- Fork jobs are moved off hosts running trusted jobs.
- We keep test results, never your logs.

[How Graphide CI keeps your jobs apart](https://graphide.com/docs/security/ci/)

1. Ten long open-source CI jobs, timed on GitHub-hosted runners and on Graphide CI

  Our runs were made on November 5, 2026, by hand, on our own copy of each project, with changes to how the job runs and none to what it tests. We picked each job’s warm machine image ourselves, and ran on 64 or 128 vCPUs; GitHub’s standard hosted runner for open-source projects has 4, and a customer’s runners on Graphide CI go up to 32 today. GitHub’s time is its own run of the same job: the median of its recent runs or its run at the same commit, and for rclone its fastest run with a warm cache. Steps left out on our side: trivy’s disk clean-up (also taken off GitHub’s time), rclone’s upload, library install and two cache steps, and webpack’s Codecov upload (GitHub’s 10-second median for it is added to ours). Ours is runner start to finish, without time in the queue. Every test name and result (for a build job, every target built) was compared with GitHub’s log of the same job. Eight of the ten are Rust Miri or Go jobs, and how much faster your own job gets depends on what it does.

  [The table, with a link to each job’s runs on GitHub](https://graphide.com/#results) ↩
2. Known bugs caught by Graphide review and by Greptile, on the same pull requests

  74 real pull requests, 68 of them from one open-source project (typescript-go), held out while we tuned the reviewer, carrying 36 known bugs. Graphide review as it ships today ran on them once on October 26, 2026; Greptile’s reviews of the same pull requests were judged on October 24, 2026. The same grader, which was not told which tool wrote what, matched each tool’s findings to the known bugs and counted its false alarms on the pull requests with no known bug.↩ ↩

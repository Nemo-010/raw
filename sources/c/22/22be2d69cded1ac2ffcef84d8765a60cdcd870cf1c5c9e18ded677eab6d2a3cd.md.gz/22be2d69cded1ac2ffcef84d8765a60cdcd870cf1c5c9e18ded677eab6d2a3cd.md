IPv6 over your IPv4 line

# The whole IPv6 internet.  
Your ISP not required.

tunnel64 is a tunnel broker: we route real, static IPv6 address space to you over your existing IPv4 connection. Run servers, learn networking, or just get modern connectivity — even if your ISP is stuck in the last century.

[Get your free tunnel](https://free.tunnel64.net/) or get the VPN

## How it works

### 1. Sign up

Create an account at [free.tunnel64.net](https://free.tunnel64.net/) and tell us the public IPv4 you connect from.

### 2. Configure

Copy the generated config — plain Linux, OpenWrt, or Windows. Standard 6in4, no client software, works on almost any router.

### 3. Route

You get a static point-to-point address and a routed /64 — 18 quintillion addresses for your whole LAN, yours as long as your tunnel lives.

## Tunnel plans

IPv6 routed to the line you already have. Your IPv4 and your ISP stay exactly as they are.

### Free

0 kr / forever

- **Static routed /64** per tunnel
- Up to **5 tunnels** per account
- **100 Mbit/s** per tunnel
- Dynamic IPv4 endpoint updates (dyndns2)
- Self-service reverse DNS (PTR)

[Create tunnel](https://free.tunnel64.net/)

coming soon

### Tunnel /48

announced later this year

- **Routed /48** — 65,536 networks of your own
- **Higher bandwidth** tiers, up to line rate
- More tunnels & priority tunnel servers
- Priority support

Want early access when it launches? Create a free account — we'll announce it on the dashboard first.

Also from tunnel64

## A VPN that gives every device its own /64.

Most VPNs hand you one shared address for everything you own. This one delegates a whole routed /64 to *each device* — laptop, phone, router — 18 quintillion addresses apiece, with no NAT in front of any of them. WireGuard, on the same AS35100 hardware.

[Read the getting-started guide](https://vpn.tunnel64.net/guide) — setup, what a /64 gives you, and the things worth knowing first.

### Which one do I want?

### Tunnel

free · 6in4 · your router

You keep **your own IPv4 line**. We route IPv6 to it over 6in4. Your address, your ISP, your hardware — unchanged.

For **“my ISP has no IPv6.”**

### VPN

paid · wireguard · any device

You get a **whole new connection**. Our IPv4, our IPv6, your own routed /64 — and none of your ISP's in the path.

For **“I want a different address, and ports that work.”**

### Standard

monthly or yearly · card or crypto

- **A routed /64 per device** — not shared, not NATed
- Up to **5 devices**, each with its own network
- Shared public IPv4, **stable between sessions**
- **Unlimited traffic**
- Reverse DNS you set yourself
- Email-only signup — no name, no phone

Choose a location

available now

### Dedicated

monthly or yearly · card or crypto

- **Dedicated public IPv4** — yours alone
- **Incoming connections work** — host what you like
- Up to **10 devices**, each with its own /64
- Reverse DNS for your IPv6 *and* your IPv4
- Everything in Standard

Choose a location

### Pick where you come out

Each location is a separate gateway with its own address space. Your account, your devices and your subscription live on the one you choose and **do not transfer between them** — so pick the country you actually want to appear from.

### Växjö

Sweden · EU

vpn.tunnel64.net

live **IPv6** routed /64 per device

live **IPv4** shared or dedicated

live reverse DNS, inbound, port 25 on request

[Sign up in Sweden](https://vpn.tunnel64.net/)

### Singapore

Singapore · Asia

vpnsg.tunnel64.net

live **IPv6** routed /64 per device

live **IPv4** shared or dedicated

live reverse DNS, inbound, port 25 on request

[Sign up in Singapore](https://vpnsg.tunnel64.net/)

### Manila

Philippines · Asia

vpnph.tunnel64.net

live **IPv6** routed /64 per device

live **IPv4** shared or dedicated

live reverse DNS, inbound, port 25 on request

[Sign up in Manila](https://vpnph.tunnel64.net/)

Every location runs the same software on our own hardware, with the same address space and the same features. The only real difference is latency, so pick the one nearest the people or services you deal with — roughly 20 ms within northern Europe from Sweden, 22 ms within the Philippines from Manila, and about 100 ms to most of southeast Asia from Singapore.

Next: Amsterdam and Los Angeles. The address space is allocated and the routing is in place; we will list them here when there is a gateway behind them, and not before.

Your private key is generated once, shown once and never stored — if you lose it you rotate, because there is nothing for us to recover. Each device needs its own configuration; the same one on two devices at once will not work. Outbound port 25 is blocked by default to keep our address space off spam blocklists; ask if you need it opened. Payments are final — [read the terms](https://vpn.tunnel64.net/terms) before buying.

For companies

## Your own VPN node. Hosted, run, and handed over.

The same platform that runs the gateways above, deployed as a **dedicated node for your organisation** — your staff, your offices, your cloud workloads, your address space. We run the network and the machine; your IT team runs the VPN through its own control panel.

### Your team administers it

Multiple operator accounts with enforced two-factor authentication and a per-person audit trail. Staff get a self-service portal with quotas and permissions your team sets.

### Bring your own addresses

**BYOIP** — we announce your blocks under AS35100 on your LOA — or announce your **own ASN with BGP** directly to the node. Your address reputation stays yours, and moves with you.

### Built for business traffic

1–10 Gbit/s per node, a routed /48 of IPv6 (up to /40), dedicated public IPv4 with working inbound, site-to-site tunnels for offices, and reverse DNS for mail that actually delivers.

Sweden Singapore Amsterdam Los Angeles deployed to order

[Contact sales](https://tunnel64.net/cdn-cgi/l/email-protection#fd8e888d8d928f89bd898893939891cbc9d3939889c28e889f97989e89c0b5928e899899d8cfcdbf888e9493988e8ed8cfcdabadb3) [Technical overview (PDF)](https://tunnel64.net/vpn-business-sales.pdf)

Tell us roughly how many people and sites, and which region — we reply from [[email protected]](https://tunnel64.net/cdn-cgi/l/email-protection) with a specification and a quote. The PDF covers the platform, the security model and the BYOIP options in detail.

## Run by network people

tunnel64 runs on AS35100 with our own address space and infrastructure — not a reseller, no third-party cloud in the data path. Tunnels and VPN sessions both terminate on hardware we operate, and the service portals are the same tooling we use ourselves.

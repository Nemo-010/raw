HTTP/1.1 200 OK
Date: Sat, 31 Oct 2026 06:35:18 GMT
Content-Type: text/html
Transfer-Encoding: chunked
Connection: keep-alive
Accept-Ranges: bytes
Access-Control-Allow-Origin: *
Nel: {"report_to":"cf-nel","success_fraction":0.0,"max_age":604800}
Last-Modified: Thu, 29 Oct 2026 19:23:43 GMT
Server: cloudflare
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload
Vary: accept-encoding
Cf-Placement: [redacted]
access-control-expose-headers: *, x-web-egress, x-web-form, x-web-provider, x-web-account, x-web-body, x-web-snapshot-at, x-web-cache, x-web-headers, x-web-origin-status, x-web-provider-origin-status, x-web-final-url, x-web-providers, x-web-corpus, x-web-store, allow, retry-after, location, memento-datetime
stadia-cache: MISS
stadia-entrypoint: dfw-pop-g4-e45a0a
x-web-corpus: W/"c5e9e64342a33f898201763b7422e7f35f8503b673ae043cb409af3787ae5c74"
x-web-egress: egress=cf-fetch tried=cf-fetch identity=fixed tls=platform headers=partial dialFailureObservable=true responseFramingModified=true decoded=gzip
x-web-form: path-scheme
Report-To: {"group":"cf-nel","max_age":604800,"endpoints":[{"url":"https://a.nel.cloudflare.com/report/v4?s=5PyYQQJfMV%2FOHOhXuPUD8E5ey6GmedNPiQUSK554bYW9oMSCWPwFmrNhlfnFEsFjvxt2npDdmPwAkU4XmOoF5jLTH%2F1eNlVmDLFjPykiE3OxoSknAN%2FYg3Udbcm2S0JKrBP5OHFJoxPiMh%2F7tOfZL6%2F%2FYUwu"}]}
CF-RAY: a530a38f3c9286dd-[redacted]
alt-svc: h3=":443"; ma=86400



<!doctype html>
<html lang="en" class="no-js">
  <head>
    
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      
        <meta name="description" content="Get turn-by-turn directions for car, bike, walking, and more with unparalleled flexibility for any application.">
      
      
        <meta name="author" content="Stadia Maps, Inc.">
      
      
        <link rel="canonical" href="https://docs.stadiamaps.com/routing/standard-routing/">
      
      
        <link rel="prev" href="../">
      
      
        <link rel="next" href="../optimized-routing/">
      
      
        
      
      
      <link rel="icon" href="../../img/favicon.ico">
      <meta name="generator" content="mkdocs-1.6.1, mkdocs-material-9.7.7">
    
    
      
        <title>Standard Routing - Stadia Maps Documentation</title>
      
    
    
      <link rel="stylesheet" href="../../assets/stylesheets/main.ec1eaa64.min.css">
      
        
        <link rel="stylesheet" href="../../assets/stylesheets/palette.ab4e12ef.min.css">
      
      


    
    
      
    
    
      
    
    
      <link rel="stylesheet" href="../../stylesheets/extra.css">
    
      <link rel="stylesheet" href="../../stylesheets/newsletter.css">
    
    <script>__md_scope=new URL("../..",location),__md_hash=e=>[...e].reduce(((e,_)=>(e<<5)-e+_.charCodeAt(0)),0),__md_get=(e,_=localStorage,t=__md_scope)=>JSON.parse(_.getItem(t.pathname+"."+e)),__md_set=(e,_,t=localStorage,a=__md_scope)=>{try{t.setItem(a.pathname+"."+e,JSON.stringify(_))}catch(e){}}</script>
    
      

    
    
<meta name="twitter:creator" content="@stadiamaps" />
<meta name="twitter:site" content="@stadiamaps" />

  
<meta property="og:type" content="website" />
<meta property="og:title" content="Standard Routing - Stadia Maps Documentation" />
<meta property="og:description" content="Get turn-by-turn directions for car, bike, walking, and more with unparalleled flexibility for any application." />
<meta property="og:image" content="https://docs.stadiamaps.com/img/social/routing/standard-routing.png" />
<meta property="og:image:type" content="image/png" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta property="og:url" content="https://docs.stadiamaps.com/routing/standard-routing/" />
<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:title" content="Standard Routing - Stadia Maps Documentation" />
<meta property="twitter:description" content="Get turn-by-turn directions for car, bike, walking, and more with unparalleled flexibility for any application." />
<meta property="twitter:image" content="https://docs.stadiamaps.com/img/social/routing/standard-routing.png" />
</head>
  
  
    
    
      
    
    
    
    
    <body dir="ltr" data-md-color-scheme="default" data-md-color-primary="indigo" data-md-color-accent="indigo">
  
    
    <input class="md-toggle" data-md-toggle="drawer" type="checkbox" id="__drawer" autocomplete="off">
    <input class="md-toggle" data-md-toggle="search" type="checkbox" id="__search" autocomplete="off">
    <label class="md-overlay" for="__drawer"></label>
    <div data-md-component="skip">
      
        
        <a href="#standard-routing" class="md-skip">
          Skip to content
        </a>
      
    </div>
    <div data-md-component="announce">
      
    </div>
    
    
      

  

<header class="md-header md-header--shadow md-header--lifted" data-md-component="header">
  <nav class="md-header__inner md-grid" aria-label="Header">
    <a href="../.." title="Stadia Maps Documentation" class="md-header__button md-logo" aria-label="Stadia Maps Documentation" data-md-component="logo">
      <svg fill="#363636" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
     width="300" height="300"
	 shape-rendering="optimizeQuality"
     viewBox="0 0 176.179 172.152" style="enable-background:new 0 0 176.179 172.152;" xml:space="preserve">
<g>
	<g>
		<path class="st0" d="M89.244,97.036c4.036-18.534,11.259-25.237,15.416-34.469l0.043-0.099c1.039-2.2,1.533-4.543,1.533-7.141
			c0-9.388-7.621-16.975-17.044-16.975s-16.975,7.587-16.975,16.975c0,2.598,0.554,5.023,1.594,7.223
			c4.122,9.25,11.328,15.936,15.381,34.469L89.244,97.036z M84.463,50.494c0-2.631,2.133-4.763,4.763-4.763
			c2.631,0,4.763,2.133,4.763,4.763c0,2.631-2.133,4.763-4.763,4.763C86.596,55.257,84.463,53.124,84.463,50.494z"/>
	</g>
    <g>
		<path class="st0" d="M37.081,94.068l-13.488,10.967c-3.591,2.92-3.446,6.533,0.388,8.047l43.014,16.991l20.175-17.865
			L37.081,94.068z M66.497,126.347L26.73,110.822c-2.237-0.873-2.341-2.974-0.254-4.68l10.858-8.872l43.913,16.089L66.497,126.347z"
        />
	</g>
    <g>
		<path class="st0" d="M70.289,131.375l17.082,6.747c4.585,1.811,11.33,0.53,14.956-2.846l13.59-12.656l-25.449-9.217
			L70.289,131.375z"/>
	</g>
    <g>
		<path class="st0" d="M91.374,98.976c-0.208,1.005-1.109,1.732-2.13,1.732v-0.017c-1.039,0-1.905-0.693-2.148-1.732
			c-1.148-5.242-2.552-9.616-4.07-13.432l-18.171,15.416l53.697,19.223l20.073-18.694L94.798,87.135
			C93.524,90.567,92.351,94.445,91.374,98.976z"/>
	</g>
    <g>
		<path class="st0" d="M150.796,79.922L108.039,67.22c0.427-0.848,0.842-1.702,1.228-2.575l0.173-0.346
			c1.264-2.858,1.905-5.855,1.905-8.972c0-12.194-9.925-22.119-22.137-22.119c-12.194,0-22.102,9.925-22.119,22.119
			c0,3.256,0.693,6.426,2.079,9.319c0.369,0.815,0.759,1.607,1.157,2.392l-30.623,24.9l22.086,7.906l20.126-16.985
			c-1.885-4.287-3.888-7.854-5.765-11.198c-1.136-2.02-2.23-3.989-3.236-5.979c-0.376-0.74-0.751-1.48-1.094-2.231
			c-1.161-2.529-1.767-5.3-1.767-8.141c0-10.566,8.574-19.157,19.157-19.157c10.601,0,19.227,8.591,19.227,19.175
			c0,2.737-0.676,5.595-1.819,8.124c-0.52,1.188-1.102,2.354-1.716,3.518c-0.817,1.551-1.695,3.099-2.615,4.692
			c-0.361,0.644-0.728,1.299-1.097,1.963c-0.027,0.049-0.054,0.096-0.081,0.145l0.001-0.001c-1.384,2.494-2.804,5.161-4.172,8.179
			l-0.004-0.001c-0.029,0.064-0.057,0.133-0.085,0.197c-0.067,0.15-0.136,0.294-0.203,0.446l0.008,0.003
			c-0.279,0.629-0.559,1.258-0.833,1.921l45.29,14.646l12.311-11.465C156.571,84.76,155.362,81.278,150.796,79.922z M149.922,86.624
			l-9.847,9.114L99.773,82.853c1.676-3.654,3.424-6.805,5.077-9.755c0.67-1.188,1.318-2.348,1.947-3.508l41.627,12.507
			C151.077,82.895,151.759,84.924,149.922,86.624z"/>
	</g>
</g>
</svg>
    </a>
    <label class="md-header__button md-icon" for="__drawer">
      
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M3 6h18v2H3zm0 5h18v2H3zm0 5h18v2H3z"/></svg>
    </label>
    <div class="md-header__title" data-md-component="header-title">
      <div class="md-header__ellipsis">
        <div class="md-header__topic">
          <span class="md-ellipsis">
            Stadia Maps Documentation
          </span>
        </div>
        <div class="md-header__topic" data-md-component="header-topic">
          <span class="md-ellipsis">
            
              Standard Routing
            
          </span>
        </div>
      </div>
    </div>
    
      
        <form class="md-header__option" data-md-component="palette">
  
    
    
    
    <input class="md-option" data-md-color-media="(prefers-color-scheme)" data-md-color-scheme="default" data-md-color-primary="indigo" data-md-color-accent="indigo"  aria-label="Switch to light mode"  type="radio" name="__palette" id="__palette_0">
    
      <label class="md-header__button md-icon" title="Switch to light mode" for="__palette_1" hidden>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="m14.3 16-.7-2h-3.2l-.7 2H7.8L11 7h2l3.2 9zM20 8.69V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69L23.31 12zm-9.15 3.96h2.3L12 9z"/></svg>
      </label>
    
  
    
    
    
    <input class="md-option" data-md-color-media="(prefers-color-scheme: light)" data-md-color-scheme="default" data-md-color-primary="white" data-md-color-accent="indigo"  aria-label="Switch to dark mode"  type="radio" name="__palette" id="__palette_1">
    
      <label class="md-header__button md-icon" title="Switch to dark mode" for="__palette_2" hidden>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 8a4 4 0 0 0-4 4 4 4 0 0 0 4 4 4 4 0 0 0 4-4 4 4 0 0 0-4-4m0 10a6 6 0 0 1-6-6 6 6 0 0 1 6-6 6 6 0 0 1 6 6 6 6 0 0 1-6 6m8-9.31V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69L23.31 12z"/></svg>
      </label>
    
  
    
    
    
    <input class="md-option" data-md-color-media="(prefers-color-scheme: dark)" data-md-color-scheme="slate" data-md-color-primary="indigo" data-md-color-accent="blue"  aria-label="Switch to system preference"  type="radio" name="__palette" id="__palette_2">
    
      <label class="md-header__button md-icon" title="Switch to system preference" for="__palette_0" hidden>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 18c-.89 0-1.74-.2-2.5-.55C11.56 16.5 13 14.42 13 12s-1.44-4.5-3.5-5.45C10.26 6.2 11.11 6 12 6a6 6 0 0 1 6 6 6 6 0 0 1-6 6m8-9.31V4h-4.69L12 .69 8.69 4H4v4.69L.69 12 4 15.31V20h4.69L12 23.31 15.31 20H20v-4.69L23.31 12z"/></svg>
      </label>
    
  
</form>
      
    
    
      <script>var palette=__md_get("__palette");if(palette&&palette.color){if("(prefers-color-scheme)"===palette.color.media){var media=matchMedia("(prefers-color-scheme: light)"),input=document.querySelector(media.matches?"[data-md-color-media='(prefers-color-scheme: light)']":"[data-md-color-media='(prefers-color-scheme: dark)']");palette.color.media=input.getAttribute("data-md-color-media"),palette.color.scheme=input.getAttribute("data-md-color-scheme"),palette.color.primary=input.getAttribute("data-md-color-primary"),palette.color.accent=input.getAttribute("data-md-color-accent")}for(var[key,value]of Object.entries(palette.color))document.body.setAttribute("data-md-color-"+key,value)}</script>
    
    
    
      
      
        <label class="md-header__button md-icon" for="__search">
          
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M9.5 3A6.5 6.5 0 0 1 16 9.5c0 1.61-.59 3.09-1.56 4.23l.27.27h.79l5 5-1.5 1.5-5-5v-.79l-.27-.27A6.52 6.52 0 0 1 9.5 16 6.5 6.5 0 0 1 3 9.5 6.5 6.5 0 0 1 9.5 3m0 2C7 5 5 7 5 9.5S7 14 9.5 14 14 12 14 9.5 12 5 9.5 5"/></svg>
        </label>
        <div class="md-search" data-md-component="search" role="dialog">
  <label class="md-search__overlay" for="__search"></label>
  <div class="md-search__inner" role="search">
    <form class="md-search__form" name="search">
      <input type="text" class="md-search__input" name="query" aria-label="Search" placeholder="Search" autocapitalize="off" autocorrect="off" autocomplete="off" spellcheck="false" data-md-component="search-query" required>
      <label class="md-search__icon md-icon" for="__search">
        
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M9.5 3A6.5 6.5 0 0 1 16 9.5c0 1.61-.59 3.09-1.56 4.23l.27.27h.79l5 5-1.5 1.5-5-5v-.79l-.27-.27A6.52 6.52 0 0 1 9.5 16 6.5 6.5 0 0 1 3 9.5 6.5 6.5 0 0 1 9.5 3m0 2C7 5 5 7 5 9.5S7 14 9.5 14 14 12 14 9.5 12 5 9.5 5"/></svg>
        
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M20 11v2H8l5.5 5.5-1.42 1.42L4.16 12l7.92-7.92L13.5 5.5 8 11z"/></svg>
      </label>
      <nav class="md-search__options" aria-label="Search">
        
        <button type="reset" class="md-search__icon md-icon" title="Clear" aria-label="Clear" tabindex="-1">
          
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
        </button>
      </nav>
      
    </form>
    <div class="md-search__output">
      <div class="md-search__scrollwrap" tabindex="0" data-md-scrollfix>
        <div class="md-search-result" data-md-component="search-result">
          <div class="md-search-result__meta">
            Initializing search
          </div>
          <ol class="md-search-result__list" role="presentation"></ol>
        </div>
      </div>
    </div>
  </div>
</div>
      
    
    
  </nav>
  
    
      
<nav class="md-tabs" aria-label="Tabs" data-md-component="tabs">
  <div class="md-grid">
    <ul class="md-tabs__list">
      
        
  
  
  
  
    
    
      <li class="md-tabs__item">
        <a href="../.." class="md-tabs__link">
          
  
  
  Home

        </a>
      </li>
    
  

      
        
  
  
  
  
    
    
      <li class="md-tabs__item">
        <a href="../../maps-for-web/" class="md-tabs__link">
          
  
  
  Maps

        </a>
      </li>
    
  

      
        
  
  
  
  
    
    
      <li class="md-tabs__item">
        <a href="../../geocoding-search-autocomplete/overview/" class="md-tabs__link">
          
  
  
  Geocoding & Search

        </a>
      </li>
    
  

      
        
  
  
  
    
  
  
    
    
      <li class="md-tabs__item md-tabs__item--active">
        <a href="../" class="md-tabs__link">
          
  
  
  Routing

        </a>
      </li>
    
  

      
        
  
  
  
  
    
    
      <li class="md-tabs__item">
        <a href="../../sdks/overview/" class="md-tabs__link">
          
  
  
  SDKs

        </a>
      </li>
    
  

      
        
  
  
  
  
    
    
      <li class="md-tabs__item">
        <a href="../../tutorials/overview/" class="md-tabs__link">
          
  
  
  Tutorials & Guides

        </a>
      </li>
    
  

      
        
  
  
  
  
    <li class="md-tabs__item">
      <a href="../../api-reference/" class="md-tabs__link">
        
  
  
    
  
  Interactive API Reference

      </a>
    </li>
  

      
        
  
  
  
  
    <li class="md-tabs__item">
      <a href="https://stadiamaps.com/support/" class="md-tabs__link">
        
  
  
    
  
  Get Support

      </a>
    </li>
  

      
    </ul>
  </div>
</nav>
    
  
</header>
    
    <div class="md-container" data-md-component="container">
      
      
        
      
      <main class="md-main" data-md-component="main">
        <div class="md-main__inner md-grid">
          
            
              
              <div class="md-sidebar md-sidebar--primary" data-md-component="sidebar" data-md-type="navigation" >
                <div class="md-sidebar__scrollwrap">
                  <div class="md-sidebar__inner">
                    


  


<nav class="md-nav md-nav--primary md-nav--lifted" aria-label="Navigation" data-md-level="0">
  <label class="md-nav__title" for="__drawer">
    <a href="../.." title="Stadia Maps Documentation" class="md-nav__button md-logo" aria-label="Stadia Maps Documentation" data-md-component="logo">
      <svg fill="#363636" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
     width="300" height="300"
	 shape-rendering="optimizeQuality"
     viewBox="0 0 176.179 172.152" style="enable-background:new 0 0 176.179 172.152;" xml:space="preserve">
<g>
	<g>
		<path class="st0" d="M89.244,97.036c4.036-18.534,11.259-25.237,15.416-34.469l0.043-0.099c1.039-2.2,1.533-4.543,1.533-7.141
			c0-9.388-7.621-16.975-17.044-16.975s-16.975,7.587-16.975,16.975c0,2.598,0.554,5.023,1.594,7.223
			c4.122,9.25,11.328,15.936,15.381,34.469L89.244,97.036z M84.463,50.494c0-2.631,2.133-4.763,4.763-4.763
			c2.631,0,4.763,2.133,4.763,4.763c0,2.631-2.133,4.763-4.763,4.763C86.596,55.257,84.463,53.124,84.463,50.494z"/>
	</g>
    <g>
		<path class="st0" d="M37.081,94.068l-13.488,10.967c-3.591,2.92-3.446,6.533,0.388,8.047l43.014,16.991l20.175-17.865
			L37.081,94.068z M66.497,126.347L26.73,110.822c-2.237-0.873-2.341-2.974-0.254-4.68l10.858-8.872l43.913,16.089L66.497,126.347z"
        />
	</g>
    <g>
		<path class="st0" d="M70.289,131.375l17.082,6.747c4.585,1.811,11.33,0.53,14.956-2.846l13.59-12.656l-25.449-9.217
			L70.289,131.375z"/>
	</g>
    <g>
		<path class="st0" d="M91.374,98.976c-0.208,1.005-1.109,1.732-2.13,1.732v-0.017c-1.039,0-1.905-0.693-2.148-1.732
			c-1.148-5.242-2.552-9.616-4.07-13.432l-18.171,15.416l53.697,19.223l20.073-18.694L94.798,87.135
			C93.524,90.567,92.351,94.445,91.374,98.976z"/>
	</g>
    <g>
		<path class="st0" d="M150.796,79.922L108.039,67.22c0.427-0.848,0.842-1.702,1.228-2.575l0.173-0.346
			c1.264-2.858,1.905-5.855,1.905-8.972c0-12.194-9.925-22.119-22.137-22.119c-12.194,0-22.102,9.925-22.119,22.119
			c0,3.256,0.693,6.426,2.079,9.319c0.369,0.815,0.759,1.607,1.157,2.392l-30.623,24.9l22.086,7.906l20.126-16.985
			c-1.885-4.287-3.888-7.854-5.765-11.198c-1.136-2.02-2.23-3.989-3.236-5.979c-0.376-0.74-0.751-1.48-1.094-2.231
			c-1.161-2.529-1.767-5.3-1.767-8.141c0-10.566,8.574-19.157,19.157-19.157c10.601,0,19.227,8.591,19.227,19.175
			c0,2.737-0.676,5.595-1.819,8.124c-0.52,1.188-1.102,2.354-1.716,3.518c-0.817,1.551-1.695,3.099-2.615,4.692
			c-0.361,0.644-0.728,1.299-1.097,1.963c-0.027,0.049-0.054,0.096-0.081,0.145l0.001-0.001c-1.384,2.494-2.804,5.161-4.172,8.179
			l-0.004-0.001c-0.029,0.064-0.057,0.133-0.085,0.197c-0.067,0.15-0.136,0.294-0.203,0.446l0.008,0.003
			c-0.279,0.629-0.559,1.258-0.833,1.921l45.29,14.646l12.311-11.465C156.571,84.76,155.362,81.278,150.796,79.922z M149.922,86.624
			l-9.847,9.114L99.773,82.853c1.676-3.654,3.424-6.805,5.077-9.755c0.67-1.188,1.318-2.348,1.947-3.508l41.627,12.507
			C151.077,82.895,151.759,84.924,149.922,86.624z"/>
	</g>
</g>
</svg>
    </a>
    Stadia Maps Documentation
  </label>
  
  <ul class="md-nav__list" data-md-scrollfix>
    
      
      
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_1" >
        
          
          <label class="md-nav__link" for="__nav_1" id="__nav_1_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Home
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="1" aria-labelledby="__nav_1_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_1">
            <span class="md-nav__icon md-icon"></span>
            
  
    Home
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../.." class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Home
  

    
      <br>
      <small>Location APIs for Humans</small>
    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../authentication/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Authentication
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../limits/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Service Limits
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../attribution/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Required Attribution
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../client-api/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Account Management API
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../api-status/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    API Status
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

    
      
      
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_2" >
        
          
          <label class="md-nav__link" for="__nav_2" id="__nav_2_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Maps
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="1" aria-labelledby="__nav_2_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_2">
            <span class="md-nav__icon md-icon"></span>
            
  
    Maps
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../maps-for-web/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Interactive Web Maps
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../static-maps/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Static Maps
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../maps-for-data-visualization/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Maps for Data Visualization
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../native-multiplatform/overview/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Native & Multi-platform
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_2_5" >
        
          
          <label class="md-nav__link" for="__nav_2_5" id="__nav_2_5_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Map Tiles API
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_2_5_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_2_5">
            <span class="md-nav__icon md-icon"></span>
            
  
    Map Tiles API
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../vector/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Vector Map Tiles
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../raster/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Raster Map Tiles
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tilesets/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Additional Data Tilesets
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_2_7" >
        
          
          <label class="md-nav__link" for="__nav_2_7" id="__nav_2_7_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Map Styles
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_2_7_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_2_7">
            <span class="md-nav__icon md-icon"></span>
            
  
    Map Styles
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../themes/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Style Library
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../map-styles/alidade-smooth/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Alidade Smooth
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../map-styles/alidade-smooth-dark/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Alidade Smooth Dark
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../map-styles/alidade-bright/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Alidade Bright
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../map-styles/alidade-satellite/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Alidade Satellite
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../map-styles/outdoors/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Stadia Outdoors
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../map-styles/stamen-toner/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Stamen Toner
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../map-styles/stamen-terrain/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Stamen Terrain
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../map-styles/stamen-watercolor/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Stamen Watercolor
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../map-styles/osm-bright/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    OSM Bright
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../custom-styles/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Custom Map Styling
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

    
      
      
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_3" >
        
          
          <label class="md-nav__link" for="__nav_3" id="__nav_3_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Geocoding & Search
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="1" aria-labelledby="__nav_3_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_3">
            <span class="md-nav__icon md-icon"></span>
            
  
    Geocoding & Search
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/overview/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Geocoding & Search Overview
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/autocomplete/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Autocomplete Search
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/search/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Forward Geocoding
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/structured-search/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Structured Geocoding
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/bulk-geocoding-search/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Bulk Geocoding
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/reverse-search/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Reverse Geocoding
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/place-details/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Place Details
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tz/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Time Zones
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_3_9" >
        
          
          <label class="md-nav__link" for="__nav_3_9" id="__nav_3_9_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Other Documentation
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_3_9_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_3_9">
            <span class="md-nav__icon md-icon"></span>
            
  
    Other Documentation
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/layers/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Layers
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/sources/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Sources
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/determining-result-quality/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Determining Result Quality
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/api-response-format/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Common Response Format
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../geocoding-search-autocomplete/v2-api-migration-guide/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Migrating to v2
  

    
  </span>
  
  
    
  
  
    <span class="md-status md-status--new"></span>
  

  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

    
      
      
  
  
    
  
  
  
    
    
    
    
      
        
        
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--active md-nav__item--section md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_4" checked>
        
          
          <label class="md-nav__link" for="__nav_4" id="__nav_4_label" tabindex="">
            
  
  
  <span class="md-ellipsis">
    
  
    Routing
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="1" aria-labelledby="__nav_4_label" aria-expanded="true">
          <label class="md-nav__title" for="__nav_4">
            <span class="md-nav__icon md-icon"></span>
            
  
    Routing
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Routing Overview
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
    
  
  
  
    
    
    
    
      
      
        
          
          
        
      
    
    
    <li class="md-nav__item md-nav__item--active md-nav__item--section md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_4_2" checked>
        
          
          <label class="md-nav__link" for="__nav_4_2" id="__nav_4_2_label" tabindex="">
            
  
  
  <span class="md-ellipsis">
    
  
    Turn-by-Turn Directions
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_4_2_label" aria-expanded="true">
          <label class="md-nav__title" for="__nav_4_2">
            <span class="md-nav__icon md-icon"></span>
            
  
    Turn-by-Turn Directions
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
    
  
  
  
    <li class="md-nav__item md-nav__item--active">
      
      <input class="md-nav__toggle md-toggle" type="checkbox" id="__toc">
      
      
        
      
      
        <label class="md-nav__link md-nav__link--active" for="__toc">
          
  
  
  <span class="md-ellipsis">
    
  
    Standard Routing
  

    
  </span>
  
  

          <span class="md-nav__icon md-icon"></span>
        </label>
      
      <a href="./" class="md-nav__link md-nav__link--active">
        
  
  
  <span class="md-ellipsis">
    
  
    Standard Routing
  

    
  </span>
  
  

      </a>
      
        

<nav class="md-nav md-nav--secondary" aria-label="Table of contents">
  
  
  
    
  
  
    <label class="md-nav__title" for="__toc">
      <span class="md-nav__icon md-icon"></span>
      Table of contents
    </label>
    <ul class="md-nav__list" data-md-component="toc" data-md-scrollfix>
      
        <li class="md-nav__item">
  <a href="#example-code" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Example Code
        </span>
      
    </span>
  </a>
  
</li>
      
        <li class="md-nav__item">
  <a href="#traffic-influenced-profiles" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Traffic-Influenced Profiles
        </span>
      
    </span>
  </a>
  
</li>
      
        <li class="md-nav__item">
  <a href="#turn-by-turn-navigation" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Turn-by-Turn Navigation
        </span>
      
    </span>
  </a>
  
</li>
      
        <li class="md-nav__item">
  <a href="#service-limits" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Service Limits
        </span>
      
    </span>
  </a>
  
</li>
      
        <li class="md-nav__item">
  <a href="#complementary-apis" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Complementary APIs
        </span>
      
    </span>
  </a>
  
</li>
      
        <li class="md-nav__item">
  <a href="#next-steps" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Next Steps
        </span>
      
    </span>
  </a>
  
</li>
      
    </ul>
  
</nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../optimized-routing/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Optimized Routing
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../map-matching/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Map Matching
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
          
          
        
      
    
    
    <li class="md-nav__item md-nav__item--section md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_4_3" >
        
          
          <label class="md-nav__link" for="__nav_4_3" id="__nav_4_3_label" tabindex="">
            
  
  
  <span class="md-ellipsis">
    
  
    Road Information
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_4_3_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_4_3">
            <span class="md-nav__icon md-icon"></span>
            
  
    Road Information
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../nearest-roads/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Nearest Roads
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../trace-attributes/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Trace Attributes
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../time-distance-matrix/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Time/Distance Matrix
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../isochrones/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Isochrones (Reachable Range)
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../elevation/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Elevation
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

    
      
      
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_5" >
        
          
          <label class="md-nav__link" for="__nav_5" id="__nav_5_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    SDKs
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="1" aria-labelledby="__nav_5_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_5">
            <span class="md-nav__icon md-icon"></span>
            
  
    SDKs
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../sdks/overview/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Overview
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../sdks/maplibre-gl-js-autocomplete-search-plugin/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    MapLibre GL JS Search Box
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../sdks/swiftui-autocomplete-search/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Autocomplete Search for SwiftUI
  

    
  </span>
  
  
    
  
  
    <span class="md-status md-status--new"></span>
  

  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../sdks/jetpack-compose-autocomplete-search/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Autocomplete Search for Jetpack Compose
  

    
  </span>
  
  
    
  
  
    <span class="md-status md-status--new"></span>
  

  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../sdks/ferrostar/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Ferrostar Navigation SDK
  

    
  </span>
  
  
    
  
  
    <span class="md-status md-status--new"></span>
  

  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../sdks/javascript-typescript/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    JavaScript
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../sdks/python/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Python
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../sdks/kotlin-jvm/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Kotlin
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../sdks/swift/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Swift
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../sdks/php/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    PHP
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../sdks/mcp-server/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    MCP Server
  

    
  </span>
  
  
    
  
  
    <span class="md-status md-status--new"></span>
  

  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

    
      
      
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6" >
        
          
          <label class="md-nav__link" for="__nav_6" id="__nav_6_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Tutorials & Guides
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="1" aria-labelledby="__nav_6_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6">
            <span class="md-nav__icon md-icon"></span>
            
  
    Tutorials & Guides
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/overview/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Tutorial Index
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_2" >
        
          
          <label class="md-nav__link" for="__nav_6_2" id="__nav_6_2_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Interactive Web Maps
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_6_2_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_2">
            <span class="md-nav__icon md-icon"></span>
            
  
    Interactive Web Maps
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_2_1" >
        
          
          <label class="md-nav__link" for="__nav_6_2_1" id="__nav_6_2_1_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    React
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="3" aria-labelledby="__nav_6_2_1_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_2_1">
            <span class="md-nav__icon md-icon"></span>
            
  
    React
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/getting-started-with-react-leaflet/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: React Leaflet
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/vector-tiles-with-react-leaflet/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Vector Tiles with React Leaflet
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/getting-started-with-maplibre-react-components/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: MapLibre React Components
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_2_2" >
        
          
          <label class="md-nav__link" for="__nav_6_2_2" id="__nav_6_2_2_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Leaflet
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="3" aria-labelledby="__nav_6_2_2_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_2_2">
            <span class="md-nav__icon md-icon"></span>
            
  
    Leaflet
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/getting-started-with-react-leaflet/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: React Leaflet
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/vector-tiles-with-react-leaflet/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Vector Tiles with React Leaflet
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/vector-tiles-with-leaflet/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Vector Tiles with Leaflet
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/getting-started-with-vue-leaflet/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: Vue Leaflet
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/raster-maps-with-leaflet/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: Leaflet JS
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_2_3" >
        
          
          <label class="md-nav__link" for="__nav_6_2_3" id="__nav_6_2_3_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    MapLibre GL JS
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="3" aria-labelledby="__nav_6_2_3_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_2_3">
            <span class="md-nav__icon md-icon"></span>
            
  
    MapLibre GL JS
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/vector-maps-with-maplibre-gl-js/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: MapLibre GL JS
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/clustering-styling-points-with-maplibre/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Clustering with MapLibre GL JS
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/incorporating-global-landcover-tiles-maplibre/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Incorporating Global Landcover Tiles with MapLibre GL JS
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/3d-globe-view-with-maplibre-gl-js/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Turn your Maps into a 3D Globe
  

    
  </span>
  
  
    
  
  
    <span class="md-status md-status--new"></span>
  

  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/raster-maps-with-openlayers/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: OpenLayers
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_3" >
        
          
          <label class="md-nav__link" for="__nav_6_3" id="__nav_6_3_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Maps for Native & Multi-platform
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_6_3_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_3">
            <span class="md-nav__icon md-icon"></span>
            
  
    Maps for Native & Multi-platform
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_3_1" >
        
          
          <label class="md-nav__link" for="__nav_6_3_1" id="__nav_6_3_1_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Flutter
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="3" aria-labelledby="__nav_6_3_1_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_3_1">
            <span class="md-nav__icon md-icon"></span>
            
  
    Flutter
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../native-multiplatform/flutter-maplibre-gl/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: Flutter MapLibre GL
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../native-multiplatform/flutter-map/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: flutter_map
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/offline-maps-with-flutter-maplibre-gl/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Offline Maps with Flutter MapLibre GL
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_3_2" >
        
          
          <label class="md-nav__link" for="__nav_6_3_2" id="__nav_6_3_2_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    iOS
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="3" aria-labelledby="__nav_6_3_2_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_3_2">
            <span class="md-nav__icon md-icon"></span>
            
  
    iOS
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/interactive-markers-gestures-and-clustering-in-swiftui/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Markers, Gestures, and Clustering in SwiftUI
  

    
  </span>
  
  
    
  
  
    <span class="md-status md-status--new"></span>
  

  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/using-stadia-maps-tile-layers-in-mapkit/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Using Stadia Maps Tiles in MapKit
  

    
  </span>
  
  
    
  
  
    <span class="md-status md-status--new"></span>
  

  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../native-multiplatform/maplibre-gl-native/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: MapLibre Native
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../native-multiplatform/maplibre-react-native/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: MapLibre React Native
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_4" >
        
          
          <label class="md-nav__link" for="__nav_6_4" id="__nav_6_4_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Maps for Data Visualization
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_6_4_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_4">
            <span class="md-nav__icon md-icon"></span>
            
  
    Maps for Data Visualization
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/getting-started-with-geopandas-contextily/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: geopandas and contextily
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/getting-started-in-r-with-ggmap/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: ggmap
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/how-to-use-stadia-maps-as-a-raster-base-layer-in-qgis/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Raster Base Layers in QGIS
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_5" >
        
          
          <label class="md-nav__link" for="__nav_6_5" id="__nav_6_5_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Custom Map Styling
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_6_5_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_5">
            <span class="md-nav__icon md-icon"></span>
            
  
    Custom Map Styling
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/changing-the-map-label-language/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Changing Place Labels to Another Language
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/incorporating-global-landcover-tiles-maplibre/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Incorporating Global Landcover Tiles with MapLibre GL JS
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/adding-3d-buildings-to-your-maps-with-maplibre/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Add 3D Buildings to your Maps
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/changing-place-labels/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Changing Specific Place Labels on the Map
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_6" >
        
          
          <label class="md-nav__link" for="__nav_6_6" id="__nav_6_6_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    No-Code Solutions
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_6_6_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_6">
            <span class="md-nav__icon md-icon"></span>
            
  
    No-Code Solutions
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/bubbleio-with-leafymaps/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Leafy Maps on Bubble.io
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_7" >
        
          
          <label class="md-nav__link" for="__nav_6_7" id="__nav_6_7_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    QGIS
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_6_7_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_7">
            <span class="md-nav__icon md-icon"></span>
            
  
    QGIS
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/how-to-use-stadia-maps-as-a-raster-base-layer-in-qgis/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Raster Base Layers in QGIS
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_8" >
        
          
          <label class="md-nav__link" for="__nav_6_8" id="__nav_6_8_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Routing and Navigation
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_6_8_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_8">
            <span class="md-nav__icon md-icon"></span>
            
  
    Routing and Navigation
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/getting-directions-in-javascript-from-geospatial-apis-maplibre/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Getting and Visualizing Directions in JavaScript
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/display-isochrones-on-a-map/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Visualize Travel Time with Isochrones in MapLibre GL JS
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/getting-an-elevation-profile-with-your-route/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Getting an Elevation Profile With Your Route
  

    
  </span>
  
  
    
  
  
    <span class="md-status md-status--new"></span>
  

  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_9" >
        
          
          <label class="md-nav__link" for="__nav_6_9" id="__nav_6_9_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Video
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_6_9_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_9">
            <span class="md-nav__icon md-icon"></span>
            
  
    Video
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/getting-started-with-geolayers/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Quickstart: GEOlayers 3
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_10" >
        
          
          <label class="md-nav__link" for="__nav_6_10" id="__nav_6_10_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Wordpress
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_6_10_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_10">
            <span class="md-nav__icon md-icon"></span>
            
  
    Wordpress
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/wordpress-with-leaflet/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    LeafletJS Plugin
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../tutorials/wordpress-with-mapster/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Mapster WP Maps Plugin
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
              
                
  
  
  
  
    
    
    
    
      
      
        
      
    
    
    <li class="md-nav__item md-nav__item--nested">
      
        
        
        <input class="md-nav__toggle md-toggle " type="checkbox" id="__nav_6_11" >
        
          
          <label class="md-nav__link" for="__nav_6_11" id="__nav_6_11_label" tabindex="0">
            
  
  
  <span class="md-ellipsis">
    
  
    Guides
  

    
  </span>
  
  

            <span class="md-nav__icon md-icon"></span>
          </label>
        
        <nav class="md-nav" data-md-level="2" aria-labelledby="__nav_6_11_label" aria-expanded="false">
          <label class="md-nav__title" for="__nav_6_11">
            <span class="md-nav__icon md-icon"></span>
            
  
    Guides
  

          </label>
          <ul class="md-nav__list" data-md-scrollfix>
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../guides/securing-your-integration/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Securing Your Integration
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../eu-gdpr-endpoints/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Ensure GDPR Compliance with EU Endpoints
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../guides/getting-the-best-routes-with-valhalla-turn-by-turn-directions-apis/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Getting the Best Routes for Your Use Case
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../guides/migrate-from-mapbox/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Migrate from Mapbox
  

    
  </span>
  
  
    
  
  
    <span class="md-status md-status--new"></span>
  

  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../guides/migrating-from-stamen-map-tiles/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Migration Guide for Stamen Map Tile Users
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../guides/switching-your-maps-from-raster-to-vector-tiles/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Switching to Vector Tiles
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../upgrading-subscription/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Upgrading Your Subscription
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../guides/getting-accurate-results-at-scale-with-bulk-geocoding/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Getting Accurate Results at Scale with Bulk Geocoding
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../guides/location-intelligence-for-apps-with-foundation-models/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Location Intelligence for Apps with Foundation Models
  

    
  </span>
  
  
    
  
  
    <span class="md-status md-status--new"></span>
  

  

      </a>
    </li>
  

              
            
              
                
  
  
  
  
    <li class="md-nav__item">
      <a href="../../guides/gathering-debugging-information/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Gathering Debugging Information
  

    
  </span>
  
  

      </a>
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

              
            
          </ul>
        </nav>
      
    </li>
  

    
      
      
  
  
  
  
    <li class="md-nav__item">
      <a href="../../api-reference/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Interactive API Reference
  

    
  </span>
  
  

      </a>
    </li>
  

    
      
      
  
  
  
  
    <li class="md-nav__item">
      <a href="https://stadiamaps.com/support/" class="md-nav__link">
        
  
  
  <span class="md-ellipsis">
    
  
    Get Support
  

    
  </span>
  
  

      </a>
    </li>
  

    
  </ul>
</nav>
                  </div>
                </div>
              </div>
            
            
              
              <div class="md-sidebar md-sidebar--secondary" data-md-component="sidebar" data-md-type="toc" >
                <div class="md-sidebar__scrollwrap">
                  <div class="md-sidebar__inner">
                    

<nav class="md-nav md-nav--secondary" aria-label="Table of contents">
  
  
  
    
  
  
    <label class="md-nav__title" for="__toc">
      <span class="md-nav__icon md-icon"></span>
      Table of contents
    </label>
    <ul class="md-nav__list" data-md-component="toc" data-md-scrollfix>
      
        <li class="md-nav__item">
  <a href="#example-code" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Example Code
        </span>
      
    </span>
  </a>
  
</li>
      
        <li class="md-nav__item">
  <a href="#traffic-influenced-profiles" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Traffic-Influenced Profiles
        </span>
      
    </span>
  </a>
  
</li>
      
        <li class="md-nav__item">
  <a href="#turn-by-turn-navigation" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Turn-by-Turn Navigation
        </span>
      
    </span>
  </a>
  
</li>
      
        <li class="md-nav__item">
  <a href="#service-limits" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Service Limits
        </span>
      
    </span>
  </a>
  
</li>
      
        <li class="md-nav__item">
  <a href="#complementary-apis" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Complementary APIs
        </span>
      
    </span>
  </a>
  
</li>
      
        <li class="md-nav__item">
  <a href="#next-steps" class="md-nav__link">
    <span class="md-ellipsis">
      
        <span class="md-typeset">
          Next Steps
        </span>
      
    </span>
  </a>
  
</li>
      
    </ul>
  
</nav>
                  </div>
                </div>
              </div>
            
          
          
            <div class="md-content" data-md-component="content">
              
                




  <nav class="md-path" aria-label="Navigation" >
    <ol class="md-path__list">
      
      
        
  
  
    
    
      <li class="md-path__item">
        <a href="../" class="md-path__link">
          
  <span class="md-ellipsis">
    Routing
  </span>

        </a>
      </li>
    
  

      
        
  
  
    
    
      <li class="md-path__item">
        <a href="./" class="md-path__link">
          
  <span class="md-ellipsis">
    Turn-by-Turn Directions
  </span>

        </a>
      </li>
    
  

      
    </ol>
  </nav>

              
              <article class="md-content__inner md-typeset">
                
                  

  <nav class="md-tags" >
    
      
      
      
      
        <a href="../../tutorials/overview/#tag:routing" class="md-tag">Routing</a>
      
    
  </nav>



<h1 id="standard-routing">Standard Routing<a class="headerlink" href="#standard-routing" title="Permanent link">&para;</a></h1>
<div class="grid plans">
<p><span class="twemoji"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Free 7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2025 Fonticons, Inc.--><path d="M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512m0-464a208 208 0 1 0 0 416 208 208 0 1 0 0-416m70.7 121.9c7.8-10.7 22.8-13.1 33.5-5.3s13.1 22.8 5.3 33.5l-122.1 168c-4.1 5.7-10.5 9.3-17.5 9.8s-13.9-2-18.8-6.9l-55.9-55.9c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l36 36L326.7 170z"/></svg></span> Free</p>
<p><span class="twemoji"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Free 7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2025 Fonticons, Inc.--><path d="M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512m0-464a208 208 0 1 0 0 416 208 208 0 1 0 0-416m70.7 121.9c7.8-10.7 22.8-13.1 33.5-5.3s13.1 22.8 5.3 33.5l-122.1 168c-4.1 5.7-10.5 9.3-17.5 9.8s-13.9-2-18.8-6.9l-55.9-55.9c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l36 36L326.7 170z"/></svg></span> Starter</p>
<p><span class="twemoji"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Free 7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2025 Fonticons, Inc.--><path d="M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512m0-464a208 208 0 1 0 0 416 208 208 0 1 0 0-416m70.7 121.9c7.8-10.7 22.8-13.1 33.5-5.3s13.1 22.8 5.3 33.5l-122.1 168c-4.1 5.7-10.5 9.3-17.5 9.8s-13.9-2-18.8-6.9l-55.9-55.9c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l36 36L326.7 170z"/></svg></span> Standard</p>
<p><span class="twemoji"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Free 7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2025 Fonticons, Inc.--><path d="M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512m0-464a208 208 0 1 0 0 416 208 208 0 1 0 0-416m70.7 121.9c7.8-10.7 22.8-13.1 33.5-5.3s13.1 22.8 5.3 33.5l-122.1 168c-4.1 5.7-10.5 9.3-17.5 9.8s-13.9-2-18.8-6.9l-55.9-55.9c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l36 36L326.7 170z"/></svg></span> Professional</p>
</div>
<p>The standard route endpoint gives turn-by-turn directions between one or more points that must be visited in order.
It is highly configurable with routing profiles for car, bicycle, pedestrian, and more.
We give developers an immense amount of room to fine tune routes for any application.</p>
<p>Here's a sampling of the versatility we offer:</p>
<ul>
<li>Access restrictions for trucks, buses, golf carts, and other specialized vehicle types</li>
<li>Vehicle attributes (weight, height, width, top speed, etc.)</li>
<li>Prefer or avoid highways, toll roads, and ferries</li>
<li>Number of passengers, for HOV lane usage</li>
<li>Hill avoidance for bicycles, motor scooters, and pedestrians</li>
<li>Traffic-influenced routing for more accurate travel time estimates</li>
<li>Support for guidance in over 25 languages</li>
</ul>
<p><strong>Endpoint:</strong> <code>https://api.stadiamaps.com/route/v1</code></p>
<h2 id="example-code">Example Code<a class="headerlink" href="#example-code" title="Permanent link">&para;</a></h2>
<div class="tabbed-set tabbed-alternate" data-tabs="1:6"><input checked="checked" id="__tabbed_1_1" name="__tabbed_1" type="radio" /><input id="__tabbed_1_2" name="__tabbed_1" type="radio" /><input id="__tabbed_1_3" name="__tabbed_1" type="radio" /><input id="__tabbed_1_4" name="__tabbed_1" type="radio" /><input id="__tabbed_1_5" name="__tabbed_1" type="radio" /><input id="__tabbed_1_6" name="__tabbed_1" type="radio" /><div class="tabbed-labels"><label for="__tabbed_1_1">TypeScript</label><label for="__tabbed_1_2">Python</label><label for="__tabbed_1_3">Kotlin</label><label for="__tabbed_1_4">Swift</label><label for="__tabbed_1_5">PHP</label><label for="__tabbed_1_6">cURL</label></div>
<div class="tabbed-content">
<div class="tabbed-block">
<details class="tip">
<summary>Installation Instructions</summary>
<p>The Stadia Maps JavaScript/TypeScript SDK is available for any package manager that supports the npm registry.</p>
<p><a href="https://www.npmjs.com/package/@stadiamaps/api"><img alt="NPM Downloads" src="https://img.shields.io/npm/dm/%40stadiamaps%2Fapi?style=for-the-badge&amp;color=rgb(64%2C81%2C181)" /></a></p>
<div class="tabbed-set tabbed-alternate" data-tabs="2:3"><input checked="checked" id="__tabbed_2_1" name="__tabbed_2" type="radio" /><input id="__tabbed_2_2" name="__tabbed_2" type="radio" /><input id="__tabbed_2_3" name="__tabbed_2" type="radio" /><div class="tabbed-labels"><label for="__tabbed_2_1"><code>npm</code></label><label for="__tabbed_2_2"><code>yarn</code></label><label for="__tabbed_2_3"><code>bun</code></label></div>
<div class="tabbed-content">
<div class="tabbed-block">
<div class="highlight"><pre><span></span><code>npm<span class="w"> </span>install<span class="w"> </span>@stadiamaps/api
</code></pre></div>
</div>
<div class="tabbed-block">
<div class="highlight"><pre><span></span><code>yarn<span class="w"> </span>add<span class="w"> </span>@stadiamaps/api
</code></pre></div>
</div>
<div class="tabbed-block">
<div class="highlight"><pre><span></span><code>bun<span class="w"> </span>add<span class="w"> </span>@stadiamaps/api
</code></pre></div>
</div>
</div>
</div>
</details>
<div class="highlight"><pre><span></span><code><span class="k">import</span><span class="w"> </span><span class="p">{</span><span class="w"> </span><span class="nx">RoutingApi</span><span class="p">,</span><span class="w"> </span><span class="nx">Configuration</span><span class="p">,</span><span class="w"> </span><span class="nx">RouteRequest</span><span class="p">,</span><span class="w"> </span><span class="nx">instanceOfRouteResponse</span><span class="p">,</span><span class="w"> </span><span class="nx">instanceOfOsrmRouteResponse</span><span class="w"> </span><span class="p">}</span><span class="w"> </span><span class="kr">from</span><span class="w"> </span><span class="s1">'@stadiamaps/api'</span><span class="p">;</span>

<span class="c1">// If you are writing for a backend application or can't use domain-based auth,</span>
<span class="c1">// then you'll need to add your API key like so:</span>
<span class="c1">// </span>
<span class="c1">// const config = new Configuration({ apiKey: "YOUR-API-KEY" }); (1)</span>
<span class="c1">// You can also use our EU endpoint to keep traffic within the EU using the basePath option:</span>
<span class="c1">// const config = new Configuration({ basePath: "https://api-eu.stadiamaps.com" });</span>
<span class="c1">// const api = new RoutingApi(config);</span>
<span class="kd">const</span><span class="w"> </span><span class="nx">api</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="ow">new</span><span class="w"> </span><span class="nx">RoutingApi</span><span class="p">();</span>

<span class="kd">const</span><span class="w"> </span><span class="nx">locationA</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="p">{</span>
<span class="w">    </span><span class="s2">"lon"</span><span class="o">:</span><span class="w"> </span><span class="o">-</span><span class="mf">76.306572</span><span class="p">,</span>
<span class="w">    </span><span class="s2">"lat"</span><span class="o">:</span><span class="w"> </span><span class="mf">40.042072</span><span class="p">,</span>
<span class="w">    </span><span class="s2">"type"</span><span class="o">:</span><span class="w"> </span><span class="nx">RoutingWaypointTypeEnum</span><span class="p">.</span><span class="nx">Break</span>
<span class="p">};</span>
<span class="kd">const</span><span class="w"> </span><span class="nx">locationB</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="p">{</span>
<span class="w">    </span><span class="s2">"lon"</span><span class="o">:</span><span class="w"> </span><span class="o">-</span><span class="mf">76.781559</span><span class="p">,</span>
<span class="w">    </span><span class="s2">"lat"</span><span class="o">:</span><span class="w"> </span><span class="mf">39.992115</span><span class="p">,</span>
<span class="w">    </span><span class="s2">"type"</span><span class="o">:</span><span class="w"> </span><span class="nx">RoutingWaypointTypeEnum</span><span class="p">.</span><span class="nx">Break</span>
<span class="p">};</span>
<span class="kd">const</span><span class="w"> </span><span class="nx">req</span><span class="o">:</span><span class="w"> </span><span class="nx">RouteRequest</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="p">{</span>
<span class="w">    </span><span class="nx">locations</span><span class="o">:</span><span class="w"> </span><span class="p">[</span>
<span class="w">        </span><span class="nx">locationA</span><span class="p">,</span>
<span class="w">        </span><span class="nx">locationB</span>
<span class="w">    </span><span class="p">],</span>
<span class="w">    </span><span class="nx">costing</span><span class="o">:</span><span class="w"> </span><span class="s2">"auto"</span><span class="p">,</span>
<span class="w">    </span><span class="nx">costingOptions</span><span class="o">:</span><span class="w"> </span><span class="p">{</span>
<span class="w">        </span><span class="nx">auto</span><span class="o">:</span><span class="w"> </span><span class="p">{</span>
<span class="w">            </span><span class="nx">useHighways</span><span class="o">:</span><span class="w"> </span><span class="mf">0.3</span><span class="p">,</span><span class="w">  </span><span class="c1">// Take the scenic route ;)</span>
<span class="w">        </span><span class="p">}</span>
<span class="w">    </span><span class="p">},</span>
<span class="w">    </span><span class="nx">units</span><span class="o">:</span><span class="w"> </span><span class="nx">DistanceUnit</span><span class="p">.</span><span class="nx">Mi</span><span class="p">,</span>
<span class="p">};</span>
<span class="kd">const</span><span class="w"> </span><span class="nx">res</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="k">await</span><span class="w"> </span><span class="nx">api</span><span class="p">.</span><span class="nx">route</span><span class="p">({</span><span class="w"> </span><span class="nx">routeRequest</span><span class="o">:</span><span class="w"> </span><span class="nx">req</span><span class="w"> </span><span class="p">});</span>

<span class="k">if</span><span class="w"> </span><span class="p">(</span><span class="nx">instanceOfRouteResponse</span><span class="p">(</span><span class="nx">res</span><span class="p">))</span><span class="w"> </span><span class="p">{</span>
<span class="w">  </span><span class="c1">// TODO: Process the response (default format)</span>
<span class="p">}</span><span class="w"> </span><span class="k">else</span><span class="w"> </span><span class="k">if</span><span class="w"> </span><span class="p">(</span><span class="nx">instanceOfOsrmRouteResponse</span><span class="p">(</span><span class="nx">res</span><span class="p">))</span><span class="w"> </span><span class="p">{</span>
<span class="w">  </span><span class="c1">// TODO: Process the response (for navigation requests where your request options include format: "osrm"</span>
<span class="p">}</span>
</code></pre></div>
<ol>
<li>Learn how to get an API key in our <a href="../../authentication/">authentication guide</a>.</li>
</ol>
</div>
<div class="tabbed-block">
<details class="tip">
<summary>Installation Instructions</summary>
<p>The Stadia Maps Python SDK is available through any package manager that supports PyPi.</p>
<p><a href="https://pypi.org/project/stadiamaps/"><img alt="PyPI - Downloads" src="https://img.shields.io/pypi/dm/stadiamaps?style=for-the-badge&amp;color=rgb(64%2C81%2C181)" /></a></p>
<div class="tabbed-set tabbed-alternate" data-tabs="3:3"><input checked="checked" id="__tabbed_3_1" name="__tabbed_3" type="radio" /><input id="__tabbed_3_2" name="__tabbed_3" type="radio" /><input id="__tabbed_3_3" name="__tabbed_3" type="radio" /><div class="tabbed-labels"><label for="__tabbed_3_1"><code>pip</code></label><label for="__tabbed_3_2"><code>uv</code></label><label for="__tabbed_3_3"><code>poetry</code></label></div>
<div class="tabbed-content">
<div class="tabbed-block">
<div class="highlight"><pre><span></span><code>pip<span class="w"> </span>install<span class="w"> </span>stadiamaps
</code></pre></div>
</div>
<div class="tabbed-block">
<div class="highlight"><pre><span></span><code>uv<span class="w"> </span>add<span class="w"> </span>stadiamaps
</code></pre></div>
</div>
<div class="tabbed-block">
<div class="highlight"><pre><span></span><code>poetry<span class="w"> </span>add<span class="w"> </span>stadiamaps
</code></pre></div>
</div>
</div>
</div>
</details>
<div class="highlight"><pre><span></span><code><span class="kn">import</span><span class="w"> </span><span class="nn">os</span>
<span class="kn">import</span><span class="w"> </span><span class="nn">stadiamaps</span>
<span class="kn">from</span><span class="w"> </span><span class="nn">stadiamaps.rest</span><span class="w"> </span><span class="kn">import</span> <span class="n">ApiException</span>

<span class="c1"># You can also use our EU endpoint to keep traffic within the EU like so:</span>
<span class="c1"># configuration = stadiamaps.Configuration(host="https://api-eu.stadiamaps.com")</span>
<span class="n">configuration</span> <span class="o">=</span> <span class="n">stadiamaps</span><span class="o">.</span><span class="n">Configuration</span><span class="p">()</span>

<span class="c1"># Configure API key authentication (ex: via environment variable). (1)</span>
<span class="n">configuration</span><span class="o">.</span><span class="n">api_key</span><span class="p">[</span><span class="s1">'ApiKeyAuth'</span><span class="p">]</span> <span class="o">=</span> <span class="n">os</span><span class="o">.</span><span class="n">environ</span><span class="p">[</span><span class="s2">"API_KEY"</span><span class="p">]</span>

<span class="k">with</span> <span class="n">stadiamaps</span><span class="o">.</span><span class="n">ApiClient</span><span class="p">(</span><span class="n">configuration</span><span class="p">)</span> <span class="k">as</span> <span class="n">api_client</span><span class="p">:</span>
    <span class="c1"># Create an instance of the API class</span>
    <span class="n">api_instance</span> <span class="o">=</span> <span class="n">stadiamaps</span><span class="o">.</span><span class="n">RoutingApi</span><span class="p">(</span><span class="n">api_client</span><span class="p">)</span>

    <span class="k">try</span><span class="p">:</span>
        <span class="n">location_a</span> <span class="o">=</span> <span class="p">{</span><span class="s2">"lat"</span><span class="p">:</span> <span class="mf">40.042072</span><span class="p">,</span> <span class="s2">"lon"</span><span class="p">:</span> <span class="o">-</span><span class="mf">76.306572</span><span class="p">}</span>
        <span class="n">location_b</span> <span class="o">=</span> <span class="p">{</span><span class="s2">"lat"</span><span class="p">:</span> <span class="mf">39.992115</span><span class="p">,</span> <span class="s2">"lon"</span><span class="p">:</span> <span class="o">-</span><span class="mf">76.781559</span><span class="p">}</span>
        <span class="n">req</span> <span class="o">=</span> <span class="n">stadiamaps</span><span class="o">.</span><span class="n">RouteRequest</span><span class="p">(</span>
            <span class="nb">id</span><span class="o">=</span><span class="s2">"route"</span><span class="p">,</span>
            <span class="n">locations</span><span class="o">=</span><span class="p">[</span>
                <span class="n">stadiamaps</span><span class="o">.</span><span class="n">RoutingWaypoint</span><span class="o">.</span><span class="n">from_dict</span><span class="p">(</span><span class="n">location_a</span><span class="p">),</span>
                <span class="n">stadiamaps</span><span class="o">.</span><span class="n">RoutingWaypoint</span><span class="o">.</span><span class="n">from_dict</span><span class="p">(</span><span class="n">location_b</span><span class="p">)</span>
            <span class="p">],</span>
            <span class="n">costing</span><span class="o">=</span><span class="n">stadiamaps</span><span class="o">.</span><span class="n">CostingModel</span><span class="o">.</span><span class="n">AUTO</span><span class="p">,</span>
            <span class="n">costing_options</span><span class="o">=</span><span class="n">stadiamaps</span><span class="o">.</span><span class="n">CostingOptions</span><span class="p">(</span><span class="n">auto</span><span class="o">=</span><span class="n">stadiamaps</span><span class="o">.</span><span class="n">AutoCostingOptions</span><span class="p">(</span><span class="n">use_highways</span><span class="o">=</span><span class="mf">0.3</span><span class="p">)),</span>  <span class="c1"># Take the scenic route ;)</span>
            <span class="n">units</span><span class="o">=</span><span class="n">stadiamaps</span><span class="o">.</span><span class="n">DistanceUnit</span><span class="o">.</span><span class="n">MI</span>
        <span class="p">)</span>

        <span class="c1"># NOTE: Usable properties vary depending on the format parameter of the request!</span>
        <span class="c1"># The standard (compact) format includes an id, trip, and alternates.</span>
        <span class="c1"># The OSRM (navigation details in a single response) format uses the routes and waypoints parameters.</span>
        <span class="n">res</span> <span class="o">=</span> <span class="n">api_instance</span><span class="o">.</span><span class="n">route</span><span class="p">(</span><span class="n">req</span><span class="p">)</span><span class="o">.</span><span class="n">actual_instance</span>
    <span class="k">except</span> <span class="n">ApiException</span> <span class="k">as</span> <span class="n">e</span><span class="p">:</span>
        <span class="c1"># Add your error handling here</span>
        <span class="nb">print</span><span class="p">(</span><span class="s2">"Exception when calling the Stadia Maps API: </span><span class="si">%s</span><span class="se">\n</span><span class="s2">"</span> <span class="o">%</span> <span class="n">e</span><span class="p">)</span>
</code></pre></div>
<ol>
<li>Learn how to get an API key in our <a href="../../authentication/">authentication guide</a>.</li>
</ol>
</div>
<div class="tabbed-block">
<details class="tip">
<summary>Installation Instructions</summary>
<div class="tabbed-set tabbed-alternate" data-tabs="4:2"><input checked="checked" id="__tabbed_4_1" name="__tabbed_4" type="radio" /><input id="__tabbed_4_2" name="__tabbed_4" type="radio" /><div class="tabbed-labels"><label for="__tabbed_4_1">Gradle</label><label for="__tabbed_4_2">Maven</label></div>
<div class="tabbed-content">
<div class="tabbed-block">
<p>If aren't already using Maven Central,
add the repository in your Gradle build script.</p>
<div class="highlight"><pre><span></span><code><span class="n">repositories</span><span class="w"> </span><span class="p">{</span>
<span class="w">    </span><span class="n">mavenCentral</span><span class="p">()</span>
<span class="p">}</span>
</code></pre></div>
<p>Then, add the API package and its dependencies.</p>
<div class="tabbed-set tabbed-alternate" data-tabs="5:2"><input checked="checked" id="__tabbed_5_1" name="__tabbed_5" type="radio" /><input id="__tabbed_5_2" name="__tabbed_5" type="radio" /><div class="tabbed-labels"><label for="__tabbed_5_1">Kotlin DSL</label><label for="__tabbed_5_2">Groovy DSL</label></div>
<div class="tabbed-content">
<div class="tabbed-block">
<p><div class="highlight"><span class="filename">build.gradle.kts</span><pre><span></span><code><span class="n">dependencies</span><span class="w"> </span><span class="p">{</span>
<span class="w">    </span><span class="kd">val</span><span class="w"> </span><span class="nv">retrofitVersion</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="s">"2.12.0"</span>

<span class="w">    </span><span class="c1">// API package</span>
<span class="w">    </span><span class="n">implementation</span><span class="p">(</span><span class="s">"com.stadiamaps:api:7.1.0"</span><span class="p">)</span>

<span class="w">    </span><span class="c1">// Dependencies</span>
<span class="w">    </span><span class="n">implementation</span><span class="p">(</span><span class="s">"com.squareup.moshi:moshi-kotlin:1.15.2"</span><span class="p">)</span>
<span class="w">    </span><span class="n">implementation</span><span class="p">(</span><span class="s">"com.squareup.moshi:moshi-adapters:1.15.2"</span><span class="p">)</span>
<span class="w">    </span><span class="n">implementation</span><span class="p">(</span><span class="s">"com.squareup.okhttp3:logging-interceptor:4.12.0"</span><span class="p">)</span>
<span class="w">    </span><span class="n">implementation</span><span class="p">(</span><span class="s">"com.squareup.retrofit2:retrofit:</span><span class="si">$</span><span class="n">retrofitVersion</span><span class="s">"</span><span class="p">)</span>
<span class="w">    </span><span class="n">implementation</span><span class="p">(</span><span class="s">"com.squareup.retrofit2:converter-moshi:</span><span class="si">$</span><span class="n">retrofitVersion</span><span class="s">"</span><span class="p">)</span>
<span class="w">    </span><span class="n">implementation</span><span class="p">(</span><span class="s">"com.squareup.retrofit2:converter-scalars:</span><span class="si">$</span><span class="n">retrofitVersion</span><span class="s">"</span><span class="p">)</span>
<span class="p">}</span>
</code></pre></div>
<div class="highlight"><span class="filename">build.gradle</span><pre><span></span><code><span class="n">dependencies</span><span class="w"> </span><span class="o">{</span>
<span class="w">    </span><span class="kt">def</span><span class="w"> </span><span class="n">retrofitVersion</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="s2">"2.12.0"</span>

<span class="w">    </span><span class="c1">// API package</span>
<span class="w">    </span><span class="n">implementation</span><span class="w"> </span><span class="s1">'com.stadiamaps:api:7.1.0'</span>

<span class="w">    </span><span class="c1">// Dependencies</span>
<span class="w">    </span><span class="n">implementation</span><span class="w"> </span><span class="s1">'com.squareup.moshi:moshi-kotlin:1.15.2'</span>
<span class="w">    </span><span class="n">implementation</span><span class="w"> </span><span class="s1">'com.squareup.moshi:moshi-adapters:1.15.2'</span>
<span class="w">    </span><span class="n">implementation</span><span class="w"> </span><span class="s1">'com.squareup.okhttp3:logging-interceptor:4.12.0'</span>
<span class="w">    </span><span class="n">implementation</span><span class="w"> </span><span class="s2">"com.squareup.retrofit2:retrofit:${retrofitVersion}"</span>
<span class="w">    </span><span class="n">implementation</span><span class="w"> </span><span class="s2">"com.squareup.retrofit2:converter-moshi:${retrofitVersion}"</span>
<span class="w">    </span><span class="n">implementation</span><span class="w"> </span><span class="s2">"com.squareup.retrofit2:converter-scalars:${retrofitVersion}"</span>
<span class="o">}</span>
</code></pre></div></p>
</div>
<div class="tabbed-block"></div>
</div>
</div>
</div>
<div class="tabbed-block">
<p>Our API package is available on Maven Central.
All you need to do is add a few dependencies to your <code>pom.xml</code>.</p>
<div class="highlight"><span class="filename">pom.xml</span><pre><span></span><code><span class="nt">&lt;properties&gt;</span>
<span class="w">    </span><span class="nt">&lt;retrofit.version&gt;</span>2.12.0<span class="nt">&lt;/retrofit.version&gt;</span>
<span class="nt">&lt;/properties&gt;</span>

<span class="nt">&lt;dependencies&gt;</span>
<span class="w">    </span><span class="cm">&lt;!-- API package --&gt;</span>
<span class="w">    </span><span class="nt">&lt;dependency&gt;</span>
<span class="w">        </span><span class="nt">&lt;groupId&gt;</span>com.stadiamaps<span class="nt">&lt;/groupId&gt;</span>
<span class="w">        </span><span class="nt">&lt;artifactId&gt;</span>api<span class="nt">&lt;/artifactId&gt;</span>
<span class="w">        </span><span class="nt">&lt;version&gt;</span>7.1.0<span class="nt">&lt;/version&gt;</span>
<span class="w">    </span><span class="nt">&lt;/dependency&gt;</span>

<span class="w">    </span><span class="cm">&lt;!-- Dependencies --&gt;</span>
<span class="w">    </span><span class="nt">&lt;dependency&gt;</span>
<span class="w">        </span><span class="nt">&lt;groupId&gt;</span>com.squareup.moshi<span class="nt">&lt;/groupId&gt;</span>
<span class="w">        </span><span class="nt">&lt;artifactId&gt;</span>moshi-kotlin<span class="nt">&lt;/artifactId&gt;</span>
<span class="w">        </span><span class="nt">&lt;version&gt;</span>1.15.2<span class="nt">&lt;/version&gt;</span>
<span class="w">    </span><span class="nt">&lt;/dependency&gt;</span>
<span class="w">    </span><span class="nt">&lt;dependency&gt;</span>
<span class="w">        </span><span class="nt">&lt;groupId&gt;</span>com.squareup.moshi<span class="nt">&lt;/groupId&gt;</span>
<span class="w">        </span><span class="nt">&lt;artifactId&gt;</span>moshi-adapters<span class="nt">&lt;/artifactId&gt;</span>
<span class="w">        </span><span class="nt">&lt;version&gt;</span>1.15.2<span class="nt">&lt;/version&gt;</span>
<span class="w">    </span><span class="nt">&lt;/dependency&gt;</span>
<span class="w">    </span><span class="nt">&lt;dependency&gt;</span>
<span class="w">        </span><span class="nt">&lt;groupId&gt;</span>com.squareup.okhttp3<span class="nt">&lt;/groupId&gt;</span>
<span class="w">        </span><span class="nt">&lt;artifactId&gt;</span>logging-interceptor<span class="nt">&lt;/artifactId&gt;</span>
<span class="w">        </span><span class="nt">&lt;version&gt;</span>4.12.0<span class="nt">&lt;/version&gt;</span>
<span class="w">    </span><span class="nt">&lt;/dependency&gt;</span>
<span class="w">    </span><span class="nt">&lt;dependency&gt;</span>
<span class="w">        </span><span class="nt">&lt;groupId&gt;</span>com.squareup.retrofit2<span class="nt">&lt;/groupId&gt;</span>
<span class="w">        </span><span class="nt">&lt;artifactId&gt;</span>retrofit<span class="nt">&lt;/artifactId&gt;</span>
<span class="w">        </span><span class="nt">&lt;version&gt;</span>${retrofit.version}<span class="nt">&lt;/version&gt;</span>
<span class="w">    </span><span class="nt">&lt;/dependency&gt;</span>
<span class="w">    </span><span class="nt">&lt;dependency&gt;</span>
<span class="w">        </span><span class="nt">&lt;groupId&gt;</span>com.squareup.retrofit2<span class="nt">&lt;/groupId&gt;</span>
<span class="w">        </span><span class="nt">&lt;artifactId&gt;</span>converter-moshi<span class="nt">&lt;/artifactId&gt;</span>
<span class="w">        </span><span class="nt">&lt;version&gt;</span>${retrofit.version}<span class="nt">&lt;/version&gt;</span>
<span class="w">    </span><span class="nt">&lt;/dependency&gt;</span>
<span class="w">    </span><span class="nt">&lt;dependency&gt;</span>
<span class="w">        </span><span class="nt">&lt;groupId&gt;</span>com.squareup.retrofit2<span class="nt">&lt;/groupId&gt;</span>
<span class="w">        </span><span class="nt">&lt;artifactId&gt;</span>converter-scalars<span class="nt">&lt;/artifactId&gt;</span>
<span class="w">        </span><span class="nt">&lt;version&gt;</span>${retrofit.version}<span class="nt">&lt;/version&gt;</span>
<span class="w">    </span><span class="nt">&lt;/dependency&gt;</span>
<span class="nt">&lt;/dependencies&gt;</span>
</code></pre></div>
</div>
</div>
</div>
</details>
<div class="highlight"><pre><span></span><code><span class="c1">// Imports (at the top of your source file; we've used some wildcard imports for simplicity)</span>
<span class="k">import</span><span class="w"> </span><span class="nn">com.stadiamaps.api.*</span>
<span class="k">import</span><span class="w"> </span><span class="nn">com.stadiamaps.api.auth.ApiKeyAuth</span>
<span class="k">import</span><span class="w"> </span><span class="nn">com.stadiamaps.api.infrastructure.*</span>
<span class="k">import</span><span class="w"> </span><span class="nn">com.stadiamaps.api.models.*</span>

<span class="c1">// Set your API key (from an environment variable in this case) (1)</span>
<span class="kd">val</span><span class="w"> </span><span class="nv">apiKey</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">System</span><span class="p">.</span><span class="na">getenv</span><span class="p">(</span><span class="s">"STADIA_API_KEY"</span><span class="p">)</span><span class="w"> </span><span class="o">?:</span><span class="w"> </span><span class="k">throw</span><span class="w"> </span><span class="n">RuntimeException</span><span class="p">(</span><span class="s">"API Key not set"</span><span class="p">)</span>

<span class="c1">// Defining the host is optional and defaults to https://api.stadiamaps.com</span>
<span class="c1">// You can also use our EU endpoint to keep traffic within the EU like so:</span>
<span class="c1">// val client = ApiClient(baseUrl = "https://api-eu.stadiamaps.com")</span>
<span class="kd">val</span><span class="w"> </span><span class="nv">client</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">ApiClient</span><span class="p">()</span>
<span class="n">client</span><span class="p">.</span><span class="na">addAuthorization</span><span class="p">(</span><span class="s">"ApiKeyAuth"</span><span class="p">,</span><span class="w"> </span><span class="n">ApiKeyAuth</span><span class="p">(</span><span class="s">"query"</span><span class="p">,</span><span class="w"> </span><span class="s">"api_key"</span><span class="p">,</span><span class="w"> </span><span class="n">apiKey</span><span class="p">))</span>

<span class="c1">// Configure a service for the group of APIs we want to talk to</span>
<span class="kd">val</span><span class="w"> </span><span class="nv">service</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">client</span><span class="p">.</span><span class="na">createService</span><span class="p">(</span><span class="n">RoutingApi</span><span class="o">::</span><span class="n">class</span><span class="p">.</span><span class="na">java</span><span class="p">)</span>

<span class="c1">// Set up the request.</span>
<span class="c1">// Note: this code is blocking for demonstration purposes.</span>
<span class="c1">// If you're using Kotlin with coroutines,</span>
<span class="c1">// you can also use these asynchronously within suspend functions.</span>
<span class="c1">// Synchronous code can enqueue a callback to avoid blocking</span>
<span class="c1">// (you'll definitely want to do one of these instead when on the main thread of an app).</span>
<span class="c1">// See the docs for details: https://square.github.io/retrofit/2.x/retrofit/retrofit2/Call.html</span>
<span class="kd">val</span><span class="w"> </span><span class="nv">locations</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">listOf</span><span class="p">(</span>
<span class="w">    </span><span class="n">RoutingWaypoint</span><span class="p">(</span><span class="m">40.042072</span><span class="p">,</span><span class="w"> </span><span class="o">-</span><span class="m">76.306572</span><span class="p">),</span><span class="w"> </span><span class="n">RoutingWaypoint</span><span class="p">(</span><span class="m">39.992115</span><span class="p">,</span><span class="w"> </span><span class="o">-</span><span class="m">76.781559</span><span class="p">)</span>
<span class="p">)</span>
<span class="kd">val</span><span class="w"> </span><span class="nv">costingOptions</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">CostingOptions</span><span class="p">(</span><span class="n">auto</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">AutoCostingOptions</span><span class="p">(</span><span class="n">useHighways</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="m">0.3</span><span class="p">))</span><span class="w">  </span><span class="c1">// Take the scenic route ;)</span>
<span class="kd">val</span><span class="w"> </span><span class="nv">req</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">RouteRequest</span><span class="p">(</span>
<span class="w">    </span><span class="n">id</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="s">"route"</span><span class="p">,</span>
<span class="w">    </span><span class="n">locations</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">locations</span><span class="p">,</span>
<span class="w">    </span><span class="n">costing</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">CostingModel</span><span class="p">.</span><span class="na">auto</span><span class="p">,</span>
<span class="w">    </span><span class="n">costingOptions</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">costingOptions</span><span class="p">,</span>
<span class="w">    </span><span class="n">units</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">DistanceUnit</span><span class="p">.</span><span class="na">mi</span><span class="p">,</span>
<span class="w">    </span><span class="n">language</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">RoutingLanguages</span><span class="p">.</span><span class="na">enMinusGB</span>
<span class="p">)</span>
<span class="kd">val</span><span class="w"> </span><span class="nv">res</span><span class="w"> </span><span class="o">=</span><span class="w"> </span><span class="n">service</span><span class="p">.</span><span class="na">route</span><span class="p">(</span><span class="n">req</span><span class="p">).</span><span class="na">execute</span><span class="p">()</span>

<span class="k">if</span><span class="w"> </span><span class="p">(</span><span class="n">res</span><span class="p">.</span><span class="na">isSuccessful</span><span class="p">)</span><span class="w"> </span><span class="p">{</span>
<span class="w">    </span><span class="n">println</span><span class="p">(</span><span class="s">"Found result: </span><span class="si">${</span><span class="n">res</span><span class="p">.</span><span class="na">body</span><span class="p">()</span><span class="si">}</span><span class="s">"</span><span class="p">)</span>
<span class="p">}</span><span class="w"> </span><span class="k">else</span><span class="w"> </span><span class="p">{</span>
<span class="w">    </span><span class="n">println</span><span class="p">(</span><span class="s">"Request failed with error code </span><span class="si">${</span><span class="n">res</span><span class="p">.</span><span class="na">code</span><span class="p">()</span><span class="si">}</span><span class="s">"</span><span class="p">)</span>
<span class="p">}</span>
</code></pre></div>
<ol>
<li>Learn how to get an API key in our <a href="../../authentication/">authentication guide</a>.</li>
</ol>
</div>
<div class="tabbed-block">
<details class="tip">
<summary>Installation Instructions</summary>
<p>Our Swift SDK is distributed using the Swift Package Manager (SPM).
Apple's <a href="https://developer.apple.com/documentation/xcode/adding-package-dependencies-to-your-app" target="_blank">documentation</a>
shows how to add a Swift Package dependency to your Xcode project.
On the Add Package screen, you can find our package by its repository URL: <code>https://github.com/stadiamaps/stadiamaps-api-swift</code>.</p>
</details>
<div class="highlight"><pre><span></span><code><span class="kd">import</span><span class="w"> </span><span class="nc">StadiaMaps</span>

<span class="c1">// This setup code can go anywhere before you actually make an API call (typically in your app init)</span>
<span class="kd">func</span><span class="w"> </span><span class="nf">setupStadiaMapsAPI</span><span class="p">()</span><span class="w"> </span><span class="p">{</span>
<span class="w">    </span><span class="c1">// Set your API key (1)</span>
<span class="w">    </span><span class="n">StadiaMapsAPI</span><span class="p">.</span><span class="n">customHeaders</span><span class="w"> </span><span class="p">=</span><span class="w"> </span><span class="p">[</span><span class="s">"Authorization"</span><span class="p">:</span><span class="w"> </span><span class="s">"Stadia-Auth YOUR-API-KEY"</span><span class="p">]</span>
<span class="w">    </span><span class="c1">// Optionally use our EU endpoint to keep traffic within the EU</span>
<span class="w">    </span><span class="c1">// StadiaMapsAPI.basePath = "https://api-eu.stadiamaps.com"</span>
<span class="p">}</span>

<span class="c1">// This function demonstrates how to call the Stadia Maps API.</span>
<span class="c1">// If you have not yet adopted async/await in your Swift codebase, you can use the Task API</span>
<span class="c1">// to call async functions in a non-async context: https://developer.apple.com/documentation/swift/task.</span>
<span class="kd">func</span><span class="w"> </span><span class="nf">myFunction</span><span class="p">()</span><span class="w"> </span><span class="k">async</span><span class="w"> </span><span class="kr">throws</span><span class="w"> </span><span class="p">{</span>
<span class="w">    </span><span class="kd">let</span><span class="w"> </span><span class="nv">req</span><span class="w"> </span><span class="p">=</span><span class="w"> </span><span class="n">RouteRequest</span><span class="p">(</span><span class="n">units</span><span class="p">:</span><span class="w"> </span><span class="p">.</span><span class="n">mi</span><span class="p">,</span>
<span class="w">                           </span><span class="n">id</span><span class="p">:</span><span class="w"> </span><span class="s">"route"</span><span class="p">,</span>
<span class="w">                           </span><span class="n">locations</span><span class="p">:</span><span class="w"> </span><span class="p">[</span>
<span class="w">                               </span><span class="n">RoutingWaypoint</span><span class="p">(</span><span class="n">lat</span><span class="p">:</span><span class="w"> </span><span class="mf">40.042072</span><span class="p">,</span><span class="w"> </span><span class="n">lon</span><span class="p">:</span><span class="w"> </span><span class="o">-</span><span class="mf">76.306572</span><span class="p">),</span>
<span class="w">                               </span><span class="n">RoutingWaypoint</span><span class="p">(</span><span class="n">lat</span><span class="p">:</span><span class="w"> </span><span class="mf">39.992115</span><span class="p">,</span><span class="w"> </span><span class="n">lon</span><span class="p">:</span><span class="w"> </span><span class="o">-</span><span class="mf">76.781559</span><span class="p">),</span>
<span class="w">                           </span><span class="p">],</span>
<span class="w">                           </span><span class="n">costing</span><span class="p">:</span><span class="w"> </span><span class="p">.</span><span class="n">auto</span><span class="p">,</span>
<span class="w">                           </span><span class="n">costingOptions</span><span class="p">:</span><span class="w"> </span><span class="n">CostingOptions</span><span class="p">(</span><span class="n">auto</span><span class="p">:</span><span class="w"> </span><span class="n">AutoCostingOptions</span><span class="p">(</span><span class="n">useTolls</span><span class="p">:</span><span class="w"> </span><span class="mf">0.3</span><span class="p">)))</span><span class="w">  </span><span class="c1">// Take the scenic route :)</span>
<span class="w">    </span><span class="kd">let</span><span class="w"> </span><span class="nv">res</span><span class="w"> </span><span class="p">=</span><span class="w"> </span><span class="k">try</span><span class="w"> </span><span class="k">await</span><span class="w"> </span><span class="n">RoutingAPI</span><span class="p">.</span><span class="n">route</span><span class="p">(</span><span class="n">routeRequest</span><span class="p">:</span><span class="w"> </span><span class="n">req</span><span class="p">)</span>

<span class="w">    </span><span class="c1">// Do something with the response...</span>
<span class="w">    </span><span class="bp">print</span><span class="p">(</span><span class="n">res</span><span class="p">)</span>
<span class="p">}</span>
</code></pre></div>
<ol>
<li>Learn how to get an API key in our <a href="../../authentication/">authentication guide</a>.</li>
</ol>
</div>
<div class="tabbed-block">
<details class="tip">
<summary>Installation Instructions</summary>
<p><strong>Composer</strong></p>
<p>To install the package via <a href="https://getcomposer.org/">Composer</a>,
add <code>stadiamaps/api</code> to your <code>composer.json</code>:</p>
<div class="highlight"><pre><span></span><code><span class="p">{</span>
<span class="w">  </span><span class="nt">"require"</span><span class="p">:</span><span class="w"> </span><span class="p">{</span>
<span class="w">    </span><span class="nt">"stadiamaps/api"</span><span class="p">:</span><span class="w"> </span><span class="s2">"5.*"</span>
<span class="w">  </span><span class="p">}</span>
<span class="p">}</span>
</code></pre></div>
<p>Then run <code>composer install</code>.</p>
<p><strong>Manual Installation</strong></p>
<p>You can also download the files manually and include <code>autoload.php</code> in your scripts:</p>
<div class="highlight"><pre><span></span><code><span class="cp">&lt;?php</span>
<span class="k">require_once</span><span class="p">(</span><span class="s1">'/path/to/OpenAPIClient-php/vendor/autoload.php'</span><span class="p">);</span>
</code></pre></div>
</details>
<div class="highlight"><pre><span></span><code><span class="cp">&lt;?php</span>
<span class="c1">// use or require, depending on your installation method.</span>

<span class="c1">// Configure API key authorization (replace with your Stadia Maps API key) (1)</span>
<span class="nv">$config</span> <span class="o">=</span> <span class="nx">OpenAPI\Client\Configuration</span><span class="o">::</span><span class="na">getDefaultConfiguration</span><span class="p">()</span><span class="o">-&gt;</span><span class="na">setApiKey</span><span class="p">(</span><span class="s1">'api_key'</span><span class="p">,</span> <span class="s1">'YOUR-API-KEY'</span><span class="p">);</span>
<span class="c1">// You can also use our EU endpoint to keep traffic within the EU using setHost:</span>
<span class="c1">// $config = Configuration::getDefaultConfiguration()-&gt;setApiKey('api_key', 'YOUR-API-KEY')-&gt;setHost('https://api-eu.stadiamaps.com');</span>

<span class="nv">$apiInstance</span> <span class="o">=</span> <span class="k">new</span> <span class="nx">OpenAPI\Client\Api\RoutingApi</span><span class="p">(</span>
    <span class="k">new</span> <span class="nx">GuzzleHttp\Client</span><span class="p">(),</span>
    <span class="nv">$config</span>
<span class="p">);</span>

<span class="k">try</span> <span class="p">{</span>
    <span class="nv">$locationA</span> <span class="o">=</span> <span class="p">(</span><span class="k">new</span> <span class="nx">RoutingWaypoint</span><span class="p">())</span>
        <span class="o">-&gt;</span><span class="na">setLat</span><span class="p">(</span><span class="mf">40.042072</span><span class="p">)</span>
        <span class="o">-&gt;</span><span class="na">setLon</span><span class="p">(</span><span class="o">-</span><span class="mf">76.306572</span><span class="p">)</span>
        <span class="o">-&gt;</span><span class="na">setType</span><span class="p">(</span><span class="nx">RoutingWaypoint</span><span class="o">::</span><span class="na">TYPE__BREAK</span><span class="p">);</span>
    <span class="nv">$locationB</span> <span class="o">=</span> <span class="p">(</span><span class="k">new</span> <span class="nx">RoutingWaypoint</span><span class="p">())</span>
        <span class="o">-&gt;</span><span class="na">setLat</span><span class="p">(</span><span class="mf">39.992115</span><span class="p">)</span>
        <span class="o">-&gt;</span><span class="na">setLon</span><span class="p">(</span><span class="o">-</span><span class="mf">76.781559</span><span class="p">)</span>
        <span class="o">-&gt;</span><span class="na">setType</span><span class="p">(</span><span class="nx">RoutingWaypoint</span><span class="o">::</span><span class="na">TYPE__BREAK</span><span class="p">);</span>
    <span class="nv">$req</span> <span class="o">=</span> <span class="p">(</span><span class="k">new</span> <span class="nx">RouteRequest</span><span class="p">())</span>
        <span class="o">-&gt;</span><span class="na">setId</span><span class="p">(</span><span class="s1">'route'</span><span class="p">)</span>
        <span class="o">-&gt;</span><span class="na">setLocations</span><span class="p">([</span><span class="nv">$locationA</span><span class="p">,</span> <span class="nv">$locationB</span><span class="p">])</span>
        <span class="o">-&gt;</span><span class="na">setCosting</span><span class="p">(</span><span class="nx">CostingModel</span><span class="o">::</span><span class="na">AUTO</span><span class="p">)</span>
        <span class="o">-&gt;</span><span class="na">setUnits</span><span class="p">(</span><span class="nx">DistanceUnit</span><span class="o">::</span><span class="na">MI</span><span class="p">)</span>
        <span class="o">-&gt;</span><span class="na">setCostingOptions</span><span class="p">((</span><span class="k">new</span> <span class="nx">CostingOptions</span><span class="p">())</span>
            <span class="o">-&gt;</span><span class="na">setAuto</span><span class="p">((</span><span class="k">new</span> <span class="nx">AutoCostingOptions</span><span class="p">())</span>
                <span class="o">-&gt;</span><span class="na">setUseHighways</span><span class="p">(</span><span class="mf">0.3</span><span class="p">)));</span>
    <span class="nv">$result</span> <span class="o">=</span> <span class="nv">$apiInstance</span><span class="o">-&gt;</span><span class="na">route</span><span class="p">(</span><span class="nv">$req</span><span class="p">);</span>
<span class="p">}</span> <span class="k">catch</span> <span class="p">(</span><span class="nx">Exception</span> <span class="nv">$e</span><span class="p">)</span> <span class="p">{</span>
    <span class="c1">// Add your error handling here</span>
    <span class="k">echo</span> <span class="s1">'Exception when calling the Stadia Maps API: '</span><span class="p">,</span> <span class="nv">$e</span><span class="o">-&gt;</span><span class="na">getMessage</span><span class="p">(),</span> <span class="nx">PHP_EOL</span><span class="p">;</span>
<span class="p">}</span>
</code></pre></div>
<ol>
<li>Learn how to get an API key in our <a href="../../authentication/">authentication guide</a>.</li>
</ol>
</div>
<div class="tabbed-block">
<div class="highlight"><pre><span></span><code>curl<span class="w"> </span>-X<span class="w"> </span>POST<span class="w"> </span>-H<span class="w"> </span><span class="s2">"Content-Type: application/json"</span><span class="w"> </span>-d<span class="w"> </span><span class="s1">'{</span>
<span class="s1">    "locations": [</span>
<span class="s1">        {</span>
<span class="s1">            "lon": -76.306572,</span>
<span class="s1">            "lat": 40.042072,</span>
<span class="s1">            "type": "break"</span>
<span class="s1">        },</span>
<span class="s1">        {</span>
<span class="s1">            "lon": -76.781559,</span>
<span class="s1">            "lat": 39.992115,</span>
<span class="s1">            "type": "break"</span>
<span class="s1">        }</span>
<span class="s1">    ],</span>
<span class="s1">    "costing": "auto",</span>
<span class="s1">    "costing_options": {</span>
<span class="s1">        "auto": {</span>
<span class="s1">            "use_highways": 0.3</span>
<span class="s1">        }</span>
<span class="s1">    },</span>
<span class="s1">    "units": "miles"</span>
<span class="s1">}'</span><span class="w"> </span><span class="s2">"https://api.stadiamaps.com/route/v1?api_key=YOUR-API-KEY"</span>
</code></pre></div>
</div>
</div>
</div>
<h2 id="traffic-influenced-profiles">Traffic-Influenced Profiles<a class="headerlink" href="#traffic-influenced-profiles" title="Permanent link">&para;</a></h2>
<p>Traffic-influenced routing profiles incorporate current live conditions and historical data
to provide better ETAs and routes.
Traffic-influenced variants are available for <code>auto</code>, <code>bus</code>, <code>taxi</code>, and <code>truck</code>
using the <code>_traffic</code> and <code>_traffic_premium</code> suffixes (e.g., <code>auto_traffic</code>, and <code>truck_traffic_premium</code>).</p>
<div class="admonition info">
<p class="admonition-title">Traffic Profile Access</p>
<p>Traffic-influenced routing requires a Standard plan or higher.
See our <a href="https://stadiamaps.com/pricing/">pricing page</a>
for plan details and the API credit schedule.</p>
</div>
<table>
<thead>
<tr>
<th>Suffix</th>
<th>Traffic Data</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>_traffic</code></td>
<td>Adaptive, heuristically-selected sources balancing accuracy and credit cost</td>
</tr>
<tr>
<td><code>_traffic_premium</code></td>
<td>Combines current conditions and predictive data for maximum accuracy</td>
</tr>
</tbody>
</table>
<p>Optimal routes and ETAs often vary by the time of day and day of the week.
The <code>date_time</code> parameter lets you explicitly factor in
traffic conditions and time-based access restrictions.
Traffic-influenced routing profiles benefit most from this.</p>
<table>
<thead>
<tr>
<th>Property</th>
<th>Type</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td><code>type</code></td>
<td>integer</td>
<td><strong>Required.</strong> <code>0</code> = current time (depart now), <code>1</code> = depart at specified time, <code>2</code> = arrive by specified time.</td>
</tr>
<tr>
<td><code>value</code></td>
<td>string</td>
<td>Date and time in <code>YYYY-MM-DDTHH:MM</code> format (the time is always <em>local</em> time; you cannot specify a time zone). Required for types <code>1</code> and <code>2</code>. Must not be provided for type <code>0</code>.</td>
</tr>
</tbody>
</table>
<h2 id="turn-by-turn-navigation">Turn-by-Turn Navigation<a class="headerlink" href="#turn-by-turn-navigation" title="Permanent link">&para;</a></h2>
<p>If you are building a turn-by-turn navigation experience
such as a driver app or in-dash navigation,
our routing APIs are up to the task!
Just set the <code>format</code> parameter to <code>"osrm"</code> in your request to get
a variety of navigation aids in a single API request:</p>
<ul>
<li>Instruction banners</li>
<li>Spoken prompts</li>
<li>Speed limits (where available)</li>
<li>Intersection information (including lane guidance, where available)</li>
</ul>
<p>Our next-generation navigation SDK, <a href="../../sdks/ferrostar/">Ferrostar</a>,
makes it easy to build interactive turn-by-turn guidance experiences.
On major platforms like iOS and Android,
Ferrostar handles the API integration for you.
And, unlike existing solutions,
the UI components are built with SwiftUI and Jetpack Compose.
So if even if you're designing a bespoke interface,
you won't need to start from scratch.</p>
<h2 id="service-limits">Service Limits<a class="headerlink" href="#service-limits" title="Permanent link">&para;</a></h2>
<p>The following complexity limits apply to standard routing requests.</p>
<table>
<thead>
<tr>
<th>Routing profile/mode of travel</th>
<th>Max locations per route</th>
<th>Max b-line distance between all locations</th>
</tr>
</thead>
<tbody>
<tr>
<td>Automobile, bus, truck, taxi, and motorcycle</td>
<td>50</td>
<td>5000 kilometers</td>
</tr>
<tr>
<td>Bicycle, bikeshare, and motor scooter</td>
<td>50</td>
<td>500 kilometers</td>
</tr>
<tr>
<td>Low speed vehicle and pedestrian</td>
<td>50</td>
<td>250 kilometers</td>
</tr>
</tbody>
</table>
<h2 id="complementary-apis">Complementary APIs<a class="headerlink" href="#complementary-apis" title="Permanent link">&para;</a></h2>
<p>The routing API deals in terms of geographic locations. In the case that you are dealing with human-readable addresses,
you can use our <a href="../../geocoding-search-autocomplete/search/">forward geocoding</a> and
<a href="../../geocoding-search-autocomplete/structured-search/">structured geocoding</a> APIs to convert to latitude and longitude.</p>
<p>If you are building a turn-by-turn navigation application, you may find the
<a href="../nearest-roads/">nearest roads</a> and <a href="../trace-attributes/">trace attributes</a> APIs useful for getting road attributes
like tagged speed limits.</p>
<p>Finally, for fitness applications, you can augment routes with an elevation profile using our
<a href="../../elevation/">elevation API</a>.</p>
<h2 id="next-steps">Next Steps<a class="headerlink" href="#next-steps" title="Permanent link">&para;</a></h2>
<ul>
<li><a href="../../tutorials/getting-directions-in-javascript-from-geospatial-apis-maplibre/">Tutorial: Getting directions JavaScript and visualize the route on a map</a></li>
<li><a href="../../guides/getting-the-best-routes-with-valhalla-turn-by-turn-directions-apis/">Guide: Getting the most out of Routing with Valhalla</a></li>
<li><a href="../../api-reference/">Learn more: Interactive Specification and API reference</a></li>
<li><a href="../../sdks/overview/">Get started with an official SDK</a></li>
<li><a href="../../authentication/">401 Unauthorized? Learn about domain auth and API keys</a></li>
</ul>







  
    
  
  
    
  


  <aside class="md-source-file">
    
      
  <span class="md-source-file__fact">
    <span class="md-icon" title="Last update">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M21 13.1c-.1 0-.3.1-.4.2l-1 1 2.1 2.1 1-1c.2-.2.2-.6 0-.8l-1.3-1.3c-.1-.1-.2-.2-.4-.2m-1.9 1.8-6.1 6V23h2.1l6.1-6.1zM12.5 7v5.2l4 2.4-1 1L11 13V7zM11 21.9c-5.1-.5-9-4.8-9-9.9C2 6.5 6.5 2 12 2c5.3 0 9.6 4.1 10 9.3-.3-.1-.6-.2-1-.2s-.7.1-1 .2C19.6 7.2 16.2 4 12 4c-4.4 0-8 3.6-8 8 0 4.1 3.1 7.5 7.1 7.9l-.1.2z"/></svg>
    </span>
    <span class="git-revision-date-localized-plugin git-revision-date-localized-plugin-date" title="March 30, 2026 04:01:50 UTC">March 30, 2026</span>
  </span>

    
    
      
  <span class="md-source-file__fact">
    <span class="md-icon" title="Created">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M14.47 15.08 11 13V7h1.5v5.25l3.08 1.83c-.41.28-.79.62-1.11 1m-1.39 4.84c-.36.05-.71.08-1.08.08-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8c0 .37-.03.72-.08 1.08.69.1 1.33.32 1.92.64.1-.56.16-1.13.16-1.72 0-5.5-4.5-10-10-10S2 6.5 2 12s4.47 10 10 10c.59 0 1.16-.06 1.72-.16-.32-.59-.54-1.23-.64-1.92M18 15v3h-3v2h3v3h2v-3h3v-2h-3v-3z"/></svg>
    </span>
    <span class="git-revision-date-localized-plugin git-revision-date-localized-plugin-date" title="June 20, 2023 12:37:00 UTC">June 20, 2023</span>
  </span>

    
    
    
  </aside>





                
              </article>
            </div>
          
          
  <script>var tabs=__md_get("__tabs");if(Array.isArray(tabs))e:for(var set of document.querySelectorAll(".tabbed-set")){var labels=set.querySelector(".tabbed-labels");for(var tab of tabs)for(var label of labels.getElementsByTagName("label"))if(label.innerText.trim()===tab){var input=document.getElementById(label.htmlFor);input.checked=!0;continue e}}</script>

<script>var target=document.getElementById(location.hash.slice(1));target&&target.name&&(target.checked=target.name.startsWith("__tabbed_"))</script>
        </div>
        
          <button type="button" class="md-top md-icon" data-md-component="top" hidden>
  
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M13 20h-2V8l-5.5 5.5-1.42-1.42L12 4.16l7.92 7.92-1.42 1.42L13 8z"/></svg>
  Back to top
</button>
        
      </main>
      

        <footer class="md-footer">
  
  <div class="md-footer-meta md-typeset">
    <div class="md-footer-meta__inner md-grid">
      <div class="md-copyright">
  
    <div class="md-copyright__highlight">
      &copy;2026 Stadia Maps, Inc.
    </div>
  
  
    Made with
    <a href="https://squidfunk.github.io/mkdocs-material/" target="_blank" rel="noopener">
      Material for MkDocs
    </a>
  
</div>
      
        
<div class="md-social">
  
    
      
      
      
      
        
        
      
      <a href="https://stadiamaps.com/" target="_blank" rel="noopener" title="stadiamaps.com" class="md-social__link">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Free 7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2025 Fonticons, Inc.--><path d="M234.2 8.6c12.3-11.4 31.3-11.4 43.5 0L368 92.3V80c0-17.7 14.3-32 32-32h32c17.7 0 32 14.3 32 32v101.5l37.8 35.1c9.6 9 12.8 22.9 8 35.1S493.2 272 480 272h-16v176c0 35.3-28.7 64-64 64H112c-35.3 0-64-28.7-64-64V272H32c-13.2 0-25-8.1-29.8-20.3s-1.6-26.2 8-35.1zM240 320c-26.5 0-48 21.5-48 48v96h128v-96c0-26.5-21.5-48-48-48z"/></svg>
      </a>
    
  
    
      
      
        
      
      
      
        
        
      
      <a href="https://en.osm.town/@stadiamaps" target="_blank" rel="noopener me" title="en.osm.town" class="md-social__link">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Free 7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2025 Fonticons, Inc.--><path d="M433 179.1c0-97.2-63.7-125.7-63.7-125.7-62.5-28.7-228.6-28.4-290.5 0 0 0-63.7 28.5-63.7 125.7 0 115.7-6.6 259.4 105.6 289.1 40.5 10.7 75.3 13 103.3 11.4 50.8-2.8 79.3-18.1 79.3-18.1l-1.7-36.9s-36.3 11.4-77.1 10.1c-40.4-1.4-83-4.4-89.6-54-.6-4.6-.9-9.3-.9-13.9 85.6 20.9 158.7 9.1 178.7 6.7 56.1-6.7 105-41.3 111.2-72.9 9.8-49.8 9-121.5 9-121.5zm-75.1 125.2h-46.6V190.1c0-49.7-64-51.6-64 6.9v62.5H201V197c0-58.5-64-56.6-64-6.9v114.2H90.3c0-122.1-5.2-147.9 18.4-175 25.9-28.9 79.8-30.8 103.8 6.1l11.6 19.5 11.6-19.5c24.1-37.1 78.1-34.8 103.8-6.1 23.7 27.3 18.4 53 18.4 175"/></svg>
      </a>
    
  
    
      <button type="button" class="md-social__link md-social__link--newsletter" title="Join our mailing list" aria-label="Join our mailing list" aria-haspopup="dialog" data-newsletter="open">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Free 7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2025 Fonticons, Inc.--><path d="M48 64C21.5 64 0 85.5 0 112c0 15.1 7.1 29.3 19.2 38.4l208 156a48 48 0 0 0 57.6 0l208-156c12.1-9.1 19.2-23.3 19.2-38.4 0-26.5-21.5-48-48-48zM0 196v188c0 35.3 28.7 64 64 64h384c35.3 0 64-28.7 64-64V196L313.6 344.8c-34.1 25.6-81.1 25.6-115.2 0z"/></svg>
      </button>
    
  
    
      
      
      
      
        
        
      
      <a href="https://discord.gg/qRBy6qqtdT" target="_blank" rel="noopener" title="discord.gg" class="md-social__link">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--! Font Awesome Free 7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2025 Fonticons, Inc.--><path d="M492.5 69.8c-.2-.3-.4-.6-.8-.7-38.1-17.5-78.4-30-119.7-37.1-.4-.1-.8 0-1.1.1s-.6.4-.8.8c-5.5 9.9-10.5 20.2-14.9 30.6-44.6-6.8-89.9-6.8-134.4 0-4.5-10.5-9.5-20.7-15.1-30.6-.2-.3-.5-.6-.8-.8s-.7-.2-1.1-.2C162.5 39 122.2 51.5 84.1 69c-.3.1-.6.4-.8.7C7.1 183.5-13.8 294.6-3.6 404.2c0 .3.1.5.2.8s.3.4.5.6c44.4 32.9 94 58 146.8 74.2.4.1.8.1 1.1 0s.7-.4.9-.7c11.3-15.4 21.4-31.8 30-48.8.1-.2.2-.5.2-.8s0-.5-.1-.8-.2-.5-.4-.6-.4-.3-.7-.4c-15.8-6.1-31.2-13.4-45.9-21.9-.3-.2-.5-.4-.7-.6s-.3-.6-.3-.9 0-.6.2-.9.3-.5.6-.7c3.1-2.3 6.2-4.7 9.1-7.1.3-.2.6-.4.9-.4s.7 0 1 .1c96.2 43.9 200.4 43.9 295.5 0 .3-.1.7-.2 1-.2s.7.2.9.4c2.9 2.4 6 4.9 9.1 7.2.2.2.4.4.6.7s.2.6.2.9-.1.6-.3.9-.4.5-.6.6c-14.7 8.6-30 15.9-45.9 21.8-.2.1-.5.2-.7.4s-.3.4-.4.7-.1.5-.1.8.1.5.2.8c8.8 17 18.8 33.3 30 48.8.2.3.6.6.9.7s.8.1 1.1 0c52.9-16.2 102.6-41.3 147.1-74.2.2-.2.4-.4.5-.6s.2-.5.2-.8c12.3-126.8-20.5-236.9-86.9-334.5zm-302 267.7c-29 0-52.8-26.6-52.8-59.2s23.4-59.2 52.8-59.2c29.7 0 53.3 26.8 52.8 59.2 0 32.7-23.4 59.2-52.8 59.2m195.4 0c-29 0-52.8-26.6-52.8-59.2s23.4-59.2 52.8-59.2c29.7 0 53.3 26.8 52.8 59.2 0 32.7-23.2 59.2-52.8 59.2"/></svg>
      </a>
    
  
    
      
      
      
      
        
        
      
      <a href="https://github.com/stadiamaps" target="_blank" rel="noopener" title="github.com" class="md-social__link">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Free 7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2025 Fonticons, Inc.--><path d="M173.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6m-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3m44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9M252.8 8C114.1 8 8 113.3 8 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C436.2 457.8 504 362.9 504 252 504 113.3 391.5 8 252.8 8M105.2 352.9c-1.3 1-1 3.3.7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1m-10.8-8.1c-.7 1.3.3 2.9 2.3 3.9 1.6 1 3.6.7 4.3-.7.7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3.7m32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3.7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1m-11.4-14.7c-1.6 1-1.6 3.6 0 5.9s4.3 3.3 5.6 2.3c1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2"/></svg>
      </a>
    
  
    
      
      
      
      
        
        
      
      <a href="https://www.npmjs.com/org/stadiamaps" target="_blank" rel="noopener" title="www.npmjs.com" class="md-social__link">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--! Font Awesome Free 7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License) Copyright 2025 Fonticons, Inc.--><path d="M288 288h-32v-64h32zm288-128v192H288v32H160v-32H0V160zm-416 32H32v128h64v-96h32v96h32zm160 0H192v160h64v-32h64zm224 0H352v128h64v-96h32v96h32v-96h32v96h32z"/></svg>
      </a>
    
  
</div>
      
    </div>
  </div>
</footer>
      

<dialog class="md-newsletter md-typeset" aria-labelledby="newsletter-title" data-newsletter="dialog" data-form-id="cmpmqyhou03cn0j094o1f73mf" data-source="Docs footer" data-state="idle">
  <div class="md-newsletter__inner">
    <button type="button" class="md-newsletter__close" aria-label="Close" data-newsletter="close">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
    </button>
    <h2 class="md-newsletter__title" id="newsletter-title">Join Our Mailing List</h2>
    <p class="md-newsletter__intro">
      Get occasional updates on new features, releases, and product news.
      Unsubscribe anytime.
    </p>
    <form class="md-newsletter__form" data-newsletter="form">
      <div class="md-newsletter__row">
        <div class="md-newsletter__field">
          <label for="newsletter-first-name">First name</label>
          <input id="newsletter-first-name" name="firstName" type="text" autocomplete="given-name" autofocus>
        </div>
        <div class="md-newsletter__field">
          <label for="newsletter-last-name">Last name</label>
          <input id="newsletter-last-name" name="lastName" type="text" autocomplete="family-name">
        </div>
      </div>
      <div class="md-newsletter__field">
        <label for="newsletter-email">Email address</label>
        <input id="newsletter-email" name="email" type="email" autocomplete="email" placeholder="you@example.com" required>
      </div>
      <button type="submit" class="md-newsletter__submit">Subscribe</button>
    </form>
    <p class="md-newsletter__status" role="status" aria-live="polite" data-newsletter="status"></p>
  </div>
</dialog>


    </div>
    <div class="md-dialog" data-md-component="dialog">
      <div class="md-dialog__inner md-typeset"></div>
    </div>
    
    
    
      
      
      <script id="__config" type="application/json">{"annotate": null, "base": "../..", "features": ["toc.follow", "content.code.annotate", "content.code.copy", "content.tabs.link", "navigation.top", "navigation.tabs", "navigation.tabs.sticky", "navigation.path", "navigation.sections"], "search": "../../assets/javascripts/workers/search.2c215733.min.js", "tags": null, "translations": {"clipboard.copied": "Copied to clipboard", "clipboard.copy": "Copy to clipboard", "search.result.more.one": "1 more on this page", "search.result.more.other": "# more on this page", "search.result.none": "No matching documents", "search.result.one": "1 matching document", "search.result.other": "# matching documents", "search.result.placeholder": "Type to start searching", "search.result.term.missing": "Missing", "select.version": "Select version"}, "version": null}</script>
    
    

      <script src="../../assets/javascripts/bundle.d7400e89.min.js"></script>
      
        <script src="https://sa.stadiamaps.com/latest.js"></script>
      
        <script src="../../js/matomo.js"></script>
      
        <script src="../../js/newsletter.js"></script>
      
    
<!-- Update URLs to the one that ends in slash if required -->
<script type="application/javascript">
    // Get the current URL
    let currentUrl = new URL(window.location.href);

    // Check if the URL ends with a slash
    if (!currentUrl.pathname.endsWith('/')) {
        // Redirect to the URL with a slash at the end
        currentUrl.pathname += '/';
        window.history.replaceState(null, null, currentUrl.href);
    }
</script>

  </body>
</html>
Billing & Payments | Support | Hosting Mammoth

info@hostingmammoth.com

# Billing & Payments

Invoices, payment methods, subscriptions, promo codes, and billing troubleshooting.

### Accepted Payment Methods

All payment methods accepted by Data Mammoth — credit cards, PayPal, cryptocurrency, and more.

### Accepted Payment Methods

Data Mammoth accepts a wide range of payment methods so you can choose the option that is most convenient for you. Whether you prefer traditional credit card payments, digital wall…

### Adding and Managing Payment Methods

Guide to adding credit cards, PayPal, and other payment methods to your Data Mammoth account.

### Adding and Managing Payment Methods

Having a valid payment method on file ensures your Data Mammoth services remain active without interruption. This guide walks you through adding, updating, and managing your paymen…

### Billing Troubleshooting — Failed Payments, Disputes

Troubleshoot failed payments, billing disputes, unexpected charges, and other billing issues on your Data Mammoth account.

### Billing Troubleshooting — Failed Payments, Disputes

Billing issues can be stressful, especially when they risk service interruptions. This guide helps you diagnose and resolve the most common billing problems, from failed payments t…

### How to Add Account Credit (Top Up)

Learn how to add credit to your Data Mammoth account balance for faster payments, auto-renewal, and prepaid billing.

### How to Add Account Credit (Top Up)

Account credit also called account balance or prepaid credit lets you pre-load funds into your Data Mammoth account. Credit is automatically applied to future invoices, making paym…

### How to Apply Promo Codes & Discounts

Learn how to find and apply promo codes, coupons, and discounts to your Data Mammoth orders for savings on hosting services.

### How to Apply Promo Codes & Discounts

Data Mammoth occasionally offers promotional discounts, coupon codes, and special pricing for new and existing customers. This guide explains how to find promo codes, apply them du…

### How to Cancel a Subscription

Step-by-step guide to cancelling a Data Mammoth subscription — servers, add-ons, and services with billing implications.

### How to Cancel a Subscription

If you no longer need a Data Mammoth service, you can cancel your subscription through the dashboard. This guide explains the cancellation process, timing options, and what happens…

### How to Pay an Invoice

Learn how to pay outstanding invoices in your Data Mammoth account using credit card, PayPal, or account credit.

### How to Pay an Invoice

Timely invoice payment ensures your Data Mammoth services remain active and uninterrupted. This guide explains how to find unpaid invoices, make payments, and set up automatic paym…

### How to View and Download Invoices

Learn how to access, view, and download your invoices from the Data Mammoth client area.

### How to View and Download Invoices

Keeping track of your invoices is essential for managing your hosting expenses and maintaining accurate financial records. Data Mammoth provides a straightforward invoicing system…

### Refund Policy & How to Request a Refund

Understand Data Mammoth's refund policy, eligibility criteria, and how to submit a refund request through your dashboard.

### Refund Policy & How to Request a Refund

Data Mammoth strives to provide reliable hosting services that meet your needs. If a service does not meet your expectations, we offer a clear refund policy. This guide explains el…

### Tax & VAT Information

Understand how taxes and VAT are applied to your Data Mammoth invoices, how to add a VAT number, and tax exemption info.

### Tax & VAT Information

Data Mammoth applies taxes and VAT Value Added Tax to invoices based on applicable tax regulations and your billing location. This guide explains how taxes are calculated, how to p…

### Understanding Auto-Renewal & Subscriptions

Learn how auto-renewal works for your Data Mammoth services, how to manage subscriptions, and how to update payment settings.

### Understanding Auto-Renewal & Subscriptions

Data Mammoth services operate on a subscription basis with automatic renewal. This means your servers, add-ons, and other services renew automatically at the end of each billing pe…

### Understanding Your Billing Cycle

Learn how billing cycles work at Data Mammoth, including monthly, quarterly, and annual plans, proration, and renewal dates.

### Understanding Your Billing Cycle

Understanding your billing cycle helps you anticipate charges, manage your budget, and avoid unexpected service interruptions. This guide explains how billing cycles work at Data M…

Can't find what you need?

info@hostingmammoth.com

Sun - Fri, 9:00am - 5:00pm
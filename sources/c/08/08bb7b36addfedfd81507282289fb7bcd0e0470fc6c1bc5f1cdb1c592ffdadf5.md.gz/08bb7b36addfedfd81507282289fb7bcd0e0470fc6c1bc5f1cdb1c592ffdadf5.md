
[Skip to main content](#main-content)

# ISP Proxies Pricing

Single subscription. All product access.

- Search
- Scrape
-
- Residential Proxies
- Mobile Proxies
- ISP Proxies
- Dedicated Datacenter Proxies
- Datacenter Proxies
- Web Unblocker
-
- Agent Browser

Welcome credits

FREE

$5 toward any product

Start for free

Starter

$15/mo

VAT may apply

Buy now

Basic

$100/mo

VAT may apply

Buy now

Flexible

Most popular

$500/mo

VAT may apply

Buy now

Enterprise

Tailored solutions for high-volume needs

For plans starting at $2,500/month

Get an offer

Proxies

ISP Proxies

$1.5/IP

Up to 3 IPs

$1.5/IP

Up to 10 IPs

$1.4/IP

Up to 71 IPs

$1.2/IP

Up to 416 IPs

$1.1/IP

2.27K+ IPs

Single subscription. All product access.

- Search
- Scrape
-
- Residential Proxies
- Mobile Proxies
- ISP Proxies
- Dedicated Datacenter Proxies
- Datacenter Proxies
- Web Unblocker
-
- Agent Browser

Welcome credits

FREE

Start for free

Starter

$ 15 /mo

Buy now

Basic

$ 100 /mo

Buy now

Flexible

$ 500 /mo

Buy now

Enterprise

Custom

Get an offer

Proxies

ISP Proxies

$1.5/IP

Up to 3 IPs

$1.5/IP

Up to 10 IPs

$1.4/IP

Up to 71 IPs

$1.2/IP

Up to 416 IPs

$1.1/IP

2.27K+ IPs

Can't find the plan that suits your business case? Explore more options See full pricing

![](https://oxylabs.io/oxylabs-web/pQS47cLC4azqUAin_desktopproxies.png?auto=format%2Ccompress&w=3840&q=75)

![](https://oxylabs.io/oxylabs-web/OVwaPRkkFsn2P8io_Mobileproxies.png?auto=format%2Ccompress&w=3840&q=75)

### Why our ISP Proxies are the best choice

- Shared with up to 3 users
- Premium ASN providers
- HTTP/HTTPS/SOCKS5 protocols
- Unlimited bandwidth with fair usage
- Unlimited-duration sessions

## Frequently Asked Questions

[More FAQs](https://developers.oxylabs.io/help-center)

### Do you offer a free trial for ISP Proxies?

We offer free credits for ISP Proxies. Every new account receives a one-time $5.00 welcome credit on registration, added to your balance immediately – no commitment required to start testing products. Please note that our ISP Proxies free trial is for a single use.

### Are there target restrictions for ISP Proxies?

We restrict some websites for ISP Proxies to avoid abuse and suspicious activities. You can find the list of restricted targets [here](https://developers.oxylabs.io/products/proxies/isp-proxies/restricted-targets).

However, we can access specific targets after you go through a short KYC procedure. Contact our support via the live chat on our home page or contact us at [support@oxylabs.io](mailto:support@oxylabs.io).

### What is an ISP Proxy server?

An ISP proxy server is an IP address hosted on a data center but registered under ISPs (Internet Service Providers). These proxies combine the speed of [Datacenter Proxies](https://oxylabs.io/products/datacenter-proxies) with the anonymity of [Residential Proxies](https://oxylabs.io/products/residential-proxy-pool).

### What is a fair usage policy?

Oxylabs, in order to ensure stability of the provision of services and prevent any potential traffic abuse, limits the concurrent sessions of provided ISP proxies.  
The available concurrent sessions depend on the amount of traffic used per 1 ISP proxy during a billing cycle:

Until 50 GBs of usage per 1 ISP proxy in a month is reached, available concurrent sessions shall be limited to 100 concurrent sessions per 1 purchased ISP proxy (For example, purchasing 100 ISP proxies means that 10,000 concurrent sessions in a billing cycle will be available until 5,000 GB of usage is reached);

If 50 GBs of usage per 1 ISP proxy is reached, the available concurrent sessions are reduced to 10 concurrent sessions per 1 ISP proxy for the remainder of the ongoing billing cycle (For example, purchasing 100 ISP proxies and reaching 5,000 GB of usage means that 1,000 concurrent sessions will be available until the end of the current billing cycle).

### What is your refund policy?

All purchases made through self-service are non-refundable. To help you evaluate our services before purchasing, we offer **a welcome credit** that letsyou test our products with no upfront commitment.

### How does credit-based billing work?

With credit-based billing, you purchase a single plan (a monthly subscription for a set dollar amount) that funds one shared credit balance for all Oxylabs products. Instead of a separate subscription for each product, you can spend your balance across Residential Proxies, Web API, Datacenter Proxies, and more.

Each month, you pay the full amount of your plan, and that amount is added to your balance as credits. As you use a product, credits are deducted from your balance according to that product’s rates and your actual usage.

Unused credits expire at the end of the billing cycle, unless they carry over as part of an upgrade.

### How am I charged for using ISP Proxies?

ISP Proxies are a pay-per-IP product, billed daily. The daily charge is calculated by dividing the total monthly cost by 30 days, regardless of the calendar month.

Example: if an IP costs $2, billed as part of a $30 monthly charge, that works out to a daily price of $2 / 30 = $0.06 per IP, per day. Now, say the user later buys an additional 100 IPs – that adds 100 × $0.06 = $6 per day in extra cost for those IPs.

As you use your proxies, credits are deducted from your balance according to the product’s current rates and your actual usage.

### Do I keep my IPs when I upgrade from a free plan?

Yes. Your assigned IPs stay with your account when you move from a free plan to a paid plan, upgrade, or downgrade. They aren’t lost or returned to the shared pool, so you keep your setup.

```json
{"@context":"https://schema.org","@graph":[{"@type":"ItemList","@id":"urn:itemlist:isp-proxies-plans","name":"ISP Proxies Pricing Plans","itemListOrder":"https://schema.org/ItemListOrderAscending","itemListElement":[{"@type":"ListItem","position":1,"item":{"@id":"urn:plan:isp:shared"}}]},{"@type":"Product","@id":"urn:plan:isp:shared","name":"ISP Proxies","description":"Unlimited-duration sessions, residential-like proxies from premium ASN providers. Shared with up to 3 users.","brand":{"@type":"Organization","name":"Oxylabs"},"category":"ISP Proxies","additionalProperty":[{"@type":"PropertyValue","name":"Bandwidth","value":"Unlimited (fair usage policy applies)"},{"@type":"PropertyValue","name":"Locations","value":"US, UK, FR, ES, DE, JP, CA, IT, NL, PL, BE"},{"@type":"PropertyValue","name":"ASNs","value":"AT&T, Lumen, Frontier, Orange"},{"@type":"PropertyValue","name":"Success rate","value":"99.9%"},{"@type":"PropertyValue","name":"Protocols","value":"HTTP, HTTPS, SOCKS5"},{"@type":"PropertyValue","name":"IP type","value":"Shared (up to 3 users)"},{"@type":"PropertyValue","name":"Sessions","value":"Unlimited duration"}],"offers":{"@type":"AggregateOffer","priceCurrency":"USD","lowPrice":"1.10","highPrice":"1.60","offerCount":6,"offers":[{"@type":"Offer","url":"https://oxylabs.io/pricing/isp-proxies","priceCurrency":"USD","price":"1.60","priceSpecification":{"@type":"UnitPriceSpecification","price":"1.60","priceCurrency":"USD","unitText":"IP","eligibleQuantity":{"@type":"QuantitativeValue","minValue":10,"maxValue":49,"unitText":"IP"}},"availability":"https://schema.org/InStock"},{"@type":"Offer","url":"https://oxylabs.io/pricing/isp-proxies","priceCurrency":"USD","price":"1.45","priceSpecification":{"@type":"UnitPriceSpecification","price":"1.45","priceCurrency":"USD","unitText":"IP","eligibleQuantity":{"@type":"QuantitativeValue","minValue":50,"maxValue":99,"unitText":"IP"}},"availability":"https://schema.org/InStock"},{"@type":"Offer","url":"https://oxylabs.io/pricing/isp-proxies","priceCurrency":"USD","price":"1.30","priceSpecification":{"@type":"UnitPriceSpecification","price":"1.30","priceCurrency":"USD","unitText":"IP","eligibleQuantity":{"@type":"QuantitativeValue","minValue":100,"maxValue":499,"unitText":"IP"}},"availability":"https://schema.org/InStock"},{"@type":"Offer","url":"https://oxylabs.io/pricing/isp-proxies","priceCurrency":"USD","price":"1.20","priceSpecification":{"@type":"UnitPriceSpecification","price":"1.20","priceCurrency":"USD","unitText":"IP","eligibleQuantity":{"@type":"QuantitativeValue","minValue":500,"maxValue":999,"unitText":"IP"}},"availability":"https://schema.org/InStock"},{"@type":"Offer","url":"https://oxylabs.io/pricing/isp-proxies","priceCurrency":"USD","price":"1.15","priceSpecification":{"@type":"UnitPriceSpecification","price":"1.15","priceCurrency":"USD","unitText":"IP","eligibleQuantity":{"@type":"QuantitativeValue","minValue":1000,"maxValue":1999,"unitText":"IP"}},"availability":"https://schema.org/InStock"},{"@type":"Offer","url":"https://oxylabs.io/pricing/isp-proxies","priceCurrency":"USD","price":"1.10","priceSpecification":{"@type":"UnitPriceSpecification","price":"1.10","priceCurrency":"USD","unitText":"IP","eligibleQuantity":{"@type":"QuantitativeValue","minValue":2000,"unitText":"IP"}},"availability":"https://schema.org/InStock"}]}}]}
```

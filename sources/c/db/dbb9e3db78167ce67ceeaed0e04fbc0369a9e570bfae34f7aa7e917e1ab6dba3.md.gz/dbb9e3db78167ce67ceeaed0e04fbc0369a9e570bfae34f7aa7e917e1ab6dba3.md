```
Sign me up for Fly.io and deploy my first app. Fly.io runs apps on Machines: fast-booting VMs that start in about a second, run close to users in regions around the world, and stop when idle so I only pay for what I use.

1. Install flyctl:
   curl -L https://fly.io/install.sh | sh
2. Create my Fly.io account. This opens the sign-up page in my browser, where I can use my email address, Google account, or GitHub account. It waits until I approve, so run it in the background:
   fly auth signup
3. From inside my project source directory, launch my app. This detects my framework, generates a Dockerfile and fly.toml if needed, and deploys it to Machines:
   fly launch
4. Check that my Machines are running:
   fly status
5. Open my app in the browser, and check that it loads:
   fly apps open

If `fly auth signup` can't open a browser, it prints a link. Show me the link so I can open it, sign up, and approve. Keep that same command running: each run makes a new link, and only the one I approve finishes. If it stopped, ask me for the code the page shows after I approve, and run `fly auth login --code <code>`.

If I don't have a project yet, run a Machine directly from a public image instead. App names are unique across Fly.io, so let flyctl pick one, and use the name it prints in place of <app-name>. A Machine started this way has no public IP address, so add one before opening the app:
   fly apps create --generate-name
   fly machine run nginx --app <app-name> --port 80:80/tcp:http --port 443:80/tcp:http:tls
   fly ips allocate-v4 --shared --app <app-name>
   fly ips allocate-v6 --app <app-name>
   fly apps open --app <app-name>

To make future changes live, run `fly deploy` from the project directory.

Quickstart: https://fly.io/docs/getting-started/launch/
Machines docs: https://fly.io/docs/machines/
```

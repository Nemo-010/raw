|  | Free account | Pro Lite account | Pro account | Pro+ account | Community Site |
| --- | --- | --- | --- | --- | --- |
| Price for 12 months of service | free | $49.90 | $119.90 | $239.90 | free |
| Number of sites | 5 | 5 | 10 | 30 | - |
| Storage | 5 x 300MB | 30 GB | 100 GB | 200 GB | unlimited[1](javascript:;) |
| Account-based storage calculation | - | yes (30 GB + 5 GB per purchased slot) | yes (100 GB + 5 GB per purchased slot) | yes (200 GB + 5 GB per purchased slot) | - |
| Can buy more sites and storage (slots) | - | yes | yes | yes | - |
| New features earlier | - | yes | yes | yes | yes |
| Hide own karma and pro status | - | - | - | yes | - |
| Support | community | community | email | priority email | priority email |
| Features that apply to all sites created by a User |  |  |  |  |  |
|  | Free account | Pro Lite account | Pro account | Pro+ account | Community Site |
| Max number of pages | unlimited | unlimited | unlimited | unlimited | unlimited |
| Max number of revisions per page | unlimited | unlimited | unlimited | unlimited | unlimited |
| Custom CSS themes | yes | yes | yes | yes | yes |
| Simple backups | yes | yes | yes | yes | yes |
| Max members of a public site | unlimited | unlimited | unlimited | unlimited | unlimited |
| Advanced membership, roles and permissions | yes | yes | yes | yes | yes |
| Can make a site private (non public) | yes | yes | yes | yes | no |
| Max number of members for private sites | 5 | 10 | 20 | unlimited | - |
| Max upload storage per site | 300 MB | flexible | flexible | flexible | unlimited[2](javascript:;) |
| Max uploaded file size | 25 MB | 50 MB | 100 MB | 200 MB | 200 MB |
| Custom domain mapping | yes | yes | yes | yes | yes |
| Secure access via https (SSL) | yes | yes | yes | yes | yes |
| **Advertising** | **no control** | **full control** | **full control** | **full control** | limited control |
| Custom layout | - | yes | yes | yes | yes |
| XML-RPC api | - | yes | yes | yes | yes |
| Block cloning of site | - | yes | yes | yes | yes |
| Block inclusion of site | - | yes | yes | yes | yes |
| Advanced web statistics | - | yes | yes | yes | yes |
| Per-site user profiles | - | - | yes | yes | yes |
| Hide karma and pro status icons for all users within a site | - | - | - | yes | yes |
| Custom footer | - | - | - | yes | yes |

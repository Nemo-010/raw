
# Flexible Pricing

Start with 20,000 free credits, then pay only for what you use

API Subscription plans

## A credit allowance every month,<br> at low cost per credit

Every plan ships the full response, always: city-level geolocation, ASN and company data, carrier and VPN/proxy detection. We never hold fields back for a higher tier.

Monthly Annual 2 months free

### Starter

100,000 credits / mo

$29 $24 / month

billed $290 yearly

- All response fields
- 2 API keys included
- Auto top-up with packs (requires initial configuration)

[Subscribe](https://dashboard.ipregistry.co/signup "Subscribe to Starter")

Most popular

### Professional

300,000 credits / mo

$79 $66 / month

billed $790 yearly

- All response fields
- 3 API keys included
- Auto top-up with packs (requires initial configuration)

[Subscribe](https://dashboard.ipregistry.co/signup "Subscribe to Professional")

### Business

1,150,000 credits / mo

$199 $166 / month

billed $1,990 yearly

- All response fields
- 4 API keys included
- Auto top-up with packs (requires initial configuration)

[Subscribe](https://dashboard.ipregistry.co/signup "Subscribe to Business")

### Scale

2,450,000 credits / mo

$399 $333 / month

billed $3,990 yearly

- All response fields
- 5 API keys included
- Auto top-up with packs (requires initial configuration)

[Subscribe](https://dashboard.ipregistry.co/signup "Subscribe to Scale")

Need more API keys? Add extra keys to any plan for $2/mo ($20/yr) each.

Prices in US dollars, excluding taxes. Customers in the European Economic Area and the United Kingdom pay in euros.

1 lookup= 1 request= 1 credit

The only exception is our batch endpoints, which spend one credit per lookup in the batch request, plus 1.

[See how credits work](https://ipregistry.co/how-credits-work)

One-time packs

## Prefer to pay as you go?<br> Buy credits once, use them anytime

Pack credits never expire and need no subscription. The bigger the pack, the lower the cost per credit.

15,000

credits

$10

$0.667 / 1,000 credits

[Buy this pack](https://dashboard.ipregistry.co/signup "Buy a pack of 15,000 credits")

100,000

credits

$50

$0.500 / 1,000 credits

[Buy this pack](https://dashboard.ipregistry.co/signup "Buy a pack of 100,000 credits")

250,000

credits

$100

$0.400 / 1,000 credits

[Buy this pack](https://dashboard.ipregistry.co/signup "Buy a pack of 250,000 credits")

Best value

1,750,000

credits

$500

$0.286 / 1,000 credits

[Buy this pack](https://dashboard.ipregistry.co/signup "Buy a pack of 1,750,000 credits")

Enterprise

## Never get blocked, no matter how much you scale

A committed monthly allowance that keeps working past your limit: automatic overage instead of an error, billed on your terms with invoicing, purchase orders, and wire transfer.

- 10+ API keys
- Uptime SLA (99.99%)
- Priority support, 7 days a week
- Payment on invoice, purchase orders
- Wire transfer and other payment methods

[Contact us](mailto:sales@ipregistry.co "Contact Ipregistry Sales")

from$299/ month

or $2,990/year, 2 months free

includes 500,000 credits / month

Additional credit blocks +$20/mo per +100,000 credits

Overage, beyond your plan $0.25 per 1,000 credits

Very high volumes Discount available, contact sales

Offline datasets

## Need the raw data instead of the API?

Subscribe to any dataset for self-hosted, sub-millisecond lookups on your own infrastructure.  
 See [all datasets](https://ipregistry.co/datasets) for field details and sample files.

[Abuser from $200/mo IP ranges recently observed in spam, brute force and other abusive behavior.](https://ipregistry.co/datasets/abuser) [Anycast from $200/mo IP ranges announced from many locations at once, as used by DNS resolvers, CDNs and DDoS mitigation.](https://ipregistry.co/datasets/anycast) [AS from $300/mo Every allocated Autonomous System Number with its organization, domain, type, country and registry.](https://ipregistry.co/datasets/as) [Attacker from $200/mo Active attack infrastructure: sources of exploitation attempts, scanners and malicious campaigns.](https://ipregistry.co/datasets/attacker) [Bogon from $100/mo Unallocated, reserved and otherwise unroutable address space that should never reach your edge.](https://ipregistry.co/datasets/bogon) [Company from $500/mo The business or organization behind every IP range, with name, domain and network type.](https://ipregistry.co/datasets/company) [Connection from $300/mo Connection type and announcing network for every IP range, including the routed prefix.](https://ipregistry.co/datasets/connection) [Geofeed from $500/mo The Ipregistry geolocation database in RFC 8805 geofeed format, one CIDR prefix per line.](https://ipregistry.co/datasets/geofeed) [Geolocation from $500/mo IP to location mapping for IPv4 and IPv6, from country down to city, postal code and coordinates.](https://ipregistry.co/datasets/geolocation) [Mobile from $300/mo Mobile carrier ranges with MCC, MNC, operator and brand for cellular traffic identification.](https://ipregistry.co/datasets/mobile) [Proxy from $300/mo Millions of known proxy exit ranges: HTTP, SOCKS, web and residential proxies.](https://ipregistry.co/datasets/proxy) [Relay from $200/mo Privacy relay egress ranges such as iCloud Private Relay, kept current daily.](https://ipregistry.co/datasets/relay) [Tor from $200/mo Tor relays and exit nodes, flagged so you can treat exit traffic differently from the rest.](https://ipregistry.co/datasets/tor) [VPN from $300/mo Exit ranges of commercial and self-hosted VPN services, updated daily.](https://ipregistry.co/datasets/vpn)

**Planning to redistribute this data to your own customers?** The prices above cover private, internal use only. Redistribution requires a separate custom license: [contact sales for a quote](mailto:sales@ipregistry.co "Ask about a redistribution license").

LIR & registry services

## Need IP resources of your own?

A separate service from IP geolocation and threat intelligence: get RIPE NCC number resources through our Local Internet Registry, without becoming an LIR yourself. See [all LIR services](https://ipregistry.co/lir-services) for details. Prices in euros for customers in the European Economic Area and the United Kingdom. Everywhere else, prices are in US dollars.

[ASN Registration from €60/yr\* Obtain your own Autonomous System Number to run BGP and multi-home your network.](https://ipregistry.co/asn-registration) [IPv4 Address Lease from €130/mo Lease routable IPv4 space without the upfront cost of buying address blocks.](https://ipregistry.co/ipv4-address-lease) [IPv6 Address Lease from €15/yr Move to IPv6 with ready-to-route address ranges and full LIR sponsorship.](https://ipregistry.co/ipv6-address-lease) [Resource Sponsoring from €120/yr\* We act as your Local Internet Registry so you can hold RIPE resources directly.](https://ipregistry.co/lir-sponsoring)

\*Your first independent resource with us, an AS number or PI space, is 50% off its first year. Leases and one-time fees are not discounted.

Free to start

## 0 credits, free

Every new account gets 20,000 credits on sign-up.  
No credit card, no time limit. Build, test, and see real results before you spend a cent.

[Start for free](https://dashboard.ipregistry.co/signup "Sign up for free")

FAQ

## Frequently asked questions

<details>

<summary>Is there a minimum subscription period?

</summary>

No, you can cancel anytime you want. You can choose to subscribe on a month to month basis, or pick an annual plan and get two months free. And if you prefer no subscription at all, one-time packs of credits never expire.

</details>

<details>

<summary>Can you handle my high-volume use case?

</summary>

Ipregistry's reputation is built on its enterprise-grade API for IP Geolocation and Threat Intelligence. The infrastructure runs in multiple data centers globally (Australia, Brazil, Europe, India, Japan, US, United Arab Emirates, and more). Data is loaded and indexed in-memory on our nodes, and requests are routed to the closest data center through a global anycast load balancer for low latency.

Our infrastructure handles millions of requests per day. If you anticipate growth in request volumes, we can easily handle it.

Have specific requirements, such as access to our raw datasets or sub-millisecond lookups on your own infrastructure? Take a look at our <a href="https://ipregistry.co/enterprise" title="Ipregistry Enterprise Solutions">Enterprise solutions</a>.

</details>

<details>

<summary>How much of the IP Address space do you cover?

</summary>

Ipregistry covers about 99.99% of all available IPv4 and IPv6 addresses in use.

Some IP addresses are simply not locatable. For example, <code>192.168.0.1</code> is a private address that isn't routable on the public Internet and has no meaning outside a local network, so not every response field will have a value.

More generally, this applies to all reserved IP addresses (*loopback*, *link-local*, *multicast*, *private*, *site-local* or *wildcard*), which don't make sense in a geolocation context. Anycast IP addresses that route content based on requester location (e.g. <code>1.1.1.1</code>) have low-confidence accuracy. This limitation applies to any IP geolocation provider.

</details>

<details>

<summary>Where do you get the data?

</summary>

Ipregistry datasets are crafted from multiple sources using unique AI algorithms. We collect, parse, analyze, classify and correlate hundreds of Gigabytes of data every day from several partners and public sources: snapshots of BGP tables, Regional Internet Registry (RIR) databases, ISP data, data-sharing agreements, geofeeds, latency-based tracking, and <a href="https://ipregistry.co/data-corrections" title="Data Corrections">corrections</a> we receive.

</details>

<details>

<summary>How often is the data updated?

</summary>

We detect and apply changes continuously. All IP geolocation data is refreshed at least once per day, and <a href="https://ipregistry.co/docs/proxy-tor-threat-detection#content">threat/security data</a> is updated on average every 15 minutes, so you get fresh results with false positives reduced to a minimum.

</details>

<details>

<summary>How can I keep an eye on my request volumes?

</summary>

You can analyze your usage per period directly from the <a href="https://dashboard.ipregistry.co" title="Ipregistry Dashboard">dashboard</a>. Once authenticated, it shows a graph of credits consumed, and it can send a weekly or monthly summary by email.

To get the number of remaining credits programmatically, read the <code>Ipregistry-Credits-Remaining</code> response header on any API request.

</details>

<details>

<summary>What do I get for free when I sign up?

</summary>

Every new account gets 20,000 free credits, one time, so you can build and test with up to 20,000 requests before spending anything. Features are never segmented, so you get all data (company data, VPN detection, and more) from the first request.

Once your free credits are used, subscribe to a monthly plan or buy a pack starting at $10. Packs never expire and carry no subscription of their own.

</details>

<details>

<summary>Can I just register many accounts to stay within the free limit?

</summary>

Many thanks to everyone who doesn't do this. By playing within the rules you enable us to keep working on this service.

If you do abuse it, be warned: when we detect this, we start feeding back randomly wrong results. Enjoy!

</details>

<details>

<summary>How is Ipregistry compliant with privacy laws?

</summary>

Ipregistry is <a href="https://ipregistry.co/ccpa">CCPA</a>, <a href="https://ipregistry.co/gdpr">GDPR</a> and <a href="https://ipregistry.co/lgpd">LGPD</a> compliant. You can read more on the dedicated pages and in our <a href="https://ipregistry.co/privacy">Privacy Policy</a>.

</details>

<details>

<summary>Can I cancel anytime?

</summary>

Yes. Subscription plans have no commitment. Cancel from the dashboard at any time, effective at the end of the paid period, and unused pack credits are never affected or forfeited since they were never tied to a subscription in the first place.

</details>

<details>

<summary>How does Ipregistry compare to other providers?

</summary>

Unlike most subscription-based providers, Ipregistry never segments data behind higher tiers: every plan and every pack includes the same full response, city-level geolocation, ASN, company, carrier, and VPN/proxy detection. See our detailed comparisons with <a href="https://ipregistry.co/blog/ipinfo-alternative-competitor">ipinfo.io</a>, <a href="https://ipregistry.co/blog/ipstack-alternative-competitor">ipstack</a>, and <a href="https://ipregistry.co/blog/ipdata-alternative">ipdata.co</a>.

</details>

<details>

<summary>How can I contact you?

</summary>

Your question isn't answered above, or you'd like to share some feedback? Get in touch.

</details>

Get started with 20,000 free lookups: [sign up](https://dashboard.ipregistry.co/signup)

```json
{"@context":"http://schema.org","@type":"Organization","name":"Ipregistry","alternateName":"ipregistry","url":"https://ipregistry.co/","logo":"https://cdn.ipregistry.co/logo/logo-blue-512x512.png","slogan":"All the IP data you need, none of the headache","sameAs":["https://twitter.com/ipregistryco","https://github.com/ipregistry","https://www.linkedin.com/company/ipregistry"]}
{"@context":"https://schema.org","@type":"FAQPage","mainEntity":[{"@type":"Question","name":"Is there a minimum subscription period?","acceptedAnswer":{"@type":"Answer","text":"No, you can cancel anytime you want. You can choose to subscribe on a month to month basis, or pick an annual plan and get two months free. And if you prefer no subscription at all, one-time packs of credits never expire."}},{"@type":"Question","name":"Can you handle my high-volume use case?","acceptedAnswer":{"@type":"Answer","text":"Yes. The Ipregistry API is enterprise-grade and runs in multiple data centers worldwide with in-memory data and global anycast routing, handling millions of requests per day. For raw datasets or sub-millisecond self-hosted lookups, see our Enterprise solutions."}},{"@type":"Question","name":"How much of the IP Address space do you cover?","acceptedAnswer":{"@type":"Answer","text":"Ipregistry covers about 99.99% of all IPv4 and IPv6 addresses in use. Some IPs are simply not locatable: reserved, private, loopback, link-local, multicast or wildcard addresses. Anycast IPs also have low-confidence accuracy. This applies to any IP geolocation provider."}},{"@type":"Question","name":"Where do you get the data?","acceptedAnswer":{"@type":"Answer","text":"Our datasets are built from multiple sources using AI algorithms: BGP table snapshots, Regional Internet Registry (RIR) databases, ISP data, data-sharing agreements, geofeeds, latency-based tracking, and corrections we receive."}},{"@type":"Question","name":"How often is the data updated?","acceptedAnswer":{"@type":"Answer","text":"IP geolocation data is refreshed at least once per day, and threat/security data is updated on average every 15 minutes, so you get fresh results with minimal false positives."}},{"@type":"Question","name":"How can I keep an eye on my request volumes?","acceptedAnswer":{"@type":"Answer","text":"The dashboard shows a graph of credits consumed and can email a weekly or monthly summary. Programmatically, read the Ipregistry-Credits-Remaining response header on any API request."}},{"@type":"Question","name":"What do I get for free when I sign up?","acceptedAnswer":{"@type":"Answer","text":"Every new account gets 20,000 free credits, one time, to build and test with. No credit card required, and free credits never expire, so there is no rush to use them."}},{"@type":"Question","name":"How is Ipregistry compliant with privacy laws?","acceptedAnswer":{"@type":"Answer","text":"Ipregistry is CCPA, GDPR and LGPD compliant. See the dedicated pages and our Privacy Policy for details."}},{"@type":"Question","name":"Can I cancel anytime?","acceptedAnswer":{"@type":"Answer","text":"Yes. Subscription plans and packs both have no commitment. Cancel a plan whenever you like from the dashboard, effective at the end of the paid period, and pack credits are never subject to a subscription at all."}},{"@type":"Question","name":"How does Ipregistry compare to other providers?","acceptedAnswer":{"@type":"Answer","text":"Unlike most subscription-based providers, Ipregistry never segments data behind higher tiers: every plan and every pack includes the same full response, city-level geolocation, ASN, company, carrier, and VPN/proxy detection. See our detailed comparison with ipinfo.io."}},{"@type":"Question","name":"How can I contact you?","acceptedAnswer":{"@type":"Answer","text":"If your question is not answered here, reach us through the chat on the site to get in touch."}}]}
```

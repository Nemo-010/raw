#### Data Questions

8–20 years of data, depending on the API endpoint. The coverage grows every day because the data is constantly updated.

10+ years, depending on the API endpoint.

8+ years, depending on the API endpoint.

17.000+ stocks, 20.000+ funds, 3000+ ETFs, 13.000+ OTC securities, 200.000+ derivatives.

Yes, stock prices are adjusted for splits.

#### API Questions

In your [dashboard](https://financialdata.net/dashboard). You must be signed in to access the dashboard.

If the API endpoint specifies a limit on records to be retrieved, then you need to use the offset parameter. For example, if the record limit is 500, then with the first API call, you will retrieve records 0–499, with the second API call records 500–999, etc.

JSON and CSV.

50–100 KB.

#### Subscription Questions

1 month.

Yes, you can.

Credit and debit cards, PayPal, Google Pay, Apple Pay, Link.

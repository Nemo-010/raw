## GMI Cloud

`gmicloud`

Models

17

Package

@ai-sdk/openai-compatible

API

https://api.gmi-serving.com/v1

Docs

[Provider docs](https://docs.gmicloud.ai/inference-engine/api-reference/llm-api-reference)

### Models

17

| [Claude Opus 4.6](https://models.dev/models/anthropic/claude-opus-4-6)anthropic/claude-opus-4-6 | anthropic/claude-opus-4.6 | 409,600 | 128,000 | $5.00 / $25.00 | Yes | Yes | - | Yes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| [Claude Opus 4.7](https://models.dev/models/anthropic/claude-opus-4-7)anthropic/claude-opus-4-7 | anthropic/claude-opus-4.7 | 409,600 | 128,000 | $4.50 / $22.50 | Yes | Yes | - | No |
| [Claude Opus 4.8](https://models.dev/models/anthropic/claude-opus-4-8)anthropic/claude-opus-4-8 | anthropic/claude-opus-4.8 | 1,000,000 | 128,000 | $5.00 / $25.00 | Yes | Yes | - | No |
| [Claude Sonnet 4.6](https://models.dev/models/anthropic/claude-sonnet-4-6)anthropic/claude-sonnet-4-6 | anthropic/claude-sonnet-4.6 | 409,600 | 64,000 | $3.00 / $15.00 | Yes | Yes | - | Yes |
| [DeepSeek V4 Flash](https://models.dev/models/deepseek/deepseek-v4-flash)deepseek/deepseek-v4-flash | deepseek-ai/DeepSeek-V4-Flash | 1,048,575 | 384,000 | $0.112 / $0.224 | Yes | Yes | Yes | Yes |
| [DeepSeek V4 Pro](https://models.dev/models/deepseek/deepseek-v4-pro)deepseek/deepseek-v4-pro | deepseek-ai/DeepSeek-V4-Pro | 1,048,576 | 384,000 | $1.392 / $2.784 | Yes | Yes | Yes | Yes |
| [GLM-5](https://models.dev/models/zhipuai/glm-5)zhipuai/glm-5 | zai-org/GLM-5-FP8 | 202,752 | 131,072 | $0.60 / $1.92 | Yes | Yes | - | Yes |
| [GLM-5.1](https://models.dev/models/zhipuai/glm-5.1)zhipuai/glm-5.1 | zai-org/GLM-5.1-FP8 | 202,752 | 131,072 | $0.98 / $3.08 | Yes | Yes | Yes | Yes |
| [GLM-5.2](https://models.dev/models/zhipuai/glm-5.2)zhipuai/glm-5.2 | zai-org/GLM-5.2-FP8 | 1,000,000 | 131,072 | $0.979 / $3.08 | Yes | Yes | Yes | Yes |
| [GPT-5.5](https://models.dev/models/openai/gpt-5.5)openai/gpt-5.5 | openai/gpt-5.5 | 1,050,000 | 128,000 | $5.00 / $30.00 | Yes | Yes | Yes | Yes |
| [Kimi K2.6](https://models.dev/models/moonshotai/kimi-k2.6)moonshotai/kimi-k2.6 | moonshotai/Kimi-K2.6 | 65,536 | 65,536 | $0.855 / $3.60 | Yes | Yes | Yes | Yes |
| [Kimi K2.7 Code Highspeed](https://models.dev/models/moonshotai/kimi-k2.7-code-highspeed)moonshotai/kimi-k2.7-code-highspeed | moonshotai/kimi-k2.7-code-highspeed | 262,144 | 262,144 | $1.90 / $8.00 | Yes | Yes | Yes | No |
| [MiniMax-M2.7](https://models.dev/models/minimax/MiniMax-M2.7)minimax/MiniMax-M2.7 | MiniMaxAI/MiniMax-M2.7 | 196,608 | 131,072 | $0.30 / $1.20 | Yes | Yes | - | Yes |
| [MiniMax-M3](https://models.dev/models/minimax/MiniMax-M3)minimax/MiniMax-M3 | MiniMaxAI/MiniMax-M3 | 1,048,576 | 512,000 | $0.60 / $2.40 | Yes | Yes | - | Yes |
| [Qwen3.7 Max](https://models.dev/models/alibaba/qwen3.7-max)alibaba/qwen3.7-max | Qwen/Qwen3.7-Max | 1,000,000 | 131,072 | $2.50 / $7.50 | Yes | Yes | - | Yes |
| [Qwen3.8 Flash](https://models.dev/models/alibaba/qwen3.8-flash)alibaba/qwen3.8-flash | Qwen/Qwen3.8-Flash | 1,048,575 | 131,072 | $0.16 / $0.47 | Yes | Yes | Yes | Yes |
| [Qwen3.8 Max](https://models.dev/models/alibaba/qwen3.8-max)alibaba/qwen3.8-max | Qwen/Qwen3.8-Max | 262,144 | 131,072 | $2.00 / $6.00 | Yes | Yes | - | Yes |
| No rows match the current search. |  |  |  |  |  |  |  |  |

No rows match the current search.

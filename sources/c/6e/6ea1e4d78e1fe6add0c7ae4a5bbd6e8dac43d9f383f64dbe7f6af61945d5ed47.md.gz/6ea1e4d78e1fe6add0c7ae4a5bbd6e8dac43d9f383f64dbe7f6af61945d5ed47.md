Virtual Machine Instances OVHcloud

### Virtual Machine Instances

Get versatile instances that can be adapted to suit all your needs.

[Find out more](https://us.ovhcloud.com/public-cloud/virtual-instances/)

### General Purpose

These instances provide you with balanced CPU/RAM resources for development servers, and web or enterprise applications. vCores are clocked at 2 GHz and higher

| Name | Memory | vCore | Storage | Public network | Private network |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| b3-8 | 8 GB | 2 | Local storage low latency ** | 500 Mbit/s | 4 Gbit/s max. | $0.0605 | 12 months plan$37.54 * |
| b3-16 | 16 GB | 4 | Local storage low latency ** | 1 Gbit/s | 4 Gbit/s max. | $0.1208 | 12 months plan$74.96 * |
| b3-32 | 32 GB | 8 | Local storage low latency ** | 2 Gbit/s | 4 Gbit/s max. | $0.2415 | 12 months plan$149.85 * |
| b3-64 | 64 GB | 16 | Local storage low latency ** | 4 Gbit/s | 4 Gbit/s max. | $0.4829 | 12 months plan$299.64 * |
| b3-128 | 128 GB | 32 | Local storage low latency ** | 8 Gbit/s | 8 Gbit/s max. | $0.967 | 12 months plan$600.02 * |
| b3-256 | 256 GB | 64 | Local storage low latency ** | 16 Gbit/s | 16 Gbit/s max. | $1.932 | 12 months plan$1,198.81 * |
| b3-512 | 512 GB | 128 | Local storage low latency ** | 20 Gbit/s | 20 Gbit/s max. | $3.864 | 12 months plan$2,397.61 * |
| b3-640 | 640 GB | 160 | Local storage low latency ** | 20 Gbit/s | 20 Gbit/s max. | $4.829 | 12 months plan$2,996.39 * |
| b2-7 | 7 GB | 2 | 50 GB SSD | 250 Mbit/s guaranteed | 300 Mbit/s max. | $0.0879 | $31.19 |
| b2-15 | 15 GB | 4 | 100 GB SSD | 250 Mbit/s guaranteed | 1 Gbit/s max. | $0.1663 | $59.54 |
| b2-30 | 30 GB | 8 | 200 GB SSD | 500 Mbit/s guaranteed | 2 Gbit/s max. | $0.3364 | $120.49 |
| b2-60 | 60 GB | 16 | 400 GB SSD | 1 Gbit/s guaranteed | 4 Gbit/s max. | $0.652 | $234.6 |
| b2-120 | 120 GB | 32 | 400 GB SSD | 10 Gbit/s | 4 Gbit/s max. | $1.28 | $461.5 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Instances do not include an IPv4 address by default: a public IPv4 address is available as an option, including when it is not attached to an instance. You can view the prices in the Control Panel when you place your order.

The monthly price is estimated based on 730 hours per month for Gen 3 instances (B3, C3, R3).

*Price for a 12 months Savings Plan. The Windows instance rate displayed covers the license price ($0.039 * /vCore/hour). The [Savings Plans page](https://us.ovhcloud.com/public-cloud/savings-plan/).

Local Zone resources are not eligible for Savings Plans.

### Compute Optimized

These instances are perfect for applications that require high-frequency computing, or for parallel processing of workloads. vCores are clocked at 2.3 GHz and higher.

| Name | Memory | vCore | Storage | Public network | Private network |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| c3-4 | 4 GB | 2 | Local storage low latency ** | 250 Mbit/s | 4 Gbit/s max. | $0.054 | 12 months plan$33.51 * |
| c3-8 | 8 GB | 4 | Local storage low latency ** | 500 Mbit/s | 4 Gbit/s max. | $0.1078 | 12 months plan$66.89 * |
| c3-16 | 16 GB | 8 | Local storage low latency ** | 1 Gbit/s | 4 Gbit/s max. | $0.2154 | 12 months plan$133.66 * |
| c3-32 | 32 GB | 16 | Local storage low latency ** | 2 Gbit/s | 4 Gbit/s max. | $0.4307 | 12 months plan$267.25 * |
| c3-64 | 64 GB | 32 | Local storage low latency ** | 4 Gbit/s | 4 Gbit/s max. | $0.8616 | 12 months plan$534.62 * |
| c3-128 | 128 GB | 64 | Local storage low latency ** | 8 Gbit/s | 8 Gbit/s max. | $1.724 | 12 months plan$1,069.74 * |
| c3-256 | 256 GB | 128 | Local storage low latency ** | 20 Gbit/s | 20 Gbit/s max. | $3.447 | 12 months plan$2,138.86 * |
| c3-320 | 320 GB | 160 | Local storage low latency ** | 20 Gbit/s | 20 Gbit/s max. | $4.309 | 12 months plan$2,673.73 * |
| c2-7 | 7 GB | 2 | 50 GB SSD | 250 Mbit/s guaranteed | 300 Mbit/s max. | $0.1262 | $45.36 |
| c2-15 | 15 GB | 4 | 100 GB SSD | 250 Mbit/s guaranteed | 1 Gbit/s max. | $0.2449 | $87.89 |
| c2-30 | 30 GB | 8 | 200 GB SSD | 500 Mbit/s guaranteed | 2 Gbit/s max. | $0.4937 | $177.83 |
| c2-60 | 60 GB | 16 | 400 GB SSD | 1 Gbit/s guaranteed | 4 Gbit/s max. | $0.966 | $348 |
| c2-120 | 120 GB | 32 | 400 GB SSD | 10 Gbit/s | 4 Gbit/s max. | $1.909 | $688.2 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Instances do not include an IPv4 address by default: a public IPv4 address is available as an option, including when it is not attached to an instance. You can view the prices in the Control Panel when you place your order.

The monthly price is estimated based on 730 hours per month for Gen 3 instances (B3, C3, R3).

*Price for a 12 months Savings Plan. The Windows instance rate displayed covers the license price ($0.039 * /vCore/hour). The [Savings Plans page](https://us.ovhcloud.com/public-cloud/savings-plan/).

Local Zone resources are not eligible for Savings Plans.

### Memory Optimized

These instances are designed for data analysis and data science, with optimized CPU/RAM ratios and accelerated IOPS. vCores are clocked at 2 GHz and higher

| Name | Memory | vCore | Storage | Public network | Private network |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r3-16 | 16 GB | 2 | Local storage low latency ** | 500 Mbit/s | 4 Gbit/s max. | $0.0783 | 12 months plan$48.59 * |
| r3-32 | 32 GB | 4 | Local storage low latency ** | 1 Gbit/s | 4 Gbit/s max. | $0.1563 | 12 months plan$96.98 * |
| r3-64 | 64 GB | 8 | Local storage low latency ** | 2 Gbit/s | 4 Gbit/s max. | $0.3125 | 12 months plan$193.91 * |
| r3-128 | 128 GB | 16 | Local storage low latency ** | 4 Gbit/s | 4 Gbit/s max. | $0.626 | 12 months plan$388.43 * |
| r3-256 | 256 GB | 32 | Local storage low latency ** | 8 Gbit/s | 8 Gbit/s max. | $1.25 | 12 months plan$775.63 * |
| r3-512 | 512 GB | 64 | Local storage low latency ** | 20 Gbit/s | 20 Gbit/s max. | $2.5 | 12 months plan$1,551.25 * |
| r3-1024 | 1024 GB | 128 | Local storage low latency ** | 20 Gbit/s | 20 Gbit/s max. | $4.999 | 12 months plan$3,101.88 * |
| r2-15 | 15 GB | 2 | 50 GB SSD | 250 Mbit/s guaranteed | 1 Gbit/s max. | $0.1262 | $45.36 |
| r2-30 | 30 GB | 2 | 50 GB SSD | 250 Mbit/s guaranteed | 1 Gbit/s max. | $0.1458 | $52.45 |
| r2-60 | 60 GB | 4 | 100 GB SSD | 250 Mbit/s guaranteed | 2 Gbit/s max. | $0.2835 | $102.06 |
| r2-120 | 120 GB | 8 | 200 GB SSD | 1 Gbit/s guaranteed | 4 Gbit/s max. | $0.572 | $206.2 |
| r2-240 | 240 GB | 16 | 400 GB SSD | 10 Gbit/s | 4 Gbit/s max. | $1.123 | $404.7 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Instances do not include an IPv4 address by default: a public IPv4 address is available as an option, including when it is not attached to an instance. You can view the prices in the Control Panel when you place your order.

The monthly price is estimated based on 730 hours per month for Gen 3 instances (B3, C3, R3).

*Price for a 12 months Savings Plan. The Windows instance rate displayed covers the license price ($0.039 * /vCore/hour). The [Savings Plans page](https://us.ovhcloud.com/public-cloud/savings-plan/).

Local Zone resources are not eligible for Savings Plans.

### Discovery

Start your Public Cloud journey with instances that have shared resources, delivering stable performance at a very affordable price.

| Name | Memory | vCore | Storage | Public network | Private network |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| d2-2 | 2 GB | 1 | 25 GB | 100 Mbit/s | 100 Mbit/s max. | $0.0129 | $7.08 |
| d2-4 | 4 GB | 2 | 50 GB | 250 Mbit/s | 250 Mbit/s max. | $0.0256 | $14.18 |
| d2-8 | 8 GB | 4 | 50 GB | 500 Mbit/s | 500 Mbit/s max. | $0.0461 | $25.53 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

These instances are perfect for test, development and sandbox environments.

Cloud GPU OVHcloud

### Cloud GPU

Get our most powerful public cloud instances, up to 1,000 times faster than a CPU for parallel processing

[Find out more](https://us.ovhcloud.com/public-cloud/gpu/)

### GPU Instances

These instances offer CPUs with a frequency greater than or equal to 2.2GHz.

Select a location to view the GPU instance prices available there.

| Name | Memory | vCore | GPU | Storage | Public network | Private network |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| rubin-nvl8Coming soon | - | - | 8x GPU Rubin with NVlink | - | 25 Gbit/s | 25 Gbit/s max. | $194.89 | 12 months plan$88,950.50 * |
| l40s-90 | 90 GB | 15 | 1x L40S (48 GB GDDR6) | 400 GB NVMe | 8 Gbit/s | 8 Gbit/s max. | $1.8 | $1,296 |
| l40s-180 | 180 GB | 30 | 2x L40S (48 GB GDDR6) | 400 GB NVMe | 16 Gbit/s | 16 Gbit/s max. | $3.6 | $2,592 |
| l40s-360 | 360 GB | 60 | 4x L40S (48 GB GDDR6) | 400 GB NVMe | 25 Gbit/s | 25 Gbit/s max. | $7.2 | $5,184 |
| l4-90 | 90 GB | 22 | 1x L4 (24 GB GDDR6) | 400 GB NVMe | 8 Gbit/s | 8 Gbit/s max. | $1 | $720 |
| l4-180 | 180 GB | 45 | 2x L4 (24 GB GDDR6) | 400 GB NVMe | 16 Gbit/s | 16 Gbit/s max. | $2 | $1,440 |
| l4-360 | 360 GB | 90 | 4x L4 (24 GB GDDR6) | 400 GB NVMe | 25 Gbit/s | 25 Gbit/s max. | $4 | $2,880 |
| t2-45 | 45 GB | 15 | 1x Tesla V100S (32 GB HBM2) | 400 GB SSD | 2 Gbit/s guaranteed | 4 Gbit/s max. | $0.88 | $639 |
| t2-le-45 | 45 GB | 15 | 1x Tesla V100S (32 GB HBM2) | 300 GB SSD | 2 Gbit/s guaranteed | 4 Gbit/s max. | $0.88 | $630 |
| t2-90 | 90 GB | 30 | 2x Tesla V100S (32 GB HBM2) | 800 GB SSD | 4 Gbit/s guaranteed | 4 Gbit/s max. | $1.76 | $1,270 |
| t2-le-90 | 90 GB | 30 | 2x Tesla V100S (32 GB HBM2) | 500 GB SSD | 4 Gbit/s guaranteed | 4 Gbit/s max. | $1.76 | $1,270 |
| t2-180 | 180 GB | 60 | 4x Tesla V100S (32 GB HBM2) | 50 GB SSD + 2 x 2 TB NVMe | 10 Gbit/s | 4 Gbit/s max. | $3.53 | $2,539 |
| t2-le-180 | 180 GB | 60 | 4x Tesla V100S (32 GB HBM2) | 500 GB SSD | 10 Gbit/s | 4 Gbit/s max. | $3.53 | $2,539 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

NGC integration is up to 1,000 times faster than a CPU on parallel computing, making it easy to use TensorFlow, Caffe, MXNet and much more.

Backup Instance OVHcloud

### Instance Backup

Get a backup service for your instances

| Name |  |  |
| --- | --- | --- |
| Storage replicated x3 |  | $0.0123 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Backup instances are charged according to the space used, with a granularity of 1GB.

For readability, the price is displayed per GB/month, but billing granularity is per GB/hour, based on an average of 730 hours in a month.

virtual server OVHcloud

### Private Image Catalog

Maintain and store customized images of your virtual servers within your private catalog

| Name |  |  |
| --- | --- | --- |
| Storage replicated x3 | $0.000017 | $0.0123 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Private Image Catalog images are charged according to the space used, with a granularity of 1 GB.

Private Network OVHcloud

### Private Network

Deploy private networks, supported by the OVHcloud vRack, to connect your instances across the globe

[Find out more](https://us.ovhcloud.com/public-cloud/private-network/)

| Name | Price |
| --- | --- |
| Incoming traffic | Included |
| Outgoing traffic | Included |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Private networks are free to create and use. Resources within the [Local Zone](https://us.ovhcloud.com/about-us/global-infrastructure/local-zone/) instances can only be interconnected through the private network, with no connectivity to the vRack.

Load Balancer OVHcloud

### Load Balancer

Deploy with cloud automation tools and handle traffic spikes by distributing requests across multiple resources.

[Find out more](https://us.ovhcloud.com/public-cloud/load-balancer/)

| Name | Bandwidth | Connections per second | Requests per second | High Availability | TLS |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Load Balancer S | 200 Mbit/s | 250 | 10000 |  |  | $0.0095 | ~$6.935 |
| Load Balancer M | 500 Mbit/s | 500 | 20000 |  |  | $0.0238 | ~$17.374 |
| Load Balancer L | 2 Gbit/s | 1000 | 40000 |  |  | $0.0633 | ~$46.209 |
| Load Balancer XL | 4 Gbit/s | 2000 | 80000 |  |  | $0.2304 | ~$168.192 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Floating IP OVHcloud

### Floating IP

Expose your services flexibly by assigning a public IP and moving it between instances or services.

[Find out more](https://us.ovhcloud.com/public-cloud/floating-ip/)

| Name |  |  |
| --- | --- | --- |
| Floating IP IPv4 (/32) | $0.00319 | ~$2.3287 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Public IP OVHcloud

### Public IP

Attach a dedicated public IP address to your resources for direct, stable access.

| Name |  |  |
| --- | --- | --- |
| Public IP IPv4 (/32) | $0.00319 | ~$2.3287 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Gateway OVHcloud

### Gateway

Give fully private instances secure internet access, and expose services by combining Gateway with Floating IP and Load Balancer.

[Find out more](https://us.ovhcloud.com/public-cloud/gateway/)

| Name | Public network | High Availability | SNAT (outbound) | Floating IP Support Inbound |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| Gateway S | 200 Mbit/s |  |  |  | $0.0032 | ~$2.336 |
| Gateway M | 500 Mbit/s |  |  |  | $0.0127 | ~$9.271 |
| Gateway L | 2 Gbit/s |  |  |  | $0.0554 | ~$40.442 |
| Gateway XL | 4 Gbit/s |  |  |  | $0.1843 | ~$134.539 |
| Gateway 2XL | 8 Gbit/s |  |  |  | $0.4608 | ~$336.384 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

The gateway requires a Public IPv4.

Instance Public Traffic OVHcloud

### Instance Public Traffic

| Name | Price |
| --- | --- |
| Incoming public traffic | Included |
| Outgoing public traffic | Included |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Outbound public network traffic is included in the price of instances in all locations except the Asia-Pacific region (Singapore, Sydney, and Mumbai). In these three regions, each Public Cloud project includes 1 TB/month of outbound public traffic. Beyond this quota, each additional GB of traffic is charged. Inbound public network traffic is included in all locations.

Block Storage Small OVHcloud

### Block Storage

Create storage volumes, which can be used as additional disks and secured via triple data replication

[Find out more](https://us.ovhcloud.com/public-cloud/block-storage/)

| Volume | Bandwidth | Performance |  |  |
| --- | --- | --- | --- | --- |
| Classic | - | From 500 IOPS | $0.000066 | ~$0.04818 |
| High Speed | - | Up to 3000 IOPS | $0.000132 | ~$0.09636 |
| High Speed Gen2 | 0.5 MB/s/GB up to 512 MB/s * | 30 IOPS/GB up to 20000 IOPS ** | $0.000132 | ~$0.09636 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Volumes are billed according to the selected performance level, duration of use and size provisioned, with a granularity of 1 GB. A volume can be increased at any time.

For readability, the price is displayed per GB/month, but billing granularity is per GB/hour, based on an average of 730 hours in a month.

* Base of 50 MiB/s between 10 GB and 100 GB

** Base of 3000 IOPS between 10 GB and 100 GB

### Volume Snapshot

Trigger a snapshot on your Block Storage volumes.

| Name |  |  |
| --- | --- | --- |
| Storage replicated x3 | $0.000066 | ~$0.04818 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Volume snapshots are charged according to the space used, with a granularity of 1GB.

For readability, the price is displayed per GB/month, but billing granularity is per GB/hour, based on an average of 730 hours in a month.

### Volume Backup

Back up your Block Storage volumes. The backed-up data is stored on our Object Storage service.

| Name |  |  |
| --- | --- | --- |
| Storage replicated x3 | $0.000017 | ~$0.01241 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Volume Backups are charged according to the space used, with a granularity of 1GB.

To ensure optimal readability, the price is displayed per GB/month. However, the granularity of billing is per GB/hour, since each month has an average of 730 hours.

File Storage OVHcloud

### File Storage

Create fully managed file storage volumes, designed for containers and instances.

[Find out more](https://us.ovhcloud.com/public-cloud/file-storage/)

| Volume | Bandwidth | Performance |  |  |
| --- | --- | --- | --- | --- |
| File Storage Standard | 0.25 MB/s/GB up to 128 MB/s maximum per volume | 24 IOPS/GB up to 16000 IOPS per volume | $0.000234 | ~$0.17082 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

### Share Snapshot

Create a snapshot of your File Storage volumes.

| Name |  |  |
| --- | --- | --- |
| Storage replicated x3 | $0.000066 | ~$0.04818 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Share snapshots are billed according to the space used, with a granularity of 1 GB.

To clarify, the price is displayed in GB/month, using an hourly billing rate (GB/hour), based on a monthly average of 730 hours.

Local Storage OVHcloud

### Local Storage

Ephemeral local storage, designed for hot, temporary data directly on your instances.

[Find out more](https://us.ovhcloud.com/public-cloud/virtual-instances/)

| Name | Size | Compatibility | SLA |  |  |
| --- | --- | --- | --- | --- | --- |
| Local Storage NVMe | 1 GB | Gen 3 (B3, C3, R3) | 99.99% | $0.0001721 | ~$0.125633 |
| Local Storage NVMe | 50 GB | Gen 3 (B3, C3, R3) | 99.99% | $0.008605 | ~$6.28165 |
| Local Storage NVMe | 100 GB | Gen 3 (B3, C3, R3) | 99.99% | $0.01721 | ~$12.5633 |
| Local Storage NVMe | 200 GB | Gen 3 (B3, C3, R3) | 99.99% | $0.03442 | ~$25.1266 |
| Local Storage NVMe | 400 GB | Gen 3 (B3, C3, R3) | 99.99% | $0.06884 | ~$50.2532 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB/month estimated based on 730 hours per month

Object Storage OVHcloud

### Object Storage

Get S3-compatible unlimited storage on demand[2]

[Find out more](https://us.ovhcloud.com/public-cloud/object-storage/)

| Offer | Tier | Ingoing/Outgoing internal traffic | Ingoing/Outgoing external traffic |  | API Requests | Minimum storage billed* |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Performance | - | Free | Free | Free | Free | N/A | $0.00002778 | ~$0.0202794 |
| Standard | - | Free | Free | Free | Free | N/A | $0.00001111 | ~$0.0081103 |
| Infrequent Access | - | Free | Free | $0.00436 | Free | 30 days | $0.00000597 | ~$0.0043581 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

1 TiB = 1024 GiB. Object Storage is billed based on the storage space used, with a granularity of 1 GiB.

For optimal readability, the price is displayed as GiB/month – but since there are 730 hours in an average month, the invoicing granularity is GiB/hour.

More details on Object Storage billing in this guide – [FAQs](https://help.ovhcloud.com/csm/en-public-cloud-storage-s3-faq?id=kb_article_view&sysparm_article=KB0059679)

*A minimum storage duration applies to cold storage classes: 730 hours (30 days) for Infrequent Access, 2,190 hours (90 days) for Active Archive and 4,380 hours (180 days) for Cold Archive. If an object is deleted (or moved to another class) before the end of this period, an additional charge will be applied and calculated using the following formula: [minimum storage duration of the storage class in hours − number of hours of storage of the object] × price per hour of the storage class.

### Object Storage - Local Zone

| Offer | Tier | Ingoing/Outgoing internal traffic | Ingoing/Outgoing external traffic |  | API Requests |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Standard | - | Free | Free | Free | Free | $0.00001111 | ~$0.0081103 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

1 TiB = 1024 GiB. Object Storage is billed based on the storage space used, with a granularity of 1 GiB.

For optimal readability, the price is displayed as GiB/month – but since there are 730 hours in an average month, the invoicing granularity is GiB/hour.

More details on Object Storage billing in this guide – [FAQs](https://help.ovhcloud.com/csm/en-public-cloud-storage-s3-faq?id=kb_article_view&sysparm_article=KB0059679)

### Standard object storage (SWIFT)

| Offer | Internal traffic | Incoming public traffic | Outgoing public traffic |  |  |
| --- | --- | --- | --- | --- | --- |
| Standard Object Storage SWIFT | Free | Free | Free | $0.000017 | ~$0.01241 |
| Cloud Archive | Free | $0.0121 /GB | Free | $0.0000033 | ~$0.002409 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Object Storage is charged according to the storage space used with a granularity of 1 GB.

The billing granularity is hourly (per GB/hour). Monthly (per GB/month) pricing under the Monthly payment selection is for convenience and is based on an average of 730 hours per month.

### Cloud Archive

Store your rarely accessed data in a cloud storage space.

Cloud Archive archives are invoiced according to the storage space used, with a granularity of 1 GB.

The billing granularity is hourly (per GB/hour). Monthly (per GB/month) pricing under the Monthly payment selection is for convenience and is based on an average of 730 hours per month.

Managed Kubernetes Service OVHcloud

### Managed Kubernetes Service

Orchestrate your containerized applications with a CNCF-certified Kubernetes cluster

[Find out more](https://us.ovhcloud.com/public-cloud/kubernetes/)

| Name | Service availability | ETCD quota | Max nodes | Price |
| --- | --- | --- | --- | --- |
| Free | 99.5% SLO | 400 MiB | 100 | Included |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

The prices listed only apply to MKS (Managed Kubernetes Service) control planes. Block Storage volumes and Public IP addresses (Floating IPs) used by your Kubernetes nodes on Public Cloud instances are billed individually.

To find out the pricing for each OVHcloud service in your cluster, please refer to its dedicated pricing page.

Managed Private Registry OVHcloud

### Managed Private Registry

Manage a repository for your software building blocks, in the form of Docker images or Helm charts

[Find out more](https://us.ovhcloud.com/public-cloud/managed-private-registry/)

You can migrate from your current plan to a higher level plan at any time. The new limits become effective within a few tens of seconds, with no loss of data and no changes to the configuration required. If you create, modify or remove a service part way through the month, you will be billed only for the actual hours used in your plan. Traffic is unlimited, no matter what its destination.

| Name | Storage | Public network | Concurrent connections | Vulnerability scanning |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| S | 200 GiB | Included | 15 connections (3 x 5)* | - | $0.0317 | ~$23.141 |
| M | 600 GiB | Included | 45 connections (9 x 5)* |  | $0.0721 | ~$52.633 |
| L | 5 TiB | Included | 90 connections (18 x 5)* |  | $0.34 | ~$248.2 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

*Most client software is configured to use five simultaneous http connections when accessing a registry.

Each plan includes a guaranteed level of service, as specified in our public cloud general terms and conditions.

MySQL OVHcloud

### MySQL

Deploy MySQL, the most popular open-source relational database, as a managed service in just a few clicks.

[Find out more](https://us.ovhcloud.com/public-cloud/mysql/)

### Essential Plan - Databases for MySQL

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Essential DB1-4 | From 80 GiB to 240 GiB | 1 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.088 | $0.088 | ~$64.24 |
| Essential DB1-7 | From 160 GiB to 480 GiB | 1 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.1742 | $0.1742 | ~$127.166 |
| Essential DB1-15 | From 320 GiB to 960 GiB | 1 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.3503 | $0.3503 | ~$255.719 |
| Essential DB1-30 | From 640 GiB to 1.875 TiB | 1 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.7041 | $0.7041 | ~$513.993 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0004/hour/node

### Business plan - Databases for MySQL

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Business DB1-4 | From 80 GiB to 240 GiB | 2 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.112 | $0.224 | ~$163.52 |
| Business DB1-7 | From 160 GiB to 480 GiB | 2 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.224 | $0.448 | ~$327.04 |
| Business DB1-15 | From 320 GiB to 960 GiB | 2 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.4481 | $0.8962 | ~$654.226 |
| Business DB1-30 | From 640 GiB to 1.875 TiB | 2 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.8979 | $1.7958 | ~$1,310.934 |
| Business DB1-60 | From 1.25 TiB to 3.75 TiB | 2 | 60 GB | 16 | 1 Gbit/s | 4 Gbit/s | $1.7976 | $3.5952 | ~$2,624.496 |
| Business DB1-120 | From 2.5 TiB to 7.5 TiB | 2 | 120 GB | 32 | 10 Gbit/s | 4 Gbit/s | $3.5971 | $7.1942 | ~$5,251.766 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0006/hour/node

### Enterprise plan - Databases for MySQL

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Enterprise DB1-4 | From 80 GiB to 240 GiB | 3 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.1138 | $0.3414 | ~$249.222 |
| Enterprise DB1-7 | From 160 GiB to 480 GiB | 3 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.224 | $0.672 | ~$490.56 |
| Enterprise DB1-15 | From 320 GiB to 960 GiB | 3 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.4481 | $1.3443 | ~$981.339 |
| Enterprise DB1-30 | From 640 GiB to 1.875 TiB | 3 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.8979 | $2.6937 | ~$1,966.401 |
| Enterprise DB1-60 | From 1.25 TiB to 3.75 TiB | 3 | 60 GB | 16 | 1 Gbit/s | 4 Gbit/s | $1.7976 | $5.3928 | ~$3,936.744 |
| Enterprise DB1-120 | From 2.5 TiB to 7.5 TiB | 3 | 120 GB | 32 | 10 Gbit/s | 4 Gbit/s | $3.5971 | $10.7913 | ~$7,877.649 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0007/hour/node

PostgreSQL OVHcloud

### PostgreSQL

With the PostgreSQL database service, you can create your business applications and migrate your old workloads to the cloud with total confidence.

[Find out more](https://us.ovhcloud.com/public-cloud/postgresql/)

### Essential Plan - Databases for PostgreSQL

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Essential DB1-4 | From 80 GiB to 240 GiB | 1 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.088 | $0.088 | ~$64.24 |
| Essential DB1-7 | From 160 GiB to 480 GiB | 1 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.1742 | $0.1742 | ~$127.166 |
| Essential DB1-15 | From 320 GiB to 960 GiB | 1 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.3503 | $0.3503 | ~$255.719 |
| Essential DB1-30 | From 640 GiB to 1.875 TiB | 1 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.7041 | $0.7041 | ~$513.993 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0004/hour/node

### Business plan - Databases for PostgreSQL

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Business DB1-4 | From 80 GiB to 240 GiB | 2 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.112 | $0.224 | ~$163.52 |
| Business DB1-7 | From 160 GiB to 480 GiB | 2 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.224 | $0.448 | ~$327.04 |
| Business DB1-15 | From 320 GiB to 960 GiB | 2 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.4481 | $0.8962 | ~$654.226 |
| Business DB1-30 | From 640 GiB to 1.875 TiB | 2 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.8979 | $1.7958 | ~$1,310.934 |
| Business DB1-60 | From 1.25 TiB to 3.75 TiB | 2 | 60 GB | 16 | 1 Gbit/s | 4 Gbit/s | $1.7976 | $3.5952 | ~$2,624.496 |
| Business DB1-120 | From 2.5 TiB to 7.5 TiB | 2 | 120 GB | 32 | 10 Gbit/s | 4 Gbit/s | $3.5971 | $7.1942 | ~$5,251.766 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0006/hour/node

### Enterprise plan - Databases for PostgreSQL

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Enterprise DB1-4 | From 80 GiB to 240 GiB | 3 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.1138 | $0.3414 | ~$249.222 |
| Enterprise DB1-7 | From 160 GiB to 480 GiB | 3 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.224 | $0.672 | ~$490.56 |
| Enterprise DB1-15 | From 320 GiB to 960 GiB | 3 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.4481 | $1.3443 | ~$981.339 |
| Enterprise DB1-30 | From 640 GiB to 1.875 TiB | 3 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.8979 | $2.6937 | ~$1,966.401 |
| Enterprise DB1-60 | From 1.25 TiB to 3.75 TiB | 3 | 60 GB | 16 | 1 Gbit/s | 4 Gbit/s | $1.7976 | $5.3928 | ~$3,936.744 |
| Enterprise DB1-120 | From 2.5 TiB to 7.5 TiB | 3 | 120 GB | 32 | 10 Gbit/s | 4 Gbit/s | $3.5971 | $10.7913 | ~$7,877.649 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0007/hour/node

MongoDB OVHcloud

### MongoDB

Try for free and deploy MongoDB, the leading document-oriented NoSQL database, using JSON-like documents with optional schemas.

[Find out more](https://us.ovhcloud.com/public-cloud/mongodb/)

### Production - Databases for MongoDB

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Production DB2-2 | From 10 GiB to 100 GiB | 3 | 2 GB | 1 | 100 Mbit/s | 100 Mbit/s | $0.0261 | $0.0783 | ~$57.159 |
| Production DB2-4 | From 20 GiB to 250 GiB | 3 | 4 GB | 2 | 250 Mbit/s | 250 Mbit/s | $0.0568 | $0.1704 | ~$124.392 |
| Production DB2-7 | From 40 GiB to 500 GiB | 3 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.1227 | $0.3681 | ~$268.713 |
| Production DB2-15 | From 80 GiB to 1000 GiB | 3 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.2438 | $0.7314 | ~$533.922 |
| Production DB2-30 | From 160 GiB to 1.953125 TiB | 3 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.4892 | $1.4676 | ~$1,071.348 |
| Production DB2-60 | From 320 GiB to 3.90625 TiB | 3 | 60 GB | 16 | 1 Gbit/s | 4 Gbit/s | $0.9645 | $2.8935 | ~$2,112.255 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0006/hour/node

Backups, Private Network (vRack), Bandwidth and IOPS provisioning are included in this plan.

### Advanced - Databases for MongoDB

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Advanced DB2-15 | From 80 GiB to 1000 GiB | 3 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.6517 | $1.9551 | ~$1,427.223 |
| Advanced DB2-30 | From 160 GiB to 1.953125 TiB | 3 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $1.2957 | $3.8871 | ~$2,837.583 |
| Advanced DB2-60 | From 320 GiB to 3.90625 TiB | 3 | 60 GB | 16 | 1 Gbit/s | 4 Gbit/s | $2.5836 | $7.7508 | ~$5,658.084 |
| Advanced DB2-120 | From 640 GiB to 3.90625 TiB | 3 | 120 GB | 32 | 10 Gbit/s | 4 Gbit/s | $5.1596 | $15.4788 | ~$11,299.524 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0008/hour/node

Backups, Private Network (vRack), Bandwidth and IOPS provisioning are included in this plan.

Databases for Valkey

### Valkey

Your Valkey-compatible NoSQL in-memory database service, managed by OVHcloud. Boost your apps’ run speed with a high-performance caching solution.

[Find out more](https://us.ovhcloud.com/public-cloud/valkey/)

### Essential Plan - Databases for Valkey

| Service information | Information per node | Total price |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |
| Name | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Essential DB1-4 | 1 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.0764 | $0.0764 | ~$55.772 |
| Essential DB1-7 | 1 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.1547 | $0.1547 | ~$112.931 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

### Business Plan - Databases for Valkey

| Service information | Information per node | Total price |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |
| Name | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Business DB1-4 | 2 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.088 | $0.176 | ~$128.48 |
| Business DB1-7 | 2 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.1956 | $0.3912 | ~$285.576 |
| Business DB1-15 | 2 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.2916 | $0.5832 | ~$425.736 |
| Business DB1-30 | 2 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.5761 | $1.1522 | ~$841.106 |
| Business DB1-60 | 2 | 60 GB | 16 | 1 Gbit/s | 4 Gbit/s | $1.1522 | $2.3044 | ~$1,682.212 |
| Business DB1-120 | 2 | 120 GB | 32 | 10 Gbit/s | 4 Gbit/s | $2.2973 | $4.5946 | ~$3,354.058 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Kafka OVHcloud

### Kafka

Use Kafka, the world’s leading queueing platform, to develop and deploy an event-driven architecture for your applications.

[Find out more](https://us.ovhcloud.com/public-cloud/apache-kafka/)

### Business Plan - Analytics with Kafka

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Business DB1-4 | From 480 GiB to 1.40625 TiB | 3 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.1903 | $0.5709 | ~$416.757 |
| Business DB1-7 | From 960 GiB to 2.8125 TiB | 3 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.377 | $1.131 | ~$825.63 |
| Business DB1-15 | From 1.875 TiB to 5.625 TiB | 3 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.7166 | $2.1498 | ~$1,569.354 |
| Business DB1-30 | From 3.75 TiB to 11.25 TiB | 3 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $1.3869 | $4.1607 | ~$3,037.311 |
| Business DB1-60 | From 7.5 TiB to 22.5 TiB | 3 | 60 GB | 16 | 1 Gbit/s | 4 Gbit/s | $2.7756 | $8.3268 | ~$6,078.564 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0005/hour/node

### Enterprise Plan - Analytics with Kafka

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Enterprise DB1-7 | From 1.875 TiB to 5.625 TiB | 6 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.3787 | $2.2722 | ~$1,658.706 |
| Enterprise DB1-15 | From 3.75 TiB to 11.25 TiB | 6 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.7166 | $4.2996 | ~$3,138.708 |
| Enterprise DB1-30 | From 7.5 TiB to 22.5 TiB | 6 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $1.3869 | $8.3214 | ~$6,074.622 |
| Enterprise DB1-60 | From 15 TiB to 45 TiB | 6 | 60 GB | 16 | 1 Gbit/s | 4 Gbit/s | $2.7756 | $16.6536 | ~$12,157.128 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0005/hour/node

Kafka Connect OVHcloud

### Kafka Connect

Deploy Kafka Connect, an extension that simplifies the ingestion of a wide range of systems and data sources to Apache Kafka®

Kafka Connect requires an additional Apache Kafka service to work.

[Find out more](https://us.ovhcloud.com/public-cloud/kafka-connect/)

### Essential Plan - Analytics with Kafka Connect

| Service information | Information per node | Total price |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |
| Name | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Essential DB1-4 | 1 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.1351 | $0.1351 | ~$98.623 |
| Essential DB1-7 | 1 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.272 | $0.272 | ~$198.56 |
| Essential DB1-15 | 1 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.5068 | $0.5068 | ~$369.964 |
| Essential DB1-30 | 1 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.9175 | $0.9175 | ~$669.775 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

### Business Plan - Analytics with Kafka Connect

| Service information | Information per node | Total price |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |
| Name | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Business DB1-7 | 3 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.272 | $0.816 | ~$595.68 |
| Business DB1-15 | 3 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.521 | $1.563 | ~$1,140.99 |
| Business DB1-30 | 3 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.9175 | $2.7525 | ~$2,009.325 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

### Enterprise Plan - Analytics with Kafka Connect

| Service information | Information per node | Total price |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |
| Name | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Enterprise DB1-7 | 6 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.272 | $1.632 | ~$1,191.36 |
| Enterprise DB1-15 | 6 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.521 | $3.126 | ~$2,281.98 |
| Enterprise DB1-30 | 6 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.9175 | $5.505 | ~$4,018.65 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Kafka MirrorMaker OVHcloud

### Kafka MirrorMaker

Replicate data between your Kafka clusters to guarantee high data availability.

[Find out more](https://us.ovhcloud.com/public-cloud/kafka-mirrormaker/)

### Essential Plan - Analytics with Kafka MirrorMaker

| Service information | Information per node | Total price |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |
| Name | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Essential DB1-4 | 1 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.1351 | $0.1351 | ~$98.623 |
| Essential DB1-7 | 1 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.272 | $0.272 | ~$198.56 |
| Essential DB1-15 | 1 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.5068 | $0.5068 | ~$369.964 |
| Essential DB1-30 | 1 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.9175 | $0.9175 | ~$669.775 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

### Business Plan - Analytics with Kafka MirrorMaker

| Service information | Information per node | Total price |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |
| Name | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Business DB1-4 | 3 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.1369 | $0.4107 | ~$299.811 |
| Business DB1-7 | 3 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.272 | $0.816 | ~$595.68 |
| Business DB1-15 | 3 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.521 | $1.563 | ~$1,140.99 |
| Business DB1-30 | 3 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.9175 | $2.7525 | ~$2,009.325 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

### Enterprise Plan - Analytics with Kafka MirrorMaker

| Service information | Information per node | Total price |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |
| Name | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Enterprise DB1-7 | 6 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.272 | $1.632 | ~$1,191.36 |
| Enterprise DB1-15 | 6 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.521 | $3.126 | ~$2,281.98 |
| Enterprise DB1-30 | 6 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.9175 | $5.505 | ~$4,018.65 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

OpenSearch OVHcloud

### OpenSearch

Deploy and run OpenSearch, the NoSQL engine for indexing, content search, and analytics

[Find out more](https://us.ovhcloud.com/public-cloud/opensearch/)

### Essential Plan - Analytics with OpenSearch

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Essential DB1-4 | From 40 GiB to 120 GiB | 1 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.096 | $0.096 | ~$70.08 |
| Essential DB1-7 | From 80 GiB to 240 GiB | 1 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.1938 | $0.1938 | ~$141.474 |
| Essential DB1-15 | From 160 GiB to 480 GiB | 1 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.3894 | $0.3894 | ~$284.262 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0005/hour/node

### Business Plan - Analytics with OpenSearch

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Business DB1-7 | From 240 GiB to 720 GiB | 3 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.208 | $0.624 | ~$455.52 |
| Business DB1-15 | From 480 GiB to 1.40625 TiB | 3 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.4161 | $1.2483 | ~$911.259 |
| Business DB1-30 | From 960 GiB to 2.8125 TiB | 3 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.8393 | $2.5179 | ~$1,838.067 |
| Business DB1-60 | From 1.875 TiB to 5.625 TiB | 3 | 60 GB | 16 | 1 Gbit/s | 4 Gbit/s | $1.6803 | $5.0409 | ~$3,679.857 |
| Business DB1-120 | From 3.75 TiB to 11.25 TiB | 3 | 120 GB | 32 | 10 Gbit/s | 4 Gbit/s | $3.3695 | $10.1085 | ~$7,379.205 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0006/hour/node

### Enterprise Plan - Analytics with OpenSearch

| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |  |
| Name | Usable storage | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Enterprise DB1-7 | From 480 GiB to 1.40625 TiB | 6 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.2098 | $1.2588 | ~$918.924 |
| Enterprise DB1-15 | From 960 GiB to 2.8125 TiB | 6 | 15 GB | 4 | 250 Mbit/s | 1 Gbit/s | $0.4214 | $2.5284 | ~$1,845.732 |
| Enterprise DB1-30 | From 1.875 TiB to 5.625 TiB | 6 | 30 GB | 8 | 500 Mbit/s | 2 Gbit/s | $0.8446 | $5.0676 | ~$3,699.348 |
| Enterprise DB1-60 | From 3.75 TiB to 11.25 TiB | 6 | 60 GB | 16 | 1 Gbit/s | 4 Gbit/s | $1.6856 | $10.1136 | ~$7,382.928 |
| Enterprise DB1-120 | From 7.5 TiB to 22.5 TiB | 6 | 120 GB | 32 | 10 Gbit/s | 4 Gbit/s | $3.3712 | $20.2272 | ~$14,765.856 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

Price per GB of additional storage:$0.0007/hour/node

Managed Dashboards Grafana OVHcloud

### Managed Dashboards

Generate dashboards and dynamic charts from various sources with the Grafana platform.

[Find out more](https://us.ovhcloud.com/public-cloud/grafana/)

### Essential Plan - Analytics with Grafana

| Service information | Information per node | Total price |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service information | Information per node | Total price |  |  |  |  |  |  |
| Name | Dedicated node(s) | Memory | vCore | Public network | Private network (max) |  |  |  |
| Essential DB1-4 | 1 | 4 GB | 1 | 250 Mbit/s | 250 Mbit/s | $0.0764 | $0.0764 | ~$55.772 |
| Essential DB1-7 | 1 | 7 GB | 2 | 250 Mbit/s | 300 Mbit/s | $0.1547 | $0.1547 | ~$112.931 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

AI Notebooks OVHcloud

### AI Notebooks

Get a quick, simple start launching your Jupyter or VS Code notebooks in the cloud

[Find out more](https://us.ovhcloud.com/public-cloud/ai-notebooks/)

### CPUs

AI Notebooks is a pay-as-you-go solution. You only pay for the notebooks that are currently running, and the price depends on the CPU and GPU computing resources you choose. With our pricing system, you can start a notebook for a few cents per day.

OVHcloud includes 10GB of AI Notebooks workspace. After 30 consecutive days of storage and/or exceeding this quota by 10GB, the prices applied will be those for Public Cloud Object Storage.

Get guaranteed CPU resources for basic test, pre-production and machine learning phases. You can deploy up to 12 resource units per notebook. Object Storage is unlimited.

### GPUs

Set up GPU resources for all of your AI training and deep learning needs, which are resource-intensive in terms of computing power.

You can deploy up to 8 resource units per notebook or training task. Object Storage is unlimited.

| Node | Memory | vCore | GPU | Ephemeral local storage | Public network |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ai1-1-cpu | 4 GB | 1 | - | 40 GiB | 500 Mbit/s | $0.04 | ~$29.2 |
| l4-1-gpu | 80 GB | 20 | NVIDIA Ada Lovelace L4 24 GiB 30.3 TFLOPS | 500 GiB | 5 Gbit/s | $0.91 | ~$664.3 |
| l40s-1-gpu | 80 GB | 13 | NVIDIA Ada Lovelace L40S 48 GiB 91.6 TFLOPS | 1536 GiB | 5 Gbit/s | $1.69 | ~$1,233.7 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

The hourly billing rate is listed, so that it is easier to read and calculate prices.

The pricing includes computing power, excluding:

- Private registry costs to host container images deployed on your cluster (this service is billed as described in the “Containers and orchestration” section).
- the storage costs for your data.

AI training OVHcloud

### AI Training

Train your AI, machine learning and deep learning models efficiently and easily, and optimize your GPU usage.

[Find out more](https://us.ovhcloud.com/public-cloud/ai-training/)

### CPUs

For each training task you launch, you pay for the computing resources used, depending on their lifespan and power.

AI Training is based on a Docker image, so you may need to containerize your training process. A catalog of public images is available for Jupyter Notebook, TensorFlow, MXNet, PyTorch, FastAI and much more. These images do not require any specialized containerization skills.

You can manage your data directly via the OVHcloud Control Panel, or via the command line (object storage).

Get guaranteed CPU resources that are adapted to your test, pre-production and even basic machine learning phases.

Deploy up to 12 resource units per notebook or training job. Object Storage is unlimited.

### GPUs

Deploy GPU resources for all of your AI training and deep learning use cases, which require intensive processing.

Deploy up to 8 resource units per notebook or training task. Object Storage is unlimited.

| Node | Memory | vCore | GPU | Ephemeral local storage | Public network |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ai1-1-cpu | 4 GB | 1 | - | 40 GiB | 500 Mbit/s | $0.04 | ~$29.2 |
| l4-1-gpu | 80 GB | 20 | NVIDIA Ada Lovelace L4 24 GiB 30.3 TFLOPS | 500 GiB | 5 Gbit/s | $0.91 | ~$664.3 |
| l40s-1-gpu | 80 GB | 13 | NVIDIA Ada Lovelace L40S 48 GiB 91.6 TFLOPS | 1536 GiB | 5 Gbit/s | $1.69 | ~$1,233.7 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

For simplification purposes, the price displayed is per hour.

The pricing includes computing power, excluding:

- container registry costs to host container images deployed on your cluster (this service is billed as described in the “Container and Orchestration” section)
- the storage costs for your data.

AI Deploy OVHcloud

### AI Deploy

Easily deploy machine learning models and applications to production, create your API access points effortlessly, and make effective predictions.

[Find out more](https://us.ovhcloud.com/public-cloud/ai-deploy/)

### CPUs

AI Deploy deploys your applications or models via Docker on a cluster, which then boots computing nodes (called replicas). Each deployment is defined by a minimum and maximum number of nodes, which you choose. Each node you launch is billed depending on its lifespan and power. The cluster will meet all your specifications, whether it is fixed or adapts automatically to the workload.

To deploy a model into production, you can get a price estimate in the OVHcloud Control Panel. You have an unlimited number of deployment requests.

Get guaranteed CPU resources that are adapted to your test, pre-production and even basic machine learning phases.

Deploy up to 12 resource units per node. Object Storage is unlimited.

### GPUs

Deploy GPU resources for all of your use cases that require intensive processing, such as AI training and deep learning.

Deploy up to 8 resource units per node. Object Storage is unlimited.

| Node | Memory | vCore | GPU | Ephemeral local storage | Public network |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ai1-1-cpu | 4 GB | 1 | - | 40 GiB | 500 Mbit/s | $0.04 | ~$29.2 |
| l4-1-gpu | 80 GB | 20 | NVIDIA Ada Lovelace L4 24 GiB 30.3 TFLOPS | 500 GiB | 5 Gbit/s | $0.91 | ~$664.3 |
| l40s-1-gpu | 80 GB | 13 | NVIDIA Ada Lovelace L40S 48 GiB 91.6 TFLOPS | 1536 GiB | 5 Gbit/s | $1.69 | ~$1,233.7 |

[Start](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

For simplicity, the price displayed is the hourly price.

Rates include computing power, with the exception of:

- Container registry costs to host images of containers deployed on your cluster. This service is billed in accordance with the conditions listed in the “Containers & Orchestration” section.
- the storage costs for your data.

**Third-party software and services**

Some deployments may offer third-party software and services. Their pricing and usage conditions are available to view during deployment.

## Pricing model

All Public Cloud services are billed based on usage: you only pay for the resources you consume, for the time you actually use them.

You can start and stop your resources at any time, according to your needs, to optimise your consumption.

Most Public Cloud services are billed per second, with a minimum billing duration of one minute per resource. Each month, a single invoice summarises all your usage over the period concerned.

For more information, please refer to the [Public Cloud services Specific Terms and Conditions](https://us.ovhcloud.com/terms-and-conditions/contracts/).

## Ready to get started?

Create an account and launch your services in minutes

[Get started](https://us.ovhcloud.com/auth/?onsuccess=https%3A%2F%2Fconsole.us.ovhcloud.com%2F%23%2Fpublic-cloud%3Fcontext%3Dwebsite%26voucher%3DFREETRIAL&ovhSubsidiary=US)

1 Customers are eligible to receive up to $300.00 (USD) in Public Cloud credits ("Public Cloud Credits") when creating their first Public Cloud infrastructure project and purchasing their first Managed Databases service with OVHcloud US. Customers will receive $200.00 (USD) in Public Cloud Credits when creating their first Public Cloud infrastructure project. An additional $100.00 (USD) in Public Cloud Credits will be applied when customers purchase their first Managed Databases service for use on Public Cloud. Offer applies only to Public Cloud services purchased from OVHcloud datacenters in the United States. Offer available only to customers who, at the time when the Public Cloud Credits are applied, are not purchasing Public Cloud services from OVHcloud and who purchase at least $0.99 (USD) of Public Cloud services from OVHcloud. No code is required. The Public Cloud Credits will be added to eligible accounts within 30 days of OVHcloud’s receipt of the $0.99 for a customer’s purchase of Public Cloud services. The Public Cloud Credits are valid for 90 days from the day the credit has been applied. The time of order placement shall be determined by OVHcloud’s time of registering the corresponding order. Offer is subject to availability. The Public Cloud Credits will automatically be applied to a customer’s next bill(s) up to a maximum amount of $300.00. Any unused portion of the Public Cloud Credits will expire. The Public Cloud Credits cannot be exchanged or refunded for cash or other credits, and may not be transferred. Once the Public Cloud Credits are exhausted or expired, the customer’s account will be debited in accordance with OVHcloud’s billing guide. Void where prohibited.

2 S3 is a trademark filed by Amazon Technologies, Inc. OVHcloud's service is not sponsored by, endorsed by, or otherwise affiliated with Amazon Technologies, Inc.

AWS Free Tier

* Overview
* Free Tier Categories
* Featured Offers for Business
* Terms and Conditions
* More

# Create an account on AWS today

AWS has the services to help you build applications with increased flexibility, scalability, and reliability.

Create an AWS Account

## How to create an AWS account in 3 steps

Sign up with your existing GitHub, Google, Amazon, or Apple account. Connect your coding agent with a single prompt. Start building with up to $200 in AWS Free Tier credits as a new customer.

### 

Go to the sign-up page and choose a sign-up method.

### 

Enter your name, verify your email with a one-time code, create a password, and provide your contact information.

### 

AWS provisions your first project for you. You're in the console and ready to build.   
  
Create account | Learn more

## What happens next

Once you're signed up, you can:

* Connect an AI coding tool like Cursor, Kiro, or Claude Code with one prompt
* Invite team members to collaborate in AWS Settings
* Create a spend limit for your project in AWS Settings when you upgrade to a paid account
* Activate advanced features as your workload evolves

## Need advanced AWS features?

If you have regulated workloads or need full control over how your account is configured, where your workload runs, or access to all AWS services, sign up for the advanced experience.   
  
Compare signup options

Learn more about advanced signup

* Sign up, Features, Activation

  7

## FAQS

### Sign up, Features, Activation

Open all

#### 

Sign up for AWS (new) is for new users who want to start building quickly with preconfigured defaults, a login they already own, and spend limits. No credit card is required for most new customers to get started. Sign up for AWS (advanced) is for users who need complete control over account configuration, access to the full AWS service catalog, or have regulated workloads like HIPAA or FedRAMP. Compare sign-up options.

#### 

Sign up for AWS (new) is the right sign-up option for most new users. Your account comes with preconfigured defaults so you can start building right away, without configuring permissions. Choose Sign up for AWS (advanced) if you need fine-grained control over your users or role-based permissions, net terms billing, regulated workloads like HIPAA or FedRAMP, or access to the full set of AWS services. If you start with Sign up for AWS (new), you can activate advanced features at any time.

#### 

Yes. You can activate advanced features at any time from AWS Settings, with no migration or downtime required. Your existing projects and resources stay intact. You must be on the Paid plan to activate advanced features. Learn more about activating advanced features.

#### 

With Sign up for AWS (new), most new customers will not be required to provide a payment method to get started. In some cases, we may ask for additional verification to protect your account. In addition, when you sign up for AWS, you might be ineligible for the free plan or Free Tier credits if you have an existing AWS account or have had one in the past. The Free plan and Free Tier credits are available only to new AWS customers. If you are ineligible for the Free Tier or Free plan, you'll need to provide payment information, and you'll be placed on the Paid plan.

#### 

As part of our commitment to keeping AWS accounts secure, we occasionally request additional information, like a payment method, during sign-up. This is a routine security measure. Our verification process holds USD $1 (or equivalent) for 3-5 days to verify your account and help prevent fraud; however, your card will not be charged, and you will not incur any costs as long as you remain on the Free plan.

#### 

The AWS Free Tier program allows new customers to explore AWS services at no cost for up to 6 months. New customers receive up to $200 in AWS credits—$100 upon sign-up and up to $100 more as you explore foundational AWS services. The AWS Free Tier program is available to all new customers—students, entrepreneurs, and small businesses are all welcome to sign up online. Learn more.

#### 

Activating advanced features unlocks the full AWS service catalog including multiple regions, enterprise services, and AWS Organizations. It's free to activate, requires no migration, and causes no downtime. Learn more about activating advanced features.
The Trove Application Programming Interface (API) allows you to build a complex search query and then delivers it in a machine-readable form, enabling you to develop new applications, tools and interfaces.

Check out [What is the Trove API?](https://trove.nla.gov.au/about/create-something/using-the-api/what-is-the-trove-api) for more information about the types of data available and what it can be used for.

There are four steps to get started with the Trove API:

1. Agree to the Trove API terms of use

1. Get an API key

1. The application process

1. Begin using the Trove API

## 1. Access and Terms of Use

On-going use of the Trove API will require an active API key.

By using any Trove API functionality, you agree to the [Trove API Terms of Use](https://trove.nla.gov.au/about/create-something/using-api/trove-api-terms-use).

## 2. Get an API key

You will need a Trove account to receive a Trove API key. If you don't already have a Trove account, it's easy to [sign up](https://login.nla.gov.au/new/realms/troveservices/protocol/openid-connect/registrations?client_id=trove&response_type=code&redirect_uri=https%3A%2F%2Ftrove.nla.gov.au%2Fabout%2Fcreate-something%2Fusing-api).

Once you have a Trove account, complete the [Request a Trove API key form](https://librariesaustraliaref.nla.gov.au/reft100.aspx?key=TroveAPIKey) to apply for a Trove API key. This form is also available in your Trove account by selecting your profile and then the ‘Trove API’ tab.

In the form you will need to tell us:

- your Trove username and other contact details

- the rate of calls you require

- why you are requesting access to the Trove API key

- how you will use the Trove API

- that you have read and agreed to our Terms of Use

- if you require an exemption to the Trove API Terms of Use

Please have these details ready as the form will time out after 20 minutes. If you have any questions about how to request an API key, please [contact us](https://trove.nla.gov.au/about/contact-us).

## 3. The application process

Once you have submitted your application, we will review the form to determine the level of review. Information about the levels of review is available in Table 1.

Most requests will be answered within a week, however complex enquiries or those that need higher review may take longer.

Table 1: Trove API application review levels

| Level of Review | Call rate | Reason for Accessing API | Intended Use of API | Exemption Required? |
| --- | --- | --- | --- | --- |
| Technical | Custom |  |  | N |
| Level 1 | 200m | Personal use Education or Training Academic Research To create something for a library or cultural institution To create something for an Australian Government organisation | Develop a new application or research tool Link Trove search results to another website Teach, demonstrate or learn about API capabilities Bulk download of search results Download metadata for analyses or research Cross-reference Trove records with another institution’s holdings | N |
| Level 2 | 200m | Private employment – Non-commercial use Non-Commercial websites Other responses | Use with existing applications or research tools (please specify) Other responses | N |
| Level 3 | 200m | Commercial websites Private employment – Commercial use | Downloading/harvesting full-text records AI modelling/Machine learning | Y |
| Level 4 | 200m |  | Training generative AI | Y |
| No approval |  |  | Creating backlinks to other sites Advertising products or services | n/a |

For transparency and guidance, we have outlined what we will be looking for at each of the different review levels in Table 2.

Table 2: Review focus for each level of Trove API application review.

| Level of Review | Review focus |
| --- | --- |
| Technical | Does the requested call rate pose any technical risks? |
| Level 1 | Is the form complete? Do they agree to the Trove API Terms of Use? |
| Level 2 | Does the stated use align with the Trove API Terms of Use? Have they provided sufficient detail about their intended use? Are they working with applications or research tools that draw on metadata rather than full text? Does the stated use match non-commercial use? Do any of the responses contradict each other or require further investigation? |
| Level 3 | Have they requested an exemption to the Trove API Terms of Use? If no, does their stated use align with the Trove API Terms of Use? If yes, have they provided sufficient justification for an exemption? Is it research? (and what kind/level) Have they detailed the project? Can the project be done without an exemption? Is there a data sharing agreement in place? Will any commercial use of the Trove API acknowledge Trove and the NLA? Has the application indicated that it will be accessing content that is still in copyright? |
| Level 4 | What are the benefits or positive outcomes of the project for the Australian public? Does the stated use pose a reputational risk to the library? Factors to consider include the probability of: ICIP, copyright, moral rights or infringements; potential of hate speech or other harms or potential to deliberately mislead the public. Is the user intending to use the API to access material that is in copyright? Does the stated use oppose our obligations as collection custodians? Does the stated use align with the Library’s AI framework? Is there a data sharing agreement in place? |

Uses of the Trove API that require higher review may require a data sharing agreement between you or your organisation and the National Library of Australia.

If you would like to dispute a decision, you can reopen your application enquiry, and it will be escalated to the next level of review. You may be asked to provide additional information.

## 4. Begin using the Trove API

Once we have generated an API key, you're ready to get started.

You can find your Trove API key, your rate of calls and other details about your access to the Trove API in your Trove account. To access:

- Log in to your Trove Account and click on your username

- Select 'My Profile'

- Select the 'Trove API' tab

The [Trove API version 3.0](https://api.trove.nla.gov.au/v3/) has a handy interface to assist you in building your first search query. You can start experimenting with the search parameters available in each field.

Be sure to check out the [API v3 technical guide](https://trove.nla.gov.au/node/53198) for detailed assistance.

#### Trove API versions

##### v3.0

We have released the Trove API version 3.0, which received[investment from the Australian Research Data Commons (ARDC)](http://doi.org/10.47486/hir008). The [ARDC](https://ardc.edu.au/)is funded by the [National Collaborative Research Infrastructure Strategy (NCRIS)](https://www.education.gov.au/ncris).

Version 2.0 was discontinued in September 2024. This [introduction](https://trove.nla.gov.au/sites/default/files/attachments/2023-07/Introducing%20Trove%20API%20v3%20-%20Release%203%20updated.pdf)(PDF:231KB) outlines what we changed in the Trove API v3 and why. If you have any feedback on v3.0, please [contact us](https://trove.nla.gov.au/about/contact-us).

##### Share it

We would love to hear how you've used the API to create something, so feel free to share your creation or research with us. [Contact us](https://trove.nla.gov.au/about/contact-us), or share with us on [Twitter](https://twitter.com/TroveAustralia) or [Facebook](https://www.facebook.com/TroveAustralia).

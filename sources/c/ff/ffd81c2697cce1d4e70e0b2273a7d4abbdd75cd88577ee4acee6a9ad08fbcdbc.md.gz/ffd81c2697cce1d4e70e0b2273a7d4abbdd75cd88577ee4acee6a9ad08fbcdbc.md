
Docs

# Docs

Get started

Collapse sidebar

[Run a model from Node.js](https://replicate.com/docs/get-started/nodejs)

[Run a model from Google Colab](https://replicate.com/docs/get-started/google-colab)

[Run a model from Python](https://replicate.com/docs/get-started/python)

[Fine-tune an image model](https://replicate.com/docs/get-started/fine-tune-with-flux)

[Deploy a custom model](https://replicate.com/docs/get-started/deploy-a-custom-model)

Guides

Run models

[Build a website with vinext](https://replicate.com/docs/guides/run/vinext)

[Build a website with Next.js](https://replicate.com/docs/guides/run/nextjs)

[Build a Discord bot with Python](https://replicate.com/docs/guides/run/discord-bot)

[Build an app with SwiftUI](https://replicate.com/docs/guides/run/swiftui)

[Make art with Stable Diffusion](https://replicate.com/docs/guides/run/make-art-with-stable-diffusion)

[Upscale images with AI models](https://replicate.com/docs/guides/run/upscale-images-with-ai-models)

Build models

[Publish using GitHub Actions](https://replicate.com/docs/guides/build/push-a-model-using-github-actions)

[Set up a CI/CD pipeline](https://replicate.com/docs/guides/build/continuous-model-deployment)

[Push your own model](https://replicate.com/docs/guides/build/push-a-model)

[Push a Transformers model](https://replicate.com/docs/guides/build/push-a-transformers-model)

[Push a Diffusers model](https://replicate.com/docs/guides/build/push-a-diffusers-model)

[Optimize models with Pruna](https://replicate.com/docs/guides/build/optimize-models-with-pruna)

[Get a GPU on Brev](https://replicate.com/docs/guides/build/get-a-gpu-on-brev)

[Get a GPU on Lambda Labs](https://replicate.com/docs/guides/build/get-a-gpu-on-lambda-labs)

[Best practices for Replicate models](https://replicate.com/docs/guides/build/model-best-practices)

[Optimize with torch.compile](https://replicate.com/docs/guides/build/torch-compile)

Go deeper

[Cache images with Cloudflare](https://replicate.com/docs/guides/extend/cloudflare-image-cache)

[Get started with ComfyUI](https://replicate.com/docs/guides/extend/comfyui)

[Use realtime speech with OpenAI](https://replicate.com/docs/guides/extend/openai-realtime)

[Handle webhooks with Val Town](https://replicate.com/docs/guides/extend/build-a-webhook-notifier-with-val-town)

[Working with LoRAs](https://replicate.com/docs/guides/extend/working-with-loras)

Topics

Models

[About models](https://replicate.com/docs/topics/models)

[Run a model](https://replicate.com/docs/topics/models/run-a-model)

[Create a model](https://replicate.com/docs/topics/models/create-a-model)

[Publish a model](https://replicate.com/docs/topics/models/publish-a-model)

[Model versions](https://replicate.com/docs/topics/models/versions)

[Model hardware](https://replicate.com/docs/topics/models/hardware)

[Official models](https://replicate.com/docs/topics/models/official-models)

[Community models](https://replicate.com/docs/topics/models/community-models)

[Private and public models](https://replicate.com/docs/topics/models/private-models)

[Training destinations](https://replicate.com/docs/topics/models/models-as-training-destinations)

[Delete a model](https://replicate.com/docs/topics/models/delete-a-model)

[Secrets](https://replicate.com/docs/topics/models/secrets)

Predictions

[About predictions](https://replicate.com/docs/topics/predictions)

[Create a prediction](https://replicate.com/docs/topics/predictions/create-a-prediction)

[Input files](https://replicate.com/docs/topics/predictions/input-files)

[Output files](https://replicate.com/docs/topics/predictions/output-files)

[Prediction lifecycle](https://replicate.com/docs/topics/predictions/lifecycle)

[Share a prediction](https://replicate.com/docs/topics/predictions/share-a-prediction)

[Rate limits](https://replicate.com/docs/topics/predictions/rate-limits)

[Safety checking](https://replicate.com/docs/topics/predictions/safety-checking)

[Data retention](https://replicate.com/docs/topics/predictions/data-retention)

[Secrets](https://replicate.com/docs/topics/predictions/secrets)

[Streaming output](https://replicate.com/docs/topics/predictions/streaming)

Deployments

[About deployments](https://replicate.com/docs/topics/deployments)

[Create a deployment](https://replicate.com/docs/topics/deployments/create-a-deployment)

[View deployments](https://replicate.com/docs/topics/deployments/view-deployments)

[Monitor a deployment](https://replicate.com/docs/topics/deployments/monitor-a-deployment)

[Delete a deployment](https://replicate.com/docs/topics/deployments/delete-a-deployment)

Webhooks

[About webhooks](https://replicate.com/docs/topics/webhooks)

[Set up webhooks](https://replicate.com/docs/topics/webhooks/setup-webhook)

[Receive webhooks](https://replicate.com/docs/topics/webhooks/receive-webhook)

[Verify webhooks](https://replicate.com/docs/topics/webhooks/verify-webhook)

[Test your webhook code](https://replicate.com/docs/topics/webhooks/testing-webhook-code)

Organizations

[About organizations](https://replicate.com/docs/topics/organizations)

Security

[API tokens](https://replicate.com/docs/topics/security/api-tokens)

Billing

[About billing](https://replicate.com/docs/topics/billing)

[Prepaid credit](https://replicate.com/docs/topics/billing/prepaid-credit)

Site policy

[About subprocessors](https://replicate.com/docs/topics/site-policy/subprocessors)

Reference

[How does Replicate work?](https://replicate.com/docs/reference/how-does-replicate-work)

[Agent skills](https://replicate.com/docs/reference/skills)

[MCP server](https://replicate.com/docs/reference/mcp)

[Client libraries](https://replicate.com/docs/reference/client-libraries)

[HTTP API](https://replicate.com/docs/reference/http)

[OpenAPI schema](https://replicate.com/docs/reference/openapi)

[llms.txt](https://replicate.com/docs/reference/llms-txt)

[Error codes](https://replicate.com/docs/reference/error-codes)

[Open source](https://replicate.com/docs/reference/open-source)

Search documentation

Get started

Collapse sidebar

[Run a model from Node.js](https://replicate.com/docs/get-started/nodejs)

[Run a model from Google Colab](https://replicate.com/docs/get-started/google-colab)

[Run a model from Python](https://replicate.com/docs/get-started/python)

[Fine-tune an image model](https://replicate.com/docs/get-started/fine-tune-with-flux)

[Deploy a custom model](https://replicate.com/docs/get-started/deploy-a-custom-model)

Guides

Run models

[Build a website with vinext](https://replicate.com/docs/guides/run/vinext)

[Build a website with Next.js](https://replicate.com/docs/guides/run/nextjs)

[Build a Discord bot with Python](https://replicate.com/docs/guides/run/discord-bot)

[Build an app with SwiftUI](https://replicate.com/docs/guides/run/swiftui)

[Make art with Stable Diffusion](https://replicate.com/docs/guides/run/make-art-with-stable-diffusion)

[Upscale images with AI models](https://replicate.com/docs/guides/run/upscale-images-with-ai-models)

Build models

[Publish using GitHub Actions](https://replicate.com/docs/guides/build/push-a-model-using-github-actions)

[Set up a CI/CD pipeline](https://replicate.com/docs/guides/build/continuous-model-deployment)

[Push your own model](https://replicate.com/docs/guides/build/push-a-model)

[Push a Transformers model](https://replicate.com/docs/guides/build/push-a-transformers-model)

[Push a Diffusers model](https://replicate.com/docs/guides/build/push-a-diffusers-model)

[Optimize models with Pruna](https://replicate.com/docs/guides/build/optimize-models-with-pruna)

[Get a GPU on Brev](https://replicate.com/docs/guides/build/get-a-gpu-on-brev)

[Get a GPU on Lambda Labs](https://replicate.com/docs/guides/build/get-a-gpu-on-lambda-labs)

[Best practices for Replicate models](https://replicate.com/docs/guides/build/model-best-practices)

[Optimize with torch.compile](https://replicate.com/docs/guides/build/torch-compile)

Go deeper

[Cache images with Cloudflare](https://replicate.com/docs/guides/extend/cloudflare-image-cache)

[Get started with ComfyUI](https://replicate.com/docs/guides/extend/comfyui)

[Use realtime speech with OpenAI](https://replicate.com/docs/guides/extend/openai-realtime)

[Handle webhooks with Val Town](https://replicate.com/docs/guides/extend/build-a-webhook-notifier-with-val-town)

[Working with LoRAs](https://replicate.com/docs/guides/extend/working-with-loras)

Topics

Models

[About models](https://replicate.com/docs/topics/models)

[Run a model](https://replicate.com/docs/topics/models/run-a-model)

[Create a model](https://replicate.com/docs/topics/models/create-a-model)

[Publish a model](https://replicate.com/docs/topics/models/publish-a-model)

[Model versions](https://replicate.com/docs/topics/models/versions)

[Model hardware](https://replicate.com/docs/topics/models/hardware)

[Official models](https://replicate.com/docs/topics/models/official-models)

[Community models](https://replicate.com/docs/topics/models/community-models)

[Private and public models](https://replicate.com/docs/topics/models/private-models)

[Training destinations](https://replicate.com/docs/topics/models/models-as-training-destinations)

[Delete a model](https://replicate.com/docs/topics/models/delete-a-model)

[Secrets](https://replicate.com/docs/topics/models/secrets)

Predictions

[About predictions](https://replicate.com/docs/topics/predictions)

[Create a prediction](https://replicate.com/docs/topics/predictions/create-a-prediction)

[Input files](https://replicate.com/docs/topics/predictions/input-files)

[Output files](https://replicate.com/docs/topics/predictions/output-files)

[Prediction lifecycle](https://replicate.com/docs/topics/predictions/lifecycle)

[Share a prediction](https://replicate.com/docs/topics/predictions/share-a-prediction)

[Rate limits](https://replicate.com/docs/topics/predictions/rate-limits)

[Safety checking](https://replicate.com/docs/topics/predictions/safety-checking)

[Data retention](https://replicate.com/docs/topics/predictions/data-retention)

[Secrets](https://replicate.com/docs/topics/predictions/secrets)

[Streaming output](https://replicate.com/docs/topics/predictions/streaming)

Deployments

[About deployments](https://replicate.com/docs/topics/deployments)

[Create a deployment](https://replicate.com/docs/topics/deployments/create-a-deployment)

[View deployments](https://replicate.com/docs/topics/deployments/view-deployments)

[Monitor a deployment](https://replicate.com/docs/topics/deployments/monitor-a-deployment)

[Delete a deployment](https://replicate.com/docs/topics/deployments/delete-a-deployment)

Webhooks

[About webhooks](https://replicate.com/docs/topics/webhooks)

[Set up webhooks](https://replicate.com/docs/topics/webhooks/setup-webhook)

[Receive webhooks](https://replicate.com/docs/topics/webhooks/receive-webhook)

[Verify webhooks](https://replicate.com/docs/topics/webhooks/verify-webhook)

[Test your webhook code](https://replicate.com/docs/topics/webhooks/testing-webhook-code)

Organizations

[About organizations](https://replicate.com/docs/topics/organizations)

Security

[API tokens](https://replicate.com/docs/topics/security/api-tokens)

Billing

[About billing](https://replicate.com/docs/topics/billing)

[Prepaid credit](https://replicate.com/docs/topics/billing/prepaid-credit)

Site policy

[About subprocessors](https://replicate.com/docs/topics/site-policy/subprocessors)

Reference

[How does Replicate work?](https://replicate.com/docs/reference/how-does-replicate-work)

[Agent skills](https://replicate.com/docs/reference/skills)

[MCP server](https://replicate.com/docs/reference/mcp)

[Client libraries](https://replicate.com/docs/reference/client-libraries)

[HTTP API](https://replicate.com/docs/reference/http)

[OpenAPI schema](https://replicate.com/docs/reference/openapi)

[llms.txt](https://replicate.com/docs/reference/llms-txt)

[Error codes](https://replicate.com/docs/reference/error-codes)

[Open source](https://replicate.com/docs/reference/open-source)

Close

Popular searches on Replicate

- [Run a model from Node.js](https://replicate.com/docs/get-started/nodejs)
- [Deploy a custom model](https://replicate.com/docs/guides/deploy-a-custom-model)
- [How does Replicate work?](https://replicate.com/docs/reference/how-does-replicate-work)

Showing results

Some models accept files as input, like images, audio, or video, zip files, PDFs, etc.

There are multiple ways to use files as input when running a model on Replicate. You can provide a file as input using a URL, a local file on your computer, or a base64-encoded object.

## Anchor for option-1-hosted-fileOption 1: Hosted file

Use a URL to provide a hosted file:

This is useful if you already have a file hosted somewhere on the internet.

## Anchor for option-2-local-fileOption 2: Local file

You can provide Replicate with a `Blob`, `File`, or `Buffer` object, and the library will handle the upload for you. This will work for files up to 100MB:

## Anchor for option-3-data-uriOption 3: Data URI

Create a data URI consisting of the base64 encoded data for your file. This is only recommended if the file is less than 1MB:

## Anchor for using-the-file-inputUsing the file input

Once you have your file input ready, you can use it in your prediction:

[Next: Output files](https://replicate.com/docs/topics/predictions/output-files)
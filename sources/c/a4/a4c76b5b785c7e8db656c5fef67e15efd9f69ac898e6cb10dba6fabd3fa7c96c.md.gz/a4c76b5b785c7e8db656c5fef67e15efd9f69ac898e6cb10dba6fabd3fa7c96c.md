# Pricing

free

Explore Gel Cloud for free.

$0 /month

- 1/4 compute unit (1/2 GiB RAM, 1/16 vCPU)
- Up to 1GB of disk space
- Data encrypted at rest
- Community support

pro

Tailor Gel Cloud to your needs. Too expensive?

Starts at $19.50 /month

1/2 compute units (1 GiB RAM, 1/8 vCPU)

- 10GiB of storage ($0.50/GiB afterwards)
- 100GiB of transfer ($0.10/GiB afterwards)
- Unlimited number of reads/writes
- Email support

enterprise

A completely custom Cloud experience.

Custom pricing

- Priority support
- Deploy in your AWS account
- Custom contracts
- Custom pricing based on requirements
- Volume discounts

[Talk to us](mailto:sales@geldata.com?subject=Gel%20Cloud%20enterprise%20enquiry)

All prices are given in USD for the aws-us-east-2 region.

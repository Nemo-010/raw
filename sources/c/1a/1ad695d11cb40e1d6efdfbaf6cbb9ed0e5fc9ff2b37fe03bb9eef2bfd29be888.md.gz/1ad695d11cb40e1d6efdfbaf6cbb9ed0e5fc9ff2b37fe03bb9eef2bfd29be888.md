> ## Documentation Index
> Fetch the complete documentation index at: https://platform.stepfun.com/docs/llms.txt
> Use this file to discover all available pages before exploring further.

# 快速开始

## 实名认证

免费套餐用户需完成个人实名认证才能继续使用，所有用户在付费前均需完成认证。

1. 登录 [StepFun 开放平台](https://platform.stepfun.com/)，进入右上角 **用户中心 > 账户管理 > 账户信息**。
2. 在**实名认证**一行点击**认证**，选择**个人实名认证**，填写本人姓名和身份证号。
3. 用支付宝扫码完成人脸识别，返回平台查看结果。

认证失败、次数限制等问题请参阅[常见问题](https://platform.stepfun.com/docs/zh/faq/common-questions.md)。

## 申请 API 密钥

1. 在控制台左侧导航栏选择 **账户管理 > 接口密钥**。
2. 在[接口密钥](https://platform.stepfun.com/interface-key)页面创建 API Key 并复制。

## 环境准备

### Python 依赖安装

Python 示例使用 OpenAI SDK：

> [tab] macOS / Linux
>
> ```bash theme={"theme":{"light":"light-plus","dark":"dark-plus"}}
> python3 -m pip install --upgrade "openai>=1.0"
> ```

> [tab] Windows
>
> ```powershell theme={"theme":{"light":"light-plus","dark":"dark-plus"}}
> py -m pip install --upgrade "openai>=1.0"
> ```

## 发送请求

示例使用 Step 5 Preview（Model ID `step-5-preview`），将 `YOUR_STEP_API_KEY` 替换为您的 API Key。其他模型的 ID 与输入能力见[模型列表](https://platform.stepfun.com/docs/zh/guides/models/list.md)。

> [tab] 文本对话
>
> ```python Python theme={"theme":{"light":"light-plus","dark":"dark-plus"}}
> from openai import OpenAI
>
> client = OpenAI(
>     api_key="YOUR_STEP_API_KEY",
>     base_url="https://api.stepfun.com/v1",
> )
>
> response = client.chat.completions.create(
>     model="step-5-preview",
>     messages=[
>         {"role": "user", "content": "你好，请用一句话介绍你自己。"}
>     ],
> )
>
> print(response.choices[0].message.content)
> ```
>
> ```bash cURL theme={"theme":{"light":"light-plus","dark":"dark-plus"}}
> curl https://api.stepfun.com/v1/chat/completions \
>   -H "Content-Type: application/json" \
>   -H "Authorization: Bearer YOUR_STEP_API_KEY" \
>   -d '{
>     "model": "step-5-preview",
>     "messages": [
>       {
>         "role": "user",
>         "content": "你好，请用一句话介绍你自己。"
>       }
>     ]
>   }'
> ```

> [tab] 图片理解
>
> ```python Python theme={"theme":{"light":"light-plus","dark":"dark-plus"}}
> from openai import OpenAI
>
> client = OpenAI(
>     api_key="YOUR_STEP_API_KEY",
>     base_url="https://api.stepfun.com/v1",
> )
>
> response = client.chat.completions.create(
>     model="step-5-preview",
>     messages=[{
>         "role": "user",
>         "content": [
>             {"type": "text", "text": "请提取图中的关键信息并概括主要结论。"},
>             {
>                 # 请将此占位地址替换为您自己的可访问图片 URL。
>                 "type": "image_url",
>                 "image_url": {"url": "https://example.com/image.jpg"},
>             },
>         ],
>     }],
> )
>
> print(response.choices[0].message.content)
> ```
>
> ```bash cURL theme={"theme":{"light":"light-plus","dark":"dark-plus"}}
> # 请将此占位地址替换为您自己的可访问图片 URL。
> curl https://api.stepfun.com/v1/chat/completions \
>   -H "Content-Type: application/json" \
>   -H "Authorization: Bearer YOUR_STEP_API_KEY" \
>   -d '{
>     "model": "step-5-preview",
>     "messages": [
>       {
>         "role": "user",
>         "content": [
>           {"type": "text", "text": "请提取图中的关键信息并概括主要结论。"},
>           {
>             "type": "image_url",
>             "image_url": {"url": "https://example.com/image.jpg"}
>           }
>         ]
>       }
>     ]
>   }'
> ```

> [tab] 视频理解
>
> ```python Python theme={"theme":{"light":"light-plus","dark":"dark-plus"}}
> from openai import OpenAI
>
> client = OpenAI(
>     api_key="YOUR_STEP_API_KEY",
>     base_url="https://api.stepfun.com/v1",
> )
>
> response = client.chat.completions.create(
>     model="step-5-preview",
>     messages=[{
>         "role": "user",
>         "content": [
>             {"type": "text", "text": "请按时间顺序总结视频中的主要内容。"},
>             {
>                 # 请将此占位地址替换为您自己的可访问视频 URL。
>                 "type": "video_url",
>                 "video_url": {"url": "https://example.com/video.mp4"},
>             },
>         ],
>     }],
> )
>
> print(response.choices[0].message.content)
> ```
>
> ```bash cURL theme={"theme":{"light":"light-plus","dark":"dark-plus"}}
> # 请将此占位地址替换为您自己的可访问视频 URL。
> curl https://api.stepfun.com/v1/chat/completions \
>   -H "Content-Type: application/json" \
>   -H "Authorization: Bearer YOUR_STEP_API_KEY" \
>   -d '{
>     "model": "step-5-preview",
>     "messages": [
>       {
>         "role": "user",
>         "content": [
>           {"type": "text", "text": "请按时间顺序总结视频中的主要内容。"},
>           {
>             "type": "video_url",
>             "video_url": {"url": "https://example.com/video.mp4"}
>           }
>         ]
>       }
>     ]
>   }'
> ```

## 响应请求

非流式请求的生成内容位于 `choices[0].message.content`：

```json theme={"theme":{"light":"light-plus","dark":"dark-plus"}}
{
  "model": "所选模型 ID",
  "choices": [
    {
      "message": {
        "role": "assistant",
        "content": "模型生成的回复"
      },
      "finish_reason": "stop"
    }
  ]
}
```

完整响应还包含请求 ID、token 用量等字段，详见 [Chat Completions API](https://platform.stepfun.com/docs/zh/api-reference/chat/chat-completion-create.md)。

如果请求失败，请根据返回的错误信息查阅[错误码文档](https://platform.stepfun.com/docs/zh/api-reference/error-codes.md)。

## 深入使用

> [card] [模型列表](https://platform.stepfun.com/docs/zh/guides/models/list.md)
>
> 对比 Step 5 Preview、Step 3.7 Flash 和 Step 3.5 Flash 的定位与能力。

> [card] [图片理解](https://platform.stepfun.com/docs/zh/guides/developer/image-chat.md)
>
> 查看图片格式、传入方式和参数建议。

> [card] [视频理解](https://platform.stepfun.com/docs/zh/guides/developer/video-chat.md)
>
> 查看视频输入方式、限制和常见问题。

> [card] [API 参考](https://platform.stepfun.com/docs/zh/api-reference/chat/chat-completion-create.md)
>
> 查看完整请求参数、响应字段和用量信息。


This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.
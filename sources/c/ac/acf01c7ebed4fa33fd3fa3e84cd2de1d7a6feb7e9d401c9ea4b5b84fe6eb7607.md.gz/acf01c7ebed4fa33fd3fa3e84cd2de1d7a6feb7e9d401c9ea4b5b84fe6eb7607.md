## Personal information

First name *    {[ ctrl.errorFor['FirstName'] ]}   Minimun characters allowed.   Maximum characters allowed.

Last name *    {[ ctrl.errorFor['LastName'] ]}   Minimun characters allowed.   Maximum characters allowed.

Email address (Institution account preferred)    {[ ctrl.errorFor['Email'] ]}   Minimun characters allowed.   Maximum characters allowed.

Country *   {[ ctrl.errorFor['CountryCode'] ]}

The program is currently only available in the countries listed. If your country is not on this list, you can still [express interest.](https://edu.google.com/programs/express-interest/)

State    {[ ctrl.errorFor['StateCode'] ]}

## Organization information

Job Title *   {[ ctrl.errorFor['Title'] ]}

Organization Name *   {[ ctrl.errorFor['Company'] ]}

Begin typing and select institution from the provided list

Type of institution (optional)

University

Nonprofit Research Institution

{[ ctrl.errorFor['Type_Of_Institution__c'] ]}

Department name (optional)    {[ ctrl.errorFor['Name_Of_Edu_Department__c'] ]}   Minimun characters allowed.   Maximum characters allowed.

Link to your profile in your institution's faculty or researcher directory  Link to URL showing your candidacy status   {[ ctrl.errorFor['Faculty_Directory_Link__c'] ]}   Minimun characters allowed.   Maximum characters allowed.

How did you hear about the program? *   {[ ctrl.errorFor['Additional_Information__c'] ]}

## Project information

Project name *    {[ ctrl.errorFor['Edu_Course1_Course_name'] ]}   Minimun characters allowed.   Maximum characters allowed.

Project start date *    {[ ctrl.errorFor['Edu_Course1_Expected_Course_Start_Date__c'] ]}   Minimun characters allowed.   Maximum characters allowed.

Proposal *    {[ ctrl.errorFor['Edu_Course1_Abstract__c'] ]}

Please provide a project proposal that includes: research problem to be solved, GCP tools to be used, project timeline, key milestones and outcomes, and how GCP can support your research in the future. Please include a link to your shared Google Doc OR copy and paste text in the field below. (250 words maximum)

Field of research *   {[ ctrl.errorFor['Rental_Global_07__c'] ]}

## Additional information

Google scholar link (Optional)    {[ ctrl.errorFor['GCP_EDU_Faculty_Directory_Link__c'] ]}   Minimun characters allowed.   Maximum characters allowed.

How do you intend to apply awarded cloud credits? *   {[ ctrl.errorFor['Rental_Global_08__c'] ]}

Does your research project have an external funding source? *

Yes

No

{[ ctrl.errorFor['Rental_EMEA_23__c'] ]}

Have you used cloud infrastructure for your research before? *

Yes

No

{[ ctrl.errorFor['Rental_EMEA_24__c'] ]}

Have you used Google Cloud before? *

Yes

No

{[ ctrl.errorFor['Rental_EMEA_25__c'] ]}

Please calculate your expected costs using the pricing calculator. Submit the total amount and a link to your calculator results.

[Pricing calculator](https://cloud.google.com/products/calculator)

{[ ctrl.errorFor['Rental_Global_09__c'] ]}    {[ ctrl.errorFor['Gcp_Pricing_Calculator_Url__c'] ]}

Use the link above to estimate the price of products relevant to you, then enter the provided URL.

Google Cloud Billing Account ID *    {[ ctrl.errorFor['Rental_Global_10__c'] ]}   Minimun characters allowed.   Maximum 25 characters allowed.

[Create a Google Cloud billing account to use your GCP credits](https://services.google.com/fh/files/helpcenter/create_new_billing_account_edu_credits.pdf)

After your credit expires, how do you intend to continue funding your project? *    {[ ctrl.errorFor['Rental_Global_11__c'] ]}

Please provide information on how you intend to fund your project after your credit expires in 1 year.

Would you like to receive periodic emails on news, product updates, and special offers from Google or our partners? *

Yes

No

{[ ctrl.errorFor['Opt_In__c'] ]}

By submitting this form, you, on behalf of yourself (“You”) agree to these terms and conditions:

The credit is valid for Google Cloud Platform products and is subject to Your acceptance of the applicable Google Cloud Platform License Agreement and any other applicable terms of service.

The credit is non-transferable and may not be sold or bartered. Credit awards must be activated within 60 days of the project start date indicated in the application form. Credit awards expire 365 days from the coupon redemption date, or when the credit amount has been fully used, whichever comes first. The credit may be issued in increments as You use the credit over the period of time during which the credit is valid. The credits do not have commercial value and may not be used for commercial purposes.

Offer void where prohibited by law. If you are faculty at Your educational institution, You represent that You are accepting the promotional credit on behalf of Your educational institution and the credit can only be used on behalf of the educational entity in connection with the project described in this application form and not for Your personal use. If you are a PhD student at Your educational institution, You represent that the credit will only be used in connection with the project described in this application form and in Your capacity as a PhD student at Your educational institution. Credit cannot be used for Your personal use.

(i) You are authorized to accept this credit; (ii) the credit is consistent with all applicable laws and regulations, including relevant ethics rules and laws; and (iii) the provision of credits will not negatively impact Google's current or future ability to do business with such educational entity.

By submitting this form, you, on behalf of yourself (“You”) agree to these terms and conditions:

The credit is valid for Google Cloud Platform products and is subject to Your acceptance of the applicable Google Cloud Platform License Agreement and any other applicable terms of service.

The credit is non-transferable and may not be sold or bartered. Credit awards must be activated within 60 days of the project start date indicated in the application form. Credit awards expire 365 days from the coupon redemption date, or when the credit amount has been fully used, whichever comes first. The credit may be issued in increments as You use the credit over the period of time during which the credit is valid. The credits do not have commercial value and may not be used for commercial purposes.

Offer void where prohibited by law. If you are faculty at Your educational institution, You represent that You are accepting the promotional credit on behalf of Your educational institution and the credit can only be used on behalf of the educational entity in connection with the project described in this application form and not for Your personal use. If you are a PhD student at Your educational institution, You represent that the credit will only be used in connection with the project described in this application form and in Your capacity as a PhD student at Your educational institution. Credit cannot be used for Your personal use.

(i) You are authorized to accept this credit; (ii) the credit is consistent with all applicable laws and regulations, including relevant ethics rules and laws; and (iii) the provision of credits will not negatively impact Google's current or future ability to do business with such educational entity.


> Agent-friendly representation of <https://container-registry.com/docs/2.15/administration-manual/storage-management/project-quotas/index.md>. Site index: <https://container-registry.com/llms.txt>.


# Project Quotas

*What a project quota covers, how the storage overview reads, and how shared image layers count when an artifact is pushed, retagged or deleted.*

Project Quotas
=================================

Individual accounts have 1 GB of storage included. Dedicated accounts have 100 GB. You can set the upper limit for storage usage for every project.

To set or change one, see [Manage Project Quotas](/docs/2.15/administration-manual/storage-management/manage-project-quotas/index.md).

## Overview of the Storage Usage
In the **Project Quotas** tab of the navigation pane, you can check how much storage is used and by which projects.
**Default disk space per project** shows how much storage every newly created project will be assigned.
![](../img/storage_usage_overview.png)
The bar in the *Storage* column of the overview shows the percentage of storage use. If it is green, you are below the first half of the storage reserved for this project. The yellow color shows that you are above the first half. The red color shows that the project is close to exhausting its available storage.


> **Note:** <strong>Default disk space per project</strong> is not the total storage use per instance, nor it is the sum of all other project quotas.


## How Storage Size Is Counted
A few notes on when you should expect changes in your storage usage: what makes your storage quotas exhausted quickly and what makes some storage space vacant again.


> **Note:** Helm Charts do not influence the storage usage that you see in the project quotas overview.

Every Docker image has at least one &ndash; usually, numerous &ndash; layers. Those layers are "stored" in blobs: binary files. The track of layers is kept in the image manifest.
### Shared Blobs and Project Quotas
The hierarchy of the image layers was explained in detail [here](/docs/2.15/administration-manual/replication/replication-rules.md#flattening). From this perspective, one can say that some image layers are included in more than one image. But the underlying Harbor technology does not multiply identical layers but rather maps different images to store one unique layer only once and to spare some storage space.\
Consequently, shared blobs &ndash; identical layers &ndash; add to the exhaustion of the project storage only once. However, shared blobs stretched across different projects add to the exhaustion of *every* project.
### What Happens With the Storage on Image Push
On image push, blob files are transmitted first. The manifest is pushed only upon their successful arrival in the registry. Therefore, you may exceed your project quota but you won't be notified about it immediately after you've started the push. The storage may be exhausted in the process but Container Registry can reject the push only when its manifest arrives and gets rejected due to the quota exceeded by the blobs. \
Rejection or acceptance happens on "First come, first served" principle, in the order image *manifests* arrive. Keep this in mind when pushing a few images in parallel. They may race with each other and the first to be pushed is not necessarily the one to be stored successfully. Images with blobs already existing in the registry will squeeze through faster than those with completely new layers.
### What Happens With the Storage on Retagging Images
Retagging images **increases** storage exhaustion if you copy an image from one project to another. It **does not change** project quota exhaustion if you tag the image but leave it in the same project.
### What Happens With the Storage on Deleting Images
Image blobs are not deleted when the image is deleted. Therefore, deleting images **won't free any storage space**. To remove the blobs completely and to reduce the storage exhaustion in the project, run **Garbage Collection** as described [here](/docs/2.15/administration-manual/storage-management/garbage-collection-and-terminal-deletion-of-images/index.md).


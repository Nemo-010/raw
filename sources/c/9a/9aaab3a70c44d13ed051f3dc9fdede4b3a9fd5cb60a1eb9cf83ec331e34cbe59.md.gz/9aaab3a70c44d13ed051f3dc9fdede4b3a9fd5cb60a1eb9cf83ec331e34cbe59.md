# Aiven API

Use the Aiven API to programmatically access and automate tasks in the Aiven platform.

Common use cases for the Aiven API:

- Use with continuous integration to create services during test runs.
- Integrate with other parts of your existing automation setup to complete complex tasks.
- Deploy and tear down development or demo platforms on a schedule.
- Scale your disks based on specific events.

tip

Want to manage Aiven services from an AI assistant? Use [Aiven MCP](https://aiven.io/docs/tools/mcp-server) to create, update, and inspect services in natural language from clients such as Cursor and Claude Code.

## Get started with Aiven API​

Use the [Postman workspace](https://www.postman.com/aiven-apis/workspace/aiven/overview) to try the Aiven API.

1. [Create a token](https://aiven.io/docs/platform/howto/create_authentication_token).
2. Fork the Postman **collection** and **environment**.

  [Run In Postman](https://app.getpostman.com/run-collection/32630186-ad894eed-9287-4a30-8534-d2b4422a254a?action=collection%2Ffork&source=rip_markdown&collection-url=entityId%3D32630186-ad894eed-9287-4a30-8534-d2b4422a254a%26entityType%3Dcollection%26workspaceId%3D85dcbab4-8e52-4836-839f-9157852fef73#?env%5BAiven%20environment%5D=W3sia2V5IjoiYXV0aFRva2VuIiwidmFsdWUiOiIiLCJlbmFibGVkIjp0cnVlLCJ0eXBlIjoic2VjcmV0Iiwic2Vzc2lvblZhbHVlIjoiIiwic2Vzc2lvbkluZGV4IjowfSx7ImtleSI6ImJhc2VVcmwiLCJ2YWx1ZSI6Imh0dHBzOi8vYXBpLmFpdmVuLmlvL3YxIiwiZW5hYmxlZCI6dHJ1ZSwidHlwZSI6ImRlZmF1bHQiLCJzZXNzaW9uVmFsdWUiOiJodHRwczovL2FwaS5haXZlbi5pby92MSIsInNlc3Npb25JbmRleCI6MX0seyJrZXkiOiJhY2NvdW50X2lkIiwidmFsdWUiOiJpZCIsImVuYWJsZWQiOnRydWUsInNlc3Npb25WYWx1ZSI6ImlkIiwic2Vzc2lvbkluZGV4IjoyfSx7ImtleSI6InRlYW1faWQiLCJ2YWx1ZSI6ImlkIiwiZW5hYmxlZCI6dHJ1ZSwic2Vzc2lvblZhbHVlIjoiaWQiLCJzZXNzaW9uSW5kZXgiOjN9LHsia2V5IjoicHJvamVjdCIsInZhbHVlIjoiaWQiLCJlbmFibGVkIjp0cnVlLCJzZXNzaW9uVmFsdWUiOiJpZCIsInNlc3Npb25JbmRleCI6NH0seyJrZXkiOiJiaWxsaW5nX2dyb3VwX2lkIiwidmFsdWUiOiJpZCIsImVuYWJsZWQiOnRydWUsInNlc3Npb25WYWx1ZSI6ImlkIiwic2Vzc2lvbkluZGV4Ijo1fSx7ImtleSI6InRlbmFudCIsInZhbHVlIjoidGVuYW50IiwiZW5hYmxlZCI6dHJ1ZSwic2Vzc2lvblZhbHVlIjoidGVuYW50Iiwic2Vzc2lvbkluZGV4Ijo2fSx7ImtleSI6Im9yZ2FuaXphdGlvbl9pZCIsInZhbHVlIjoiaWQiLCJlbmFibGVkIjp0cnVlLCJzZXNzaW9uVmFsdWUiOiJpZCIsInNlc3Npb25JbmRleCI6N30seyJrZXkiOiJkb21haW5faWQiLCJ2YWx1ZSI6ImlkIiwiZW5hYmxlZCI6dHJ1ZSwic2Vzc2lvblZhbHVlIjoiaWQiLCJzZXNzaW9uSW5kZXgiOjh9LHsia2V5IjoidXNlcl9ncm91cF9pZCIsInZhbHVlIjoiaWQiLCJlbmFibGVkIjp0cnVlLCJzZXNzaW9uVmFsdWUiOiJpZCIsInNlc3Npb25JbmRleCI6OX0seyJrZXkiOiJzZXJ2aWNlX25hbWUiLCJ2YWx1ZSI6Im5hbWUiLCJlbmFibGVkIjp0cnVlLCJzZXNzaW9uVmFsdWUiOiJuYW1lIiwic2Vzc2lvbkluZGV4IjoxMH1d)
3. Insert the token in the `authToken` in the Postman environment.
4. See the [API documentation](https://api.aiven.io/doc/).
5. Send your requests via Postman.

## API examples​

### List your projects​

- Request
- Response

```bash
curl -H "Authorization: aivenv1 TOKEN" https://api.aiven.io/v1/project
```

Where `TOKEN` is your token.

### List cloud regions​

- Request
- Response

```bash
curl https://api.aiven.io/v1/clouds
```

This endpoint does not require authorization. If you aren't authenticated, it returns the standard set of cloud regions.

Related pages

- [Personal tokens](https://aiven.io/docs/platform/concepts/authentication-tokens)
- [Aiven Provider for Terraform](https://registry.terraform.io/providers/aiven/aiven/latest/docs)
- [API reference docs](https://api.aiven.io/doc/)
- [Aiven MCP](https://aiven.io/docs/tools/mcp-server): Manage Aiven services in natural language.

[Edit this page](https://github.com/aiven/aiven-docs/blob/main/docs/tools/api.md)

Last updated on **Jun 16, 2026**

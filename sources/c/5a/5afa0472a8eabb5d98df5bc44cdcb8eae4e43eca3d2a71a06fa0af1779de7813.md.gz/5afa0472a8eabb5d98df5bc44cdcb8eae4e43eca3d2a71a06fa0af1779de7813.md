# Sandboxes

> Run generated code in an isolated microVM and see its activity alongside your function steps and retries.

When an agent needs to run generated code or test a repository, put that work in a Sandbox. Each Sandbox has its own filesystem and processes. Inngest records Sandbox operations in the durable function run, so you can inspect the job and retry the surrounding steps from one trace.

## What you can do

- **Run code in isolation.** Each Sandbox runs in a separate VM, isolated from the host and other Sandboxes. Sandboxes cannot send traffic directly to one another; outbound network access is allowed by default.
- **Start quickly and keep your work.** Sandboxes boot in under a second. Pause and resume the same Sandbox, or capture a snapshot and clone it into a new Sandbox. Its filesystem persists through those operations.
- **Share files when tasks need them.** S3-backed persistent mounts let different Sandboxes use the same backing path.
- **Follow the whole job.** See Sandbox operations alongside function steps, waits, and retries in a run trace.
- **Run Python or TypeScript in one call.** `step.sandbox.python` and `step.sandbox.typescript` start a Sandbox, run your code, return a typed result, and clean up. [Managed lifecycle](/docs-markdown/sandboxes/features/managed-lifecycle#run-python-or-typescript-in-one-call)
- **Run commands like a script.** `sb.$` runs a command as one step and returns text, lines, or JSON. [Commands](/docs-markdown/sandboxes/features/commands)
- **Let sandboxed code call your app.** Tools run your functions as durable steps with your credentials. [Tools](/docs-markdown/sandboxes/features/tools)
- **Start from your own image.** Choose `image.inngest()` or `image.custom()` when creating a Sandbox. [Base images](/docs-markdown/sandboxes/features/base-images)

A durable function can start a Sandbox, run code, wait for another event, and continue later. With the low-level `step.sandbox.create()` path your function destroys the Sandbox and handles cleanup after permanent failure; the one-call runners clean up for you.

## Start here

- [Overview](/docs-markdown/sandboxes/overview) explains how Sandboxes fit into durable execution.
- [Quick start](/docs-markdown/sandboxes/quick-start) runs a command with the TypeScript beta.
- [Features](/docs-markdown/sandboxes/features) covers lifecycle, filesystems, SSH, secrets, isolation, and traces.
- [Guides](/docs-markdown/sandboxes/guides) shows how to use Sandboxes in a durable job.
- [Reference](/docs-markdown/sandboxes/reference) and [Limits](/docs-markdown/sandboxes/limits) give the current API and beta limits.

**Open beta.** Sandboxes are available on Pro plans and above. The TypeScript Sandbox beta is intended for evaluation.
# Discontinued: Donated Microsoft 365 Business Premium and Office 365 E1

- October 01, 2026 03:19
- Updated

# Contents

# Overview

Microsoft recently informed nonprofits on May 14, 2025 the donated Microsoft 365 Business Premium and Office 365 E1 offers for nonprofits will be discontinued **starting on July 1, 2025**. These changes do not impact the discounted licenses of Microsoft 365 Business Premium or Office 365 E1 that are available for nonprofits. Learn more about these changes in [our blog post](https://blog.techsoup.org/posts/microsoft-to-discontinue-select-donated-microsoft-365-and-office-365-plans?utm_medium=email&_hsenc=p2ANqtz-9EcQNnPU5x5lgkYH4iJ6x2ZKRtTD5ibT0dQSstgnhSrkhaqHl8_ZgHrUHytmvNSlfs9olsVIdLblqMuiBobhLgyOyQ7qVh3mLSt4YwxrndGXuPPpY&_hsmi=362041164&utm_content=361971744&utm_source=hs_email).

TS CSP.png

# What Happens to Your Current Licenses

**Microsoft will automatically cancel your donated Microsoft 365 Business Premium and Office 365 E1 licenses upon your next renewal on or after July 1, 2025.**

To continue your services, you will need to switch to a different license type before your subscription is canceled. Organizations that do not take action will lose access to their impacted licenses.

## Verify Your Subscription Renewal Date

**Verify your organization's subscription information and renewal dates by following **[**these instructions**](https://page.techsoup.org/hubfs/Downloads/How%20to%20Find%20Subscription%20Renewal%20Information%20-%20092622.pdf?utm_campaign=Microsoft%20Cloud)**.**

Please note, subscriptions may be on an Annual term, but paid monthly or annually.

For example, if your current subscription is set to expire on:

- **July 15, 2025**, it will be automatically cancelled on July 15th, since the expiration occurs after the July 1st discontinuation.
- **June 5, 2025**, it will be automatically renewed for one year, since the expiration occurs before the July 1st discontinuation. If successfully renewed, you will be able use the donated licenses until June 5, 2026.

## License Access and Data Retention

Review [Microsoft’s article](https://learn.microsoft.com/en-us/compliance/assurance/assurance-data-retention-deletion-and-destruction-overview) to learn more about their subscription and data retention policies:

- **Subscription Retention**: Customers have access to the full license (apps, etc.).
- **Data Retention: Data** is retained, but is only accessible to account admins.

### License Access

Microsoft has provided a **30 day grace period** allowing customers access to their licenses (apps, etc.) after their subscription is canceled. After the 30 day grace period, customers will permanently lose access to their donated licenses.

### Data Retention

Microsoft has provided a **90 day grace period** allowing admins access to data after their subscription is canceled. After the 90 day grace period, customers will permanently lose their access to their data.

# TechSoup is Here to Help

To start, we recommend that you do the following:

- Read [our TechSoup Support article](https://support.techsoup.org/hc/en-us/articles/37040875733915-How-to-transition-from-my-granted-Microsoft-365-Business-Premium-and-Office-365-E1-subscriptions) to understand what alternative licensing options you have and how to migrate those licenses.
- Review our alternative licensing [comparison guide](https://pages.techsoup.org/hubfs/Downloads/microsoft-comparison-guide.pdf).
- Review the recording and slide deck and recording of our recent webinar (May 22, 2025) to learn more about the changes and actions required.

    - [Webinar recording](https://youtu.be/QAzosfMG2pY?si=wqgmf2oxQeOo5D0I)
    - [Presentation slides](https://www.slideshare.net/slideshow/techsoup-microsoft-discontinuation-of-selected-cloud-donated-offers-2025-05-22-pdf/279559822)

Additional resources such as step by step guides to transition your licenses, and workshops are forthcoming.

Was this article helpful?

0 out of 1 found this helpful

Return to top

## Comments

0 comments

Article is closed for comments.

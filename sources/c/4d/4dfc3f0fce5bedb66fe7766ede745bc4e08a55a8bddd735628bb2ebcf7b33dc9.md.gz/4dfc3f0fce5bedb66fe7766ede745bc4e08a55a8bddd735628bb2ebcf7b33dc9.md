Pricing

# Simple plans. Real scale.

Start free, scale as you grow. Every plan includes monthly credits you can spend on fine-tuning, evals, gateway routing, and observability.

### Free

$0forever

Everything you need to evaluate Inference.net and ship your first project.

What's included

- $1 monthly credit grant
- 1 deployment Active deployments
- 0 / mo Deployment GPU hours
- 2 / mo Training jobs
- 500 / mo Eval samples
- 0 / mo Third-party serverless inference
- 1M / mo Gateway inference requests
- 50 GB / mo Gateway inference data
- 1M / mo OTEL spans
- 50 GB / mo OTEL span data
- Pay-as-you-go serverless inference

[Start for free](https://inference.net/register/)

### Starter

$25per month

Higher limits, monthly credit, and room to grow beyond proof-of-concept.

What's included

- 1 deployment Active deployments
- 0 / mo Deployment GPU hours
- 10 / mo Training jobs
- 1K / mo Eval samples
- 0 / mo Third-party serverless inference
- 10M / mo Gateway inference requests
- 500 GB / mo Gateway inference data
- 10M / mo OTEL spans
- 500 GB / mo OTEL span data
- Pay-as-you-go serverless inference

[Get started with Starter](https://inference.net/register/)

### Growth

$250per month

Scaled limits and committed credits for teams running production workloads.

What's included

- 1 deployment Active deployments
- 0 / mo Deployment GPU hours
- 25 / mo Training jobs
- 10K / mo Eval samples
- 0 / mo Third-party serverless inference
- 50M / mo Gateway inference requests
- 2.5 TB / mo Gateway inference data
- 50M / mo OTEL spans
- 2.5 TB / mo OTEL span data
- Pay-as-you-go serverless inference

[Get started with Growth](https://inference.net/register/)

Enterprise

### Talk with our team.

Custom contracts, dedicated infrastructure, and a direct line to our team. Talk to our team about committed-use pricing, dedicated support, and bespoke deployment limits.

[Contact sales](mailto:sales@inference.net?subject=Enterprise%20plan%20inquiry)

Includes

- Custom contracts and committed-use pricing
- Dedicated infrastructure and deployment limits
- Direct support channel with our team
- Custom models trained for your workload

CONTACT

## Meet with our research team

Schedule a call with our research team to learn more about how Specialized Language Models can cut costs and improve performance.

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.growthbook.io/llms.txt
> Use this file to discover all available pages before exploring further.

# Quick Start Guide

> Create a GrowthBook account or self-hosted instance, add an SDK Connection, and evaluate your first feature flag.

This guide walks you through the basics of a full integration of GrowthBook for both feature flagging and experimentation.

## Set up GrowthBook

You can either **self-host** GrowthBook or use our **Cloud**.

For the easiest setup, [sign up for a free Cloud account](https://app.growthbook.io).

If you prefer to self-host, follow the [instructions here](https://docs.growthbook.io/self-host.md) or on our GitHub page.

After creating your account, it will walk you through the initial setup steps, including integrating one of our SDKs into your application.

> [!TIP]
>
> Press `Cmd+K` (Mac) or `Ctrl+K` (Windows and Linux) anywhere in GrowthBook to open the [command palette](https://docs.growthbook.io/command-palette.md) and jump to any feature, experiment, metric, page, doc, or REST API endpoint.

## Feature Flags

**1. Integrate the GrowthBook SDK**

As part of the initial setup, you should have created an initial SDK Connection. If not, you can do so now by going to **SDK Configuration** → **SDK Connections**. Then, click **Add SDK Connection**.  Follow the directions based on your application's language and platform.
The [full SDK docs](https://docs.growthbook.io/lib.md) are also available if you want to dive deeper.

> [!TIP]
>
> If you selected **Engineering** as your role during signup and use a coding agent, run `npx @growthbook/wizard` from your project directory. The [Setup Wizard](https://docs.growthbook.io/integrations/ai-agents/wizard.md) creates an SDK Connection and helps your agent install and connect the SDK.

**2. Create a feature flag**

On the **Features** page, create your first feature flag.

![Create Feature](https://mintcdn.com/growthbook-ea15456d/giSZyh24PfnTkKz4/static/images/features/feature-create-feature-1.png?fit=max\&auto=format\&n=giSZyh24PfnTkKz4\&q=85\&s=f28a41bb7b5e9577afbf3a4eefce5f99)

The **Feature Key** is what you will reference in your application and cannot be changed later.

Feature flags in GrowthBook are robust, supporting advanced [targeting](https://docs.growthbook.io/features/targeting.md), powerful [rule evaluation](https://docs.growthbook.io/features/rules.md), [prerequisite features](https://docs.growthbook.io/features/prerequisites.md), JSON schema validation, and more. In this quick start, we'll just stick with a simple boolean feature flag that is always `on` or `off` for everyone.

**3. Use the feature in your application**

When you create your first feature, you'll see instructions on how to use it in your application. Here's an example using our JavaScript SDK:

```js theme={null}
if (gb.isOn("my-feature")) {
    console.log("It's On!")
}
```

It really is that simple to get started! For next steps, we recommend reading our [Feature Flag Basics](https://docs.growthbook.io/features/basics.md) page, which goes into more depth.

Feature flags are the foundation for powerful experimentation. In the next section, we show you how to use them to run no-code experimentation using our AI Visual Editor. Need more advanced options? Dive into our [complete guide for code-based experimentation](https://docs.growthbook.io/features/feature-flag-experiments.md).

## Experiment Analysis

**1. Set up your data source**

GrowthBook connects to a data warehouse to query your experiment data. You have two options:

**Fastest path: [Managed Warehouse](https://docs.growthbook.io/app/managed-warehouse.md).** If you don't have an existing data warehouse, our Managed Warehouse gets you running quickly. We provision a fully managed database, create starter metrics, and provide built-in event tracking. No infrastructure setup required.

**[Bring Your Own Warehouse](https://docs.growthbook.io/warehouses).** If you already have event data in BigQuery, Snowflake, Databricks, Redshift, or another warehouse, you can connect it directly. GrowthBook supports almost any schema structure with a bit of configuration and only needs read-only access.

> [!TIP]
>
> **Not sure which to pick?**
>
> See our [data path comparison](https://docs.growthbook.io/app/choose-data-path.md) for help deciding.

To get started, go to **Metrics and Data** → **Data Sources** and pick your path.

**2. Add a metric or two**

GrowthBook needs to know what metrics you want to measure for your experiments. This starts by creating one or more Fact Tables using SQL, which selects raw data from your warehouse. Metrics are then built on top of these Fact Tables.

Go to **Metrics and Data** → **Fact Tables**. Click **Add a Fact Table** and edit the default SQL if needed. Here's an example SQL query for an Orders fact table.

```sql theme={null}
SELECT
  user_id,
  timestamp,
  qty,
  amount
FROM orders
```

Once the fact table is created, you can easily add metrics on top of it. For example, consider a simple proportion metric, which measures the percentage of experiment users who complete an action at least once. In this case, it'd measure the percentage of users who made a purchase.

Metrics in GrowthBook are powerful and have many advanced settings. Read about them on our [Metrics page](https://docs.growthbook.io/app/metrics.md).

**3. View experiment results**

Go to the **Experiments** page. If you implemented an experiment using feature flags, your experiment will already be listed. Click through to it. If you ran your experiment outside of GrowthBook instead, that's fine, too! Add a new experiment and select the **Import Existing** option.

Once inside your experiment, go to the **Results** tab. Edit your analysis settings and pick the metrics you created earlier. The results will show up in a table like this:

![Results Table](https://mintcdn.com/growthbook-ea15456d/J3C3juKhu0f7KEr_/static/images/results-table.png?fit=max\&auto=format\&n=J3C3juKhu0f7KEr_\&q=85\&s=64d384bab6842334f372056af3c602b2)

We have an [entire page in our docs](https://docs.growthbook.io/app/experiment-results.md) just about these results and how to interpret them.

## Next steps

> [card] [Self-Host](https://docs.growthbook.io/self-host.md)
>
> Run GrowthBook on your own infrastructure

> [card] [SDK Docs](https://docs.growthbook.io/lib.md)
>
> Connect GrowthBook to your application

> [card] [FAQ](https://docs.growthbook.io/faq.md)
>
> Find answers to common questions

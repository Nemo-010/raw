> ## Documentation Index
> Fetch the complete documentation index at: https://docs.tembo.io/llms.txt
> Use this file to discover all available pages before exploring further.

# Pricing

> Understand Tembo plans, model and compute rates, usage allowances, prepaid balance, and overages.

Tembo gives your workspace a dollar-denominated usage allowance. Tembo Gateway usage and cloud VM compute draw from the same balance.

## Plans

[Projects](https://docs.tembo.io/features/projects.md) are unlimited during your free trial and on paid plans.

* **Free trial**: included usage allowance, up to 10 users, sandbox size up to `xl`, and priority support
* **Pro (\$60/month)**: \$90 monthly usage allowance, up to 5 users, sandbox size up to `medium`, with overage billing
* **Max (\$200/month)**: \$400 monthly usage allowance, up to 10 users, sandbox size up to `xl`, with overage billing

Pro and Max can use overage billing so your work can continue after you use your monthly allowance and prepaid balance. You can set a maximum overage limit to control spend. When your free trial ends or its allowance runs out, upgrade to a paid plan to continue running sessions.

Standard BYOK (Anthropic, OpenAI, xAI), cloud BYOK (AWS Bedrock, GCP Vertex AI), agent keys (Cursor), and ChatGPT/Codex and [Claude subscription access](https://docs.tembo.io/features/models.md#connect-a-claude-subscription) are available during your free trial and on paid plans.

## How the usage allowance works

Two usage categories draw from the same balance:

* **Tembo Gateway**: model input, output, and cache usage is charged at the rates in [Tembo Gateway pricing](#tembo-gateway-pricing).
* **Cloud VM compute**: metered from the CPU, memory, and runtime used by each session.

BYOK, ChatGPT/Codex, and Claude subscription inference cost \$0 through Tembo because you provide the model access. The cloud VM running the session continues to draw from your usage allowance.

Included monthly allowance expires at the end of each billing cycle and does not roll over. Prepaid balance does not expire.

## Cloud VM compute rates

VM compute is a separate usage category from Tembo Gateway. It draws from the same dollar-denominated allowance at **\$0.0403/vCPU-hour + \$0.0130/GiB-RAM-hour**.

| Resource | Rate |
| - | -: |
| vCPU | \$0.0403 per vCPU-hour |
| Memory | \$0.0130 per GiB RAM-hour |

The per-size hourly prices below apply those resource rates to each VM configuration.

| Size | vCPU | Memory | Price per hour |
| - | -: | -: | - |
| Nano | 2 | 2 GiB | \$0.1066 |
| Micro | 2 | 4 GiB | \$0.1326 |
| Medium | 4 | 8 GiB | \$0.2652 |
| Large | 8 | 16 GiB | \$0.5304 |
| XL | 16 | 32 GiB | \$1.0608 |
| XXL | 16 | 64 GiB | \$1.4768 |
| Ultra | 32 | 128 GiB | \$2.9536 |

> [!NOTE]
>
> **Don't see the VM size you want?** Larger VM sizes are available upon request. Contact [support@tembo.io](mailto:support@tembo.io) to discuss your requirements.

Tembo measures each running VM in seconds and bills its actual running time at the per-second equivalent of the hourly rate. Stopped, snapshotted, and otherwise non-running VMs do not accrue compute.

See [Sandboxes](https://docs.tembo.io/features/sandbox/overview.md) for more about the execution environment.

## Tembo Gateway pricing

Pricing is shown in USD per 1M tokens.

| Provider | Model | Input | Output | Cache create | Cache read |
| - | - | -: | -: | -: | -: |
| Anthropic | `claude-fable-5` | \$11.50 | \$57.50 | \$14.375 | \$1.15 |
| Anthropic | `claude-opus-4-8` | \$5.75 | \$28.75 | n/a | n/a |
| Anthropic | `claude-opus-4-7` | \$5.75 | \$28.75 | \$7.1875 | \$0.575 |
| Anthropic | `claude-opus-4-6` | \$5.75 | \$28.75 | \$7.1875 | \$0.575 |
| Anthropic | `claude-opus-4-5` | \$5.75 | \$28.75 | \$7.1875 | \$0.575 |
| Anthropic | `claude-4-5-haiku` | \$1.15 | \$5.75 | \$1.4375 | \$0.115 |
| OpenAI | `gpt-6.1-sol` | \$2.30 | \$11.50 | \$2.875 | \$0.115 |
| OpenAI | `gpt-6.1-terra` | \$1.15 | \$5.75 | \$1.4375 | \$0.0575 |
| OpenAI | `gpt-6-astra` | \$11.50 | \$57.50 | \$14.375 | \$1.15 |
| OpenAI | `gpt-5.6-sol` | \$4.60 | \$23.00 | n/a | \$0.46 |
| OpenAI | `gpt-5.5` | \$5.75 | \$34.50 | n/a | \$0.575 |
| OpenAI | `gpt-5.4` | \$2.875 | \$17.25 | n/a | \$0.2875 |
| OpenAI | `gpt-5.4-mini` | \$0.2875 | \$2.30 | n/a | \$0.02875 |
| OpenAI | `gpt-5.4-nano` | \$0.0575 | \$0.46 | n/a | \$0.00575 |
| OpenAI | `gpt-5.3-codex` | \$2.0125 | \$16.10 | n/a | \$0.20125 |
| OpenAI | `gpt-5.3-codex-spark` | Missing | Missing | Missing | Missing |
| OpenAI | `gpt-5.2-codex` | \$2.0125 | \$16.10 | n/a | \$0.20125 |
| OpenAI | `gpt-5.2` | \$2.0125 | \$16.10 | n/a | \$0.20125 |
| Tembo | `kimi-k3` | \$3.45 | \$17.25 | n/a | \$0.345 |
| Tembo | `glm-5p3` | \$1.61 | \$5.06 | n/a | \$0.299 |
| Tembo | `glm-5p3-flash` | \$0.1725 | \$0.575 | n/a | \$0.03335 |
| Tembo | `minimax-m2p7` | \$0.345 | \$1.38 | n/a | \$0.0345 |
| Tembo | `minimax-m3` | \$0.345 | \$1.38 | n/a | \$0.0345 |
| Tembo | `deepseek-v4-pro` | \$2.001 | \$4.002 | n/a | \$0.16675 |
| Tembo | `deepseek-v4p1-flash` | \$0.253 | \$0.759 | n/a | \$0.00805 |
| Tembo | `nvidia-nemotron-3-ultra-nvfp4` | \$0.69 | \$2.76 | n/a | \$0.138 |

## What consumes the allowance

Tembo Gateway and VM compute are metered while Tembo runs work such as:

* Creating pull requests from assigned issues (Linear, Jira, Slack)
* Fixing production errors from Sentry
* Optimizing database queries and indexes
* Processing pull request feedback through [Mentioning Tembo](https://docs.tembo.io/features/mentioning-tembo.md)

## When the allowance runs out

What happens when your balance reaches zero depends on your plan and overage setting:

* **Free trial**: sessions stop when the trial ends or its allowance runs out. Upgrade to a paid plan to continue; overage billing is not available during the trial.
* **Pro or Max with overages enabled**: sessions continue and are billed as overage after the included allowance and prepaid balance are used, up to the maximum overage limit you set. Once that limit is reached, new sessions are blocked.
* **Pro or Max with overages disabled**: new sessions are blocked as soon as the included allowance and prepaid balance are exhausted.

When work is blocked, the request is rejected immediately rather than queued. On Pro and Max, work that has already started can continue its current session so its compute and inference are accounted for correctly.

## Usage bursts

Some integrations can create a large batch of work at once — for example, a repository or integration sync, or a token refresh that triggers a backlog of issues. Tembo does not cap or rate-limit how much work an integration enqueues; the batch is processed as worker capacity becomes available, and each resulting session records dollar usage when it runs. The same allowance and overage limits above apply, so a burst cannot spend beyond your available balance plus your overage limit. To absorb large bursts without interruption, enable overages with an appropriate limit.

## Usage refunds

Tembo Gateway usage may be refunded automatically in some cases:

* **Failed sessions**: if Tembo cannot complete a session because of an internal error
* **Duplicate issues**: if the same issue is queued more than once
* **Invalid inputs**: if a session fails due to missing access or configuration problems

## Usage and monitoring

You can track Tembo Gateway usage, compute, total usage, VM resource-hours, and daily spend in the [Billing dashboard](https://app.tembo.io/settings/billing). Overage invoices list Tembo Gateway and compute separately.

## Prepaid balance and on-demand usage

* **Free trial**: upgrade to Pro or Max to continue after your trial ends or its allowance runs out
* **Pro and Max**: enable overage billing and set a monthly spend limit
* **Prepaid balance**: does not expire

To change plans, open [Billing settings](https://app.tembo.io/settings/billing).

## Troubleshooting

**Payment failed**: confirm the card is valid and has available funds.

**Prepaid balance did not appear immediately**: billing updates can take a few minutes.

Need help? Contact [hi@tembo.io](mailto:hi@tembo.io).

## Enterprise pricing

If you need custom pricing, reach out to [support@tembo.io](mailto:support@tembo.io) for:

* Custom usage allowances
* Custom or unlimited sandbox sizing
* Volume pricing
* Custom inference configuration
* Dedicated support
* Flexible billing options


This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.
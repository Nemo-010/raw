
API v2

Search`/` Ask AI

- [Overview](https://www.roic.ai/api/v2)
- [Getting Started](https://www.roic.ai/api/v2/docs/getting-started)
- [Authentication](https://www.roic.ai/api/v2/docs/authentication)
- [MCP Server](https://www.roic.ai/api/mcp)
- [Changelog](https://www.roic.ai/api/v2/docs/changelog)
- Tickers
  - [List Tickers](https://www.roic.ai/api/v2/docs/tickers/list)
  - [Search Tickers](https://www.roic.ai/api/v2/docs/tickers/search)
  - [List by Exchange](https://www.roic.ai/api/v2/docs/tickers/search-exchange)
- Company
  - [Company Profile](https://www.roic.ai/api/v2/docs/company/profile)
  - [Company Logo](https://www.roic.ai/api/v2/docs/company/logo)
  - [Company News](https://www.roic.ai/api/v2/docs/company/news)
- Earnings Calls
  - [Latest Transcript](https://www.roic.ai/api/v2/docs/earnings-calls/latest)
  - [List Transcripts](https://www.roic.ai/api/v2/docs/earnings-calls/list)
  - [Get Transcript](https://www.roic.ai/api/v2/docs/earnings-calls/transcript)
- Stock Prices
  - [Historical Prices](https://www.roic.ai/api/v2/docs/stock-prices/historical)
  - [Latest Price](https://www.roic.ai/api/v2/docs/stock-prices/latest)
- Stock Splits
  - [Calendar](https://www.roic.ai/api/v2/docs/stock-splits/calendar)
  - [By Ticker](https://www.roic.ai/api/v2/docs/stock-splits/by-ticker)
- Financial Statements
  - [Income Statement](https://www.roic.ai/api/v2/docs/financial-statements/income-statement)
  - [Balance Sheet](https://www.roic.ai/api/v2/docs/financial-statements/balance-sheet)
  - [Cash Flow Statement](https://www.roic.ai/api/v2/docs/financial-statements/cash-flow)
- Financial Ratios
  - [Profitability Ratios](https://www.roic.ai/api/v2/docs/financial-ratios/profitability)
  - [Credit & Debt Ratios](https://www.roic.ai/api/v2/docs/financial-ratios/credit)
  - [Liquidity Ratios](https://www.roic.ai/api/v2/docs/financial-ratios/liquidity)
  - [Working Capital Ratios](https://www.roic.ai/api/v2/docs/financial-ratios/working-capital)
  - [Yield Analysis](https://www.roic.ai/api/v2/docs/financial-ratios/yield)
- Valuation
  - [Enterprise Value](https://www.roic.ai/api/v2/docs/valuation/enterprise-value)
  - [Valuation Multiples](https://www.roic.ai/api/v2/docs/valuation/multiples)
  - [Per-Share Data](https://www.roic.ai/api/v2/docs/valuation/per-share)
- Market Data
  - [Exchanges](https://www.roic.ai/api/v2/docs/market-data/exchanges)
  - [Sectors](https://www.roic.ai/api/v2/docs/market-data/sectors)
  - [Industries](https://www.roic.ai/api/v2/docs/market-data/industries)
  - [Countries](https://www.roic.ai/api/v2/docs/market-data/countries)

Financial Data APIGetting StartedMenu

# Getting started

Ask AI Copy for LLM

Make your first ROIC.ai API call in a few minutes. By the end, you have an API key and a working request that returns financial data for a public company. The free tier needs no credit card.

The API is a REST service over HTTPS that returns JSON, so you can call it from any HTTP client, including curl, Python, and JavaScript.

## Base URL

```
https://api.roic.ai
```

Copy

Every endpoint is a `GET` request authenticated with an `apikey` query parameter. Responses are JSON by default, or TSV with `?format=excel`.

## Quickstart

Three steps take you from zero to your first response.

1

### Create your free account

[Sign up for ROIC.ai](https://roic.ai/login) — it's free and takes no credit card. Your account holds your API key and tracks your usage.

2

### Get your API key

Your key authenticates every request. Copy it below, keep it private, and never commit it to source control.

[Sign in](https://www.roic.ai/signup?internalRedirect=%2Fapi%2Fdocs%2Fauthentication) to see your API key.

For the rules that apply to your key, see the [authentication guide](https://www.roic.ai/api/v2/docs/authentication).

3

### Make your first request

Pass your key as the `apikey` query parameter on any endpoint. The example below fetches Apple's company profile. Pick your language, add your key, and run it.

cURLPythonJavaScriptRubyGoGoogle Sheets

RunCopy

```
curl "https://api.roic.ai/v2/company/profile/AAPL?apikey=YOUR_API_KEY"
```

A successful request returns `200 OK` with a JSON body. Each endpoint documents its own fields on its reference page.

## Rate limits

Every plan, including the free tier, can call every endpoint across all public companies. Plans differ only by rate limit and history depth: the free tier allows 5 requests per minute and 2 years of history, and paid plans raise both. For current numbers, see [pricing](https://roic.ai/pricing).

When you exceed your rate limit, the API returns `429 Too Many Requests`. We recommend that you retry after a short delay and cache responses you reuse.

## Connect an AI assistant

If you work in an AI coding tool or chat client, connect through the Model Context Protocol instead of making manual requests. The MCP server exposes the same financial data as tools your assistant calls directly.

```
https://mcp.roic.ai/mcp
```

Copy

See the [MCP server guide](https://www.roic.ai/api/mcp) for setup steps in Claude, Cursor, VS Code, and Codex.

## Next steps

Explore the rest of the API:

[Authentication Secure your API key and authorize every request.](https://www.roic.ai/api/v2/docs/authentication) [Company profile Look up names, sectors, and identifiers for any ticker.](https://www.roic.ai/api/v2/docs/company/profile) [MCP server Connect AI assistants to live financial data.](https://www.roic.ai/api/mcp)
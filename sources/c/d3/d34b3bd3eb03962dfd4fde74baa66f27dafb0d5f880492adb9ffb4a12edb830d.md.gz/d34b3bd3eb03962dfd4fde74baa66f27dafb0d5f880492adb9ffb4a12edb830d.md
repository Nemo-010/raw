## Navigation Menu

[](https://github.com/)

*   
Products

    *   
Platform
        *   [![Image 1](https://github.githubassets.com/assets/platform-4ce65ae0bf273ce2.png)![Image 2](https://github.githubassets.com/assets/platform-dark-ac89fbf373737ed3.png)GitHub Repository hosting, code review, and collaboration](https://github.com/platform)
        *   [![Image 3](https://github.githubassets.com/assets/copilot-e2b89335a66dba00.png)![Image 4](https://github.githubassets.com/assets/copilot-dark-2b28403b6080e898.png)Copilot AI coding agent for tasks, projects and automated work](https://github.com/features/copilot)

    *   
Build & Ship
        *   [Actions CI/CD and automation](https://github.com/features/actions)
        *   [Code Quality Quality analysis, fixes, and enforcement](https://github.com/features/code-quality)
        *   [Codespaces Cloud development environments](https://github.com/features/codespaces)

    *   
Secure
        *   [Code Security Vulnerability detection and remediation](https://github.com/security/advanced-security/code-security)
        *   [Secret Protection Secret scanning and leak prevention](https://github.com/security/advanced-security/secret-protection)

[All Features](https://github.com/features)

*   
Developers

    *   
Learn
        *   [Documentation](https://docs.github.com/en)
        *   [Training](https://learn.github.com/skills)
        *   [Certifications](https://learn.github.com/credentials)

    *   
Build
        *   [Build with Copilot](https://github.com/features/ai)
        *   [Customize Copilot](https://docs.github.com/en/copilot/how-tos/copilot-on-github/customize-copilot/customize-copilot-overview)
        *   [Integrations](https://github.com/marketplace)

    *   
Explore
        *   [Trending repos](https://github.com/trending)
        *   [GitHub Sponsors](https://github.com/open-source/sponsors)
        *   [Events](https://github.com/resources/events)

    *   
Changelog
        *   [![Image 5](https://github.githubassets.com/assets/changelog-fd687bff072883b0.png)![Image 6](https://github.githubassets.com/assets/changelog-dark-b1c25ae971bd641b.png)Changelog Your source for the latest features, improvements, and fixes across GitHub products, all in one place.](https://github.blog/changelog/)

*   
Businesses

    *   
By Stage
        *   [Enterprises](https://github.com/enterprise)
        *   [Team](https://github.com/team)
        *   [Startups](https://github.com/enterprise/startups)
        *   [Nonprofits](https://github.com/solutions/industry/nonprofits)

    *   
By Industry
        *   [Healthcare](https://github.com/solutions/industry/healthcare)
        *   [Financial services](https://github.com/solutions/industry/financial-services)
        *   [Manufacturing](https://github.com/solutions/industry/manufacturing)
        *   [Government](https://github.com/solutions/industry/government)
        *   [See all industries](https://github.com/solutions/industry)

    *   
Evaluate GitHub
        *   [Why GitHub](https://github.com/why-github)
        *   [Customer Stories](https://github.com/customer-stories)
        *   [Business insights](https://github.com/solutions/executive-insights)
        *   [Trust Center](https://github.com/trust-center)

    *   
Add-ons
        *   [GitHub Advanced Security Enterprise-grade code security](https://github.com/security/advanced-security)
        *   [Copilot for business Enterprise-grade AI features](https://github.com/features/copilot/copilot-business)
        *   [Premium Support Enterprise-grade 24/7 support](https://github.com/enterprise/premium-support)

*   
Resources

    *   
Learn & Connect
        *   [Documentation](https://docs.github.com/en)
        *   [Resource center](https://github.com/resources)
        *   [Blog](https://github.blog/)
        *   [Events & webinars](https://github.com/resources/events)
        *   [Community Forum](https://github.com/orgs/community/discussions)
        *   [Customer Stories](https://github.com/customer-stories)
        *   [Integrations](https://github.com/marketplace)

    *   
Support
        *   [Customer support](https://help.github.com/)
        *   [Training](https://learn.github.com/skills)
        *   [GitHub Status](https://www.githubstatus.com/)

    *   
Company
        *   [About](https://github.com/about)
        *   [Partners](https://github.com/partners)
        *   [Changelog](https://github.blog/changelog/)

    *   
GitHub Universe
        *   [![Image 7](https://github.githubassets.com/assets/universe-a98cd54821b27569.png)![Image 8](https://github.githubassets.com/assets/universe-a98cd54821b27569.png)GitHub Universe The event for developers, by developers — talks, workshops, and what’s next for GitHub.](https://githubuniverse.com/)

*   [Pricing](https://github.com/pricing)

Search/

[Sign in](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fairbytehq%2Fairbyte%2Fpull%2F18301)

[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=header+logged+out&ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E%2Fvoltron%2Fpull_requests_fragments%2Fpull_request_layout&source=header-repo&source_repo=airbytehq%2Fairbyte)

Appearance settings

You signed in with another tab or window. [Reload](https://github.com/airbytehq/airbyte/pull/18301) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/airbytehq/airbyte/pull/18301) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/airbytehq/airbyte/pull/18301) to refresh your session.Dismiss alert

{{ message }}

1.   [airbytehq](https://github.com/airbytehq)
2.   [airbyte](https://github.com/airbytehq/airbyte)

## Repository navigation

*   [Code](https://github.com/airbytehq/airbyte)
*   [Issues 672(672)](https://github.com/airbytehq/airbyte/issues)
*   [Pull requests 2.1k(2.1k)](https://github.com/airbytehq/airbyte/pulls)
*   [Discussions](https://github.com/airbytehq/airbyte/discussions)
*   [Actions](https://github.com/airbytehq/airbyte/actions)
*   [Projects](https://github.com/airbytehq/airbyte/projects)
*   [Security and quality 2(2)](https://github.com/airbytehq/airbyte/security)
*   [Insights](https://github.com/airbytehq/airbyte/pulse)

More items

[](https://github.com/airbytehq/airbyte)

# 🎉 New Source: News API - #18301

#18301

Merged

[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)merged 12 commits into

[airbytehq:master](https://github.com/airbytehq/airbyte/tree/master)airbytehq/airbyte:master from 

[isaacharrisholt:news_api](https://github.com/isaacharrisholt/airbyte/tree/news_api)isaacharrisholt/airbyte:news_api Copy head branch name to clipboard

Oct 27, 2022

+895-1 Lines changed: 895 additions & 1 deletion

[Conversation 38(38)](https://github.com/airbytehq/airbyte/pull/18301)[Commits 12(12)](https://github.com/airbytehq/airbyte/pull/18301/commits)[Checks 0(0)](https://github.com/airbytehq/airbyte/pull/18301/checks)[Files changed 27(27)](https://github.com/airbytehq/airbyte/pull/18301/files)

Merged

## [🎉 New Source: News API](https://github.com/airbytehq/airbyte/pull/18301#top)#18301

[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)merged 12 commits into

[airbytehq:master](https://github.com/airbytehq/airbyte/tree/master)airbytehq/airbyte:master from 

[isaacharrisholt:news_api](https://github.com/isaacharrisholt/airbyte/tree/news_api)isaacharrisholt/airbyte:news_api Copy head branch name to clipboard

## Conversation

[![Image 9: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=80&v=4)](https://github.com/isaacharrisholt)

### ![Image 10: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=48&v=4)**[Isaac Harris-Holt (isaacharrisholt)](https://github.com/isaacharrisholt)** commented [Oct 21, 2022](https://github.com/airbytehq/airbyte/pull/18301#issue-1418486155)

 Copy link  Copy Markdown 

Contributor

## What

Many companies analyse news data to make decisions, and News API is one of the largest providers of news data available. It would be useful to have this data available to Airbyte.

## How

Adds a News API source with the following streams:

*   `everything`
*   `top_headlines`

## Recommended reading order

1.   `news_api.yaml`
2.   `spec.yaml`

## 🚨 User Impact 🚨

No changes to existing code.

## Pre-merge Checklist

Expand the relevant checklist and delete the others.

**New Connector**
### Community member or Airbyter

*   - [x] **Community member?** Grant edit access to maintainers ([instructions](https://docs.github.com/en/github/collaborating-with-pull-requests/working-with-forks/allowing-changes-to-a-pull-request-branch-created-from-a-fork#enabling-repository-maintainer-permissions-on-existing-pull-requests))
*   - [x]  Secrets in the connector's spec are annotated with `airbyte_secret`
*   - [x]  Unit & integration tests added and passing. Community members, please provide proof of success locally e.g: screenshot or copy-paste unit, integration, and acceptance test output. To run acceptance tests for a Python connector, follow instructions in the README. For java connectors run `./gradlew :airbyte-integrations:connectors:<name>:integrationTest`.
*   - [x]  Code reviews completed
*   - [x]  Documentation updated 
    *   - [x]  Connector's `README.md`
    *   - [x]  Connector's `bootstrap.md`. See [description and examples](https://docs.google.com/document/d/1ypdgmwmEHWv-TrO4_YOQ7pAJGVrMp5BOkEVh831N260/edit?usp=sharing)
    *   - [x] `docs/integrations/<source or destination>/<name>.md` including changelog. See changelog [example](https://docs.airbyte.io/integrations/sources/stripe#changelog)
    *   - [x] `docs/integrations/README.md`
    *   - [x] `airbyte-integrations/builds.md`

*   - [x]  PR name follows [PR naming conventions](https://docs.airbyte.com/contributing-to-airbyte/issues-and-pull-requests)

### Airbyter

If this is a community PR, the Airbyte engineer reviewing this PR is responsible for the below items.

*   - [x]  Create a non-forked branch based on this PR and test the below items on it
*   - [x]  Build is successful
*   - [x]  If new credentials are required for use in CI, add them to GSM. [Instructions](https://docs.airbyte.io/connector-development#using-credentials-in-ci).
*   - [x] [`/test connector=connectors/<name>` command](https://docs.airbyte.io/connector-development#updating-an-existing-connector) is passing
*   - [x]  New Connector version released on Dockerhub by running the `/publish` command described [here](https://docs.airbyte.io/connector-development#updating-an-existing-connector)
*   - [x]  After the connector is published, connector added to connector index as described [here](https://docs.airbyte.io/connector-development#publishing-a-connector)
*   - [x]  Seed specs have been re-generated by building the platform and committing the changes to the seed spec files, as described [here](https://docs.airbyte.io/connector-development#publishing-a-connector)

## Tests

**Unit**
None.

**Integration**
[![Image 11: image](https://user-images.githubusercontent.com/47423046/197228609-322bacc4-a6a3-4a9d-9531-5631a2df1d31.png)](https://user-images.githubusercontent.com/47423046/197228609-322bacc4-a6a3-4a9d-9531-5631a2df1d31.png)

**Acceptance**
[![Image 12: image](https://user-images.githubusercontent.com/47423046/197228545-33bcaf89-f0eb-4b86-8148-536a05cb7855.png)](https://user-images.githubusercontent.com/47423046/197228545-33bcaf89-f0eb-4b86-8148-536a05cb7855.png)

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

All reactions

[Isaac Harris-Holt (isaacharrisholt)](https://github.com/isaacharrisholt) added 2 commits [October 21, 2022 14:48](https://github.com/airbytehq/airbyte/pull/18301#commits-pushed-dc874f9)

[![Image 13: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&v=4)](https://github.com/isaacharrisholt)

```
Initial commit
```

```
dc874f9
```

[![Image 14: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&v=4)](https://github.com/isaacharrisholt)

```
Add streams
```

```
bfa7731
```

[![Image 15: @github-actions](https://avatars.githubusercontent.com/in/15368?s=40&v=4)](https://github.com/apps/github-actions)[github-actions](https://github.com/apps/github-actions)Bot added the [area/connectors](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Aarea%2Fconnectors)Connector related issues label [Oct 21, 2022](https://github.com/airbytehq/airbyte/pull/18301#event-7641560563)

[Isaac Harris-Holt (isaacharrisholt)](https://github.com/isaacharrisholt)and others added 3 commits [October 21, 2022 19:33](https://github.com/airbytehq/airbyte/pull/18301#commits-pushed-b794938)

[![Image 16: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&v=4)](https://github.com/isaacharrisholt)

```
Merge branch 'master' into news_api
```

```
b794938
```

[![Image 17: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&v=4)](https://github.com/isaacharrisholt)

```
Simplify using options in request_parameters
```

```
ba58a75
```

[![Image 18: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&v=4)](https://github.com/isaacharrisholt)

```
Merge branch 'master' into news_api
```

Verified

# Verified

 This commit was created on GitHub.com and signed with GitHub’s **verified signature**. The key has expired. 

GPG key ID: 4AEE18F83AFDEB23

Expired

Verified 

[Learn about vigilant mode](https://docs.github.com/github/authenticating-to-github/displaying-verification-statuses-for-all-of-your-commits)

```
1dd939f
```

[![Image 19: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=40&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)[M. Marx (marcosmarxm)](https://github.com/marcosmarxm) added [community](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Acommunity)[hacktober](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Ahacktober) labels [Oct 24, 2022](https://github.com/airbytehq/airbyte/pull/18301#event-7656063009)

[![Image 20: marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=60&v=4)](https://github.com/marcosmarxm)

**[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** suggested changes [Oct 24, 2022](https://github.com/airbytehq/airbyte/pull/18301#pullrequestreview-1153693155)

[View reviewed changes](https://github.com/airbytehq/airbyte/pull/18301/files/1dd939fab8b6d59eab8f7b30f60a30733d0758c1)

Comment thread[airbyte-integrations/connectors/source-news-api/source_news_api/spec.yaml](https://github.com/airbytehq/airbyte/pull/18301/files/1dd939fab8b6d59eab8f7b30f60a30733d0758c1#diff-0a70d11e604a52d49210faa8f53b81994cef1bad76da24d7a96ac1bbb6e54872) Resolved 

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

Comment thread[airbyte-integrations/connectors/source-news-api/source_news_api/spec.yaml](https://github.com/airbytehq/airbyte/pull/18301/files/1dd939fab8b6d59eab8f7b30f60a30733d0758c1#diff-0a70d11e604a52d49210faa8f53b81994cef1bad76da24d7a96ac1bbb6e54872) Resolved 

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

Comment thread[airbyte-integrations/connectors/source-news-api/source_news_api/spec.yaml](https://github.com/airbytehq/airbyte/pull/18301/files/1dd939fab8b6d59eab8f7b30f60a30733d0758c1#diff-0a70d11e604a52d49210faa8f53b81994cef1bad76da24d7a96ac1bbb6e54872)

description: API Key
airbyte_secret: true
order: 0
search_query:

### ![Image 21: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=48&v=4)**[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)**[Oct 24, 2022](https://github.com/airbytehq/airbyte/pull/18301#discussion_r1003693944)

 Copy link  Copy Markdown 

Contributor

There was a problem hiding this comment.

### Choose a reason for hiding this comment

The reason will be displayed to describe this comment to others. [Learn more](https://docs.github.com/articles/managing-disruptive-comments/#hiding-a-comment).

Hide comment

this shouldn't be called `terms`?

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

All reactions

### ![Image 22: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=48&v=4)**[Isaac Harris-Holt (isaacharrisholt)](https://github.com/isaacharrisholt)**[Oct 24, 2022](https://github.com/airbytehq/airbyte/pull/18301#discussion_r1003714512)

 Copy link  Copy Markdown 

Contributor Author

There was a problem hiding this comment.

### Choose a reason for hiding this comment

The reason will be displayed to describe this comment to others. [Learn more](https://docs.github.com/articles/managing-disruptive-comments/#hiding-a-comment).

Hide comment

I think `query` works better, as it allows for boolean operators within the query. Will add an example in the `sample_config`

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

All reactions

### ![Image 23: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=48&v=4)**[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)**[Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#discussion_r1004939807)

 Copy link  Copy Markdown 

Contributor

There was a problem hiding this comment.

### Choose a reason for hiding this comment

The reason will be displayed to describe this comment to others. [Learn more](https://docs.github.com/articles/managing-disruptive-comments/#hiding-a-comment).

Hide comment

Can you add the example in the examples?

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

All reactions

### ![Image 24: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=48&v=4)**[Isaac Harris-Holt (isaacharrisholt)](https://github.com/isaacharrisholt)**[Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#discussion_r1004976941)

 Copy link  Copy Markdown 

Contributor Author

There was a problem hiding this comment.

### Choose a reason for hiding this comment

The reason will be displayed to describe this comment to others. [Learn more](https://docs.github.com/articles/managing-disruptive-comments/#hiding-a-comment).

Hide comment

Done!

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

All reactions

Comment thread[airbyte-integrations/connectors/source-news-api/source_news_api/news_api.yaml](https://github.com/airbytehq/airbyte/pull/18301/files/1dd939fab8b6d59eab8f7b30f60a30733d0758c1#diff-0868ba19c8d6869151442a79b09e94f5b9fe76efa5d1f865ee1522ed714de65c) Resolved 

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

Comment thread[airbyte-integrations/connectors/source-news-api/source_news_api/news_api.yaml](https://github.com/airbytehq/airbyte/pull/18301/files/1dd939fab8b6d59eab8f7b30f60a30733d0758c1#diff-0868ba19c8d6869151442a79b09e94f5b9fe76efa5d1f865ee1522ed714de65c) Resolved 

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

Comment thread[airbyte-integrations/connectors/source-news-api/source_news_api/spec.yaml](https://github.com/airbytehq/airbyte/pull/18301/files/1dd939fab8b6d59eab8f7b30f60a30733d0758c1#diff-0a70d11e604a52d49210faa8f53b81994cef1bad76da24d7a96ac1bbb6e54872) Resolved 

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

Comment thread[airbyte-integrations/connectors/source-news-api/source_news_api/spec.yaml](https://github.com/airbytehq/airbyte/pull/18301/files/1dd939fab8b6d59eab8f7b30f60a30733d0758c1#diff-0a70d11e604a52d49210faa8f53b81994cef1bad76da24d7a96ac1bbb6e54872) Resolved 

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

Comment thread[airbyte-integrations/connectors/source-news-api/source_news_api/news_api.yaml](https://github.com/airbytehq/airbyte/pull/18301/files/1dd939fab8b6d59eab8f7b30f60a30733d0758c1#diff-0868ba19c8d6869151442a79b09e94f5b9fe76efa5d1f865ee1522ed714de65c) Resolved 

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

Comment thread[airbyte-integrations/connectors/source-news-api/source_news_api/spec.yaml](https://github.com/airbytehq/airbyte/pull/18301/files/1dd939fab8b6d59eab8f7b30f60a30733d0758c1#diff-0a70d11e604a52d49210faa8f53b81994cef1bad76da24d7a96ac1bbb6e54872) Resolved 

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 25: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&v=4)](https://github.com/isaacharrisholt)

```
Address comments
```

```
6f4a6fe
```

[![Image 26: @bleonard](https://avatars.githubusercontent.com/u/36106?s=40&v=4)](https://github.com/bleonard)[Brian Leonard (bleonard)](https://github.com/bleonard) added [bounty](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Abounty)[connectors/source/news-api](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Aconnectors%2Fsource%2Fnews-api) labels [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#event-7658854862)

[![Image 27: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&v=4)](https://github.com/isaacharrisholt)

```
Add examples to query
```

```
75657bb
```

[![Image 28: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=80&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)

### **[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** commented [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1291168335)•

 edited 

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

 Copy link  Copy Markdown 

Contributor

[Isaac Harris-Holt (@isaacharrisholt)](https://github.com/isaacharrisholt) Im having some issues running tests:

```
{"type": "DEBUG", "message": "Receiving response", 
"data": {"headers": "{'Date': 'Tue, 25 Oct 2022 21:31:00 GMT', 'Content-Type': 'application/json; charset=utf-8', 
'Content-Length': '255', 'Connection': 'keep-alive', 'Cache-Control': 'no-cache', 'Pragma': 'no-cache',
 'Expires': '-1', 'X-Cached-Result': 'false', 'CF-Cache-Status': 'DYNAMIC', 'Report-To': '{\"endpoints\":
[{\"url\":\"https:\\\\/\\\\/a.nel.cloudflare.com\\\\/report\\\\/v3?s=fUcX8aNhbgWaoPCObCDq1S22sWRe8h2Bw9JEiJUiKcDOZOvdEsfnxqnjKX0sdBxrLw3TsGGLbR5FXO1
CGHkH7Pyi6jPWjE%2BBmMQHNxyrdA1%2BNEzQJpBgfQl3ya0N\"}],\"group\":\"cf-nel\",\"max_age\":604800}', 
'NEL': '{\"success_fraction\":0,\"report_to\":\"cf-nel\",\"max_age\":604800}', 'Server': 'cloudflare', 'CF-RAY': 
'75fe0e7ce9899510-JOI'}", "body": "{\"status\":\"error\",\"code\":\"maximumResultsReached\",\"message\":\
"You have requested too many results. Developer accounts are limited to a max of 100 results. 
You are trying to request results 90 to 180. Please upgrade to a paid plan if you need more results.\"}", 
"status": "426"}}
```

All reactions

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 29: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=80&u=2f967bd888efd962f41319abb72cc4c9a347a147&v=4)](https://github.com/isaacharrisholt)

### **[Isaac Harris-Holt (isaacharrisholt)](https://github.com/isaacharrisholt)** commented [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1291170075)

 Copy link  Copy Markdown 

Contributor Author

[M. Marx (@marcosmarxm)](https://github.com/marcosmarxm) I had to set the start time to within the last 2 hours. This is only a limitation of the free plan. I will add a note to the docs.

All reactions

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 30: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=80&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)

### **[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** commented [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1291170247)

 Copy link  Copy Markdown 

Contributor

The free tier is limited to 100 request per day, basically one page. Maybe add a parameter to select: free tier?

All reactions

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 31: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=80&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)

### **[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** commented [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1291171185)

 Copy link  Copy Markdown 

Contributor

[Alexandre Girard (@girarda)](https://github.com/girarda) any idea how to solve this? Can we add a logic when the API returns error 426 to stop the sync?

All reactions

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 32: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=80&u=2f967bd888efd962f41319abb72cc4c9a347a147&v=4)](https://github.com/isaacharrisholt)

### **[Isaac Harris-Holt (isaacharrisholt)](https://github.com/isaacharrisholt)** commented [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1291171782)

 Copy link  Copy Markdown 

Contributor Author

I think the best solution for this source is just to recommend that it's not used with a free tier key.

All reactions

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 33: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=80&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)

### **[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** commented [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1291175192)

 Copy link  Copy Markdown 

Contributor

Just an update, I was only able to retrieve data using:

undefinedyaml
    authenticator:
      type: "ApiKeyAuthenticator"
      header: "x-api-key"
      api_token: "{{ config['api_key'] }}"
undefined

All reactions

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 34: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=80&u=2f967bd888efd962f41319abb72cc4c9a347a147&v=4)](https://github.com/isaacharrisholt)

### **[Isaac Harris-Holt (isaacharrisholt)](https://github.com/isaacharrisholt)** commented [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1291176620)

 Copy link  Copy Markdown 

Contributor Author

> Just an update, I was only able to retrieve data using:
> 
> 
> 
> undefinedyaml
>     authenticator:
>       type: "ApiKeyAuthenticator"
>       header: "x-api-key"
>       api_token: "{{ config['api_key'] }}"
> undefined

That's strange. Does this allow more than 100 data points to be collected?

All reactions

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 35: marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=60&v=4)](https://github.com/marcosmarxm)

**[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** suggested changes [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#pullrequestreview-1155543670)

[View reviewed changes](https://github.com/airbytehq/airbyte/pull/18301/files/75657bb64324ea52a33464e67b8f64a86cb6d89c)

### ![Image 36: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=48&v=4)**[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** left a comment

 Copy link  Copy Markdown 

Contributor

[](https://github.com/airbytehq/airbyte/pull/18301#pullrequestreview-1155543670)

There was a problem hiding this comment.

### Choose a reason for hiding this comment

The reason will be displayed to describe this comment to others. [Learn more](https://docs.github.com/articles/managing-disruptive-comments/#hiding-a-comment).

Hide comment

[Isaac Harris-Holt (@isaacharrisholt)](https://github.com/isaacharrisholt) i think we can continue with the connector but can you add the documentation for this connector? Probably will add some comments about the usage.

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

All reactions

[![Image 37: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=80&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)

### **[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** commented [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1291178136)

 Copy link  Copy Markdown 

Contributor

> > Just an update, I was only able to retrieve data using:
> > 
> > 
> > 
> > undefinedyaml
> >     authenticator:
> >       type: "ApiKeyAuthenticator"
> >       header: "x-api-key"
> >       api_token: "{{ config['api_key'] }}"
> > undefined
> 
> 
> That's strange. Does this allow more than 100 data points to be collected?

No, but using it I was able to use my API key. Using the Bearer method was failing.

All reactions

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 38: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&v=4)](https://github.com/isaacharrisholt)

```
Add docs
```

```
3c5d1be
```

[![Image 39: @github-actions](https://avatars.githubusercontent.com/in/15368?s=40&v=4)](https://github.com/apps/github-actions)[github-actions](https://github.com/apps/github-actions)Bot added the [area/documentation](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Aarea%2Fdocumentation)Improvements or additions to documentation label [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#event-7667462966)

[![Image 40: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&v=4)](https://github.com/isaacharrisholt)

```
Change authenticator to ApiKeyAuthenticator
```

```
5de2c5b
```

[![Image 41: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=80&u=2f967bd888efd962f41319abb72cc4c9a347a147&v=4)](https://github.com/isaacharrisholt)

### **[Isaac Harris-Holt (isaacharrisholt)](https://github.com/isaacharrisholt)** commented [Oct 25, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1291182137)

 Copy link  Copy Markdown 

Contributor Author

[M. Marx (@marcosmarxm)](https://github.com/marcosmarxm) added docs and changed the authenticator type.

All reactions

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[M. Marx (marcosmarxm)](https://github.com/marcosmarxm) added 2 commits [October 26, 2022 21:16](https://github.com/airbytehq/airbyte/pull/18301#commits-pushed-7985853)

[![Image 42: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=40&v=4)](https://github.com/marcosmarxm)

```
add seed config
```

```
7985853
```

[![Image 43: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=40&v=4)](https://github.com/marcosmarxm)

```
remove icon
```

```
1a9b432
```

[![Image 44: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=80&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)

### **[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** commented [Oct 27, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1292802480)•

 edited by github-actions Bot

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

 Copy link  Copy Markdown 

Contributor

/test connector=connectors/source-news-api

> 🕑 connectors/source-news-api [https://github.com/airbytehq/airbyte/actions/runs/3333520211](https://github.com/airbytehq/airbyte/actions/runs/3333520211)  
>  ✅ connectors/source-news-api [https://github.com/airbytehq/airbyte/actions/runs/3333520211](https://github.com/airbytehq/airbyte/actions/runs/3333520211)  
>  Python tests coverage:

```
Name                                                 Stmts   Miss  Cover   Missing
	 ----------------------------------------------------------------------------------
	 source_acceptance_test/base.py                          10      4    60%   15-18
	 source_acceptance_test/config.py                        83      6    93%   78-80, 84-86
	 source_acceptance_test/conftest.py                     164    164     0%   6-282
	 source_acceptance_test/plugin.py                        48     48     0%   6-104
	 source_acceptance_test/tests/test_core.py              329    111    66%   39, 50-58, 63-70, 74-75, 79-80, 164, 202-219, 228-236, 240-245, 251, 284-289, 327-334, 377-379, 382, 442-451, 480-481, 487, 490, 523-533, 546-571, 576-580
	 source_acceptance_test/tests/test_incremental.py       145     20    86%   21-23, 29-31, 36-43, 48-61, 224
	 source_acceptance_test/utils/asserts.py                 37      2    95%   57-58
	 source_acceptance_test/utils/common.py                  77     10    87%   15-16, 24-30, 64, 67
	 source_acceptance_test/utils/compare.py                 62     23    63%   21-51, 68, 97-99
	 source_acceptance_test/utils/connector_runner.py       112     50    55%   23-26, 32, 36, 39-68, 71-73, 76-78, 81-83, 86-88, 91-93, 96-114, 148-150
	 source_acceptance_test/utils/json_schema_helper.py     105     13    88%   30-31, 38, 41, 65-68, 96, 120, 190-192
	 ----------------------------------------------------------------------------------
	 TOTAL                                                 1351    451    67%
```

### Build Passed

Test summary info:

```
=========================== short test summary info ============================
SKIPPED [1] ../usr/local/lib/python3.9/site-packages/source_acceptance_test/plugin.py:60: Skipping TestIncremental.test_two_sequential_reads because not found in the config
SKIPPED [1] ../usr/local/lib/python3.9/site-packages/source_acceptance_test/tests/test_core.py:51: The previous connector image could not be retrieved.
SKIPPED [1] ../usr/local/lib/python3.9/site-packages/source_acceptance_test/tests/test_core.py:229: The previous connector image could not be retrieved.
======================== 24 passed, 3 skipped in 21.97s ========================
```

![Image 45: rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)1 github-actions[bot] reacted with rocket emoji![Image 46: eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)1 github-actions[bot] reacted with eyes emoji

All reactions
*   ![Image 47: rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)1 reaction
*   ![Image 48: eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)1 reaction

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 49: marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=60&v=4)](https://github.com/marcosmarxm)

**[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** approved these changes [Oct 27, 2022](https://github.com/airbytehq/airbyte/pull/18301#pullrequestreview-1157430526)

[View reviewed changes](https://github.com/airbytehq/airbyte/pull/18301/files/1a9b432d9c24f21410fb51a24c186848b98214d5)

### ![Image 50: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=48&v=4)**[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** left a comment

 Copy link  Copy Markdown 

Contributor

[](https://github.com/airbytehq/airbyte/pull/18301#pullrequestreview-1157430526)

There was a problem hiding this comment.

### Choose a reason for hiding this comment

The reason will be displayed to describe this comment to others. [Learn more](https://docs.github.com/articles/managing-disruptive-comments/#hiding-a-comment).

Hide comment

congrats [Isaac Harris-Holt (@isaacharrisholt)](https://github.com/isaacharrisholt)

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

All reactions

 15 hidden items  Load more… 

[![Image 51: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=80&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)

### **[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** commented [Oct 27, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1292811745)•

 edited by github-actions Bot

Loading

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

 Copy link  Copy Markdown 

Contributor

/publish connector=connectors/source-news-api

> 🕑 Publishing the following connectors:  
> connectors/source-news-api  
> [https://github.com/airbytehq/airbyte/actions/runs/3333590616](https://github.com/airbytehq/airbyte/actions/runs/3333590616)

  

| Connector | Did it publish? | Were definitions generated? |
| --- | --- | --- |
| connectors/source-news-api | ✅ | ✅ |
  

if you have connectors that successfully published but failed definition generation, follow [step 4 here ▶️](https://docs.airbyte.com/connector-development/#publishing-a-connector)

![Image 52: rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)1 github-actions[bot] reacted with rocket emoji![Image 53: eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)1 github-actions[bot] reacted with eyes emoji

All reactions
*   ![Image 54: rocket](https://github.githubassets.com/assets/1f680-d0ef47fdb515.png)1 reaction
*   ![Image 55: eyes](https://github.githubassets.com/assets/1f440-ee44e91e92a7.png)1 reaction

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 56: @octavia-squidington-iii](https://avatars.githubusercontent.com/u/90398440?s=40&v=4)](https://github.com/octavia-squidington-iii)

```
auto-bump connector version
```

```
2f73bc9
```

[![Image 57: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=80&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)

### **[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)** commented [Oct 27, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1292828928)

 Copy link  Copy Markdown 

Contributor

[Chris "Sean" Dabatos (@RealChrisSean)](https://github.com/RealChrisSean) check this one :)

All reactions

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 58: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=40&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)

[M. Marx (marcosmarxm)](https://github.com/marcosmarxm) merged commit [`84c7ff9`](https://github.com/airbytehq/airbyte/commit/84c7ff9cf50cf653bcedf4b186cbc09022eb6d67) into airbytehq:master[Oct 27, 2022](https://github.com/airbytehq/airbyte/pull/18301#event-7677855499)

[![Image 59: @RealChrisSean](https://avatars.githubusercontent.com/u/28903572?s=80&u=149e9f0e4ae4b9ad81ee6931eb0f33bcdecdd0d7&v=4)](https://github.com/RealChrisSean)

### **[Chris "Sean" Dabatos (RealChrisSean)](https://github.com/RealChrisSean)** commented [Oct 27, 2022](https://github.com/airbytehq/airbyte/pull/18301#issuecomment-1292840007)

 Copy link  Copy Markdown 

Amazing!!!

All reactions

Sorry, something went wrong.

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

[![Image 60: @RealChrisSean](https://avatars.githubusercontent.com/u/28903572?s=40&u=149e9f0e4ae4b9ad81ee6931eb0f33bcdecdd0d7&v=4)](https://github.com/RealChrisSean)[Chris "Sean" Dabatos (RealChrisSean)](https://github.com/RealChrisSean) mentioned this pull request [Oct 27, 2022](https://github.com/airbytehq/airbyte/pull/18301#ref-issue-1424885514)

[New Source: News API airbytehq/connector-contest#204](https://github.com/airbytehq/connector-contest/issues/204)

 Closed 

[Johan Hammarstedt (jhammarstedt)](https://github.com/jhammarstedt) pushed a commit to jhammarstedt/airbyte that referenced this pull request [Oct 31, 2022](https://github.com/airbytehq/airbyte/pull/18301#ref-commit-af768a1)

[![Image 61: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&u=2f967bd888efd962f41319abb72cc4c9a347a147&v=4)](https://github.com/isaacharrisholt)[![Image 62: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=40&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)[![Image 63: @octavia-squidington-iii](https://avatars.githubusercontent.com/u/90398440?s=40&u=f2a050a797352898912fdea1a3f6f157393dc340&v=4)](https://github.com/octavia-squidington-iii)[![Image 64: @jhammarstedt](https://avatars.githubusercontent.com/u/52280124?s=40&v=4)](https://github.com/jhammarstedt)

```
🎉 New Source: News API (airbytehq#18301)
```
…

```
af768a1
```

* Initial commit

* Add streams

* Simplify using options in request_parameters

* Address comments

* Add examples to query

* Add docs

* Change authenticator to ApiKeyAuthenticator

* add seed config

* remove icon

* auto-bump connector version

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

[![Image 65: @sajarin](https://avatars.githubusercontent.com/u/15092743?s=40&u=2f82f1c0850e51f6e682e11039e83bba8f11a33a&v=4)](https://github.com/sajarin)[Sajarin (sajarin)](https://github.com/sajarin) added [internal](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Ainternal) and removed [bounty](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Abounty) labels [Oct 31, 2022](https://github.com/airbytehq/airbyte/pull/18301#event-7706480580)

[![Image 66: @octavia-squidington-iii](https://avatars.githubusercontent.com/u/90398440?s=40&v=4)](https://github.com/octavia-squidington-iii)[Octavia Squidington III (octavia-squidington-iii)](https://github.com/octavia-squidington-iii) mentioned this pull request [Nov 1, 2022](https://github.com/airbytehq/airbyte/pull/18301#ref-pullrequest-1432242273)

[Bump Airbyte version from 0.40.17 to 0.40.18 #18827](https://github.com/airbytehq/airbyte/pull/18827)

 Merged 

[Nataly Merezhuk (natalyjazzviolin)](https://github.com/natalyjazzviolin) pushed a commit that referenced this pull request [Nov 3, 2022](https://github.com/airbytehq/airbyte/pull/18301#ref-commit-ae45a8b)

[![Image 67: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&u=2f967bd888efd962f41319abb72cc4c9a347a147&v=4)](https://github.com/isaacharrisholt)[![Image 68: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=40&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)[![Image 69: @octavia-squidington-iii](https://avatars.githubusercontent.com/u/90398440?s=40&u=f2a050a797352898912fdea1a3f6f157393dc340&v=4)](https://github.com/octavia-squidington-iii)![Image 70: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)

```
🎉 New Source: News API (#18301)
```
…

```
ae45a8b
```

* Initial commit

* Add streams

* Simplify using options in request_parameters

* Address comments

* Add examples to query

* Add docs

* Change authenticator to ApiKeyAuthenticator

* add seed config

* remove icon

* auto-bump connector version

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

[Alexandros Milaios (am6010)](https://github.com/am6010) referenced this pull request in rudderlabs/airbyte [Nov 10, 2022](https://github.com/airbytehq/airbyte/pull/18301#ref-commit-221e7d4)

[![Image 71: @am6010](https://avatars.githubusercontent.com/u/1304376?s=40&u=03a9a7b1f0f441908db4d8a20bee1c01ac28d95c&v=4)](https://github.com/am6010)![Image 72: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 73: @gosusnp](https://avatars.githubusercontent.com/u/1142800?s=40&v=4)](https://github.com/gosusnp)[![Image 74: @edgao](https://avatars.githubusercontent.com/u/5741425?s=40&u=c25d3e6414dd8d7a9988019d558b4807dc52bb6d&v=4)](https://github.com/edgao)[![Image 75: @octavia-squidington-iii](https://avatars.githubusercontent.com/u/90398440?s=40&u=f2a050a797352898912fdea1a3f6f157393dc340&v=4)](https://github.com/octavia-squidington-iii)[![Image 76: @girarda](https://avatars.githubusercontent.com/u/1451943?s=40&u=22d6f56670594e5eb489ee30e2eed98660728a09&v=4)](https://github.com/girarda)![Image 77: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)![Image 78: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 79: @midavadim](https://avatars.githubusercontent.com/u/3889748?s=40&u=abda86c8fd0dedc8079a0dca30ab90d5fc47619b&v=4)](https://github.com/midavadim)[![Image 80: @alovew](https://avatars.githubusercontent.com/u/102554163?s=40&v=4)](https://github.com/alovew)[![Image 81: @ryankfu](https://avatars.githubusercontent.com/u/108309971?s=40&v=4)](https://github.com/ryankfu)[![Image 82: @sarafonseca-123](https://avatars.githubusercontent.com/u/56175551?s=40&u=fa4b503be7bad092b4e31aae92ba755d804aaa51&v=4)](https://github.com/sarafonseca-123)[![Image 83: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=40&u=65f6e01395ecc4613e6a602aea702aa758e311bc&v=4)](https://github.com/marcosmarxm)[![Image 84: @grubberr](https://avatars.githubusercontent.com/u/195743?s=40&v=4)](https://github.com/grubberr)[![Image 85: @alafanechere](https://avatars.githubusercontent.com/u/5551758?s=40&u=bfa6b4d8a62a49d0861c5936fa27e29c97f76da6&v=4)](https://github.com/alafanechere)[![Image 86: @dizel852](https://avatars.githubusercontent.com/u/20929344?s=40&u=ee50184f78e546b4df96dcd4880cd12cf3c706b1&v=4)](https://github.com/dizel852)![Image 87: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 88: @xpuska513](https://avatars.githubusercontent.com/u/12461442?s=40&u=79a0dfe8be330f0d3943155cc5cd408e612cf71e&v=4)](https://github.com/xpuska513)[![Image 89: @github-actions](https://avatars.githubusercontent.com/in/15368?s=40&v=4)](https://github.com/apps/github-actions)[![Image 90: @colesnodgrass](https://avatars.githubusercontent.com/u/143818?s=40&u=2547540555884d06db6870452f14f08f43f7a743&v=4)](https://github.com/colesnodgrass)[![Image 91: @tkorenko](https://avatars.githubusercontent.com/u/14890403?s=40&v=4)](https://github.com/tkorenko)![Image 92: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 93: @etsybaev](https://avatars.githubusercontent.com/u/4688354?s=40&u=9f20f8c1d65bd8cb55abb3d4f05e0b9c0bda6aea&v=4)](https://github.com/etsybaev)[![Image 94: @antonioneto-hotmart](https://avatars.githubusercontent.com/u/91587245?s=40&v=4)](https://github.com/antonioneto-hotmart)![Image 95: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 96: @mutt-santiago-stachuk](https://avatars.githubusercontent.com/u/106173005?s=40&u=ba7a1b34cba02bb04b180f5b9fde440384390f72&v=4)](https://github.com/mutt-santiago-stachuk)![Image 97: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 98: @arsenlosenko](https://avatars.githubusercontent.com/u/20901439?s=40&u=06774c02334b3d1475173672b7f3d9350683ff9c&v=4)](https://github.com/arsenlosenko)[![Image 99: @nipunn1313](https://avatars.githubusercontent.com/u/1300387?s=40&u=118989a960fdb430a40a6f10c5c4b3c8606e5846&v=4)](https://github.com/nipunn1313)![Image 100: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 101: @malikdiarra](https://avatars.githubusercontent.com/u/1311748?s=40&u=d819a054ec9bcde281fb5f838313600f39b987f5&v=4)](https://github.com/malikdiarra)[![Image 102: @terencecho](https://avatars.githubusercontent.com/u/3916587?s=40&u=f57560051a932a4bb0eef18336c87952fee94cc9&v=4)](https://github.com/terencecho)[![Image 103: @benmoriceau](https://avatars.githubusercontent.com/u/6792130?s=40&v=4)](https://github.com/benmoriceau)[![Image 104: @lmossman](https://avatars.githubusercontent.com/u/22731524?s=40&u=345358478fea8b3a908f74eceb252d9b7e40481d&v=4)](https://github.com/lmossman)[![Image 105: @davydov-d](https://avatars.githubusercontent.com/u/7703835?s=40&u=633c4a70d299d69fe2266f404602f8df83b64fe9&v=4)](https://github.com/davydov-d)[![Image 106: @artem1205](https://avatars.githubusercontent.com/u/36314070?s=40&v=4)](https://github.com/artem1205)[![Image 107: @pinikeizman](https://avatars.githubusercontent.com/u/43240341?s=40&u=4c745f99ca1875d18106340c0b382e5adfd13be8&v=4)](https://github.com/pinikeizman)[![Image 108: @Amruta-Ranade](https://avatars.githubusercontent.com/u/11484018?s=40&v=4)](https://github.com/Amruta-Ranade)[![Image 109: @tybernstein](https://avatars.githubusercontent.com/u/104733644?s=40&u=66260026573fb42eb3098a9f42b55e4197c196d0&v=4)](https://github.com/tybernstein)[![Image 110: @sherifnada](https://avatars.githubusercontent.com/u/6246757?s=40&u=25947b738001fb02b38104c3e65456060f0f423b&v=4)](https://github.com/sherifnada)[![Image 111: @Terieyenike](https://avatars.githubusercontent.com/u/25850598?s=40&u=d680a65639c14532024da3fff7c00ab446576803&v=4)](https://github.com/Terieyenike)[![Image 112: @PragatiVerma18](https://avatars.githubusercontent.com/u/42115530?s=40&u=1b97a1f1f07636c46bff0956e31804b08b397991&v=4)](https://github.com/PragatiVerma18)[![Image 113: @sblaizerwize](https://avatars.githubusercontent.com/u/56137084?s=40&u=3f1e81a4e74f1fcaf44f0f90f37b768e5c853c79&v=4)](https://github.com/sblaizerwize)[![Image 114: @Jagrutiti](https://avatars.githubusercontent.com/u/28809492?s=40&u=60d1f089ffbd0d03b6e2d105deb8836b76bb0baa&v=4)](https://github.com/Jagrutiti)[![Image 115: @subhamX](https://avatars.githubusercontent.com/u/43654114?s=40&u=aa7d2e9ee6a9533cab879cbfb6f418d5eff78a1f&v=4)](https://github.com/subhamX)[![Image 116: @wfouche](https://avatars.githubusercontent.com/u/13682850?s=40&v=4)](https://github.com/wfouche)[![Image 117: @sophia-wiley](https://avatars.githubusercontent.com/u/106352739?s=40&u=4ffcdaa207a43a776c41d5d3b6ce55717649dc46&v=4)](https://github.com/sophia-wiley)![Image 118: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 119: @akashkulk](https://avatars.githubusercontent.com/u/113392464?s=40&u=47ff53db6c2eb6b90e29dafe669d967a8e7cf4a7&v=4)](https://github.com/akashkulk)[![Image 120: @N-o-Z](https://avatars.githubusercontent.com/u/3787958?s=40&u=dbcca9ce67d5b71e8d7369ff3f1b3f202172697b&v=4)](https://github.com/N-o-Z)[![Image 121: @VitaliiMaltsev](https://avatars.githubusercontent.com/u/39538064?s=40&u=f52dd283f8ad56b07c8a461cdd203b678dbc701c&v=4)](https://github.com/VitaliiMaltsev)[![Image 122: @sashaNeshcheret](https://avatars.githubusercontent.com/u/33333155?s=40&v=4)](https://github.com/sashaNeshcheret)[![Image 123: @macmv](https://avatars.githubusercontent.com/u/14830829?s=40&v=4)](https://github.com/macmv)[![Image 124: @RobLucchi](https://avatars.githubusercontent.com/u/38728315?s=40&u=0dd566f4ee85f73b9330f14e2227aa4f87acaaa0&v=4)](https://github.com/RobLucchi)![Image 125: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 126: @natalyjazzviolin](https://avatars.githubusercontent.com/u/65251165?s=40&u=acf7e231e6eb00fc456df339942df500272fc4ca&v=4)](https://github.com/natalyjazzviolin)[![Image 127: @edmundito](https://avatars.githubusercontent.com/u/168664?s=40&u=cde376fdc6bc8249349d3b5f0935d91689909a38&v=4)](https://github.com/edmundito)[![Image 128: @alexchouraki](https://avatars.githubusercontent.com/u/32514048?s=40&u=2102f4427b2284cc20db2c7d692f3eb195e3f550&v=4)](https://github.com/alexchouraki)[![Image 129: @YiyangLi](https://avatars.githubusercontent.com/u/6293908?s=40&v=4)](https://github.com/YiyangLi)[![Image 130: @sajarin](https://avatars.githubusercontent.com/u/15092743?s=40&u=2f82f1c0850e51f6e682e11039e83bba8f11a33a&v=4)](https://github.com/sajarin)[![Image 131: @brianjlai](https://avatars.githubusercontent.com/u/51336873?s=40&u=01019c044e1832c260fb6fc23781a749ffdee74f&v=4)](https://github.com/brianjlai)[![Image 132: @AndyTwiss](https://avatars.githubusercontent.com/u/86778456?s=40&v=4)](https://github.com/AndyTwiss)[![Image 133: @dijonkitchen](https://avatars.githubusercontent.com/u/11434205?s=40&u=25fdf1780aa6109d67a31474e4f6c2232479dce9&v=4)](https://github.com/dijonkitchen)[![Image 134: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=40&u=2f967bd888efd962f41319abb72cc4c9a347a147&v=4)](https://github.com/isaacharrisholt)![Image 135: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 136: @harshithmullapudi](https://avatars.githubusercontent.com/u/17528887?s=40&u=85cfccddf13c1207a103acd02479130f3394c0d0&v=4)](https://github.com/harshithmullapudi)[![Image 137: @cirdes](https://avatars.githubusercontent.com/u/727781?s=40&u=ddcac0431685a79f5107692edc9d6cdce110ca17&v=4)](https://github.com/cirdes)[![Image 138: @teallarson](https://avatars.githubusercontent.com/u/63751206?s=40&u=dbabb747971cd019b664a421e25b8f7facb9314e&v=4)](https://github.com/teallarson)![Image 139: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 140: @tuliren](https://avatars.githubusercontent.com/u/1933157?s=40&u=8ff81550363e0e7bc5512a345a7b613f4348b65e&v=4)](https://github.com/tuliren)[![Image 141: @dainiussa](https://avatars.githubusercontent.com/u/24483275?s=40&v=4)](https://github.com/dainiussa)[![Image 142: @rytismi](https://avatars.githubusercontent.com/u/115487686?s=40&v=4)](https://github.com/rytismi)[![Image 143: @xlahuerta](https://avatars.githubusercontent.com/u/13916396?s=40&u=7750c0ee4aa55207b7cf2f1498ab84fc13fb4718&v=4)](https://github.com/xlahuerta)[![Image 144: @evantahler](https://avatars.githubusercontent.com/u/303226?s=40&u=bbc8beba814bc3f2ec0a697bce1cf050c724aa3d&v=4)](https://github.com/evantahler)[![Image 145: @deanmalan](https://avatars.githubusercontent.com/u/4767109?s=40&u=065be81b72797b65a4470478330b044a28c80ee9&v=4)](https://github.com/deanmalan)[![Image 146: @elliottrabac](https://avatars.githubusercontent.com/u/65104164?s=40&u=e870182ef0685ed78a95b434c6aef2734d4ce081&v=4)](https://github.com/elliottrabac)[![Image 147: @haithem-souala](https://avatars.githubusercontent.com/u/75131226?s=40&u=63751ce62c9396a5822b92c550c3b884d2c4373f&v=4)](https://github.com/haithem-souala)[![Image 148: @henriblancke](https://avatars.githubusercontent.com/u/1708162?s=40&u=547c7f4a616448095aee407ef94356dae30fc74b&v=4)](https://github.com/henriblancke)[![Image 149: @itaseskii](https://avatars.githubusercontent.com/u/10071532?s=40&u=a820ec6cb5495e318f8e9c67defc0b35477ae4ff&v=4)](https://github.com/itaseskii)[![Image 150: @ikeadeoyin](https://avatars.githubusercontent.com/u/36523905?s=40&v=4)](https://github.com/ikeadeoyin)[![Image 151: @btkcodedev](https://avatars.githubusercontent.com/u/47392334?s=40&u=8f18b7dbde3c7a34663d195048b29ea9b1bdeec5&v=4)](https://github.com/btkcodedev)[![Image 152: @davinchia](https://avatars.githubusercontent.com/u/9772859?s=40&u=255ec3e830be1c1fde08ffc13b2363b25573cd15&v=4)](https://github.com/davinchia)![Image 153: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)![Image 154: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 155: @victor-cody](https://avatars.githubusercontent.com/u/69702944?s=40&u=f5c3dd9df65cfb3d73ee388fe7572f202e4f63e1&v=4)](https://github.com/victor-cody)[![Image 156: @mickaelandrieu](https://avatars.githubusercontent.com/u/1247388?s=40&u=0506c42c2e317634cd1b3bc2144e5981bc3ec7e4&v=4)](https://github.com/mickaelandrieu)[![Image 157: @roman-yermilov-gl](https://avatars.githubusercontent.com/u/86300758?s=40&v=4)](https://github.com/roman-yermilov-gl)[![Image 158: @perangel](https://avatars.githubusercontent.com/u/187442?s=40&v=4)](https://github.com/perangel)[![Image 159: @suhomud](https://avatars.githubusercontent.com/u/5124694?s=40&u=3435a3777b042ea7e1dae5253d451828bfbfd300&v=4)](https://github.com/suhomud)[![Image 160: @scottleechua](https://avatars.githubusercontent.com/u/51027688?s=40&u=46379e4f2f4736a691a725ec87245180e811c4af&v=4)](https://github.com/scottleechua)[![Image 161: @cuyk](https://avatars.githubusercontent.com/u/14345788?s=40&u=138230a8415e381e90f8fccca94a400953a71cb9&v=4)](https://github.com/cuyk)[![Image 162: @supertopher](https://avatars.githubusercontent.com/u/2591516?s=40&v=4)](https://github.com/supertopher)[![Image 163: @digambar-t7](https://avatars.githubusercontent.com/u/92970968?s=40&u=066dab957aa73a869074ae4314e1757cf9026f68&v=4)](https://github.com/digambar-t7)[![Image 164: @erohmensing](https://avatars.githubusercontent.com/u/22333512?s=40&u=82fa25d6f5e587d415304fd72bd09f8c514ef593&v=4)](https://github.com/erohmensing)[![Image 165: @grishick](https://avatars.githubusercontent.com/u/1310940?s=40&u=c6cd46617d18c9e7207cbeb8f3f1433c88e22450&v=4)](https://github.com/grishick)[![Image 166: @andresbravog](https://avatars.githubusercontent.com/u/363321?s=40&v=4)](https://github.com/andresbravog)![Image 167: Mark Berger](https://github.githubassets.com/images/gravatars/gravatar-user-420.png)[![Image 168: @lazebnyi](https://avatars.githubusercontent.com/u/53845333?s=40&u=45f9f04b18b278177652d65b51b4eccd671bf857&v=4)](https://github.com/lazebnyi)[![Image 169: @darynaishchenko](https://avatars.githubusercontent.com/u/80129833?s=40&u=2614b2098bb9b5c9a1941589a80ede6a64902568&v=4)](https://github.com/darynaishchenko)[![Image 170: @mfsiega-airbyte](https://avatars.githubusercontent.com/u/109092231?s=40&u=809db105018ebd218f3080e76351188a094a5dee&v=4)](https://github.com/mfsiega-airbyte)[![Image 171: @YowanR](https://avatars.githubusercontent.com/u/26179814?s=40&v=4)](https://github.com/YowanR)[![Image 172: @subodh1810](https://avatars.githubusercontent.com/u/28527634?s=40&u=3909012825bbec797885d68d1647b9315fe45e30&v=4)](https://github.com/subodh1810)

```
V0.40.18 (#36)
```
…

Partially verified

# Partially verified

 This commit was created on GitHub.com and signed with GitHub’s **verified signature**. The key has expired. 

 We cannot verify signatures from co-authors, and some of the co-authors attributed to this commit require their commits to be signed. 

```
221e7d4
```

* Fix broken link to config in .env comment (#18287)

* Add message migration to discover schema (#18205)

* upgrade commons-text to 1.10.0 (#18275)

* test

* fix

* fix other modules

* version bumps + changelog

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* [low-code] Propagate options to InterpolatedRequestInputProvider (#18050)

* properly propagate options

* cleanup

* turn into dataclass

* rename

* no need for deepcopy

* fix test

* bump

* cleaner

* Add message translation to GetSpec (#18130)

* Update SpecActivityImpl to build a VersionedStreamFactory

* Enable Protocol Version detection from Stream for SPEC

* Print log before the action for better debugging

* Fix buffer size for protocol detection

* Improve detectVersion error handling

* extract constan

* Rename attribute for clarity

* only rm file if it exists (#18310)

* remove extra check (#10554)

* remove extra check

* simplify logic

* Google ads: Upgrade CDK to incorporate config error handling (#18309)

* Bump version

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* :tada: Source Linkedin Ads - for adDirectSponsoredContents stream skip accounts which are not part of organization (#18111)

* for adDirectSponsoredContents stream skip accounts which are part of organization

* updated PR number

* updated log message, added unit tests

* additional formatting

* updated connector version in source_definitions.yaml

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Add SchemaChange to WebBackendConnectionRead object (#17969)

* add schemaChange field to WebBackendConnectionRead and breakingChange to ConnectionRead

* Destinations BigQuery and GCS: update docs about bucket encryption (#18315)

* Bump Airbyte version from 0.40.16 to 0.40.17 (#18316)

Co-authored-by: edgao <edgao@users.noreply.github.com>

* Updates `getPrivateKeyPair` to throw exception when private key pair does not exist (#18263)

* Changes method from returning null to throwing Exception to match method structure

* Added javadoc explaining that KeyPair should not be returning null

* Moved ConnectionErrorException to commons package

* Adds error handling for SshWrappedDestinations and markdown to include changes

* Bumps version numbers for Postgres, MySQL, MSSQL

* auto-bump connector version

* auto-bump connector version

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🎉 New Source: xkcd [python cdk] (#18049)

* Add new source: xkcd

* Add documentation for xckd connector

* Fix unit test test_parse_response

* Fix xkcd changelog

* Improve iteration method

* Update tests test_next_page_token and test_parse_response

* add timeout for full read

* add seed config and eof

* correct source def id

* auto-bump connector version

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Source pinterest: Fix type of `start_date` (#18285)

Signed-off-by: Sergey Chvalyuk <grubberr@gmail.com>

* requester = MagicMock(use_cache=False) (#18289)

Signed-off-by: Sergey Chvalyuk <grubberr@gmail.com>

* fix Connector Base build (#18351)

* SAT: new `test_strictness_level` field in config (#18218)

* 🪟 🐛 Fixed static <ConditionSection /> width (#18233)

* fixed ConditionSection width

* fixed relative scss colors import

* 🎉 Source Shopify: update API version to `2022-10` (#18298)

* Update airbyte-db reference (#18368)

* 🪟 🐛 Load global CSS in storybook (#18353)

* Bump helm chart version reference to 0.40.33 (#18371)

Co-authored-by: xpuska513 <xpuska513@users.noreply.github.com>
Co-authored-by: Kyryl Skobylko <xpuska513@gmail.com>

* enable support for publishing datadog metrics from a local environment (#18282)

* local datadog docker-compose

* add datadog docker-compose

* update comments

* Simplify the OSS documentation deploy system (#2670) (#18377)

+ Adds a placeholder for 'Deploy Docs' Github Workflow.

* fix: add task to list all dependencies (#18304)

* fix: add task to list all dependencies

* fix: remove newline

* remove useless json_size metric (#18247)

* 🎉Destination-elasticsearch: added custom sertificate support (#18177)

* [11356] Destination-elasticsearch: added custom certificate support

* update spotbugs to latest (#18208)

* Source Jira - Pagination fix on jira users stream (#16944)

* pagination fix on jira users stream

* Update spec.json

* Update spec.json

* Update streams.py

* bump docker version and changelog

* Update spec.json

* Update streams.py

* update jsons and source

* update source

* Update source.py

* auto-bump connector version

Co-authored-by: Vincent Koc <koconder@users.noreply.github.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🎉  Source Google Ads: Add fields to the campaign stream 🚨  (#18069)

* feat: add new fields to campaign stream

* docs: updated docs and bumped Dockerfile version

* Update campaigns.json

* Update Dockerfile

* auto-bump connector version

Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>
Co-authored-by: Vincent Koc <koconder@users.noreply.github.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* fixed check-style (#18390)

* Readded xkcd to source def yaml (#18386)

* readded xkcd to source def yaml

* remove changes in klavyio

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Trace errors in orchestrator workers (#18381)

* Trace errors in orchestrator workers

* Trace cancel method of workers

* Formatting

* Restore final modifier

* Source Shopify: add unit tests (#17944)

* Export python type information for airbyte-cdk (#18387)

Fixes #18384

* Fix error highlight of select boxes (#18396)

* Source Hubspot: update `contacts` scope in docs (#18380)

Signed-off-by: Sergey Chvalyuk <grubberr@gmail.com>

* remove extra ' in version (#18400)

- rm extra `'` in version string; `"2.1.1'"` -> `"2.1.1"`

* Improve listSourcesForWorkspace route (#18207)

* 🪟 🐛  Fix additional buttons for connection creation (#18372)

* make button enabled regardless credit balance

* remove FeatureItem.AllowCreateConnection at all, since we don't need it anymore

* update tests

* Replace "AllowCreateConnection" feature flag with "AllowDBTCloudIntegration" in tests

* Change port for acceptance test destination db (#18391)

* Bmoric/update connection list with breaking (#18125)

* add schemaChange

* merge conflict

* frontend tests

* tests

* l

* fix source catalog id

* test

* formatting

* move schema change to build backend web connection

* check if actor catalog id is different

* fix

* tests and fixes

* remove extra var

* remove logging

* continue to pass back new catalog id

* api updates

* fix mockdata

* tests

* add schemaChange

* merge conflict

* frontend tests

* tests

* l

* fix source catalog id

* test

* formatting

* move schema change to build backend web connection

* check if actor catalog id is different

* fix

* tests and fixes

* remove extra var

* remove logging

* continue to pass back new catalog id

* api updates

* fix mockdata

* tests

* tests

* optional of nullable

* Tmp

* For diff

* Add test

* More test

* Fix test and add some

* Fix merge and test

* Fix PMD

* Fix test

* Rm dead code

* Fix pmd

* Address PR comments

* RM unused column

Co-authored-by: alovew <anne@airbyte.io>

* Generate connector builder api client (#18274)

* update openapi for connector builder to work with orval for now

* add orval configuration for generating the connector builder client

* create ConnectorBuilderApiService with methods to call the generated connector builder API client code

* rename connector definition to manifest

* refactor builder api service to match existing patterns

* fix name of pages folder

* improve comment

* modify structure of StreamRead

* fix path

* :window: :wrench: Generify connector documentation layout into resizable panels component (#18272)

* generify connector documentation layout into resizable panels component

* add intl string for connector builder expand message

* update name of formatted download yaml message

* fix stylelint

* Update airbyte-webapp/src/components/ui/ResizablePanels/ResizablePanels.module.scss

Co-authored-by: Joey Marshment-Howell <josephkmh@users.noreply.github.com>

* move splitter styles into scss module

* simplify ResizablePanels component

* reorder

* use variables

* remove units on 0

* Update airbyte-webapp/src/views/Connector/ConnectorDocumentationLayout/ConnectorDocumentationLayout.module.scss

Co-authored-by: Joey Marshment-Howell <josephkmh@users.noreply.github.com>

* Update airbyte-webapp/src/components/ui/ResizablePanels/ResizablePanels.module.scss

Co-authored-by: Joey Marshment-Howell <josephkmh@users.noreply.github.com>

* Update airbyte-webapp/src/components/ui/ResizablePanels/ResizablePanels.module.scss

Co-authored-by: Joey Marshment-Howell <josephkmh@users.noreply.github.com>

Co-authored-by: Joey Marshment-Howell <josephkmh@users.noreply.github.com>

* SAT: declare `bypass_reason` in `acceptance-test-config.yml` (#18364)

* Source Iterable - better processing of 401 and 429 errors (#18292)

* #829 source iterable - better processing of 401 and 429 errors

* source iterable: upd changelog

* #829 source iterable: fix unit tests

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🐛 Source Asana: fix request-cache test (#18375)

* Source Asana: fix request-cache test

* Source Asana: Bump version

* 🐛 Source Asana: revert docker label; update CDK

* 🐛 Source Freshdesk: fix test; update CDK (#18389)

* 🐛 Source Freshdesk: fix test; update CDK

* 🐛 Source FreshDesk: revert docker label; update CDK

* Update cdk-speedrun.md (#18416)

* Update README.md

* Update Facebook-marketing.md with warning about ongoing setup issue (#18422)

There is an ongoing issue blocking anyone with the most recent API update from being able to setup a Facebook Marketing Source Connector. Put this warning at the top of the setup page until it is fixed.

* Source Greenhouse: extend users stream schema (#18154)

* #17506 source greenhouse: extend users stream schema

* #17506 source greenhouse: upd changelog

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🐛 Source Hubspot: update CDK; fix expected test result according to 0.2.2 update (#18424)

* Additional worker APM tracing (#18427)

* Publish new CDK version with typehints exported (#18398)

* Extract the AttemptApi out of the ConfigurationApi (#18406)

* Tmp

* Extract the Attempt API from the V1 API

* Add comments

* format

* Rename to Controller

* 🐛 Source Salesforce: update CDK; fix test supported_sync_modes is required for AirbyteStream (#18429)

* :window: :wrench: Introduce useAuthentication hook (#17965)

* Introduce useAuthentication hook

* Work for both auth mechanism

* Finalize implementation

* Add documentation

* Fix unit tests

* Add unit tests

* Remove getValues call

* Update airbyte-webapp/src/views/Connector/ServiceForm/useAuthentication.tsx

Co-authored-by: Lake Mossman <lake@airbyte.io>

* Update airbyte-webapp/src/views/Connector/ServiceForm/useAuthentication.tsx

Co-authored-by: Lake Mossman <lake@airbyte.io>

* Update airbyte-webapp/src/views/Connector/ServiceForm/useAuthentication.tsx

Co-authored-by: Lake Mossman <lake@airbyte.io>

* Update airbyte-webapp/src/views/Connector/ServiceForm/useAuthentication.tsx

Co-authored-by: Lake Mossman <lake@airbyte.io>

* Update airbyte-webapp/src/views/Connector/ServiceForm/useAuthentication.tsx

Co-authored-by: Lake Mossman <lake@airbyte.io>

* Update airbyte-webapp/src/views/Connector/ServiceForm/useAuthentication.tsx

Co-authored-by: Lake Mossman <lake@airbyte.io>

* Update airbyte-webapp/src/views/Connector/ServiceForm/useAuthentication.test.tsx

Co-authored-by: Lake Mossman <lake@airbyte.io>

* Change variable name

Co-authored-by: Lake Mossman <lake@airbyte.io>

* Update: aws ec2 deployment guide (#18360)

* Updated Deploy on GCP Doc (#18286)

* Updated Deploy on GCP Doc

* Added formatting changes

* Updated deploying Airbyte on Azure section (#18331)

* feat: deploy airbyte on kubernetes doc (#18339)

* New Source: Zoom [low-code CDK] (#18179)

* feat: implement meetings & users API in zoom connector

* feat: add support fot all zoom GET APIs

* fix: unhandled error cases by adding default handler and minor refactor

* feat: sync the catalog with the latest zoom API responses

* docs: add the new zoom connector built with low-code CDK

* chore: remove unnecessary files, and rename connector in definitions

* fix: forgot to add source_definitions.yaml earlier 😅

* remove some empty streams

* add eof

* correct spec yaml

* docs: update docs/integrations and replace zoom with low code CDK zoom

* fix: definition generation err

* udpate seed file and remove zoom-singer

* remove zoom singer spec

* add icon

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>

* 🐛 Source SurveyMonkey: fix expected test result according to 0.2.2 update (#18431)

* Update postgres.md (#18432)

* Update README.md

* SAT: make all tests mandatory when `test_strictness_level` == `high` (#18414)

* Refactor SourceHandler:buildSourceRead function (#18430)

This function takes as input a `sourceId` and performs a database call to retrieve the full source information. This refactoring ensures that call sites that already have the full object can bypass that database call. This is especially important for methods that fetch and return a list of sources.

* Make YouTube login button Google styled (#18443)

* Edited Notion Doc (#18405)

* edited doc

* some wording changes

* edited step

* SAT: enforce `bypass_reason` declaration on `empty_streams` when `test_strictness_level == high` (#18425)

* Fix the tag in openAPI (#18445)

* Fix the tag

* remove unused

* use api to do jobpersistence query (#18308)

* use api to do jobpersistence query

* renaming some variables

* fix test

* RefreshSchema Activity (#18388)

* Add RefreshSchema Activity

* Follow-up fix for SSHExceptions (#18383)

* Follow-up fix for SSHExceptions

* Catch RuntimeException instead of augmenting connection error messaging for now

* Update tests

* Bump versions + docs

* auto-bump connector version

* auto-bump connector version

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Refactor the buildDestinationRead function (#18446)

Create a new buildDestinationRead function, that function can be called by top-level functions in the handler that
already have a DestinationConnection object.

* 🐛 Fix S3 destination integration tests to use bucket path (#18031)

* Fix S3 destination tests

* Add Changelog

* CR Fixes

* add unit test

* version bump

* fix dockerfile

* auto-bump connector version

Co-authored-by: Edward Gao <edward.gao@airbyte.io>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* fix formatting + imports (#18457)

* RefreshSchema method on RefreshSchema activity (#18460)

* Add refreshSchema method to RefreshSchema activity

* 🐛 Source Tiktok Marketing: fix test timeout (#18433)

* Postgres Source : updated docs for CDC setup (#18291)

* Postgres Source updated docs for CDC setup

* fixed typo

* fixed typo

* rephrased

* rephrased

* Source postgres: disable  allow and prefer ssl modes in CDC mode (#18256)

* Source postgres: disable ssl_mode allow and prefer in CDC mode

* Source postgres: code review fixes

* Source postgres: code review fixes

* Source postgres: improve ssl mode handling

* Source postgres: bump version

* auto-bump connector version

* Source postgres: bump version

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Source Twilio: implement slicing (#18423)

* #804 source twilio: implement slicing

* #804 source twilio - format code

* #804 source twilio - implement slicing

* #804 source twilio: configure incremental streams

* #804 fix expected records

* #804 extend Calls stream schema

* #804 source twilio: allow configurable slice for SATs

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Fix broken table in the docs (#18466)

* 🎉 New Connector: Clockify [python cdk] (#17767)

* new connector source-clockify

* feat: enable caching for streams (users, projects)

* chore: pep8 changes at unit_tests

* chore: pep8 changes at integration_tests

* chore: update schema

* Adds python formatting, removes unused import.

* Makes the task duration field nullable to pass integration test.

* fix: add second type to null values to the schema files

* Adds a null fallback value to task duration.

* Updates airbyte-cdk dependency.

* Adds UUID in source definitions.

* auto-bump connector version

* Requested changes.

* add clockify to source def seed

* correct spec.json add titles

* add icon

* run format

* remove source spec

* correct spec

* add eof gitignore

* auto-bump connector version

Co-authored-by: nataly <nataly@airbyte.io>
Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>
Co-authored-by: Nataly Merezhuk <65251165+natalyjazzviolin@users.noreply.github.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>

* Optimize listDestinationsForWorkspace route (#18456)

Add a function to fetch all destinations in a workspace

* Add new streams table components (#18262)

* Add new streams table components

* Update CatalogTree and Catalog section to render new components based on env-based flag
* Add basic Bulk edit panel, stream panel, table row, table headers
* Split the overlay out of the modal and make it its own component. Use in StreamPanel
* Add Fields to en.json

* StreamPanel -> StreamDetailsPanel

* Add new stream fields table components

* Use new stream fiels table props iface on Stream details panel

* add basic auth for Lever (#17996)

* add basic auth for Lever

* Update lever-hiring.md

* Update spec.json

* Update source.py

* Revert "Update spec.json"

This reverts commit 77b10a653b1056c959664416a6c89eafb6f49e07.

* Revert "Update source.py"

This reverts commit 3d6d83c6c63597d0b8ed46038d17989b38ba9712.

* Update spec.json

* update spec.json, replace sample config, change check to auth_type

* unit tests with parametrize

* gradlew formatting python + fixing bugs to ensure it works

* modifs as suggested by reviewer

* Update test_source.py

* Update test_source.py

* fixing specs in order for integration tests to pass

* fix acceptance test TestSpec.test_oauth_flow_parameters

* bump the docker image version to 0.1.3

* auto-bump connector version

Co-authored-by: Yiyang Li <yiyangli2010@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🐛 Source File: fix check method (#18481)

* 🐛 Source File: fix check method

* 🐛 Source File: bump version

* 🐛 Source File: test for wrong format

* 🐛 Source File: docs update

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Make script both Unix/Linux and OSX compatible (#18493)

* Update to latest Temporal SDK release (#18492)

* Trace launcher worker run method (#18441)

* Bmoric/extract connection api (#18409)

* Tmp

* Extract the Attempt API from the V1 API

* Add comments

* Move Connection API out of configuration API

* format

* format

* Rename to Controller

* Rename to Controller

* Add values to the factory

* Change the constructor to use hadler instead of objects needed by the handler

* Update with new tags.

* Fix PMD errors

* Add explicit path to the controller

* 🎉 New Source: Auth0 [python cdk] (#18338)

* 🎉 New Source: Auth0 [python cdk]

- Full import and incremental are supported
- Only users stream is added
- Added unit tests and ensure all acceptance tests are passed locally
- It's free to create a new account in Auth0, so it's free to setup an integration account.

* fix: remove unused import in source.py

* auto-bump connector version

Co-authored-by: sajarin <sajarindider@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Destination Redshift: handle empty s3 bucket_path (#18434)

* make bucket_path required

* check for nonempty path

* not required

* handle null/empty path

* version bump + changelog

* fix comment

* auto-bump connector version

* format

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Use Google business mails by default for login (#18462)

* support custom error messaging for error response + retryable errors (#18204)

* support custom error messaging for error response + retryable errors

* remove changed backoff i was using for testing

* refactor filter to construct response status internally

* pr feedback

* bump version and update changelog

* Alternate way to view temp/CSV files on Windows. (#18482)

Document alternate method, using Docker intrinsic functionality, to copy temp files locally in the situation that cannot be browsed through WSL2's file explorer.

* docs: fix link reference (#18503)

* 🐛Destination-elasticsearch: enforce ssl connection on cloud (#18341)

* [16992] Destination-elasticsearch: enforce ssl connection on cloud

* Bmoric/extract destination api (#18502)

* Tmp

* Extract the Attempt API from the V1 API

* Add comments

* Move Connection API out of configuration API

* format

* format

* Rename to Controller

* Rename to Controller

* Add values to the factory

* Change the constructor to use hadler instead of objects needed by the handler

* Update with new tags.

* Fix PMD errors

* Add explicit path to the controller

* Extract destiantion API

* bump to v15.0 (#18467)

* bump to v15.0

* disable backwards compatible test for 0.2.69

* fix spec

* skip comprehensive

* bump

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Persist geography updates (#18501)

* persist geography in connection update

* use ApiPojoConverters

* add test coverage for persisting geography update

* persist geography column for workspace

* use US instead of AUTO in mock data so that tests don't pass due to the database-level default column value

* use ApiPojoConverters instead of Enum.convertTo in workspace handler

* format

* Add SSH tunnel for MongoDB Destination (#18280)

* Add SSH tunnel for MongoDB Destination

* Fixed host/port resolution issues with Docker containers

* Formatting changes

* Bump version number and adds documentation for SSH tunnel

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Improve performance of the operation that retrieve all connector for a given definition (#18499)

* 🎉 New Source: News API (#18301)

* Initial commit

* Add streams

* Simplify using options in request_parameters

* Address comments

* Add examples to query

* Add docs

* Change authenticator to ApiKeyAuthenticator

* add seed config

* remove icon

* auto-bump connector version

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🐛 Source Hubspot: acceptance fix (#18498)

* 🎉 New Source: Workable (low-code SDK) (#18033)

* Generate initial Workable connector

* Implement jobs route

* Make acceptance tests pass

* Implement pagination

* Try to fix pagination (not yet working)

* Make pagination work

* Add created_after parameter

* Add Workable docs

* Move unused test

* Add candidates stream

* Fix acceptance tests

* Remove unused files

* Add stages stream

* Add recruiters stream

* Remove sample_state file

* Add Workable to docs/integrations/README.md

* Update changelog

* Change Sentry page size back

* Rename created_after_date to start_date

* Remove data type map

* Add start_date to sample_config.json

* Add streams documentation to yaml

* add title to params inspec

* format files

* fix: added source to source_definitions

Co-authored-by: Harshith Mullapudi <harshithmullapudi@gmail.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>

* source-airtable: improve discovery logic (#18491)

* 🎉 Destination Meilisearch: migrating to python and fix integration  (#18036)

* Add meilisearch python destionation

* add destination

* first working version

* Writting tests

* writer more resilient

* Adding unit test

* correct integration test stream param

* update doc

* remove unused variables

* auto-bump connector version

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🐛 Source File: add retry logic for `Connection reset by peer - 104` error (#18428)

* 🪟  🐛  Split Heading and Text components (#17992)

* split Text and Heading components

* replace Text with Heading where appropriate

* 🐛 Source Facebook Marketing: increase timeout (#18536)

* Bmoric/extract db migration api (#18459)

* Tmp

* Extract the Attempt API from the V1 API

* Add comments

* Move Connection API out of configuration API

* format

* format

* Rename to Controller

* Rename to Controller

* Add values to the factory

* Change the constructor to use hadler instead of objects needed by the handler

* Update with new tags.

* tmp

* Fix PMD errors

* Extract DB migrator

* Add something that I forgot

* restore destination factory initialization

* format

* 🪟 Apply default sync mode logic to new streams (#18451)

* brute force solution

* cleanup

* testing and comment

* review cleanup

* Bmoric/extract destination definition api (#18515)

* Tmp

* Extract the Attempt API from the V1 API

* Add comments

* Move Connection API out of configuration API

* format

* format

* Rename to Controller

* Rename to Controller

* Add values to the factory

* Change the constructor to use hadler instead of objects needed by the handler

* Update with new tags.

* tmp

* Fix PMD errors

* Extract DB migrator

* Add something that I forgot

* extract destination definition api

* restore destination factory initialization

* format

* format

* explicit path

* 🪟 🎨 Add `PillSelect` UI component (#18376)

* Add PillButton UI component
Update Text component to support xs size

* Update PillButton prop names

* Remove outline and tint from PillButton until it's resolved with design

* Add PillButton example to popout

* PillButton -> PillSelect
Remove story from Popout
Create PillSelect component that manages select logic
Make PillButton part of PillSelect

* Support text overflow in pill button

* Show tooltip on pill select multiple items

* Use border-thin var in PillButton style

* Update gap in PillButton to use spacing var

* extract destination definition specification api (#18521)

* Tmp

* Extract the Attempt API from the V1 API

* Add comments

* Move Connection API out of configuration API

* format

* format

* Rename to Controller

* Rename to Controller

* Add values to the factory

* Change the constructor to use hadler instead of objects needed by the handler

* Update with new tags.

* tmp

* Fix PMD errors

* Extract DB migrator

* Add something that I forgot

* extract destination definition api

* restore destination factory initialization

* extract destination definition specification api

* format

* format

* format

* explicit path

* Restore docs build (#18551)

+ Corrects two errors, unblocks docs build

* add authentication info to local development guide (#18509)

* add authentication info to local development guide

* rephrase

* 🪟 🐛 Fix UI issues in connection streams table (#18544)

* Fix PathPopout styling
* Ensure that text overflow still works
* Only show tooltip when there is more than 1
* Use caret instad of sort icon so that it's centered

* Fix option content for SyncSettignsDropdown so that it fits

* Fix @forward on StreamHeader scss

* Rollback tooltip updates

* Simplify the OSS documentation deploy system (#2670) (#18436)

+ Updates tools/bin/deploy_docusaurus to work on Github Runners
+ Adds 'Deploy docs.airbyte.com' Github workflow

* Simplify the OSS documentation deploy system (#2670) (#18448)

+ Updates Airbyte Docs: informs about automated Docs site
  build and deployment.

* Source Iterable: distinguish 401 from empty stream (#18537)

* #829 source iterable: distinguish 401 from empty stream

* #829 source iterable: upd changelog

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Databricks destination: introduce personal staging location (#18557)

* Update s3 parquet writer

- Rename gcsFileLocation.
- Merge local variables.

* Implement staging location getter

* Add integration test and fix post request

* Add comment and format code

* Ensure that restart delay is set before any other activity is executed (#18547)

* Ensure that restart delay is set before any other activity is executed

* Add version check

* Formatting

* 🎉 New Source: ActiveCampaign (#18335)

* Init source ActiveCampaign

* Added documentation files

* Added contacts and campaigns streams

* Added deals stream

* added segments stream

* Added lists stream

* Formatted schemas

* Added references to API docs

* added forms stream

* Added pagination

* Updated documentation

* Formatted schemas

* Removed unnecessary files

* Added changelog

* Updated base URL

* Added sample config

* add source seed

* run format

* generate uuid for activecampaign

* auto-bump connector version

Co-authored-by: Rytis Mickevičius <rytis.mickevicius1@gmail.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* normalization: Fix failing mypy checks (#18534)

* Use Protocol Versions in Syncs (#18324)

* Pass protocol version into IntegrationLauncherConfig

* Use VersionedStreamStreamFactory in AirbyteSource/Destination

* Add AirbyteMessageBufferedWriter

* Use VersionedBufferedWriter

* 🪟 🎉  Client-side validation of cron expressions <= 1 hr for cloud (#18044)

* add feature for cron expression format

* add new validation function for sub one hr cron

* add feature-dependent validation of cronExpression

* add test coverage for create & edit connection forms

* enable sub one hour cron expressions on cloud temporarily

* Lowcode connectors: Fix few issues with stream slicers (#18529)

* Fix a few bugs

* bump

* Protocol change: Define a set of well-known data types (#17486)

* add WellKnownTypes.yaml

* rename to snakecase + put in airbyte-protocol

* add examples

* more descriptoins

* descriptions, more restrictions, better regex

* update documentation

* explicitly call out BC support

* 🎉 New Source: Coin API (#18302)

* Initial commit

* Add streams

* Correct acceptance test config

* Make secret

* Update docsurl

* Remove catalog.json

* Add second stream

* Add default to spec

* Change to start_date and end_date

* Add links to CoinAPI docs in spec

* Change to start_date and end_date

* Add docs

* add coin api to source seed file

* remove icon

* generate source spec for coin api

Co-authored-by: Vincent Koc <koconder@users.noreply.github.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>

* 🎉 New Source: TVMaze Schedule (#18333)

* Initial commit

* Add streams

* Remove file and update country code description

* Add docs

* format

* correct schema

* add tvmaze schedule to source spec seed

* auto-bump connector version

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>
Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>

* 🎉 New Source: MailerLite (#18336)

* Init source MailerLite

* Added documentation

* Removed unnecessary files and a comment

* Added changelog

* Added sample config

* Updated base URL

* format

* add mailerlite to source def seed

* update docker image tag version

* auto-bump connector version

Co-authored-by: Dainius Salkauskas <dainiuxazz@gmail.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🎉 New Source: Nasa APOD [python cdk] (#18394)

* NASA APOD connector first implementation

* Fix Acceptance and Unit tests

* Fix DecrecationWarning on NoAuth

* Update changelog with PR id

* `date` input removal in favor of `start_date` + Minor fixes

* Connector renaming to support different Nasa streams

* Update docs and source definitions with connector rename

* Support incremental updates

* Fix typo on abnormal_state.json, making acceptance tests to fail

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Add missing generated python files (#18580)

* 🎉 New Source - Lokalise [low-code SDK] (#18522)

* Add keys stream

* Fix keys stream for now

* Start to add languages stream

* Add docs

* Start to add pagination

* Remove paginator again

* Revert "Remove paginator again"

This reverts commit 3f8daace174473be767ef78d0fa852be81925203.

* Pagination seems to work

* Clean up yaml

* Increase max page size

* Docs improvements

* Add comments stream

* Add contributors stream

* Fix contributors stream

* Add translations source

* Add new acceptance test format

* Add abnormal state

* Add PR number

* run format

* simplify selector

* add eof

* auto-bump connector version

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🎉 New Source: Oura (#18224)

* Initial commit

* Add streams

* Final tidying

* Make secret

* Remove start_date and end_date parameters

* Add docs

* update cdk version

* run format + add source def for oura

* run config process manually

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>

* 🎉 New Source: Ashby (#18334)

* create boilerplate

* configure connector

* add ashby documentation

* update airbyte docs

* configure tests

* Revert "update airbyte docs"

This reverts commit 7dcf2b2dad1a77007b64aa8453aeb1c27e74ae58.

* update airbyte documentation

* update catalogs

* add start date for specific streams

* update config files

* add ashby to source def seed

* update doc

* auto-bump connector version

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🎉 New Source - Sonar Cloud (#18475)

* init commit

* add docs

* add docs

* fix comments

* change string to array

* 🎉 New source: SFTP Bulk [python cdk] (#17691)

* [INIT] setup source-ftp

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [ADD] add logic

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [ADD] unit, integration, acceptance tests

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [UPD] update docs

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [UPD] clean up crew

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [UPD] update host to localhost

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [UPD] rename from ftp to sftp bulk

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [INIT] setup source-ftp

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [ADD] add logic

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [ADD] unit, integration, acceptance tests

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [UPD] update docs

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [UPD] clean up crew

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [UPD] update host to localhost

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [UPD] rename from ftp to sftp bulk

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* update branch

* [FIX] integration tests

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [FIX] acceptance test fixture

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* [UPD] change ftp port

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* add uuid to image build

* add source def

* [FIX] generate ssh keys

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>

* auto-bump connector version

Signed-off-by: Henri Blancke <blanckehenri@gmail.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🎉 New Source: Mailjet Mail API (#18332)

* init commit

* add streams

* add schemas

* add docs

* add docs

* fix comments

* restore vscode config

* restore vscode config

* clean

* lint

* lint

* lint

* lint

* fix comments

Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>

* Sonar Cloud: add to source spec and publish connector (#18584)

* solve conflict

* solve conflict spec.yaml

* add sonar cloud to seed + format

* add eof

* generate config source spec

* Source Mailjet Mail: publish connector and additional format (#18586)

* init commit

* add streams

* add schemas

* solve conflict

* add docs

* fix comments

* restore vscode config

* restore vscode config

* clean

* lint

* lint

* lint

* lint

* fix comments

* run format

* update acceptance test

* update schema

* update acceptance test

* auto-bump connector version

Co-authored-by: Haithem SOUALA <haithem.souala@woopit.fr>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Implement Connector Builder testing panel (first iteration) (#18449)

* [SPIKE] add Builder page with editor

* add YamlEditor component

* export colors from CSS

* move template into dedicated file

* fix initial load from local storage

* move download button into separate component

* fix stylelint

* remove console log

* add todo

* make monaco background transparent and apply gradient to parent div background

* clarify comment

* remove unnecessary 180deg

* lock the builder UI behind a feature

* use rgb instead of hex to fix stylelint

* use _colors.scss and disable hex length stylelint rule

* disable rule in file

* generify ConnectorDocumentationLayout into TwoPanelLayout

* use TwoPanelLayout for BuilderPage

* add darker gradient color to _colors.scss and use in gradient

* move /builder to /connector-builder

* rename TwoPanelLayout to ResizablePanels

* put gradient on parent container instead

* make lightOverlay actually overlay instead of un-rendering children

* add testing panel component and stream selector

* fix rotated text

* fix more styling

* remove unnecessary comment

* add starting flex to right panel

* replace react-select dropdown with headless-ui listbox

* add test controls and fix button icon styling

* add Configure Test Input button and modal

* add connector builder client

* move connector builder state into dedicated context

* fix bold prop in Text component to not throw error

* pass parsed yaml->json into query

* store config in connector builder state context

* add result display

* fix styles of result display

* move config menu into testing panel

* capitalize stream names

* undo changes to Text component, since that is being addressed in a separate PR

* fix more merge issues and fix generated schema usage

* capitalize header

* remove console log

* rename data to streamRead

* fix stylelint and use variables

* use another variable for spacing

* use stream name in state data object

* move ConnectorBuilderStateProvider into ConnectorBuilderPage

* fix sizing of modal

* fix styling of active stream selector option

* Update airbyte-webapp/src/components/StreamTestingPanel/ResultDisplay.tsx

Co-authored-by: Tim Roes <tim@airbyte.io>

* Update airbyte-webapp/src/components/StreamTestingPanel/ResultDisplay.tsx

Co-authored-by: Tim Roes <tim@airbyte.io>

* hide result display panel if no data

* remove button specificity styling hacks, use size prop instead

* Update airbyte-webapp/src/components/StreamTestingPanel/StreamSelector.tsx

Co-authored-by: Tim Roes <tim@airbyte.io>

* change logs to errors

Co-authored-by: Tim Roes <tim@airbyte.io>

* Source: Google Search Console: validate custom_reports.dimension (#18568)

Signed-off-by: Sergey Chvalyuk <grubberr@gmail.com>

* SAT: make `expect_records` mandatory in `high` `test_strictness_level` (#18497)

* 🎉 New destination: Yugabytedb (#18039)

* add yugabytedb destination connector

* add dest def + add changelog

* auto-bump connector version

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* fix worker volumeMounts (#18604)

* 🎉  New Source: RD Station Marketing [python cdk] (#18348)

* Add new source: RD Station Marketing

* Update catalog with all streams

* Update changelog with the rigth PR reference number

* Minor fixes to RD Station docs

* Change field replication_start_date to start_date

* Fix unit tests after changing replication_start_date name

* Fix typo

* Refact next_page_token logic

* Fix unit tests

* Remove print function

* Update airbyte-cdk version to 0.2

* Update airbyte-integrations/connectors/source-rd-station-marketing/source_rd_station_marketing/streams.py

Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>

* Change from yield to yield from

* Apply format

* add rd station to source def

* update doc changelog

* auto-bump connector version

Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Simplify the OSS documentation deploy system (#2670) (#18598)

+ Adds Slack notification about failed Docs builds
  (slack notifications fall into "#oss-master-build-failure" for now)
+ (while here) Unbreaks docs build

* improved the digitalocean deployment guide (#18566)

* fixed failed build (#18610)

* 🎉 New Source: ConvertKit (#18455)

* Init source omnisend

* Removed unnecessary files

* Init source convertkit

* Added forms, sequences streams

* Added tags stream

* Added subscribers, broadcasts streams

* Added documentation

* Removed unnecessary files

* Updated pull request information in documentation

* Added sample config

* Updated invalid config

* Formatting, removed abnormal state, uncommented full_refresh acceptance test

* Added pagination for subscribers stream

* fix: add source definition for convertkit

* auto-bump connector version

Co-authored-by: Sajarin <sajarindider@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🎉New Source: Google Webfonts [low-code cdk] (#18496)

* New source: Google webfonts

* chore: Add Docs

* chore: update changelog

* chore: resolved given comments for PR

* chore: unwanted files removed

* fix: generate and add source definitions

Co-authored-by: sajarin <sajarindider@gmail.com>

* Clean up build.gradle. (#18555)

Upstream has fixed this bug so we no longer need to host it internally. Remove this to clean up build.gradle.

* 🎉 New Destination: Typesense (#18349)

* Initial boilerplate

* 🎉 New Destination: Typesense

* remove .java-version

* fix doc

* add typesense to dest def

* add release stage

* add requirement to main

* auto-bump connector version

* add changelog

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🎉 New Source: Waiteraid [low-code cdk] (#18165)

* added source waiteraid

* 🎉 New Source: Waiteraid

* add searchBookings stream

* add P/R number

* add SUMMARY entry

* add docs/integrations/README.md entry

* add builds.md entry

* add docs to each endpoint

* fix schema
~

* Update airbyte-integrations/builds.md

added web address

Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>

* Delete catalog.json

* Delete TODO.md

* Update spec.yaml

* add waiteraid to source def seed

* auto-bump connector version

Co-authored-by: Sebastian Brickel <sebastianbrickel@Sebastians-MacBook-Air.local>
Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Replace `recipesLink` link with `tutorialsLink` (#18616)

* Protocol Change: `AirbyteControlMessage.ConnectorConfig` (#17907)

* Protocol Change: AirbyteConfigMessage

* update PR link in docs

* Lint

* Update python files

* Update docs/understanding-airbyte/airbyte-protocol.md

Co-authored-by: Sherif A. Nada <snadalive@gmail.com>

* Update docs/understanding-airbyte/airbyte-protocol.md

Co-authored-by: Sherif A. Nada <snadalive@gmail.com>

* `AirbyteConfigMessage` -> `AirbyteConnectorConfigMessage`

* AirbyteOrchestratorMessage

* Update docs

* `AirbyteControlConnectorConfigMessage`

Co-authored-by: Sherif A. Nada <snadalive@gmail.com>

* Remove workflow version check (#18613)

* Improved the Oracle cloud deployment guide (#18615)

* Update OCI VM deployment guide

* Update OCI deployment guide

* Update on oci-vm.md

* 🐛 Lowcode: ListStreamSlicer and SubstreamSlicer should get the stream_slice from the arguments (#18574)

* fix list stream slicer

* get the stream slice from the parameters

* delete unused code

* Add comments

* missing test

* newline

* with pytest.raise

* reset to master

* newline

* Update __init__.py

* Update __init__.py

* 🎉 New Source: ConvertKit (#18455)

* Init source omnisend

* Removed unnecessary files

* Init source convertkit

* Added forms, sequences streams

* Added tags stream

* Added subscribers, broadcasts streams

* Added documentation

* Removed unnecessary files

* Updated pull request information in documentation

* Added sample config

* Updated invalid config

* Formatting, removed abnormal state, uncommented full_refresh acceptance test

* Added pagination for subscribers stream

* fix: add source definition for convertkit

* auto-bump connector version

Co-authored-by: Sajarin <sajarindider@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🎉New Source: Google Webfonts [low-code cdk] (#18496)

* New source: Google webfonts

* chore: Add Docs

* chore: update changelog

* chore: resolved given comments for PR

* chore: unwanted files removed

* fix: generate and add source definitions

Co-authored-by: sajarin <sajarindider@gmail.com>

* Clean up build.gradle. (#18555)

Upstream has fixed this bug so we no longer need to host it internally. Remove this to clean up build.gradle.

* 🎉 New Destination: Typesense (#18349)

* Initial boilerplate

* 🎉 New Destination: Typesense

* remove .java-version

* fix doc

* add typesense to dest def

* add release stage

* add requirement to main

* auto-bump connector version

* add changelog

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🎉 New Source: Waiteraid [low-code cdk] (#18165)

* added source waiteraid

* 🎉 New Source: Waiteraid

* add searchBookings stream

* add P/R number

* add SUMMARY entry

* add docs/integrations/README.md entry

* add builds.md entry

* add docs to each endpoint

* fix schema
~

* Update airbyte-integrations/builds.md

added web address

Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>

* Delete catalog.json

* Delete TODO.md

* Update spec.yaml

* add waiteraid to source def seed

* auto-bump connector version

Co-authored-by: Sebastian Brickel <sebastianbrickel@Sebastians-MacBook-Air.local>
Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Replace `recipesLink` link with `tutorialsLink` (#18616)

* Protocol Change: `AirbyteControlMessage.ConnectorConfig` (#17907)

* Protocol Change: AirbyteConfigMessage

* update PR link in docs

* Lint

* Update python files

* Update docs/understanding-airbyte/airbyte-protocol.md

Co-authored-by: Sherif A. Nada <snadalive@gmail.com>

* Update docs/understanding-airbyte/airbyte-protocol.md

Co-authored-by: Sherif A. Nada <snadalive@gmail.com>

* `AirbyteConfigMessage` -> `AirbyteConnectorConfigMessage`

* AirbyteOrchestratorMessage

* Update docs

* `AirbyteControlConnectorConfigMessage`

Co-authored-by: Sherif A. Nada <snadalive@gmail.com>

* Remove workflow version check (#18613)

* Improved the Oracle cloud deployment guide (#18615)

* Update OCI VM deployment guide

* Update OCI deployment guide

* Update on oci-vm.md

* bump

Co-authored-by: Dainius Salkauskas <dainiuxazz@gmail.com>
Co-authored-by: Sajarin <sajarindider@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>
Co-authored-by: Balasubramanian T K <btk.codedev@gmail.com>
Co-authored-by: Davin Chia <davinchia@gmail.com>
Co-authored-by: Cirdes <cirdes@linkana.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>
Co-authored-by: sbrickel-nimble <113671803+sbrickel-nimble@users.noreply.github.com>
Co-authored-by: Sebastian Brickel <sebastianbrickel@Sebastians-MacBook-Air.local>
Co-authored-by: Evan Tahler <evan@airbyte.io>
Co-authored-by: Sherif A. Nada <snadalive@gmail.com>
Co-authored-by: Jonathan Pearlin <jonathan@airbyte.io>
Co-authored-by: Victor Ikechukwu <vickyikechukwu13@gmail.com>

* Add versioning logging (#18618)

* Bmoric/extract healt api (#18523)

* Tmp

* Extract the Attempt API from the V1 API

* Add comments

* Move Connection API out of configuration API

* format

* format

* Rename to Controller

* Rename to Controller

* Add values to the factory

* Change the constructor to use hadler instead of objects needed by the handler

* Update with new tags.

* tmp

* Fix PMD errors

* Extract DB migrator

* Add something that I forgot

* extract destination definition api

* restore destination factory initialization

* extract destination definition specification api

* format

* format

* format

* extract health check api

* fix test

* format

* Fix ConfiguredCatalog for Resets (#18625)

We should only force (FULL_REFRESH,OVERWRITE) for the streams to reset.
For the other streams, we only want to replace OVERWRITE with APPEND to
avoid having destination clear the stream. The other cases should be
left as is.

* :tada: New Source: Mailjet SMS (#18345)

* init commit

* add doc

* add doc

* change authentication methode

* fix doc

* fix doc

* add docs

* fix comments

* use request_options_provider

* lint

* fix comments

Co-authored-by: Marcos Marx <marcosmarxm@users.noreply.github.com>

* More comprehensive temporal error message (#18608)

* To be remove

* Remove the signal for waiting after a failed activity and ensure we are waiting the expected time

* Revert "To be remove"

This reverts commit 3a5f7b4f729724e6943450af15b324ca05ac6c4d.

* Remove unused and move failure reason to the helper

* Avoid repetitive new Set()

* :tada: New Connector: Zendesk Sell [python cdk] (#17888)

* first working connector - overwrite only

* edit readme and source definitions

* Update source_definitions.yaml

* changing catalog and adding all available streams

* remove custom fields

* remove documents

* manage incremental syncs

* add unit tests ; add start date to specs

* try catch for next page token method

* Create source_to_test.py

* Update source.py

* Update source_to_test.py

* working source

* Delete TODO.md

* Update source.py

* Update spec.yaml

* Update test_streams.py

* give up on incremental and have something that works

* removing start date necessity in spec and sample configs

* add connector to source def

* run format

* update airbyte cdk version

* correct unit test

* run format

* auto-bump connector version

Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Source Mailjet SMS: publish PR and add source def (#18620)

* init commit

* add docs

* fix comments

* use request_options_provider

* solve conflict

* solve doc conflict

* Source Mailjet Mail: publish connector and additional format (#18586)

* init commit

* add streams

* add schemas

* solve conflict

* add docs

* fix comments

* restore vscode config

* restore vscode config

* clean

* lint

* lint

* lint

* lint

* fix comments

* run format

* update acceptance test

* update schema

* update acceptance test

* auto-bump connector version

Co-authored-by: Haithem SOUALA <haithem.souala@woopit.fr>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* add source def + correct tests

* update schema

Co-authored-by: Haithem SOUALA <haithem.souala@woopit.fr>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Add endpoint to retrieve manifest template (#18578)

* add endpoint to retrieve manifest template

* remove 400 error from endpoint

* Source S3: use AirbyteTracedException (#18602)

* #750 # 837 #904 Source S3: use AirbyteTracedException

* source s3: upd changelog

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Fix source spec diff (#18645)

* Rename maxCursor and add comment (#18570)

* Rename maxCursor to make the code easier to understand

* Rename and update comment

* ami-0d648081937c75a73 -> ami-06cf12549e3d9c522 (#18667)

Signed-off-by: Sergey Chvalyuk <grubberr@gmail.com>

* 🐛  Source Google Analytics (Universal Analytics): add `Custom Reports` schema validation on `Check Connection` (#18670)

* 🪟 🐛 Fix trailing whitespace and ending with a forward slash transformation GitHub URL issue (#18299)

* add regex matcher for custom transformation GitHub url

* move validationSchema to separate file

* add tests for validationSchema

* 🎉 New Source:  Omnisend (#18577)

* Init source omnisend

* Removed unnecessary files

* added campaigns, carts, orders, products streams

* Fix acceptance tests

* Added documentation

* Added pagination

* Removed abnormal state, uncommented acceptance tests

* Added docs references

* Added reference to PR

* Added stop condition for pagination

* Added title to API Key in spec.yaml

* add omnisend source to def seed

* run format

* auto-bump connector version

Co-authored-by: Rytis Mickevičius <rytis.mickevicius1@gmail.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Added a note about chained dbt transformations (#18678)

* Source metabase: allow using only https urls (#18607)

* #16519 source metabase: allow using only https urls

* source metabase: upd changelog

* #16519 fix url regexp

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* 🪟 🎉 Add sync mode, primary key, cursor select components to new streams table  (#18627)

* Add SyncModeSelect component
Add button type to pill button and stop propagation
Stop propagation on popoout outside click listener and migrate to scss module

* Update DropDown option to handle click event directly and stop propagation

* Add StreamPathSelect component to select the primary key and cursor paths
Update PillSelect to handle nil values

* Add SyncMode, Primary Key, and Cursor selects to CatalogTreeTableRow

* Replace popup click catcher with Overlay component
Add Overlay color variant and onClick handler option
Fix Overlay import

* Source Intercom: change airbyte-cdk version to 0.2 (#18681)

* Source Intercom: change airbyte-cdk version to 0.2

* Source Intercom: update chagelog

* Source Intercom: bump version and update chagelog

* Source Intercom: Fix PR id in chagelog

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* feat: Add airbyte-cron Helm chart (#18542)

* feat: Add airbyte-cron Helm chart

* New chart resides in `charts/airbyte-cron`
* Updated the parent chart (`airbyte`) `values.yaml` to include config
  key for `cron`

* Add airbyte-cron to release workflow

* chore: remove TEMPORAL_* vars

Co-authored-by: Kyryl Skobylko <xpuska513@gmail.com>

* fix: Typo in semver format for chart (#18686)

This looks to have been a mistaken change that was made to the workflow. Reverting back to the original value.

* 🐛 Source Amplitude: fix empty `series` for `AverageSessionLength` stream (#18684)

* Destination Redis: TLS support (#18358)

* 16249 Destination Redis TLS support

* Refactoring based on pr review

* Remove duplicate paragraph (#18662)

Removes a duplicate of the paragraph that begins "Note that we're also setting the `stream_cursor_field` in the stream's `$options`..." which followed an outdated schema.

* Simplify the job persistence method. (#18698)

Method interface:
- has generic type that isn't needed. Confusing because no generic is happening here.
- has two existing parameters that are data fields of one of the already existing parameters. Confusing since the two additional parameters aren't actually supposed to be passed in separately from the existing parameter.

Remove both.

* chore: Add airbyte-cron chart to .bumpversion.cfg (#18688)

* fix helm release workflow (#18716)

* AMI change: ami-0f23be2f917510c26 -> ami-005924fb76f7477ce (#18689)

Signed-off-by: Sergey Chvalyuk <grubberr@gmail.com>

* Remove unused test script. (#18715)

* ci: replace set-output with new github actions syntax (#18691)

* Sources postgres, mysql, alloydb: encode database name (#18538)

* Source postgres: encode database name

* Source postgres, mysql: move encoding in util class, apply for mysql

* Source postgres, mysql: make var final

* Source postgres, mysql: bump version

* Source postgres, mysql: format code

* auto-bump connector version

* Source mysql: bump version

* auto-bump connector version

* auto-bump connector version

Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Source Prestashop: prevent users from using http url (#18599)

Signed-off-by: Sergey Chvalyuk <grubberr@gmail.com>

* add nonBreakingChangePreference and notifySchemaChanges (#18636)

* add nonBreakingChangePreference and notifySchemaChanges

* Changes docs deploy failures to show up in #docs (#18738)

* Green house docs (#18314)

* corrected the documentation for FreshDesk Connector

* corrected the documentation for Greenhouse Connector

* Resurfaces hidden cloud connectors within UI (#18748)

* Update helpers functions in subcharts (#18757)

* Update helpers functions in subcharts; Refactor component.imageTag function call

* fix typo in _helpers.tpl

* Update chart.yaml to reference right subchart (#18718)

* Update chart.yaml to reference right subchart

* Update airbyte-cron chart name

* 🎉 New Destination: Heap Analytics [python cdk] (#18530)

* 🎉 New Desination: Heap Analytics [python cdk]

- implement a heap client to load data via the server-side API: https://developers.heap.io/reference/server-side-apis-overview
- the connector supports a generic data source, and the api_type determines the output schema. The output schema is dynamic.
- users pick the columns that will be loaded to the destination
- Consequently, each configured catalog only includes one stream

* add a bootstrap to illustrate the connector

* add destination dest def

* run format all files

* correct unit test

* auto-bump connector version

Co-authored-by: Vincent Koc <koconder@users.noreply.github.com>
Co-authored-by: marcosmarxm <marcosmarxm@gmail.com>
Co-authored-by: Octavia Squidington III <octavia-squidington-iii@users.noreply.github.com>

* Source Salesforce: add get_error_display_message for ConnectionError (#18753)

Signed-off-by: Sergey Chvalyuk <grubberr@gmail.com>

* fix helm release workflow (#18776)

* Update to latest Micronaut release (#18774)

* fix cron resources spec (#18778)

* ci: use oldgithub actions notation for output in publish-helm-charts worklow (#18780)

* improve connector dependency github action (#18480)

* Use more specific variable name

* Write affected sources and destinations to files

* Use Markdown template to format results

* Update workflow to edit existing comment instead of making a new one

* Check whether changed_files.txt is empty before proceeding

* move template to .github/

* Use different quotes for true

* Move logic about continuing back to after dependency report because of ignores

* Use correct filename in conditional

* Use if to avoid early exit

* Create folder for comment templates and use constant for file path

* Add handling for non-source non-destination info, pull out markdown listing

* 🐛 Add a drop table hook to drop scd tables in case of overwrite sync (#18015)

* Add a drop table hook to drop scd tables in case of overwrite sync

* Add an integration test for dropping SCD table on overwrite

* skip new…

[![Image 173: @RealChrisSean](https://avatars.githubusercontent.com/u/28903572?s=40&u=149e9f0e4ae4b9ad81ee6931eb0f33bcdecdd0d7&v=4)](https://github.com/RealChrisSean)[Chris "Sean" Dabatos (RealChrisSean)](https://github.com/RealChrisSean) added the [low-code](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Alow-code) label [Nov 15, 2022](https://github.com/airbytehq/airbyte/pull/18301#event-7810507310)

[![Image 174: @devin-ai-integration](https://avatars.githubusercontent.com/in/811515?s=40&v=4)](https://github.com/apps/devin-ai-integration)[devin-ai-integration](https://github.com/apps/devin-ai-integration)Bot mentioned this pull request [Oct 8, 2026](https://github.com/airbytehq/airbyte/pull/18301#ref-pullrequest-5769740029)

[fix(source-news-api): correct "comma-separated" typo in spec descriptions #88386](https://github.com/airbytehq/airbyte/pull/88386)

 Closed 

1 of 2 tasks

 This file contains hidden or bidirectional Unicode text that may be interpreted or compiled differently than what appears below. To review, open the file in an editor that reveals hidden Unicode characters. [Learn more about bidirectional Unicode characters](https://github.co/hiddenchars)

[Show hidden characters](https://github.com/airbytehq/airbyte/pull/%7B%7B%20revealButtonHref%20%7D%7D)

[Sign up for free](https://github.com/join?source=comment-repo)**to join this conversation on GitHub**. Already have an account? [Sign in to comment](https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fairbytehq%2Fairbyte%2Fpull%2F18301)

### Reviewers

 1 more reviewer 

[![Image 175: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=40&v=4)](https://github.com/marcosmarxm)[M. Marx (marcosmarxm)](https://github.com/marcosmarxm)[](https://github.com/airbytehq/airbyte/pull/18301/files/1a9b432d9c24f21410fb51a24c186848b98214d5)marcosmarxm approved these changes

Reviewers whose approvals may not affect merge requirements

### Uh oh!

There was an error while loading. [Please reload this page](https://github.com/airbytehq/airbyte/pull/18301).

### Assignees

 No one assigned 

### Labels

[area/connectors](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Aarea%2Fconnectors)Connector related issues[area/documentation](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Aarea%2Fdocumentation)Improvements or additions to documentation[community](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Acommunity)[connectors/source/news-api](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Aconnectors%2Fsource%2Fnews-api)[hacktober](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Ahacktober)[internal](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Ainternal)[low-code](https://github.com/airbytehq/airbyte/issues?q=state%3Aopen%20label%3Alow-code)

### Projects

 None yet 

### Milestone

 No milestone 

### Development

Successfully merging this pull request may close these issues.

None yet

### 6 participants

[![Image 176: @isaacharrisholt](https://avatars.githubusercontent.com/u/47423046?s=52&v=4)](https://github.com/isaacharrisholt)[![Image 177: @marcosmarxm](https://avatars.githubusercontent.com/u/5154322?s=52&v=4)](https://github.com/marcosmarxm)[![Image 178: @RealChrisSean](https://avatars.githubusercontent.com/u/28903572?s=52&v=4)](https://github.com/RealChrisSean)[![Image 179: @bleonard](https://avatars.githubusercontent.com/u/36106?s=52&v=4)](https://github.com/bleonard)[![Image 180: @sajarin](https://avatars.githubusercontent.com/u/15092743?s=52&v=4)](https://github.com/sajarin)[![Image 181: @octavia-squidington-iii](https://avatars.githubusercontent.com/u/90398440?s=52&v=4)](https://github.com/octavia-squidington-iii)

Add this suggestion to a batch that can be applied as a single commit.This suggestion is invalid because no changes were made to the code.Suggestions cannot be applied while the pull request is closed.Suggestions cannot be applied while viewing a subset of changes.Only one suggestion per line can be applied in a batch.Add this suggestion to a batch that can be applied as a single commit.Applying suggestions on deleted lines is not supported.You must change the existing code in this line in order to create a valid suggestion.Outdated suggestions cannot be applied.This suggestion has been applied or marked resolved.Suggestions cannot be applied from pending reviews.Suggestions cannot be applied on multi-line comments.Suggestions cannot be applied while the pull request is queued to merge.Suggestion cannot be applied right now. Please check back later.

## Footer

[](https://github.com/) © 2026 GitHub,Inc. 

### Footer navigation

*   [Terms](https://docs.github.com/site-policy/github-terms/github-terms-of-service)
*   [Privacy](https://docs.github.com/site-policy/privacy-policies/github-privacy-statement)
*   [Security](https://github.com/security)
*   [Status](https://www.githubstatus.com/)
*   [Community](https://github.community/)
*   [Docs](https://docs.github.com/)
*   [Contact](https://support.github.com/?tags=dotcom-footer)
*    Manage cookies 
*    Do not share my personal information 

 You can’t perform that action at this time.
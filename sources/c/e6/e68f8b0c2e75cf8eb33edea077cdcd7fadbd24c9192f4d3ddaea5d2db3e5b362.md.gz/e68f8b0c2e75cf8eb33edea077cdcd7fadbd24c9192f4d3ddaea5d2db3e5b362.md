We provide 100 Mbps dedicated port speed for each VPS, which depends on the selected package. However, it can be upgraded to 1 Gbps - the monthly price of the component is 1.33 EUR.

However, please note that the final speed to the client’s end depends on many factors, mostly on distance and ISPs (Internet Service Providers) between client and server. You can check port speed, latency via our [Looking Glass](http://lg.time4vps.com/).

**Attention:** If you exceed your monthly bandwidth allocation, we will divide your port speed by 10 until next month. So if you have 1 Gbps port speed and exceed monthly bandwidth, your port speed will be capped to 100 Mbps till next month.

---

Related Articles

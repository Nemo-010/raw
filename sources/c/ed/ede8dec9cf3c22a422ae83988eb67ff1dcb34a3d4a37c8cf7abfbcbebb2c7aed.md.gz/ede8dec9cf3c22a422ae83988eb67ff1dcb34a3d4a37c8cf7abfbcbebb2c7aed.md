[CORE API](https://core.ac.uk/contact)

- Welcome!
- Quick start examples
- Data Providers
 - optsIntroduction
 - optsSearch Data Providers
 - optsSearch Data Providers using aggregation
 - getGet a single data provider
 - getSearch outputs
 - getGet statistics about a data provider
 - postStatistics with options. OpenDOAR
- Discovery
 - postDiscover full texts links.
- Journals
 - optsIntroduction
 - optsSearch Journals
 - optsSearch Journals using aggregation
 - getGet the Journal by identifier
 - getStatistics
- Outputs
 - optsIntroduction
 - optsSearch Outputs
 - optsSearch Outputs using aggregation
 - getGet a single Output
 - getDownload output file
 - getHistorical data for an output
 - getDownload raw XML record for an output
 - getGet statistics about an output
- Recommender
 - postRecommend.
- Search
 - optsCORE API Query Language
 - optsKeyword Queries and Phrase Matching
 - optsFree Text Search - Searching without field lookup
 - optsSearch using aggregation
 - postSearch through all CORE entities using HTTP Post
 - getSearch through all CORE entities
 - postAggregate CORE entities based on a search query
- Works
 - optsIntroduction
 - optsSearch Works
 - optsSearch Works using aggregation
 - getGet single Work
 - getGet outputs related to Work
 - getGet statistics about Work
 - getDownload the parsed Work - TEI file
 - getDownload the Work file
- Entities
 - optsIntroduction
 - optsCORE data model
- Rate limits
 - optsCommon
 - optsHow to monitor your API rate limits
- optsHow to call the API
- optsPDF download policy

[API docs by Redocly](https://redocly.com/redoc/)

# CORE API (3.0.0)

CORE API support: [theteam@core.science](mailto:theteam@core.science) URL: [https://core.ac.uk/contact](https://core.ac.uk/contact) License: [CORE terms](https://core.ac.uk/terms) [Terms of Service](https://core.ac.uk/terms)

## Welcome!

You can use the CORE API to access the resources harvested and enriched by CORE. If you encounter any problems with the API, please [report them to us](https://core.ac.uk/contact).

### How to cite the CORE API in your work

> **[CORE: A Global Aggregation Service for Open Access Papers](https://www.nature.com/articles/s41597-023-02208-w)** 
> _Knoth, P., Herrmannova, D., Cancellieri, M. et al. CORE: A Global Aggregation Service for Open Access Papers. Nature Scientific Data 10, 366 (2023). https://doi.org/10.1038/s41597-023-02208-w_

> **[CORE: three access levels to underpin open access](http://oro.open.ac.uk/35755/)** 
> _Knoth, P., & Zdrahal, Z. (2012). CORE: three access levels to underpin open access. D-Lib Magazine, 18(11/12). Retrieved from http://oro.open.ac.uk/35755/_

[SEE MORE](https://core.ac.uk/about/research-outputs)

## Quick start examples

You can look at a webinar describing all the APIv3 features with a live example [on our blog.](https://blog.core.ac.uk/2022/01/19/access-the-worlds-research-outputs-through-the-core-api/) The following is a list of links to simple examples on how to use the features of the CORE API. This list is constantly evolving. If you would like to contribute or suggest any change,[contact us](https://core.ac.uk/contact).

- [Did research stop during COVID?](https://github.com/oacore/apiv3-webinar) The Notebook, also used throughout the webinar showcases most of the features of the API and how to use them to generate meaningful visualisations.
- [Download all the identifiers from a Data Provider](https://colab.research.google.com/drive/1_bjqDQhqj7AnSfoCAXDCMOnGZLPQWKfu?usp=sharing) Python notebook using the scan and scroll search to generate a dataset containing all the identifiers for the records of a data provider.
- [Compare Journals and Data Providers](https://colab.research.google.com/drive/10dmk7D9oA8xDQrNyh2o91eUu60a-Q7LW?usp=sharing) Python notebook that downloads a list of Journals and compare them with the list of Data Providers in CORE.

## Data Providers

## Introduction

Data-providers entity gives access to the collection of sources that supply content to CORE. These include – Institutional repositories, disciplinary repositories, preprint servers, journals and publishers. Each data provider record includes details about the source, such as its name, OAI-PMH endpoint, metadata format, software used, institutional identifiers, and geographic location. 

Data-providers response field descriptions is shown below:

| Field Name | Description | Method for obtaining the value | Searchable field | Cardinality |
| --- | --- | --- | --- | --- |
| 'aliases' | List of alternative names or acronyms for the institution. | Research Organization Registry (ROR) | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/data-providers/?q=aliases:Lisboa](https://api.core.ac.uk/v3/search/data-providers/?q=aliases:Lisboa) | multiple |
| 'createdDate' | | Database | | single |
| 'email' | Contact email for the data provider. | Manually curated and from oai-pmh | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/data-providers/?q=email:"napier.ac.uk](https://api.core.ac.uk/v3/search/data-providers/?q=email:%22napier.ac.uk)" | single |
| 'homepageUrl' | Homepage URL of the data provider. | Manually curated and automatically detected | | single |
| 'id' | Unique identifier for the data provider. | Database | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/data-providers/?q=id:"100](https://api.core.ac.uk/v3/search/data-providers/?q=id:%22100)"<br><br>Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["id"] }` | single |
| 'institutionName' | Name of the institution responsible for the repository or data provider. | Research Organization Registry (ROR) | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/data-providers/?q=institutionName:Basel](https://api.core.ac.uk/v3/search/data-providers/?q=institutionName:Basel) | single |
| 'location' | Geographical location details about the data provider or repository, including country code, latitude, and longitude. Format -<br>`"location":`<br>` {`<br>`   "countryCode": "< ISO_country_code>",`<br>`   "latitude": < latitude_value>,`<br>`   "longitude": < longitude_value>`<br>` }` | Manually curated or available at various repository sources | Searchable with subfields via GET.<br>Example: [https://api.core.ac.uk/v3/search/data-providers/?q=location.countryCode:se](https://api.core.ac.uk/v3/search/data-providers/?q=location.countryCode:se) | |
| 'logo' | CORE API URL to the logo image of the data provider. | Manually curated | | single |
| 'metadataFormat' | Metadata format used. | Automatically detected or manually curated | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/data-providers/?q=metadataFormat:"rioxx](https://api.core.ac.uk/v3/search/data-providers/?q=metadataFormat:%22rioxx)" | single |
| 'name' | Name of the data provider. | From db, manually curated and automated | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/data-providers/?q=name:Glasgow](https://api.core.ac.uk/v3/search/data-providers/?q=name:Glasgow) | single |
| 'oaiPmhUrl' | Open Archives Initiative Protocol for Metadata Harvesting (OAI-PMH) endpoint URL of a repository. | Manually curated and automatically added | | single |
| 'openDoarId' | Unique identifier of the repository from OpenDOAR. | From matching with opendoar | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/data-providers/?q=openDoarId:1275](https://api.core.ac.uk/v3/search/data-providers/?q=openDoarId:1275)<br><br>Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["openDoarId"] }` | single |
| 'otherIdentifiers' | External global identifiers for the institution including Global Research Identifier Database (GRID) ID. Format -<br>`"otherIdentifiers":`<br>`   {`<br>`    "< identifier_type>":  `<br>`       {`<br>`       "preferred": "< preferred_identifier>",`<br>`       "all": "< all_identifiers>"`<br>`       }`<br>`   }` | Research Organization Registry (ROR) | | multiple |
| 'rorId' | Unique ROR (Research Organization Registry) identifier. | Automatically detected by matching institutions and also manually curated | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/data-providers/?q=rorId:"https://ror.org/04ea70f07](https://api.core.ac.uk/v3/search/data-providers/?q=rorId:%22https://ror.org/04ea70f07)" | single |
| 'software' | Software used by data-providers for managing digital repositories. Examples include - ‘EPrints’, ‘DSpace’, ‘WEKO’, ‘DigitalCommons / BEPress’, ‘ojs’, ‘Dataverse’ etc. | Automatically detected | Searchable using field lookup via GET.Example - [https://api.core.ac.uk/v3/search/data-providers/?q=software:"DSpace](https://api.core.ac.uk/v3/search/data-providers/?q=software:%22DSpace)" Supports aggregation via POST.Example - Body: `{ "aggregations": ["software"] }` | single |
| 'type' | Indicates the classification of the data provider. Possible values are REPOSITORY, JOURNAL | Automatically detected based on repository features | | single |

##### Authorizations:

NoneNone

options/v3/data-providers/intro

Live server.

https://api.core.ac.uk/v3/data-providers/intro

## Search Data Providers

Search through the CORE data providers entity using specific query parameters and fields. Below are detailed instructions and examples of how to perform targeted searches. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/search/data-providers
```

**Example Search** 

The following query retrieves all data providers in the US with "university" in the name of the data provider. 

[https: //api.core.ac.uk/v3/search/data-providers/?q=location.countryCode:us AND name:university](https://api.core.ac.uk/v3/search/data-providers/?q=location.countryCode:us%20AND%20name:university)

```
   def search_dp_by_id(id:str):
       url = "https://api.core.ac.uk/v3/search/data-providers"
       headers = {"Authorization": f"Bearer {apikey}"}
       params = {"q": f"id:"{id}"", "limit": 1}

           try:
               response = requests.get(url, headers=headers, params=params)
               if response.status_code == 200:
                   return response.json()
               else:
                   print(f"Error {response.status_code}: {response.text}")
                   return None
           except requests.exceptions.RequestException as e:
               print(f"Request failed: {e}")
               return None
```

More examples on data-providers field specific search is available [here](https://api.core.ac.uk/docs/v3#tag/Data-Providers/operation/optionsCustomDataProviders)

##### Authorizations:

NoneNone

options/v3/data-providers/search

Live server.

https://api.core.ac.uk/v3/data-providers/search

## Search Data Providers using aggregation

POST request body example:

```
{
   "q": "climate change", 
   "aggregations": ["id"]
}
```

Example source code to aggregate results for outputs based on the above request body:

```
def search_with_aggregation(query):
   url = "https://api.core.ac.uk/v3/search/data-providers/aggregate"
   headers = {
       "Authorization": f"Bearer {apikey}",
       "Content-Type": "application/json"
   }

   data = {
       "q": query,
       "aggregations": ["id"]
   }

   try:
       response = requests.post(URL, json=data, headers=headers)
       if response.status_code == 200:
           print("Aggregation Results:")
           print(response.json())
       else:
           print(f"Error {response.status_code}: {response.text}")

   except requests.exceptions.RequestException as e:
       print(f"Request failed: {e}")
```

##### Authorizations:

NoneNone

options/v3/data-providers/aggregation

Live server.

https://api.core.ac.uk/v3/data-providers/aggregation

## Get a single data provider

Get a single data provider of CORE using the data provider id. [Here](https://core.ac.uk/data-providers) you can see our data providers. If you add the prefix `opendoar`. You can also fetch data providers using the OpenDOARId. The API endpoint retrieves detailed metadata for a single data provider in CORE. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/data-providers/{identifier}
```

where the **{identifier}** represents the data-provider id. 

Example GET request - [https://api.core.ac.uk/v3/data-providers/92](https://api.core.ac.uk/v3/data-providers/92) 
Example GET request By OpenDOAR ID - [https://api.core.ac.uk/v3/data-providers/opendoar:1334](https://api.core.ac.uk/v3/data-providers/opendoar:1334)

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

integer

`<DataProviderID>` or `opendoar:<OpenDOARId>`

### Responses

**200**

**404**

The identifier doesn't match any data provider in CORE.

get/v3/data-providers/{identifier}

Live server.

https://api.core.ac.uk/v3/data-providers/{identifier}

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "id": 86,      -   "openDoarId": 300,      -   "name": "Open Research Online",      -   "email": "library-research-support@core.science",      -   "uri": null,      -   "oaiPmhUrl": "[https://oro.open.ac.uk/cgi/oai2](https://oro.open.ac.uk/cgi/oai2)",      -   "homepageUrl": "[https://oro.open.ac.uk](https://oro.open.ac.uk)",      -   "source": null,      -   "software": "eprints",      -   "metadataFormat": "rioxx",      -   "createdDate": "2011-05-06T10:11:21+00:00",      -   "location": {          -   "countryCode": "gb",              -   "latitude": 52.0333,              -   "longitude": -0.7                   },      -   "logo": "[https://localhost:8000/data-providers/86/logo](https://localhost:8000/data-providers/86/logo)",      -   "type": "REPOSITORY",      -   "stats": null,      -   "rorId": "[https://ror.org/05mzfcs16](https://ror.org/05mzfcs16)",      -   "institutionName": "The Open University",      -   "aliases": [          -   "cy: Y Brifysgol Agored",              -   "OU"                   ],      -   "otherIdentifiers": {          -   "GRID": {                  -   "preferred": "grid.10837.3d",                      -   "all": "grid.10837.3d"                               },              -   "ISNI": {                  -   "all": "0000 0000 9606 9301"                               },              -   "FundRef": {                  -   "preferred": 100008509,                      -   "all": "100008509;501100006627;501100000605"                               },              -   "Wikidata": {                  -   "all": "Q2413375"                               }                   }       }`

## Search outputs

Search through the outputs harvested from this data provider. The simple search is great for most of the queries but is limited to 10,000 items. See the section [Querying large datasets](https://api.core.ac.uk/docs/v3#query_large) to overcome this limit.

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

integer\\d+

The Data Provider ID

##### query Parameters

| q<br>required | string<br>Default: ""<br>The query see the [Query section](https://api.core.ac.uk/docs/v3#query_language) on how to build a search query. |
| --- | --- |
| offset<br>required | integer<br>Default: "0"<br>The starting point in your search. |
| sort<br>required | string<br>Default: "relevance"<br>The way you want to sort the results. Recommended values are 'recency' and 'relevance' |
| limit<br>required | integer<br>Default: "10"<br>The size of your search, maximum size is 100 outputs per request. |

### Responses

**200**

Contains the outputs from the data provider matching the search query.

get/v3/data-providers/{identifier}/outputs

Live server.

https://api.core.ac.uk/v3/data-providers/{identifier}/outputs

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "totalHits": 10733,      -   "limit": 1,      -   "offset": 0,      -   "results": [ ],      -   "tooks": null,      -   "esTook": null       }`

## Get statistics about a data provider

Get the aggregated data behind a Data Provider. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/data-providers/{identifier}/stats
```

where the **{identifier}** represents the data-provider id. The statistics reflect the overall volume and status of content contributed by the data provider. 

Example Request - [https://api.core.ac.uk/v3/data-providers/122/stats](https://api.core.ac.uk/v3/data-providers/122/stats)

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

integer\\d+

The Data Provider ID

### Responses

**200**

Returns the rewards of an user

**404**

The identifier doesn't match any output in CORE.

get/v3/data-providers/{identifier}/stats

Live server.

https://api.core.ac.uk/v3/data-providers/{identifier}/stats

### Response samples

**200**

Content type

application/json

Copy

`{  -   "id": 86,      -   "countMetadata": 47000,      -   "countFulltext": 16795,      -   "history": null       }`

## Statistics with options. OpenDOAR

Get the aggregated data behind a Data Provider and his history

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

integer\\d+

The Data Provider ID

##### Request Body schema: application/json

optional

| identifier<br>required | integer |
| --- | --- |
| deposit\_history<br>required | boolean |
| raw\_stats<br>required | boolean |
| set<br>required | string |
| refresh<br>required | boolean |

### Responses

**200**

**404**

The identifier doesn't match any output in CORE.

post/v3/data-providers/{identifier}/stats

Live server.

https://api.core.ac.uk/v3/data-providers/{identifier}/stats

### Request samples

**Payload**

Content type

application/json

Copy

`{  -   "identifier": 0,      -   "deposit_history": true,      -   "raw_stats": true,      -   "set": "string",      -   "refresh": true       }`

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "id": 0,      -   "count_metadata": "string",      -   "count_fulltext": "string",      -   "history": [          -   "string"                   ],      -   "source_stats": [          -   "string"                   ],      -   "last_seen": [          -   "string"                   ],      -   "set": [          -   "string"                   ]       }`

## Discovery

## Discover full texts links.

This endpoint allows you to find links to full texts based on a DOI. The system will search through the CORE data and other external sources to provide you the best match.

##### Authorizations:

NoneNone

##### Request Body schema: application/json

required

Discovery parameters

| doi<br>required | string |
| --- | --- |
| title<br>required | string |
| year<br>required | integer |
| eprints\_id<br>required | string |
| plugin\_id<br>required | string |
| referrer<br>required | string |

### Responses

**200**

post/v3/discover

Live server.

https://api.core.ac.uk/v3/discover

### Request samples

**Payload**

Content type

application/json

Copy

`{  -   "doi": "string",      -   "title": "string",      -   "year": 0,      -   "eprints_id": "string",      -   "plugin_id": "string",      -   "referrer": "string"       }`

### Response samples

**200**

Content type

application/json

Copy

`{  -   "fullTextLink": "...",      -   "source": "..."       }`

## Journals

## Introduction

The Journals entity provides metadata about academic journals associated with the CORE collection. This includes journals directly supplied by CORE data providers and those referenced through metadata enrichment. Each journal object includes key information such as identifiers (e.g. ISSN, DOAJ ID), subject areas, language, publisher, and a link to a contributing data provider. 

More details about the Journals response fields is as follows:

| Field Name | Description | Method for obtaining the value | Searchable field | Cardinality |
| --- | --- | --- | --- | --- |
| 'dataProviderId' | Unique identifier in CORE assigned for data-provider. | Database | | single |
| 'identifiers' | List of unique identifiers associated with a journal, such as ISSNs, OAI identifiers, and URLs. Format -<br>`"identifiers":`<br>`   [`<br>`   "< identifier_value>",`<br>`   "issn:< issn_value>",`<br>`   "oai:< oai_identifier>",`<br>`   "url:< journal_url>"`<br>`   ]` | From list | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/journals/?q="1744-9081](https://api.core.ac.uk/v3/search/journals/?q=%221744-9081)" | multiple |
| 'language' | Language used in the journal. | Collected at submission time, either manually or automatically | | single |
| 'publisher' | Name of the publisher. | Collected at submission time, either manually or automatically | | single |
| 'subjects' | List of domains associated with the journal. Possible values - ‘Medicine’, ‘Science’, ‘Social Sciences’, ‘Mathematics’, ‘Chemistry’, etc. | Collected at submission time, either manually or automatically | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/journals/?q=subjects:Agriculture](https://api.core.ac.uk/v3/search/journals/?q=subjects:Agriculture)<br><br>Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["subjects"] }` | multiple |
| 'title' | Name of the journal. | Collected at submission time, either manually or automatically | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/journals/?q=title:Revista](https://api.core.ac.uk/v3/search/journals/?q=title:Revista) | single |

##### Authorizations:

NoneNone

options/v3/journals/intro

Live server.

https://api.core.ac.uk/v3/journals/intro

## Search Journals

Search through the CORE data providers entity using specific query parameters and fields. Below are detailed instructions and examples of how to perform targeted searches.**API Endpoint** 

```
GET https://api.core.ac.uk/v3/search/journals
```

**Example Search** 
The following query retrieves 10 journals with "neuroscience" in the subject and "Brain" in the title: 

[https: //api.core.ac.uk/v3/search/journals?q=title:"Brain" AND subjects:"neuroscience"&limit=10](https://api.core.ac.uk/v3/search/journals/?q=title:%22Brain%22%20AND%20subjects:%22neuroscience%22&limit=10) 

Example python source code to search journals by subject:

```
   def search_journal_by_subject(subject:str):
       url = "https://api.core.ac.uk/v3/search/journals"
       headers = {"Authorization": f"Bearer {apikey}"}
       params = {"q": f"subjects:"{subject}"", "limit": 1, "offset":1}

           try:
                   response = requests.get(url, headers=headers, params=params)
               if response.status_code == 200:
                   return response.json()
               else:
                   print(f"Error {response.status_code}: {response.text}")
                   return None
           except requests.exceptions.RequestException as e:
               print(f"Request failed: {e}")
               return None
```

More examples on journals field specific search is available [here](https://api.core.ac.uk/docs/v3#tag/Journals/operation/optionsCustomJournals)

##### Authorizations:

NoneNone

options/v3/journals/search

Live server.

https://api.core.ac.uk/v3/journals/search

## Search Journals using aggregation

POST request body example:

```
{
   "q": "climate change",
   "aggregations": ["subjects"]
}
```

```
def search_with_aggregation(query):
   url = "https://api.core.ac.uk/v3/search/journals/aggregate"
   headers = {
       "Authorization": f"Bearer {apikey}",
       "Content-Type": "application/json"
   }
   data = {
       "q": query,
       "aggregations": ["subjects"]
   }

   try:
       response = requests.post(url, json=data, headers=headers)

   if response.status_code == 200:
       print("Aggregation Results:")
       print(response.json())
   else:
       print(f"Error {response.status_code}: {response.text}")
   except requests.exceptions.RequestException as e:
       print(f"Request failed: {e}")
```

Aggregation response sample for `query="climate change"`

```
{'aggregations':
   {'subjects':
       {'climate change': 14,
       'Environmental sciences': 10,
       'GE1-350': 10,
       'Q': 7,
       'Science': 7,
       'G': 5,
       'Geography. Anthropology. Recreation': 5,
       'ecology': 4,
        .....................
       .....................
       'proteomics': 1,
       'renewable energies': 1,
       'risk management': 1,
       'sensors': 1,
       'social sustainability': 1}
    }
}
```

The journals API response fields that support aggregation can be viewed [here](https://api.core.ac.uk/docs/v3#tag/Journals/operation/optionsCustomJournals).

##### Authorizations:

NoneNone

options/v3/journals/aggregation

Live server.

https://api.core.ac.uk/v3/journals/aggregation

## Get the Journal by identifier

Get a single journal based on its identifier in CORE. You can use the prefix `issn:` to search by ISSN. CORE journal data comes from multiple sources including members of the Directory of Open Access Journals (DOAJ) and Open Journal System repositories. We also aggregate open access content directly from publishers via our own custom solutions.

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

string\[A-Za-z\]+:.+

The Journal id in CORE. Use `issn:ISSN` to search by ISSN instead of the CORE identifier.

### Responses

**200**

**404**

The identifier doesn't match any Journal in CORE.

get/v3/journals/{identifier}

Live server.

https://api.core.ac.uk/v3/journals/{identifier}

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "identifiers": [          -   "oai:doaj.org/journal:fc6f85dc44ed458b983814eb3628da53",              -   "issn:1179-1497",              -   "url:http://doaj.org/toc/fc6f85dc44ed458b983814eb3628da53"                   ],      -   "language": "English",      -   "publisher": "Dove Medical Press",      -   "subjects": [          -   "neuropsychiatry",              -   "behavioral complications",              -   "HIV research",              -   "AIDS research",              -   "pathology",              -   "LCC:Neurosciences. Biological psychiatry. Neuropsychiatry",              -   "LCC:RC321-571",              -   "LCC:Internal medicine",              -   "LCC:RC31-1245",              -   "LCC:Medicine",              -   "LCC:R"                   ],      -   "dataProviderId": "645",      -   "title": "Neurobehavioral HIV Medicine"       }`

## Statistics

Get the aggregated data for the corresponding Journal. This data matches the data coming from the associated Data Provider.

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

string\[A-Za-z\]+:.+

The Journal ID use `issn:` for ISSNs.

### Responses

**200**

**404**

The identifier doesn't match any Journal in CORE.

get/v3/journals/{identifier}/stats

Live server.

https://api.core.ac.uk/v3/journals/{identifier}/stats

### Response samples

**200**

Content type

application/json

Copy

`{  -   "identifier": 0,      -   "count_metadata": "string",      -   "count_fulltext": "string",      -   "doi_count": "string"       }`

## Outputs

## Introduction

Outputs are the raw, source-specific representations of research works as harvested directly from individual data providers (e.g., institutional repositories). Unlike Works, Outputs are not deduplicated or enriched — they reflect the original metadata exactly as provided by the source. Each Output is a single harvested item from a repository, preprint server, or journal and includes detailed metadata such as authors, identifiers, publication date, full text (when available), repository source information and more. 

Outputs response field details are described in the following table.

| Field Name | Description | Method for obtaining the value | Searchable field | Cardinality |
| --- | --- | --- | --- | --- |
| 'abstract' | Abstract of the document. | OAI-PMH | | single |
| 'acceptedDate' | Date when the article was accepted for publication. Format -<br>`YYYY-MM-DDTHH:MM:SS` | Crossref | Supports aggregation via POST.Example - Body: `{ "aggregations": ["acceptedDate"] }` | single |
| 'authors' | List of authors | OAI-PMH | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/outputs/?q=authors:Schmidt](https://api.core.ac.uk/v3/search/outputs/?q=authors:Schmidt) | multiple |
| 'contributors' | List of entities (editors, translators, organisations etc.) responsible for making contributions to the resource. | OAI-PMH | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/outputs/?q=contributors:Schmidt&limit=50](https://api.core.ac.uk/v3/search/outputs/?q=contributors:Schmidt&limit=50) | multiple |
| 'createdDate' | Timestamp when the output record was initially created in CORE. Format -<br>`YYYY-MM-DDTHH:MM:SS±HH:MM` | Database | | single |
| 'deleted' | Shows the status of the document, if it is accessible or not. Format - `"deleted": "< status>"`, where status is ALLOWED (accessible) or DELETED (non-accessible). | Database | Supports aggregation via POST. Example - Body: `{ "aggregations": ["deleted"] }` | single |
| 'depositedDate' | The timestamp indicating when the article was initially deposited in the institutional repository. Format -<br>`YYYY-MM-DDTHH:MM:SS±HH:MM` | OAI-PMH | Supports aggregation via POST.Example - Body: `{ "aggregations": ["depositedDate"] }` | single |
| 'disabled' | Boolean flag (true / false) that shows if the document is disabled or restricted in the system. | Database | | single |
| 'documentType' | List of types of the outputs. Example types are ‘research’, ‘thesis’, ‘unknown’, ‘slides’, ‘research article’, 'text', 'journal article', 'conference paper', 'review', 'book', 'other', 'report', 'project', 'doctoral thesis’, 'book part', 'working paper', 'dataset', 'master thesis', 'presentation', 'bachelor thesis', 'lecture', 'conference proceedings', 'image', 'software', 'conference object', 'patent', 'video', 'annotation', 'conference poster', 'musical notation', 'preprint', 'technical report', ‘interactive resource’, ‘research proposal’, ‘review article’. | Using machine learning-based approach when full-text is available, otherwise with an interpretation of the values from dc.subject and dc.type | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/outputs/?q=documentType:thesis](https://api.core.ac.uk/v3/search/outputs/?q=documentType:thesis)<br>Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["documentType"] }` | multiple |
| 'doi' | DOI of the output. | OAI-PMH and Crossref matching | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/outputs/?q=doi:"10.1007/s002210100705](https://api.core.ac.uk/v3/search/outputs/?q=doi:%2210.1007/s002210100705)"<br>Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["doi"] }` | single |
| 'downloadUrl' | Direct link to download the full-text document in PDF format (if available). More information about our PDF download policy can be viewed [here](https://api.core.ac.uk/docs/v3#operation/PDFDownloadPolicy) | Database | Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["downloadUrl"] }` | |
| 'fullText' | Full-text of the output. | From downloading and parsing the pdf | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/outputs/?q=fullText:Ontario](https://api.core.ac.uk/v3/search/outputs/?q=fullText:Ontario) | single |
| 'fulltextStatus' | Indicates whether full text is present (enabled) or not (disabled). | Database | | single |
| 'id' | Unique CORE identifier (CORE\_ID) | Database | Searchable using field lookup via GET.Example - [https://api.core.ac.uk/v3/search/outputs/?q=id:216874849](https://api.core.ac.uk/v3/search/outputs/?q=id:216874849)<br>Supports aggregation via POST. Example - Body: `{ "aggregations": ["id"] }` | single |
| 'identifiers' | External unique identifiers for the document, such as DOI and OAI. Format -<br>`"identifiers":`<br>`{`<br>`   "doi": "< doi_value>",`<br>`   "oai": "< oai_identifier>"`<br>`}` | OAI-PMH, Crossref and any other identifier provider | | multiple |
| 'journals' | List of metadata (journal title and identifiers including issn) about the journal associated with the document. Format -<br>`"journals": `<br>`[{ `<br>`   "title": "< journal_title>",`<br>`    "identifiers":  `<br>`        [  `<br>`        "< identifier_1>",  `<br>`        "< identifier_2>",  `<br>`       ...`<br>`       ]`<br>`}]` | Issn matching and CORE records | | |
| 'language' | Language of the document including the name and code. Format -<br>`“language”:`<br>` {`<br>`   "code":"< ISO_639_language_code>",`<br>`   "name":"< name_of_the_language>"`<br>` }`<br>Example language codes: 'en' (English), 'es' (Spanish), 'pt' (Portuguese), etc. | OAI-PMH and machine learning-based approach from fullText | Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["language"] }` | single |
| 'lastUpdate' | Last update timestamp and follows the format -<br>`YYYY-MM-DDTHH:MM:SS±HH:MM` | Database | | single |
| 'license' | License under which the document is published. Possible values - ‘[http://creativecommons.org/licenses/by/2.0/’](http://creativecommons.org/licenses/by/2.0/%E2%80%99), ‘[http://creativecommons.org/licenses/by/3.0/’](http://creativecommons.org/licenses/by/3.0/%E2%80%99), ‘[http://creativecommons.org/licenses/by-nc-sa/3.0/’](http://creativecommons.org/licenses/by-nc-sa/3.0/%E2%80%99), ‘[http://creativecommons.org/licenses/by/4.0/’](http://creativecommons.org/licenses/by/4.0/%E2%80%99), ‘[https://creativecommons.org/licenses/by-sa/4.0’](https://creativecommons.org/licenses/by-sa/4.0%E2%80%99), ‘[https://creativecommons.org/licenses/by-nc/4.0/’](https://creativecommons.org/licenses/by-nc/4.0/%E2%80%99). Frequently used licenses are - CC-BY<br>CC-BY-SA<br>CC-BY-ND<br>CC-BY-NC<br>CC-BY-NC-SA | OAI-PMH | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/outputs/?q=license:"http://creativecommons.org/licenses/by/3.0](https://api.core.ac.uk/v3/search/outputs/?q=license:%22http://creativecommons.org/licenses/by/3.0)" | single |
| 'links' | List of different types of CORE URLs associated with the document. Format -<br>`"links":`<br>` [`<br>`    {  `<br>`   "type": "< link_type>",`<br>`   "url": "< corresponding_url>"`<br>`   },`<br>`    ...`<br>`]`<br>Example link types are 'download', 'reader', 'display', 'thumbnail\_l', 'thumbnail\_m'. | CORE records | | multiple |
| 'oai' | OAI identifier. Format - `oai:repository.domain.com:identifier` | OAI-PMH | Searchable using field lookup via GET.Example - [https://api.core.ac.uk/v3/search/outputs/?q=oai:"oai:researchonline.lshtm.ac.uk:3689](https://api.core.ac.uk/v3/search/outputs/?q=oai:%22oai:researchonline.lshtm.ac.uk:3689)"<br>Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["oai"] }` | single |
| 'publishedDate' | Timestamp when the output was first published. Format -<br>`YYYY-MM-DDTHH:MM:SS+TZ` | OAI-PMH and Crossref | Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["publishedDate"] }` | single |
| 'publisher' | Name of the publisher. | OAI-PMH, Crossref, DOI prefixes. All made uniform using publisher names from crossref | | single |
| 'references' | List of references cited in the output. Each reference contains metadata such as id (CORE ID), title, authors, date, doi, raw (full citation text), and cites (outputs that cite the given document). | From full-text parsing when available | | multiple |
| 'repositories' | Information about repositories holding the output. Format -<br>`"repositories": `<br>` {`<br>`   "id": "< repository_id>",`<br>`   "openDoarId": < open_doar_id>,`<br>`   "name": "< repository_name>",`<br>`   "urlHomepage": "< homepage_url>,`<br>`   "uriJournals": "< journals_uri>",`<br>`   "physicalName": "< physical_repository_name>",`<br>`   "roarId": < roar_id>,`<br>`   "baseId": < base_id>,`<br>`   "pdfStatus": "< pdf_availability_status>",`<br>`   "nrUpdates": < number_of_updates>,`<br>`   "lastUpdateTime": "< last_update_timestamp>"`<br>`} ` | Database | | single |
| 'repositoryDocument' | Metadata information of the output including its id and different timestamps. Format -<br>`"repositoryDocument":`<br>` {`<br>`   "id": < CORE_ID>,`<br>`   "depositedDate": "< deposit_date>",`<br>`   "publishedDate": "< publication_date>",`<br>`   "updatedDate": "< last_updated_date>",`<br>`   "acceptedDate": "< acceptance_date>",`<br>`   "createdDate": "< record_creation_date>"`<br>`  }  ` | Database | | single |
| 'sdg' | Multi-label Sustainable Development Goals (SDG) classification. Format -<br>`[`<br>`   {`<br>`   "type": "< SDG_Class>",`<br>`   "score": "< confidence_score>"`<br>`   },`<br>`   ...`<br>`]`<br>Example SDG\_Class is ‘SDG04’ | From multi-label machine learning-based SDG classifier | | multiple |
| 'setSpecs' | List of IDs used to filter metadata records based on predefined groupings or categories within a repository. | OAI-PMH | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/outputs/?q=setSpecs:7374617475733D707562](https://api.core.ac.uk/v3/search/outputs/?q=setSpecs:7374617475733D707562) | multiple |
| 'sourceFulltextUrls' | List of URLs to view the full-text of the document. | Database | | multiple |
| 'subjects' | List with possible values - ''Article', 'Text', 'NonPeerReviewed', 'Thesis', 'PeerReviewed’, 'Peer-reviewed Article', 'Journal', 'Journal Article', 'posted-content', ''publication-article', 'preprint', 'Student thesis', 'Peer reviewed', 'Book'' | OAI-PMH | Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["subjects"] }` | multiple |
| 'tags' | List of topical labels associated with the article | OAI-PMH | | multiple |
| 'title' | Title of the article. | OAI-PMH | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/outputs/?q=title:"sustainable](https://api.core.ac.uk/v3/search/outputs/?q=title:%22sustainable) development goals" | single |
| 'updatedDate' | Date in which the article was updated in CORE. Format -<br>`YYYY-MM-DDTHH:MM:SS±HH:MM` | Database | | single |
| 'urls' | List of URLs pointing to resources related to the output. | OAI-PMH | | multiple |
| 'yearPublished' | Year the document was published. | OAI-PMH | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/outputs/?q=yearPublished:2016](https://api.core.ac.uk/v3/search/outputs/?q=yearPublished:2016) | single |

##### Authorizations:

NoneNone

options/v3/outputs/intro

Live server.

https://api.core.ac.uk/v3/outputs/intro

## Search Outputs

Search through the CORE outputs entity using specific query parameters and fields. Below are detailed instructions and examples of how to perform targeted searches. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/search/outputs
```

**Example Search** 

The following query retrieves up to 25 outputs that meet the following conditions: The documentType is "research" and the output contains license information (i.e., the license field is not empty). 

[https://api.core.ac.uk/v3/search/outputs/?q=documentType:"research" AND _exists_:license&limit=25](https://api.core.ac.uk/v3/search/outputs/?q=documentType:%22research%22%20AND%20_exists_:license&limit=25) 

Example python source code to search outputs full text by keywords: 

```
   def search_outputs_by_keywords(keywords:str):
       url = "https://api.core.ac.uk/v3/search/outputs"
       headers = {"Authorization": f"Bearer {apikey}"}
       params = {"q": f"fullText:"{keywords}"", "limit": 5}

           try:
               response = requests.get(url, headers=headers, params=params)
               if response.status_code == 200:
                   return response.json()
               else:
                   print(f"Error {response.status_code}: {response.text}")
                   return None
           except requests.exceptions.RequestException as e:
               print(f"Request failed: {e}")
               return None
```

More examples on field specific search is available [here](https://api.core.ac.uk/docs/v3#tag/Outputs/operation/optionsCustomOutputs)

##### Authorizations:

NoneNone

options/v3/outputs/search

Live server.

https://api.core.ac.uk/v3/outputs/search

## Search Outputs using aggregation

POST request body example:

```
{
"q": "climate change",
"aggregations": ["documentType"]
}
```

Example source code to aggregate results for outputs based on the above request body: 

```
def search_with_aggregation(query):
   url = "https://api.core.ac.uk/v3/search/outputs/aggregate"
   headers = {
       "Authorization": f"Bearer {apikey}",
       "Content-Type": "application/json"
   }

   data = {
       "q": query,
       "aggregations": ["documentType"]
   }

   try:
       response = requests.post(URL, json=data, headers=headers)

       if response.status_code == 200:
           print("Aggregation Results:")
           print(response.json())
       else:
           print(f"Error {response.status_code}: {response.text}")
   except requests.exceptions.RequestException as e:
       print(f"Request failed: {e}")
```

Aggregation response sample for `query="climate change"`

```
{
   'aggregations':
       {'documentType':
           {'thesis': 356641,
           'research article': 306314,
           'research': 297313,
           'text': 202666,
           'review': 124039,
           'journal article': 88727,
           'unknown': 56630,
           'book': 31395,
           ................... 
           ................... 
           'data paper': 7,
           'project deliverable': 4,
           'sound': 2,
           'technical documentation': 2,
           'musical notation': 1,
           'website': 1}
       }
}
```

##### Authorizations:

NoneNone

options/v3/outputs/aggregation

Live server.

https://api.core.ac.uk/v3/outputs/aggregation

## Get a single Output

The API endpoint retrieves a single Output from the CORE database using its unique identifier. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/outputs/{identifier}
```

where **{identifier}** corresponds to the CORE ID of the output. 

Example GET Request - [https://api.core.ac.uk/v3/outputs/80549003](https://api.core.ac.uk/v3/outputs/80549003)

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

string\\w+

The CORE ID of the output.

### Responses

**200**

**404**

The identifier doesn't match any output in CORE.

get/v3/outputs/{identifier}

Live server.

https://api.core.ac.uk/v3/outputs/{identifier}

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "orcids": [          -   "string"                   ],      -   "disabled": 0,      -   "last_update": "2019-08-24T14:15:22Z",      -   "sdg": [ ],      -   "accepted_date": "string",      -   "authors": [          -   null                   ],      -   "contributors": [          -   null                   ],      -   "created_date": "string",      -   "data_provider": [          -   null                   ],      -   "deposited_date": "string",      -   "abstract": "string",      -   "document_type": [          -   "string"                   ],      -   "versions": [          -   "string"                   ],      -   "doi": "string",      -   "oai": "string",      -   "download_url": "string",      -   "full_text": "string",      -   "id": 0,      -   "identifiers": [          -   null                   ],      -   "title": "string",      -   "language": {          -   "code": "string",              -   "name": "string"                   },      -   "published_date": "string",      -   "publisher": [          -   null                   ],      -   "references": [          -   null                   ],      -   "source_fulltext_urls": [          -   null                   ],      -   "updated_date": "string",      -   "year_published": "string",      -   "links": [          -   null                   ],      -   "tags": [          -   null                   ],      -   "set_specs": [          -   null                   ],      -   "fulltext_status": "string",      -   "subjects": [          -   null                   ],      -   "deleted": "string",      -   "journals": [          -   null                   ],      -   "repositories": [          -   null                   ],      -   "repository_document": {          -   "id": 0,              -   "deposited_date": "2019-08-24T14:15:22Z",              -   "published_date": "2019-08-24T14:15:22Z",              -   "updated_date": "2019-08-24T14:15:22Z",              -   "accepted_date": "2019-08-24T14:15:22Z",              -   "created_date": "2019-08-24T14:15:22Z"                   },      -   "urls": [          -   null                   ],      -   "license": "string"       }`

## Download output file

The API endpoint allows you to download the binary file (e.g., PDF) associated with a specific output in the CORE repository. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/outputs/{identifier}/download
```

where **{identifier}** is the CORE ID of the output. 

Example GET Request - [https://api.core.ac.uk/v3/outputs/80549003/download](https://api.core.ac.uk/v3/outputs/80549003/download) 
More details regarding the PDF download policy is available [here](https://api.core.ac.uk/docs/v3#operation/PDFDownloadPolicy)

##### Authorizations:

NoneNone

##### path Parameters

| format | string<br>Enum: "tei" "pdf" "txt" "raw"<br>The format of the download. Currently only PDF is supported. |
| --- | --- |
| identifier<br>required | string\\w+ |

### Responses

**200**

A PDF file.

get/v3/outputs/{identifier}/download

Live server.

https://api.core.ac.uk/v3/outputs/{identifier}/download

### Response samples

**200**

Content type

application/pdf

Copy

```
...%PDF%...
```

## Historical data for an output

The API endpoint retrieves the historical OAI-PMH XML records for a specific output. This includes all available versions of the metadata for that output since the beginning of CORE harvesting. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/outputs/{identifier}/history
```

where **{identifier}** is the CORE ID of the output. 

Example GET Request - [https://api.core.ac.uk/v3/outputs/80549003/history](https://api.core.ac.uk/v3/outputs/80549003/history)

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

string\\w+

### Responses

**200**

A map with data and xml record.

**404**

The identifier doesn't match any output in CORE.

get/v3/outputs/{identifier}/history

Live server.

https://api.core.ac.uk/v3/outputs/{identifier}/history

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "accepted_date": "2019-08-24T14:15:22Z",      -   "authors": [          -   "string"                   ],      -   "contributors": [          -   "string"                   ],      -   "created_date": "2019-08-24T14:15:22Z",      -   "data_provider": [          -   "string"                   ],      -   "deposited_date": "2019-08-24T14:15:22Z",      -   "abstract": "string",      -   "document_type": [          -   "string"                   ],      -   "versions": [          -   "string"                   ],      -   "doi": "string",      -   "oai": "string",      -   "download_url": "string",      -   "full_text": "string",      -   "id": 0,      -   "identifiers": [          -   {                  -   "identifier": "string",                      -   "type": "string"                               }                   ],      -   "title": "string",      -   "language": { },      -   "published_date": "2019-08-24T14:15:22Z",      -   "publisher": { },      -   "references": [          -   {                  -   "authors": [                          -   "string"                                           ],                      -   "cites": "string",                      -   "date": "string",                      -   "doi": "string",                      -   "id": 0,                      -   "raw": "string",                      -   "title": "string"                               }                   ],      -   "source_fulltext_urls": [          -   "string"                   ],      -   "updated_date": "2019-08-24T14:15:22Z",      -   "year_published": "string",      -   "links": [          -   "string"                   ],      -   "tags": [          -   "string"                   ],      -   "set_specs": [          -   "string"                   ],      -   "fulltext_status": "string",      -   "subjects": [          -   "string"                   ],      -   "deleted": "string",      -   "journals": [          -   { }                   ],      -   "repositories": [          -   { }                   ],      -   "repository_document": { },      -   "urls": [          -   "string"                   ],      -   "license": "string",      -   "orcids": [          -   "string"                   ],      -   "disabled": 0,      -   "last_update": "2019-08-24T14:15:22Z",      -   "sdg": [ ]       }`

## Download raw XML record for an output

The API endpoint retrieves the raw XML metadata record associated with a specific output. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/outputs/{identifier}/raw
```

where **{identifier}** is the CORE ID of the output. 

Example GET Request - [https://api.core.ac.uk/v3/outputs/80549003/raw](https://api.core.ac.uk/v3/outputs/80549003/raw)

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

string\\w+

### Responses

**200**

A XML file.

get/v3/outputs/{identifier}/raw

Live server.

https://api.core.ac.uk/v3/outputs/{identifier}/raw

### Response samples

**200**

Content type

application/xml

Copy

```
...<records>...
```

## Get statistics about an output

This API endpoint retrieves statistical and date-related metadata associated with a specific output. It includes information such as the published date, deposited date, updated date, accepted date and created date. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/outputs/{identifier}/stats
```

where **{identifier}** is the CORE ID of the output. 

Example GET Request - [https://api.core.ac.uk/v3/outputs/80549003/stats](https://api.core.ac.uk/v3/outputs/80549003/stats)

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

string\\w+

The CORE ID

### Responses

**200**

The dates and all the numbers that CORE has about this output.

**404**

The identifier doesn't match any output in CORE.

get/v3/outputs/{identifier}/stats

Live server.

https://api.core.ac.uk/v3/outputs/{identifier}/stats

### Response samples

**200**

Content type

application/json

Copy

`{  -   "id": 0,      -   "deposited_date": "2019-08-24T14:15:22Z",      -   "published_date": "2019-08-24T14:15:22Z",      -   "updated_date": "2019-08-24T14:15:22Z",      -   "accepted_date": "2019-08-24T14:15:22Z",      -   "created_date": "2019-08-24T14:15:22Z"       }`

## Recommender

## Recommend.

Recommends records in the CORE collection related to the input. You can request recommendations for a specific CORE record using the `core:` prefix or by passing any identifier. You can also request recommendations based on a more generic text entry. The more information you send to the recommender engine the more accurate the recommendation will be.

##### Authorizations:

NoneNone

##### Request Body schema: application/json

required

Recommendation parameters.

| text<br>required | string |
| --- | --- |
| limit<br>required | string |
| identifier<br>required | string |
| abstract<br>required | string |
| authors<br>required | Array of strings |
| title<br>required | string |
| result\_type<br>required | string |
| data\_provider\_id | integer or null |

### Responses

**200**

**404**

post/v3/recommend

Live server.

https://api.core.ac.uk/v3/recommend

### Request samples

**Payload**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "text": "string",      -   "limit": "string",      -   "identifier": "string",      -   "abstract": "string",      -   "authors": [          -   "string"                   ],      -   "title": "string",      -   "result_type": "string",      -   "data_provider_id": 0       }`

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "accepted_date": "2019-08-24T14:15:22Z",      -   "authors": [          -   "string"                   ],      -   "contributors": [          -   "string"                   ],      -   "created_date": "2019-08-24T14:15:22Z",      -   "data_provider": [          -   "string"                   ],      -   "deposited_date": "2019-08-24T14:15:22Z",      -   "abstract": "string",      -   "document_type": [          -   "string"                   ],      -   "versions": [          -   "string"                   ],      -   "doi": "string",      -   "oai": "string",      -   "download_url": "string",      -   "full_text": "string",      -   "id": 0,      -   "identifiers": [          -   {                  -   "identifier": "string",                      -   "type": "string"                               }                   ],      -   "title": "string",      -   "language": { },      -   "published_date": "2019-08-24T14:15:22Z",      -   "publisher": { },      -   "references": [          -   {                  -   "authors": [                          -   "string"                                           ],                      -   "cites": "string",                      -   "date": "string",                      -   "doi": "string",                      -   "id": 0,                      -   "raw": "string",                      -   "title": "string"                               }                   ],      -   "source_fulltext_urls": [          -   "string"                   ],      -   "updated_date": "2019-08-24T14:15:22Z",      -   "year_published": "string",      -   "links": [          -   "string"                   ],      -   "tags": [          -   "string"                   ],      -   "set_specs": [          -   "string"                   ],      -   "fulltext_status": "string",      -   "subjects": [          -   "string"                   ],      -   "deleted": "string",      -   "journals": [          -   { }                   ],      -   "repositories": [          -   { }                   ],      -   "repository_document": { },      -   "urls": [          -   "string"                   ],      -   "license": "string",      -   "orcids": [          -   "string"                   ],      -   "disabled": 0,      -   "last_update": "2019-08-24T14:15:22Z",      -   "sdg": [ ]       }`

## Search

## CORE API Query Language

The CORE API query language allows users to explore the CORE collection and construct complex queries using various operators. The following table outlines the available operators and their usage: 

| Operator | Accepted symbols | Meaning |
| --- | --- | --- |
| And | `AND`, `+`, `space` | Logical binary AND. Used to retrieve results matching all conditions. |
| Or | `OR` | Logical binary OR. Used to retrieve results matching at least one condition. |
| Grouping | `(...)` | Used to prioritize and group elements of the query. |
| Field lookup | `field_name:value` | Used to search specific fields (e.g., `title:"Artificial Intelligence"`). |
| Range queries | `fieldName(>, <, >=, <=) value` | For numeric and date fields, specifies a range of values. |
| Exists queries | `_exists_:fieldName` | Returns all items where the specified field is not empty. |

### Examples of Query Usage

1\. **Field lookup**: Search for works with "Machine Learning" in the title

```
q=title:"Machine Learning"
```

2\. **Range queries:** Search for works published after 2018

```
q=yearPublished>2018
```

3\. **AND:** Search for works by multiple authors

```
q=authors:"Jane Doe" AND authors:"John Smith"
```

4\. **OR:** Search works with "AI" in the title or "Deep Learning" in the full-text

```
q=title:"AI" OR fullText:"Deep Learning"
```

5\. **Exists queries:** Find works with full-text available

```
q=exists:fullText
```

6\. **Grouping:** Search works using multiple conditions

```
q=(title:"Artificial Intelligence" OR title:"Machine Learning") AND yearPublished>"2020"
```

##### Authorizations:

NoneNone

options/v3/search/query-language

Live server.

https://api.core.ac.uk/v3/search/query-language

## Keyword Queries and Phrase Matching

The CORE API allows flexible text matching through both keyword queries and phrase searches: 

1\. Keyword search (unquoted): When search terms are unquoted, CORE will match documents where the field contains any or all of the words, in any order.

```
q=title:Attention is all you need
```

This returns documents where the title contains any or all of the words: 'Attention', 'is', 'all', 'you', 'need'.

```
q=title:attention-is-all-you-need
```

This returns documents where the title contains all of the words: 'Attention', 'is', 'all', 'you', 'need' and the order does not matter. 

2\. Phrase search (quoted): When the search term is wrapped in double quotes, CORE matches documents containing that exact phrase, in order.

```
q=title:"Attention is all you need"
```

This returns documents where the title exactly matches that phrase.

##### Authorizations:

NoneNone

options/v3/search/keyword-queries

Live server.

https://api.core.ac.uk/v3/search/keyword-queries

## Free Text Search - Searching without field lookup

If no search lookup field is specified, the query is processed through all searchable fields.

```
q=scientometrics
```

This retrieves results where the term 'scientometrics' appears anywhere in the document’s metadata, enabling broad and flexible discovery across the complete CORE collection.

##### Authorizations:

NoneNone

options/v3/search/without-field

Live server.

https://api.core.ac.uk/v3/search/without-field

## Search using aggregation

The CORE API provides an aggregation feature to summarise and group search results based on specific fields. Aggregation queries differ from normal search queries as they provide summarised counts instead of detailed individual document records. To get the details of records, please check the CORE API Query Language page.

#### Aggregation Endpoint Structure

```
POST https://api.core.ac.uk/v3/search/{entityType}/aggregate
```

Replace **{entityType}** with one of the supported entities.

#### Request Body Format

```
{
   "q": "< search_query>", 
   "aggregations": ["< field_1>", "< field_2>", "..."]
}
```

| Field | Type | Description |
| --- | --- | --- |
| q | string | The query string is written using CORE’s query language. |
| aggregations | List | A list of fields to aggregate results by. Only supported fields are allowed. |

**Note:** The aggregation feature does not support all fields returned by the API entity responses. Only certain fields can be used effectively. 

For instance, you can aggregate works using the following fields:

```
"yearPublished"
"authors"
"dataProvider"
"documentType"
"publishedDate"
"updatedDate"
"language"
"publisher"
"fieldOfStudy"
```

Outputs can be aggregated using the following fields:

```
"acceptedDate"
"authors"
"contributors"
"depositedDate"
"documentType"
"language"
"publishedDate"
"subjects"
```

Data-providers entity supports following aggregations:

```
"software"
```

Following fields from Journals entity supports aggregation:

```
"subjects"
```

Refer to the entity-specific documentation for more information.

##### Authorizations:

NoneNone

options/v3/search/search-aggregation

Live server.

https://api.core.ac.uk/v3/search/search-aggregation

## Search through all CORE entities using HTTP Post

The CORE API also supports searching entities using POST requests, which allows complex queries to be passed in the JSON request body. This is functionally equivalent to using the GET search endpoint but is especially useful for more advanced use cases, such as:

- Long or complex query strings that exceed URL length limits
- Automated systems and UI integrations that build dynamic queries
- Filtering with precise, structured JSON payloads

**API Endpoint**

```
POST https://api.core.ac.uk/v3/search/{entityType}
```

Replace **{entityType}** with one of the supported entities. 

##### Authorizations:

NoneNone

##### path Parameters

entityType

required

string

Enum: "works" "outputs" "data-providers" "journals"

Type of the entity

##### Request Body schema: application/json

required

Search parameters in JSON format.

| q<br>required | string<br>Search query (use specific fields like doi, title, authors, etc.) |
| --- | --- |
| offset | integer<br>Default: 0<br>Offset for pagination. |
| limit | integer<br>Default: 10<br>Maximum number of results to return. |
| stats | boolean<br>Default: false<br>Include search statistics (can slow down the response). |

### Responses

**200**

Contains the entities matching the search query.

post/v3/search/{entityType}

Live server.

https://api.core.ac.uk/v3/search/{entityType}

### Request samples

**Payload**

Content type

application/json

Copy

`{  -   "q": "machine learning",      -   "offset": 0,      -   "limit": 10,      -   "stats": false       }`

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "total_hits": 0,      -   "limit": 0,      -   "offset": 0,      -   "results": [          -   { }                   ],      -   "tooks": [ ],      -   "search_id": "string"       }`

## Search through all CORE entities

The CORE API search allows you to perform comprehensive searches across multiple entities, including **works**, **outputs**, **data-providers**, and **journals**.

##### Authorizations:

NoneNone

##### path Parameters

entityType

required

string

Enum: "works" "outputs" "data-providers" "journals"

Type of the entity

##### query Parameters

| q<br>required | string<br>Search query (use specific fields like doi, title, authors, etc.) |
| --- | --- |
| offset | integer<br>Default: 0<br>The offset from the result set where you want the result to start. Needed for pagination. |
| limit | integer<br>Default: 10<br>The maximum size of your search results. The result set may be smaller than the limit. |
| stats | boolean<br>Default: false<br>If set to true the search results will include statistics related to the entity. This property has an impact on the response speed. |

### Responses

**200**

Contains the entities matching the search query.

get/v3/search/{entityType}/

Live server.

https://api.core.ac.uk/v3/search/{entityType}/

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "total_hits": 0,      -   "limit": 0,      -   "offset": 0,      -   "results": [          -   { }                   ],      -   "tooks": [ ],      -   "search_id": "string"       }`

## Aggregate CORE entities based on a search query

The CORE API provides an aggregation feature to summarise and group search results based on specific fields. Aggregation queries differ from normal search queries as they provide summarised counts instead of detailed individual document records. To get the details of records, please check the CORE API Query Language page. 
**Aggregation Endpoint Structure**

```
POST   https://api.core.ac.uk/v3/search/{entityType}/aggregate
```

Replace **{entityType}** with one of the supported entities. 

##### Authorizations:

NoneNone

##### path Parameters

entityType

required

string

Enum: "works" "outputs" "data-providers" "journals"

Type of the entity

##### Request Body schema: application/json

required

Search parameters in JSON format.

| q | string or null |
| --- | --- |
| offset | integer or null |
| limit | integer or null |
| entity\_id | any or null |
| entity\_type<br>required | string |
| search\_fields | string or null |
| stats | bool<br>Default: true<br>If set to true the search results will include statistics related to the entity. This property has an impact on the response speed. |
| raw\_stats<br>required | bool<br>If set to true the search results will include statistics related to the raw datasource of the entity if available. This property has an impact on the response speed. |
| exclude<br>required | Array of strings<br>Fields to exclude from the response. |
| sort | string<br>Default: \[\]<br>Fields to sort the results by. `FIELD_NAME:asc|desc` |
| accept<br>required | string<br>Download CSV file. `text\/csv` |
| measure | boolean<br>Default: false |
| filter<br>required | (Array of Parameter for Azure SearchAI (any or null)) or Parameter for Azure SearchAI (object) (Parameter for Azure SearchAI) |

### Responses

**200**

Contains the entities matching the search query.

post/v3/search/{entityType}/aggregate

Live server.

https://api.core.ac.uk/v3/search/{entityType}/aggregate

### Request samples

**Payload**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "q": "string",      -   "offset": 0,      -   "limit": 0,      -   "entity_id": null,      -   "entity_type": "string",      -   "search_fields": "string",      -   "stats": true,      -   "raw_stats": null,      -   "exclude": [          -   "string"                   ],      -   "sort": [ ],      -   "accept": "string",      -   "measure": false,      -   "filter": [          -   null                   ]       }`

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "total_hits": 0,      -   "limit": 0,      -   "offset": 0,      -   "results": [          -   { }                   ],      -   "tooks": [ ],      -   "search_id": "string"       }`

## Works

## Introduction

Works represent individual pieces of scholarly research, such as research articles, theses, preprints, conference papers, and more. Each Work in CORE is a deduplicated and enriched representation of one or more underlying Outputs that have been harvested from different sources (repositories or journals). 

The following table describes the Works API response fields:

| Field Name | Description | Method for obtaining the value | Searchable field | Cardinality |
| --- | --- | --- | --- | --- |
| 'abstract' | A summary of the work. | OAI-PMH. The value is populated from the output with abstract != NULL. | Searchable using field lookup via GET.Example - [https://api.core.ac.uk/v3/search/works/?q=abstract:"bibliometrics](https://api.core.ac.uk/v3/search/works/?q=abstract:%22bibliometrics)" | single |
| 'acceptedDate' | Date when the record was accepted for publication. Format -<br>`YYYY-MM-DDTHH:MM:SS` | Crossref | Supports aggregation via POST.Example - Body: `{ "aggregations": ["acceptedDate"] }` | single |
| 'arxivId' | Unique identifier assigned to the record in arXiv. Format -<br>`YYMM.number` | Obtained from arXiv or retrieved from the deduplicated group if any of the output includes a relation to an ArXiv URL. | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=arxivId:1905.13497](https://api.core.ac.uk/v3/search/works/?q=arxivId:1905.13497)<br><br>Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["arxivId"] }` | single |
| 'authors' | List of author names. Format -<br><br>`[`<br>`   {"name": < author_name>},`<br>`   ...`<br>`]` | OAI-PMH or enriched by obtaining values from output with the most number of authors from the deduplicated group. | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=authors:David](https://api.core.ac.uk/v3/search/works/?q=authors:David)<br><br>Supports aggregation via POST.<br>Example - `Body: { "aggregations": ["authors"] }` | multiple |
| 'citationCount'\* | Number of citations received. | Microsoft Academic Graph (MAG) | Supports aggregation via POST.<br><br>Example - Body: `{ "aggregations": ["citationCount"] }` | single |
| 'contributors' | List of entities (editors, translators, organisations etc.) responsible for making contributions to the resource. | OAI-PMH | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=contributors:CiteSeerX](https://api.core.ac.uk/v3/search/works/?q=contributors:CiteSeerX)<br><br>Supports aggregation via POST.<br><br>Example - Body: `{ "aggregations": ["contributors"] }` | multiple |
| 'createdDate' | Timestamp when the record was initially created in CORE. Format -<br>`YYYY-MM-DDTHH:MM:SS` | Database | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=createdDate:"2016-06-16T16:34:27](https://api.core.ac.uk/v3/search/works/?q=createdDate:%222016-06-16T16:34:27)"<br><br>Supports aggregation via POST.<br><br>Example - Body: `{ "aggregations": ["createdDate"] }` | single |
| 'dataProviders' | List of data-provider information. Format -<br>`"dataProviders": `<br>`[{ `<br>`    "id": < data_provider_id>,  `<br>`   "name": "< name_of_data_provider>",`<br>`   "url": "< API_endpoint>",`<br>`    "logo": "< URL_of_the_logo>"  `<br>`}]` | Database | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=dataProviders:103](https://api.core.ac.uk/v3/search/works/?q=dataProviders:103)<br><br>Supports aggregation via POST.<br><br>Example - Body: `{ "aggregations": ["dataProviders"] }` | multiple |
| 'depositedDate' | Date when the record was deposited to the repository and follows the format -<br>`YYYY-MM-DDTHH:MM:SS` | Crossref | Searchable using field lookup via GET.Example - [https://api.core.ac.uk/v3/search/works/?q=depositedDate:"2001-06-01T00:00:00](https://api.core.ac.uk/v3/search/works/?q=depositedDate:%222001-06-01T00:00:00)"<br><br>Supports aggregation via POST.<br><br>Example - Body: `{ "aggregations": ["depositedDate"] }` | single |
| 'documentType' | List of types of the record. Example types are ‘research’, ‘thesis’, ‘unknown’, ‘slides’, ‘research article’, 'text', 'journal article', 'conference paper', 'review', 'book', 'other', 'report', 'project', 'doctoral thesis’, 'book part', 'working paper', 'dataset', 'master thesis', 'presentation', 'bachelor thesis', 'lecture', 'conference proceedings', 'image', 'software', 'conference object', 'patent', 'video', 'annotation', 'conference poster', 'musical notation', 'preprint', 'technical report', ‘interactive resource’, ‘research proposal’, ‘review article’. | From a machine learning tool when possible with full-text, otherwise with an interpretation of the values from OAI-PMH dc.subject and dc.type | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=documentType:thesis](https://api.core.ac.uk/v3/search/works/?q=documentType:thesis)<br><br>Supports aggregation via POST.<br><br>Example - Body: { "aggregations": \["documentType"\] } | multiple |
| 'doi' | DOI of the record. | OAI-PMH and Crossref | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=doi:10.26153/tsw/52804](https://api.core.ac.uk/v3/search/works/?q=doi:10.26153/tsw/52804)<br><br>Supports aggregation via POST.<br><br>Example - Body: `{ "aggregations": ["doi"] }` | single |
| 'downloadUrl' | Download URL of the work. | Database | | single |
| 'fieldOfStudy'\* | Subject area or discipline related to the work. | Obtained from Microsoft Academic Graph (MAG) | | single |
| 'fullText' | Full-text of the work. | Using the download URL from OAI-PMH, the PDF is crawled and value is obtained from PDF using Apache PDFBox. | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=fullText:political-science](https://api.core.ac.uk/v3/search/works/?q=fullText:political-science) | single |
| 'id' | Unique Work identifier | Database | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=id:152480964](https://api.core.ac.uk/v3/search/works/?q=id:152480964)<br><br>Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["id"] }` | single |
| 'identifiers' | List of CORE\_IDs and external identifiers (ARXIV\_ID, DOI, OAI\_ID) associated with the record. Identifiers follows the structure -<br>`"identifiers": `<br>`[{`<br>` "identifier": "< identifier_value>",`<br>` "type": "< identifier_type>`<br>` },`<br>`  ...  `<br>`]` | Crossref, OAI-PMH and any additional sources identifying the work. CORE\_ID is obtained from the database. | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=identifiers:oai:arxiv.org:2310.16146](https://api.core.ac.uk/v3/search/works/?q=identifiers:oai:arxiv.org:2310.16146) | multiple |
| 'journals' | List of metadata (journal title and identifiers including issn) about the journal associated with the record. Format -<br>`"journals":`<br>`[{`<br>`"title": "< journal_title>", `<br>`"identifiers":`<br>`   [`<br>`   "< identifier_1>",`<br>`   "< identifier_2>",`<br>`   ...`<br>`   ]`<br>`}]` | From issn resolution and journal identifiers | | multiple |
| 'links' | List of different types of CORE URLs associated with the record. Format -<br>`"links":`<br>`[{`<br>`   "type": "< link_type>",`<br>`   "url": "< corresponding_url>"`<br>` },`<br>` ...`<br>`]`<br>Example link types are 'download', 'reader', 'display', 'thumbnail\_l', 'thumbnail\_m'. | CORE records | | multiple |
| 'magId'\* | Unique identifier assigned to the work in Microsoft Academic Graph. | Obtained from Microsoft Academic Graph (MAG). | Searchable using field lookup via GET.Example - [https://api.core.ac.uk/v3/search/works/?q=magId:2139460650](https://api.core.ac.uk/v3/search/works/?q=magId:2139460650)<br><br>Supports aggregation via POST.<br><br>Example - Body: `{ "aggregations": ["magId"] }` | single |
| 'oaiIds' | List of OAI identifiers for the work and follows the structure: `oai:repository.domain.com:identifier`<br>\- oai: fixed prefix indicating that this is an OAI identifier.<br>\- repository.domain.com : domain name of the repository.<br>\- identifier : unique identifier assigned by the repository to the specific record. | OAI-PMH | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=oaiIds:"oai:nrl.northumbria.ac.uk:522](https://api.core.ac.uk/v3/search/works/?q=oaiIds:%22oai:nrl.northumbria.ac.uk:522)"<br><br>Supports aggregation via POST.<br><br>Example - Body: `{ "aggregations": ["oaiIds"] }` | multiple |
| 'outputs' | List of URLs, pointing to a specific output in CORE. | List of CORE IDs of the deduplicated outputs this work represents. | Searchable via works identifier. Example - [https://api.core.ac.uk/v3/works/{identifier}/outputs](https://api.core.ac.uk/v3/works/%7Bidentifier%7D/outputs) | multiple |
| 'publishedDate' | Date, the record is published and follows the format -<br>`YYYY-MM-DDTHH:MM:SS` | Crossref and OAI-PMH. The date that is earliest is selected. | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=publishedDate:"2009-10-18T00:00:00](https://api.core.ac.uk/v3/search/works/?q=publishedDate:%222009-10-18T00:00:00)"<br><br>Supports aggregation via POST.<br><br>Example - Body: `{ "aggregations": ["publishedDate"] }` | single |
| 'publisher' | Name of the publisher. | OAI-PMH, Crossref, DOI prefixes. Normalised using publisher names from crossref | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=publisher:Nature](https://api.core.ac.uk/v3/search/works/?q=publisher:Nature)<br><br>Supports aggregation via POST.<br><br>Example - Body: `{ "aggregations": ["publisher"] }` | single |
| 'pubmedId' | Unique identifier assigned to the record in PubMed. | PubMed | Searchable using field lookup via GET.<br><br>Example - [https://api.core.ac.uk/v3/search/works/?q=pubmedId:2844484](https://api.core.ac.uk/v3/search/works/?q=pubmedId:2844484)<br><br>Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["pubmedId"] }` | single |
| 'references' | List of references cited in the work. Each reference contains metadata such as id (CORE ID), title, authors, date, doi, raw (full citation text), and cites (works that cite the given document) | From full-text parsing (when available) | | multiple |
| 'sourceFulltextUrls' | List of URLs where full-text is available. | OAI-PMH metadata | | multiple |
| 'title' | Title of the work. | OAI-PMH | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/works/?q=title:retrieval-augmented-generation](https://api.core.ac.uk/v3/search/works/?q=title:retrieval-augmented-generation) | single |
| 'updatedDate' | Date when the work was last updated in CORE | Database | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/works/?q=updatedDate:"2024-08-16T00:03:23](https://api.core.ac.uk/v3/search/works/?q=updatedDate:%222024-08-16T00:03:23)"<br>Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["updatedDate"] }` | single |
| 'yearPublished' | Year the document was published. | OAI-PMH | Searchable using field lookup via GET.<br>Example - [https://api.core.ac.uk/v3/search/works/?q=yearPublished:2024](https://api.core.ac.uk/v3/search/works/?q=yearPublished:2024)<br>Supports aggregation via POST.<br>Example - Body: `{ "aggregations": ["yearPublished"] }` | single |

\* - deprecated (This information is no longer updated.)

##### Authorizations:

NoneNone

options/v3/works/intro

Live server.

https://api.core.ac.uk/v3/works/intro

## Search Works

This section provides details about how to use the CORE API query language for more complex searches within the works entity. 

**API Endpoint**

```
GET https://api.core.ac.uk/v3/search/works
```

**Example Search** 

Search for works published between 2015 and 2024, that contain either "machine learning" or "artificial intelligence" in the title and have full text. 

[https://api.core.ac.uk/v3/search/works?q=(title:"machine learning" OR title:"artificial intelligence") AND yearPublished>="2015" AND yearPublished<="2024" AND \_exists\_:fullText&limit=5](https://api.core.ac.uk/v3/search/works/?q=(title:%22machine%20learning%22%20OR%20title:%22artificial%20intelligence%22)%20AND%20yearPublished%3E=%222015%22%20AND%20yearPublished%3C=%222024%22%20AND%20_exists_:fullText&limit=5) 

This query retrieves up to 5 works that meet all of the above conditions. 
Example python source code to search works by DOI: 

```
   def search_works_by_doi(doi:str):
       url = "https://api.core.ac.uk/v3/search/works"
       headers = {"Authorization": f"Bearer {apikey}"}
       params = {"q": f"doi:"{doi}"", "limit": 1}

           try:
               response = requests.get(url, headers=headers, params=params)
               if response.status_code == 200:
                   return response.json()
               else:
                   print(f"Error {response.status_code}: {response.text}")
                   return None
           except requests.exceptions.RequestException as e:
               print(f"Request failed: {e}")
               return None
```

More examples on field specific search is available [here](https://api.core.ac.uk/docs/v3#tag/Works/operation/optionsCustomWorks)

##### Authorizations:

NoneNone

options/v3/works/search

Live server.

https://api.core.ac.uk/v3/works/search

## Search Works using aggregation

POST request body example:

```
{
"q": "climate change",
"aggregations": ["yearPublished", "authors"]
}
```

Example source code to aggregate results for works based on the above request body:

```
def search_with_aggregation(query):
   url = "https://api.core.ac.uk/v3/search/works/aggregate"
   headers = {
       "Authorization": f"Bearer {apikey}",
       "Content-Type": "application/json"
   }
   data = {
       "q": query,
       "aggregations": ["yearPublished", "authors"]
   }
   try:
       response = requests.post(url, json=data, headers=headers)

       if response.status_code == 200:
           print("Aggregation Results:")
           print(response.json())
       else:
           print(f"Error {response.status_code}: {response.text}")
 
   except requests.exceptions.RequestException as e:
       print(f"Request failed: {e}") 
```

Aggregation response sample for `query="climate change"`

```
{
"aggregations": {
  "yearPublished": {
    "2025": 4116,
    "2024": 108312,
    "2023": 151061,
    "2022": 151742,
    "2021": 135433,
    "2020": 132744,
    .....................
    .....................
    "1897": 605,
    "1896": 664,
    "1892": 543
  },
  "authors": {
    "Wang": 5319,
    "Smith": 4805,
    "Zhang": 4524,
    "IPCC": 4397,
    ......................
    ......................
    "Campbell": 1101,
    "Hu": 1101,
    "Wood": 1100
  }
}
}
```

The works fields that support aggregation can be viewed [here](https://api.core.ac.uk/docs/v3#tag/Works/operation/optionsCustomWorks)

##### Authorizations:

NoneNone

options/v3/works/aggregation

Live server.

https://api.core.ac.uk/v3/works/aggregation

## Get single Work

The API endpoint retrieves a single Work from the CORE database using its unique identifier. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/works/{identifier}
```

where the **{identifier}** corresponds to the work ID. 

Example GET request - [https://api.core.ac.uk/v3/works/267312](https://api.core.ac.uk/v3/works/267312)

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

string(\\d+|\\w+:\\d+|\\w+:\\d+.\\d+|\\w+:\[a-z0-9.\]+:\\d+|\\...Show pattern

The Work ID

### Responses

**200**

**404**

The identifier doesn't match any work in CORE.

get/v3/works/{identifier}

Live server.

https://api.core.ac.uk/v3/works/{identifier}

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "accepted_date": "2019-08-24T14:15:22Z",      -   "arxiv_id": "string",      -   "authors": [          -   "string"                   ],      -   "citation_count": 0,      -   "contributors": [          -   "string"                   ],      -   "outputs": [          -   "string"                   ],      -   "created_date": "2019-08-24T14:15:22Z",      -   "data_providers": [          -   "string"                   ],      -   "deposited_date": "2019-08-24T14:15:22Z",      -   "abstract": "string",      -   "document_type": "string",      -   "doi": "string",      -   "download_url": "string",      -   "field_of_study": "string",      -   "full_text": "string",      -   "id": 0,      -   "identifiers": [          -   {                  -   "identifier": "string",                      -   "type": "string"                               }                   ],      -   "title": "string",      -   "language": { },      -   "mag_id": "string",      -   "oai_ids": [          -   "string"                   ],      -   "published_date": "2019-08-24T14:15:22Z",      -   "publisher": { },      -   "pubmed_id": { },      -   "references": [          -   {                  -   "authors": [                          -   "string"                                           ],                      -   "cites": "string",                      -   "date": "string",                      -   "doi": "string",                      -   "id": 0,                      -   "raw": "string",                      -   "title": "string"                               }                   ],      -   "source_fulltext_urls": [          -   "string"                   ],      -   "journals": [          -   {                  -   "title": "string",                      -   "identifiers": [                          -   null                                           ]                               }                   ],      -   "updated_date": "2019-08-24T14:15:22Z",      -   "year_published": 0,      -   "links": [          -   "string"                   ]       }`

## Get outputs related to Work

The API endpoint retrieves the list of Outputs associated with a specific Work. Each output represents an individual version or source-specific instance of the Work, typically harvested from repositories, journals, or other data providers. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/works/{identifier}/outputs
```

where the **{identifier}** corresponds to the work ID. 

Example GET request - [https://api.core.ac.uk/v3/works/58/outputs](https://api.core.ac.uk/v3/works/58/outputs) 
Sample source code for retrieving outputs related to a specific work is as follows:

```
def get_outputs_by_work_id(work_id: str):
    url = f"https://api.core.ac.uk/v3/works/{work_id}/outputs"
    headers = {"Authorization": f"Bearer {apikey}"}
    params = {"limit": 10, "offset": 0}
    try:
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error {response.status_code}: {response.text}")
            return None
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None
```

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

string(\\d+|\\w+:\\d+|\\w+:\\d+.\\d+|\\w+:\[a-z0-9.\]+:\\d+|\\...Show pattern

The Work ID

### Responses

**200**

**404**

The identifier doesn't match any work in CORE.

get/v3/works/{identifier}/outputs

Live server.

https://api.core.ac.uk/v3/works/{identifier}/outputs

### Response samples

**200**

Content type

application/json

Copy

Expand all Collapse all

`{  -   "accepted_date": "2019-08-24T14:15:22Z",      -   "authors": [          -   "string"                   ],      -   "contributors": [          -   "string"                   ],      -   "created_date": "2019-08-24T14:15:22Z",      -   "data_provider": [          -   "string"                   ],      -   "deposited_date": "2019-08-24T14:15:22Z",      -   "abstract": "string",      -   "document_type": [          -   "string"                   ],      -   "versions": [          -   "string"                   ],      -   "doi": "string",      -   "oai": "string",      -   "download_url": "string",      -   "full_text": "string",      -   "id": 0,      -   "identifiers": [          -   {                  -   "identifier": "string",                      -   "type": "string"                               }                   ],      -   "title": "string",      -   "language": { },      -   "published_date": "2019-08-24T14:15:22Z",      -   "publisher": { },      -   "references": [          -   {                  -   "authors": [                          -   "string"                                           ],                      -   "cites": "string",                      -   "date": "string",                      -   "doi": "string",                      -   "id": 0,                      -   "raw": "string",                      -   "title": "string"                               }                   ],      -   "source_fulltext_urls": [          -   "string"                   ],      -   "updated_date": "2019-08-24T14:15:22Z",      -   "year_published": "string",      -   "links": [          -   "string"                   ],      -   "tags": [          -   "string"                   ],      -   "set_specs": [          -   "string"                   ],      -   "fulltext_status": "string",      -   "subjects": [          -   "string"                   ],      -   "deleted": "string",      -   "journals": [          -   { }                   ],      -   "repositories": [          -   { }                   ],      -   "repository_document": { },      -   "urls": [          -   "string"                   ],      -   "license": "string",      -   "orcids": [          -   "string"                   ],      -   "disabled": 0,      -   "last_update": "2019-08-24T14:15:22Z",      -   "sdg": [ ]       }`

## Get statistics about Work

The API endpoint retrieves key lifecycle dates for a specific Work, such as when it was deposited, accepted, published, and last updated. 

**API Endpoint** 

```
GET https://api.core.ac.uk/v3/works/{identifier}/stats
```

where the **{identifier}** corresponds to the work ID. 

Example Request - [https://api.core.ac.uk/v3/works/267312/stats](https://api.core.ac.uk/v3/works/267312/stats)

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

string(\\d+|\\w+:\\d+|\\w+:\\d+.\\d+|\\w+:\[a-z0-9.\]+:\\d+|\\...Show pattern

The Work ID

### Responses

**200**

**404**

The identifier doesn't match any Work in CORE.

get/v3/works/{identifier}/stats

Live server.

https://api.core.ac.uk/v3/works/{identifier}/stats

### Response samples

**200**

Content type

application/json

Copy

`{  -   "id": 0,      -   "deposited_date": "2019-08-24T14:15:22Z",      -   "published_date": "2019-08-24T14:15:22Z",      -   "updated_date": "2019-08-24T14:15:22Z",      -   "accepted_date": "2019-08-24T14:15:22Z"       }`

## Download the parsed Work - TEI file

Download the structured data for the pdf file associated with the work. 

**API Endpoint** 

```
https://api.core.ac.uk/v3/works/tei/{identifier}
```

where the **{identifier}** corresponds to the work ID. 

Example Request - [https://api.core.ac.uk/v3/works/tei/127610059](https://api.core.ac.uk/v3/works/tei/127610059) will download the work with ID 127610059.

##### Authorizations:

NoneNone

##### path Parameters

identifier

required

string(\\d+|\\w+:\\d+|\\w+:\\d+.\\d+|\\w+:\[a-z0-9.\]+:\\d+|\\...Show pattern

### Responses

**200**

The file to download.

get/v3/works/tei/{identifier}

Live server.

https://api.core.ac.uk/v3/works/tei/{identifier}

### Response samples

**200**

Content type

application/xml

Copy

```
...<tei>...
```

## Download the Work file

Download the binary file associated with the work. 

**API Endpoint** 

```
https://api.core.ac.uk/v3/works/{identifier}/download
```

where the **{identifier}** corresponds to the work ID. 

Example Request - [https://api.core.ac.uk/v3/works/127610059/download](https://api.core.ac.uk/v3/works/127610059/download) will download the work with ID 127610059 as a TEI file.

##### Authorizations:

NoneNone

##### path Parameters

| format | string<br>Enum: "tei" "pdf" "txt" "raw"<br>The format of the download. Currently only PDF is supported. |
| --- | --- |
| identifier<br>required | string\\w+ |

##### header Parameters

accept

required

string

Enum: "application/pdf" "application/msword"

Possible format it will go in the accept header, if empty will return the PDF file.

### Responses

**200**

The file to download.

get/v3/works/{identifier}/download

Live server.

https://api.core.ac.uk/v3/works/{identifier}/download

### Response samples

**200**

Content type

application/pdf

Copy

```
...%PDF%...
```

## Entities

## Introduction

The CORE API provides convenient and comprehensive access to global research results. CORE is based on the global repositories network and collects, aggregates and expands the metadata provided and the associated full texts. The API allows access to the data summarised in the search index.

##### Authorizations:

NoneNone

options/custom/entities/introduction

Live server.

https://api.core.ac.uk/custom/entities/introduction

## CORE data model

The following diagram depicts the primary entities and their main attributes (the full list is in the documentation below) 

Works 
Works provide a representation of a research work in a way that is independent of its manifestations. Each research work can have one or more manifestations (Outputs) available from any data provider. Works refer to a deduplicated and harmonised meta-entity describing the research work and connecting its Outputs. 

Outputs 
Outputs refer to specific manifestations of a research work (Works). 

Data Providers 
The Data Provider entity represents the data sources from which Outputs are collected. These sources include but are not limited to institutional, subject, preprint, repositories and journals or their collections.

##### Authorizations:

NoneNone

options/custom/entities/data\_model

Live server.

https://api.core.ac.uk/custom/entities/data\_model

## Rate limits

## Common

Access to the CORE API is free and requires no authentication. Providing free access to general users is part of our mission. Being a sustainable scholarly infrastructure is also part of our mission. As a result, we offer better performance to registered users. The below table provides information about our rate limits depending on your situation. 

To control the load on our systems we use a rate-limiting technology based on tokens. Each user has access to a certain number of tokens at the start of their session and they can use them to perform their queries. 

Certain calls in CORE are more computationally expensive than others, therefore some calls such as recommender, scroll search and bulk queries will cost you more tokens than others. As a rule of thumb, a simple query will cost you 1 token while more complex queries will cost you between 3 to 5 tokens. 

We are monitoring the load on our servers and at some point we might decide to increase or decrease the “cost” of certain operations to control the overall load. The best way to keep on top of your API usage is to use the HTTP headers included in every API call response (see below for details about the headers). 

| User type | How to obtain | Rate limit | Support |
| --- | --- | --- | --- |
| Unauthenticated users\* | No registration required, just start using the API. | 100 tokens per day, maximum 10 per minute. | No support |
| Registered Personal users | Registration through the [CORE API](https://core.ac.uk/services/api) form | 1,000 tokens per day, maximum 25 per minute. | Best effort |
| Registered academic users NOT affiliated with Supporting or Sustaining institutions. | Registration through the [CORE API](https://core.ac.uk/services/api) form | 5,000 tokens per day, maximum 10 per minute. | Best effort |
| Registered academic users affiliated with Supporting or Sustaining institutions and Non-academic organisation users | Registration through the [CORE API](https://core.ac.uk/services/api) form | The API limits are designed to allow reasonable usage and we will change them depending on the load on our servers. However, on average, we estimate this plan should be good for up to about 200k tokens per day. You are able to monitor your current API limit by looking for our customised HTTP headers: X-RateLimitRemaining X-RateLimit-Retry-After X-RateLimit-Limit | Dedicated support |
| VIP | Contact us to discuss a dedicated plan to upgrade your registration. | Sky is the limit. We can support your needs. Just let us know and we will find a way to accommodate your usage needs. | Unlimited priority support |

\* - Full-text is not available for unauthenticated API users.

##### Authorizations:

NoneNone

options/custom/rate\_limit/common

Live server.

https://api.core.ac.uk/custom/rate\_limit/common

## How to monitor your API rate limits

To ensure fair usage and maintain API stability, CORE implements rate limits. These limits may be adjusted dynamically based on server load and usage patterns.

You can monitor your current rate usage by checking the following custom HTTP response headers included in every API response:

| **Header** | **Description** |
| --- | --- |
| `X-RateLimit-Limit` | The total number of requests allowed within the current rate-limiting window. This represents your maximum quota before the limit resets. |
| `X-RateLimit-Remaining` | The number of requests you still have available in the current window. Once this value reaches zero, additional requests will be blocked until the window resets. |
| `X-RateLimit-Retry-After` | Indicates when you can safely make another request after hitting the rate limit. |

##### Authorizations:

NoneNone

options/custom/rate\_limit/monitor

Live server.

https://api.core.ac.uk/custom/rate\_limit/monitor

## How to call the API

There are a few ways you can perform API requests using your API Key. [Request an API key here](https://core.ac.uk/services/api#form). Please do not disclose your API key. It is for your use only.

- _preferred_ You can embed the API Key in the header. This keeps the authorisation separated from the requests parameters. Add the header `Authorization: Bearer [API_KEY]`
- If you cannot set your headers you can also use the API key as a parameter in your requests including it like this: `api_key=[API_KEY]` .

##### Authorizations:

NoneNone

options/custom/how\_call\_API

Live server.

https://api.core.ac.uk/custom/how\_call\_API

## PDF download policy

- Outputs PDF downloads are possible via the original **‘downloadUrl’** supplied link, if a URL exists. This is the preferred method.
- Where users are prevented, restricted or blocked from reaching the resource specified in the **‘downloadUrl’**, then CORE API users can also use the GET request endpoint - 

    ```
    GET https://api.core.ac.uk/v3/outputs/{identifier}/download
    ```

 for downloading PDFs directly from CORE. This request counts against your API tokens allowance and is generally more expensive, because it has more significant data implications.
- **IMPORTANT**: Systematic harvesting of PDFs from CORE outside that circumvents the API, e.g. via `https://fileserver-az.core.ac.uk/download/{identifier}.pdf` or other methods is unacceptable. Such usage will be blocked and associated API keys will be disabled.

##### Authorizations:

NoneNone

options/custom/PDF\_download\_policy

Live server.

https://api.core.ac.uk/custom/PDF\_download\_policy
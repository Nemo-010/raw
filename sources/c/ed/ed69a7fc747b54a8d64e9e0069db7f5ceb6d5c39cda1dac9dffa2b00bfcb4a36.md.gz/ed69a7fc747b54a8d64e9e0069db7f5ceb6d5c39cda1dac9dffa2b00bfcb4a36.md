## **A spec for packaging distributed apps.**

CNABs facilitate the bundling, installing and managing of container-native apps — and their coupled services.

[View the spec](https://github.com/cnabio/cnab-spec) Scroll down for project info and resources.

Cloud Agnostic

### Cloud Agnostic

A CNAB can be composed to utilize whatever infra or services you require - there’s no vendor lock in.

### Deliverable Apps

CNABs can be used to easily deliver apps across teams, organizations and marketplaces - even shared offline.

Deliverable Apps

Signed & Secure

### Signed & Secure

A CNAB can be cryptographically signed, attested, and verified​ to ensure a trustworthy source.

### Communications:

#### Meetings

[Community meetings](https://cnab.io/community-meetings) take place every Wednesday at 09:00AM US Pacific Time.

#### Mailing List

[CNAB-Main@lists.jointdevelopment.org](mailto:CNAB-Main@lists.jointdevelopment.org)  
 Sign up at [JDF forum](https://lists.jointdevelopment.org/g/CNAB-Main/).

#### Slack Channel

Join the [#cnab](https://cloud-native.slack.com/messages/CEX1W7WMD/) channel for related discussion in the [CNCF's Slack](https://slack.cncf.io/).

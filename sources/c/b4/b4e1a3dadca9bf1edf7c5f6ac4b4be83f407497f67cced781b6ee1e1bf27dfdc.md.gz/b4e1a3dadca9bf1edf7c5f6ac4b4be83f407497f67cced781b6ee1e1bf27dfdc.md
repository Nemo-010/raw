Now with 3,000 free requests/day

# The Location API  
 Built for Developers

Geocoding, reverse geocoding, places search, vector map tiles, static map images, and custom dataset tiles — everything you need to build location-aware apps. Simple REST API, lightning-fast responses, and generous free tier.

[Get Free API Key →](https://dash.latlng.work/) [View Documentation](https://www.latlng.work/docs)

[LatLng Skills](https://www.latlng.work/skills) [MCP Server](https://www.latlng.work/mcp)

50ms

Avg Response

99.9%

Uptime

Free

To Start

```
// Geocode an address
const response = await fetch(
  'https://api.latlng.work/api?q=Seattle',
  {
    headers: {
      'X-Api-Key': 'YOUR_API_KEY'
    }
  }
);

// Response
{
  "features": [{
    "geometry": {
      "coordinates": [-122.33, 47.60]
    }
  }]
}
```

## Everything You Need

Geocoding, reverse geocoding, places search, and map tiles — all through a simple, intuitive API that developers love.

🎯

### [Forward Geocoding](https://www.latlng.work/free-geocoding-api)

Convert any address, city, or place name into precise latitude and longitude coordinates. [Learn more →](https://www.latlng.work/free-geocoding-api)

🔄

### [Reverse Geocoding](https://www.latlng.work/free-reverse-geocoding-api)

Turn coordinates into human-readable addresses. Perfect for location-based apps. [Learn more →](https://www.latlng.work/free-reverse-geocoding-api)

📍

### [Places & Autocomplete API](https://www.latlng.work/free-places-api)

Search nearby places and discover POIs ([Places API →](https://www.latlng.work/free-places-api)) or autocomplete addresses + place names as users type ([Autocomplete →](https://www.latlng.work/place-autocomplete-api)) — powered by OpenStreetMap.

🗺️

### [Vector Map Tiles](https://www.latlng.work/free-maps-api)

Fast, scalable vector tiles powered by OpenStreetMap. Works with MapLibre GL JS for fully custom styles. [Learn more →](https://www.latlng.work/free-maps-api)

🌍

### [Leaflet Raster Tiles](https://www.latlng.work/leaflet-tiles-api)

Drop-in raster PNG tiles for Leaflet.js — one `L.tileLayer` call. Light & dark styles, globally cached. [Learn more →](https://www.latlng.work/leaflet-tiles-api)

🎨

### [14 Map Styles](https://www.latlng.work/map-styles)

Light, Dark, Ocean, Winter, Forest, Topo, Vintage, Night, Atlas, Historic and more — all MapLibre-compatible. [Browse styles →](https://www.latlng.work/map-styles)

📸

### [Static Maps API](https://www.latlng.work/static-maps-api)

Generate map images (PNG/JPEG) from a single URL. Embed in emails, PDFs, and social cards — no JS needed. [Learn more →](https://www.latlng.work/static-maps-api)

📦

### [Dataset Tiles API](https://www.latlng.work/datasets-api)

Upload GeoJSON, Shapefile, GPX, or KML and serve it instantly as vector tiles via global CDN. [Learn more →](https://www.latlng.work/datasets-api)

🧭

### [Free Coordinate Tools](https://www.latlng.work/free-tools)

Free browser tools to convert coordinates between formats: [DMS ↔ Decimal →](https://www.latlng.work/dms-to-decimal-degrees), [UTM ↔ Lat/Long →](https://www.latlng.work/utm-to-lat-long), [Plus Code →](https://www.latlng.work/plus-code-to-lat-long), [What's My Location? →](https://www.latlng.work/whats-my-location), [What State Am I In? →](https://www.latlng.work/what-state-am-i-in), [What County Am I In? →](https://www.latlng.work/what-county-am-i-in). [Browse all tools →](https://www.latlng.work/free-tools)

✦

### [LatLng Skills](https://www.latlng.work/skills)

Give AI coding tools a practical playbook for geocoding, places, maps, auth, and output formats. [View skills →](https://www.latlng.work/skills)

🤖

### [MCP Server](https://www.latlng.work/mcp)

Connect MCP-compatible agents to LatLng geocoding, reverse geocoding, places search, nearby POIs, and category lookup tools. [View MCP page →](https://www.latlng.work/mcp)

⚡

### Lightning Fast

Sub-50ms response times powered by edge computing. Your users won't wait.

🌍

### Global Coverage

Worldwide address data powered by OpenStreetMap. Works in every country.

🔒

### Secure & Private

HTTPS encryption, no query logging, and GDPR compliant by design.

📊

### Usage Dashboard

Monitor your API usage, manage keys, and track requests in real-time.

## Showcase

Explore real-time data apps built on the LatLng stack.

🚢

### Global Shipping Tracker

Live AIS vessel positions worldwide on an interactive 3-D map. Cargo ships, tankers, and more — updated in real time. [Open map →](https://www.latlng.work/dash/shipping)

☀️

### HF Solar Dashboard

Real-time HF propagation conditions driven by live solar flux, sunspot, and geomagnetic data. [Open dashboard →](https://www.latlng.work/dash/hf-solar)

🌡️

### Live Temperature Map

Global air temperature updated every 6 hours from NOAA GFS forecasts, rendered as a smooth heatmap on the LatLng basemap. [Open map →](https://www.latlng.work/dash/weather)

↗

### Wind Flow Stations

Recent public NOAA METAR wind observations rendered as direction and speed markers on the LatLng basemap. [Open dashboard →](https://www.latlng.work/dash/wind-flow)

◉

### Earthquake Tracker

USGS earthquake feeds with magnitude, depth, and time filters, displayed as live map circles by viewport. [Open dashboard →](https://www.latlng.work/dash/earthquakes)

◌

### Bird Migration Radar

GBIF bird observations grouped into migration activity cells with species, month, year, and location filters. [Open dashboard →](https://www.latlng.work/dash/bird-migration-radar)

▲

### Active Wildfires Map

Current WFIGS/NIFC wildfire perimeters refreshed every 5 minutes and rendered on LatLng vector tiles. [Open map →](https://www.latlng.work/dash/active-wildfires)

◆

### Extreme Weather Alerts

Active NWS, Environment Canada, MeteoAlarm, BOM, and JMA warnings normalized into a global LatLng vector-map demo. [Open map →](https://www.latlng.work/dash/extreme-weather) [Resource page →](https://www.latlng.work/resources/extreme-weather-alerts-map)

🐚

### US Marine Protected Areas

981 National Marine Sanctuaries, monuments, and reserves covering 24% of US waters — boundaries served as vector tiles from a user-uploaded NOAA dataset. [Open map →](https://www.latlng.work/dash/marine-protected-areas)

## Simple, Transparent Pricing

Start for free, scale as you grow. No hidden fees or surprise charges.

### Free

$0/month

- 3,000 geocoding requests/day
- 300 reverse geocoding/day
- 100 static map images/day
- 3 custom dataset tiles
- Places nearby & search
- Vector map tiles
- API key authentication
- Usage dashboard
- Community support

[Get Started Free](https://dash.latlng.work/)

### Pro

$29/month

- 1,000,000 geocoding requests/month
- 10,000 static map images/month
- 50 custom dataset tiles
- Priority API access
- Advanced analytics
- Email support

[Start Pro Trial](https://dash.latlng.work/)

### Enterprise

Custom

- Unlimited requests
- Dedicated infrastructure
- Custom SLA
- On-premise option
- 24/7 phone support

[Contact Sales](https://www.latlng.work/contact)

## Ready to Build?

Join thousands of developers using LatLng to power their location features. Get your free API key in seconds.

[Get Your Free API Key →](https://dash.latlng.work/)

[Online Life](https://ownyourstack.co.uk/category/online-life)

# Tuta Drive: encrypted cloud storage with post-quantum protection, now in closed beta

Tuta, the German encrypted email provider, is adding zero-knowledge file storage. We look at what it promises, what is missing in the beta, and how it compares with the alternatives.

By **Andrew Ingleton** · Published 26 October 2026 at 05:11

Tuta Drive beta announcement graphic

Tuta Drive, now in closed beta © Tuta

Tuta, best known for its end-to-end encrypted email and calendar, opened a closed beta of Tuta Drive on 16 April 2026. It is a zero-knowledge cloud storage service that sits alongside Tuta Mail and Calendar, hosted on servers in Germany.

## How it protects your files

Files are encrypted automatically on your device before upload, so Tuta cannot read or share them. Drive uses TutaCrypt, the same protocol as Tuta's email, which combines classical and post-quantum algorithms so that a weakness in one layer does not break the other. The idea is to defend against "harvest now, decrypt later" attacks, where encrypted data is stored today in the hope that a future quantum computer can open it.

The project began in July 2023 as PQDrive, backed by €1.5 million from a German government grant for small and medium-sized businesses, and involved the University of Wuppertal on cryptographic testing and secure deduplication.

## What the beta lacks

- Folder uploads are not supported yet.
- Keyboard shortcuts are incomplete.
- There is no search.
- Uploads were slow over a VPN during early tests.

Tuta has not published pricing, and access is limited to selected users, with a public release planned after feedback. Treat it as one to watch, not one to move your photo library to.

## What it means for UK users

Hosting in Germany means EU data protection rules apply, and UK users already benefit from the UK-EU adequacy arrangements for personal data. The more interesting point is architectural: because the provider holds no keys, a government request or a data breach at the provider cannot expose your file contents, only metadata such as sizes and timestamps.

## Alternatives today

If you need encrypted storage now, you have three realistic routes: an established zero-knowledge service, your own [Nextcloud](https://ownyourstack.co.uk/go/nextcloud-com) with server-side or end-to-end encryption on a home server, or ordinary cloud storage with a tool such as Cryptomator encrypting the files before they leave your machine. Each trades convenience for control differently; we will cover them side by side in a future comparison.

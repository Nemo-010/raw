FEB – The Ultimate Cloud Storage & Media Experience,No ads Formerly known as FebBox, FEB is a powerful cloud storage solution designed for seamless file uploading, sharing, and management. Whether it’s documents, photos, videos, or other large files, FEB makes it easy to back up, sync, and access your data from any device, anytime, anywhere. With advanced sharing capabilities, you can effortlessly share files of any size with friends, family, or colleagues. Cinema Mode – Your Personal Movie Library Organize and manage all your media files effortlessly with Cinema Mode, which automatically categorizes all IMDB-linked files into a structured library: • Auto-organization of movies and TV shows based on IMDB data • Beautiful, structured layout for easy browsing • Metadata enrichment including posters, descriptions, ratings, and release years • Seamless playback integration with the built-in video player • Quick filtering by genre, release year, or watch status Smart eBook Reader Enjoy an enhanced reading experience with powerful customization options: • Supports multiple formats: EPUB, PDF, MOBI, CBR, CBZ, and more • Customizable font, size, line spacing, and Simplified/Traditional Chinese conversion • Adjustable background themes with built-in and custom options • Day & Night Mode for comfortable reading • Auto-read & auto-page turn with customizable speed • Online & offline text-to-speech (TTS) support • Source switching & catalog comparison for novels • Bookmarks & full-text search • Multiple page-turning styles: flip, overlay, slide, scroll Seamless File Sharing & Management • Subscription-based sharing for controlled access • Advanced permission settings for secure collaboration • Multiple view modes: Photo Wall, List, Thumbnail, General • IMDB integration for media files • Video file stream analysis for smooth playback Built-in Advanced Video Player • Dual playback engines: iOS Media Player & VLC • Comprehensive subtitle support: • External subtitles • OpenSubtitle search • Translation & encoding correction • Customizable size, background, color, and positioning • Casting support: AirPlay, ChromeCast, MiraCast, DLNA • Playback speed control • Screen adjustments: Stretch, 16:9, 4:3 • Picture-in-picture mode (system player only) Feature-Rich Music Player • Playlist management • Background playback • Shuffle & repeat modes • Sleep timer For more details: Terms of Service: https://www.febbox.com/Terms_of_Service Privacy Policy: https://www.febbox.com/privacy_policy

· Fixed a crash when searching within folders. · Fixed the keyboard covering the comment input field on iOS 27. · Fixed crashes when viewing images or changing subtitle encoding.

Version 12.8 6 days ago

The developer, **TOPSPEED NETWORK LIMITED**, indicated that the app’s privacy practices may include handling of data as described below. For more information, see the [developer’s privacy policy](https://www.febbox.com/privacy_policy).

- ### Data Linked to You

  The following data may be collected and linked to your identity:

    - Purchases
    - Contact Info
    - User Content
    - Search History
    - Identifiers
    - Usage Data

Privacy practices may vary based, for example, on the features you use or your age. [Learn More](https://apps.apple.com/be/iphone/story/id1538632801)

## Accessibility

The developer has not yet indicated which accessibility features this app supports. [Learn More](https://apps.apple.com/story/id1814164299)

## Information

Size

163.1 MB

Category

Productivity

Compatibility

Requires iOS 15.0 or later.

- **iPhone**  
  Requires iOS 15.0 or later.
- **iPad**  
  Requires iPadOS 15.0 or later.
- **iPod touch**  
  Requires iOS 15.0 or later.
- **Mac**  
  Requires macOS 12.0 or later.
- **Apple Vision**  
  Requires visionOS 2.0 or later.
- **Apple TV**  
  Requires tvOS 15.0 or later.
- **Apple Watch**  
  Requires watchOS 9.0 or later.

Languages

English and 2 more

- English, German, Simplified Chinese

Age Rating

13+

- 13+
- [Learn More](https://apps.apple.com/be/iphone/story/id1825160725)
- **Contains**  
  Messaging and Chat  
  User-Generated Content

In-App Purchases

Yes

- Premium · Monthly 3,99 €
- Premium · Yearly 28,49 €
- 14 Febcoins 22,00 €
- 210 Febcoins 349,00 €
- 70 Febcoins 100,00 €
- 280 Febcoins 449,00 €
- 350 Febcoins 600,00 €
- 63 Febcoins 100,00 €
- 140 Febcoins 229,00 €
- 49 Febcoins 80,00 €
- [Learn More](https://apps.apple.com/be/iphone/story/id1436214772)

Provider

TOPSPEED NETWORK LIMITED

- TOPSPEED NETWORK LIMITED has not identified itself as a trader for this app. If you are a consumer in the European Economic Area, consumer rights do not apply to agreements between you and the provider.

Copyright

©2025 TOPSPEED NETWORK LIMITED

## Supports

- ### SharePlay

  Share experiences in this app with friends and family directly inside FaceTime or Messages.

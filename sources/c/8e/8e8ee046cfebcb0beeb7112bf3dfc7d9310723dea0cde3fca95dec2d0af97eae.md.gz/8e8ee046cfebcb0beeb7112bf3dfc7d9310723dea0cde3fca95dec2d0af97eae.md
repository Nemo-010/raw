# About Standard Ebooks

Standard Ebooks is a volunteer-driven effort to produce a collection of high quality, carefully formatted, accessible, open source, and free public domain ebooks that meet or exceed the quality of commercially produced ebooks. The text and cover art in our ebooks are already believed to be in the U.S. public domain, and Standard Ebooks dedicates its own work to the public domain, thus releasing the entirety of each ebook file into the public domain. All the ebooks we produce are distributed free of cost and free of U.S. copyright restrictions.

Standard Ebooks is organized as a “[low-profit L.L.C.](https://en.wikipedia.org/wiki/Low-profit_limited_liability_company),” or “L3C,” a kind of legal entity that blends the charitable focus of a traditional not-for-profit with the ease of organization and maintenance of a regular L.L.C. Our only source of income is [donations from readers like you](https://standardebooks.org/donate).

## More information

## Masthead

### Editor-in-Chief

1. [Alex Cabal](https://alexcabal.com/) Contact information for Alex Cabal.

### Editors

*“Editor” is the honorary title bestowed on volunteers who, in their history of contributing to Standard Ebooks, have demonstrated exceptional capability in producing ebooks, as well as in managing and reviewing ebooks produced by other volunteers. They continue to volunteer as first-line consultants for new ebook projects.*

1. [Lukas Bystricky](https://www.linkedin.com/in/lukasbystricky/) Contact information for Lukas Bystricky.
2. [Weijia Cheng](https://www.weijiarhymeswith.asia/) Contact information for Weijia Cheng.
3. David Reimer Contact information for David Reimer.
4. [Vince Rice](https://www.brokenandsaved.com/) Contact information for Vince Rice.
5. [Emma Sweeney](https://www.linkedin.com/in/emma-sweeney-554927190/) Contact information for Emma Sweeney.
6. [Robin Whittleton](https://www.robinwhittleton.com/) Contact information for Robin Whittleton.

### Corporate Sponsors

1. [ElevenReader ElevenReader](https://elevenreader.io/standard-ebooks)
2. [Bookshop.org](https://bookshop.org/)
3. [Scribophile writing community & workshop Scribophile](https://www.scribophile.com/)

### Patrons Circle

[Join the Patrons Circle](https://standardebooks.org/donate#patrons-circle) to support beautiful, free, and unrestricted digital literature, and to have a direct voice in shaping the future of the Standard Ebooks catalog.

1. Златко Најденовски
2. Joseph Abell
3. John Adams
4. Kihea Adams-Wilson
5. Shervin Afshar
6. Christopher Agius
7. Edgar Aguilasocho
8. Aharon Ahdoot
9. Thomas Alcorn
10. Joshua Alexander
11. Isa Al-Khalifa
12. Jon Allen
13. David Allen
14. Trai An
15. Arif Anwar
16. Jason Armfield
17. Anthony Avina
18. Garett Backman
19. Larry Baerveldt
20. David Ballenger
21. liang baoshan
22. Michael Barrineau
23. Ann Bartyzel
24. Jonathan Bass
25. Drew Beall
26. Lysandra Belnavis-Walters
27. Matthew Berg
28. Keith Bernard
29. Neil Billingsley-Michaelsen
30. Robert Blasi
31. Russell Blickhan
32. Nicholas Boalch
33. Doug Bolden
34. Tobias Böse
35. Keith Bradner
36. Ray Ryan & Jennifer Braun
37. Garrett Brennan
38. Travis Briggs
39. Paul Broadwith
40. Justin Brooks
41. gift to my brother
42. George De Bruin
43. Solt Budavári
44. Shira Burton
45. carl byington
46. Clay Campaigne
47. Adrian Carroll
48. Joey Castillo
49. Matthew Chan
50. Daniel Chan
51. Ben Chapman
52. Wadood Chaudhary
53. Allison Clift-Jennings
54. Cannon Closson
55. Mark Cohen
56. Samuel Cole
57. Maxwell Collins-Shenfield
58. Cool Composter
59. Kathy Jo Connors
60. Andrew Conrad
61. James Conroy
62. Janella Conroy
63. Jackson Cooper
64. Michael Crews
65. Levi Currit
66. Chris Curro
67. Joshua Daulton
68. Zach Davis
69. Tadd Davis
70. Bruce Dearden
71. Bruce Dearden
72. Chris DeLuca
73. Boubacar Dembele
74. Brian Dewey
75. Joseph Dillingham
76. Frederick Doe
77. Chase Dooley
78. Joel Dowell
79. Alexander Dowson
80. Mike Drollman
81. Andrew Duke
82. Gregory Dumes
83. Lassi Eloranta
84. Klaus Engelholt
85. Cameron Esfahani
86. Ben Evans
87. Kian Faizi
88. Karen & Bennett Helm Family Fund
89. Zoellner-Fink Family Fund
90. Alvaro Fernandes
91. Wilhelm Fitzpatrick
92. Jon Flowers
93. Aaron Franks
94. Nicholas Friederich
95. David Gallagher
96. Lukasz Gandecki
97. Rohan Gandhi
98. Alan Gantzhorn
99. Richard Garrison
100. Nicholas Gawenda
101. David George
102. Bogdan Ghervan
103. John Giese
104. Carlos Giha
105. Stuart Gilliland
106. Geoffrey Gimse
107. Marcus Gitterle
108. Jonathan Gluck
109. Joshua Go
110. John Goerzen
111. Will Golden
112. Deborah Goldsmith
113. Patricia Gorla
114. Zachary Gougar
115. Michael Gove
116. Joe Gracyk
117. Christopher Graf
118. Kareem Granville
119. Matthew Graybosch
120. Brice Green
121. Jeff Greenstein
122. Derek Groothuis
123. Jeremy Gunkel
124. Anthony Gutierrez
125. Evan Hahn
126. Thomas Hahn
127. Isaac Halvorson
128. Harrison Hanna
129. Rob Hardy
130. Nick Harper
131. Gabriel Harper
132. Jason Harrison
133. Volker Hartmann
134. Mark Harviston
135. Jason Haslup
136. Mike Hathaway
137. Galen Hazelwood
138. Peter van Heerebeek
139. Conrad Heiney
140. David Heller
141. Curtis Hendzell
142. William Henry
143. Beau Henry
144. Carl Henshaw
145. Jordan Herrera
146. Sullivan Heywood
147. Jacob Hill
148. Douglas Hill
149. John Hopper
150. David Howell
151. Jeffery Huang
152. Michael Hunger
153. Matt Irons
154. Ellen Jaquette
155. Michael Jard
156. John Jarvis
157. Jolene Kaye Jensen
158. Richard Johnson
159. Sam Johnson
160. Matt Johnstone
161. Colby Jones
162. Ken Jones
163. Norah Jones
164. Brian Jordan
165. William Holt Jr
166. In memory of my brother, Harry Haritou Jr.
167. E K
168. Melissa Karolak
169. Christian Kildal-Brandt
170. Zachary Kirk
171. Gabriel Klavans
172. Ben Kleinbaum
173. Russell Klopfer
174. Leslie Koch
175. Damjan Korać
176. Adrian Lafond
177. Patrick LaForge
178. Chad Laird
179. Ross Laird
180. Gil Lamont
181. Nathaniel Lanning
182. Porter Larsen
183. Sam Larsen
184. Cody Laurent
185. Robin Law
186. John Leen
187. Catherine Leonard
188. Lisa Lerman
189. John Levine
190. Scott Lewis
191. Michel Alexandre Lind
192. Lance Linimon
193. Darren Lockhart
194. James Luke
195. Arun Luykx
196. Daniel Lyons
197. Ryan Maeda
198. Lucien Maloney
199. Marilyn Mapp
200. Brian Marick
201. Julien Marie
202. Bojidar Marinov
203. David Markham
204. Robert Martin
205. william martin
206. Nick Mathews
207. Thomas McCarthy-Howe
208. Michael McClellan
209. Robert McConeghy III
210. Raymond McDonald
211. Peter McFarland
212. Ray Michaud
213. Matt Midboe
214. Isaac Miller
215. Ben Miller
216. Stephanie Miller
217. Nelson Minar
218. Jeff Moe
219. Andrew Montalenti
220. Marcelo Montealegre
221. Matt Montgomery
222. Ian Montgomery
223. Bret Moore
224. Brian Moore
225. Jordan Moore
226. Trent Mora
227. Nicola Moretto
228. David Morris
229. Aferdita Muriqi
230. Emma Nolan
231. Hans Notelteirs
232. James Oberwetter
233. Brendan O’Connor
234. Luke Oguamanam
235. Ann Olmsted
236. Tom Osborne
237. Johan Andersson Östling
238. Rory O’Sullivan
239. Domenic Pace
240. Lydia Pagel
241. Zack Parker
242. Brian Pawlowski
243. Bruno Pereira
244. Ryan Petersen
245. Jason Petitjean
246. Vance Petree
247. Brandon Philips
248. David Phillips
249. Murphy Poplyk
250. giuseppe porta
251. Matt Post
252. Matthew Post
253. Zach Proffitt
254. Neal Quincey
255. chee rabbits
256. Neil Reddy
257. Gordan Redzic
258. Fedinand Reinke
259. Chris Richards
260. Kenn Richards
261. Mark Riegel
262. Josephine Riesman
263. Winston Riley
264. Andrew Roach
265. Thomas Robertson
266. David Romani
267. Brett Roper
268. D. Scott Ross
269. Evan Rowley
270. Elizabeth Ryan
271. W. D. Sadeep
272. Elizabeth Saewyc
273. Chris Sagers
274. Rollin Salsbery
275. Raymond Saltrelli
276. Colin Samuels
277. Morgan Sandquist
278. Edelmiro Santos
279. Jonathan Saunders
280. George Scherer
281. Jan Schmidt
282. Hans-Peter Schrei
283. Matthew Sconyers
284. Colin Scroggins
285. Russ Shanahan
286. Deepankar Sharma
287. Jeff Shaw
288. Justin Sheehy
289. Michael Shiplett
290. Michael Shull
291. David Remahl & Monica Sircar
292. Jay Sitter
293. William Sked
294. Nicholas K. Smith
295. Christian Smith
296. Philip Snead
297. Aurelia Song
298. Tyrel Souza
299. Brandon Sowers
300. Ben Spearman
301. Dustin Speckhals
302. John Spiers
303. William Starnes
304. Bret Starr
305. j stegman
306. Gerriet Suiter
307. Robert Sullivan
308. Amanda Swain
309. Mark Swenson
310. Dr. Alexandria Szeman
311. Christopher Tarry
312. Doron Tauber
313. Benjamin Taylor
314. Clayton Teague
315. Ellen Teapot
316. James Thomas
317. Connor Thompson
318. Suzanne Tiedeman
319. William Tiffany
320. Douglas Beach & Shannon Toohey
321. Diana Whitworth Trust
322. Andrew Turner
323. J.P. Tuttle
324. Árni Geir Úlfarsson
325. Eamonn Upperton
326. Susek Uziemblo
327. Nguyen Van
328. Vane Vander
329. Tobias Vaudrey
330. Aaron Vazquez
331. Goutham Veeramachaneni
332. Mike Vendetti
333. Kelson Vibber
334. Donald Vitz
335. Nicholas Walker
336. Rohn Walter
337. Lester Ward
338. Timothy Warren
339. Trevor Warren
340. Alex Washwin
341. Joseph Webb
342. Hazen Weber
343. Nicholas Weeks
344. Robyn Weimer
345. Tom Weinstein
346. Chris Weiss
347. Benjamin Welch
348. Zachary West
349. Patrick Weyer
350. Patrick Whitnell
351. Michael Wick
352. Austin Wicketts
353. Tanner Wigington
354. Lance Wilcox
355. William Wilhelm
356. Amy Wilhelm
357. Ciaran Willis
358. Jonas Wisser
359. Max Wolffe
360. Eric Wong Fund
361. Jeremy Worrells
362. Brandon Wright
363. John Wyatt
364. Sturla Y
365. Norris Yarbrough
366. Angelica Yoon
367. leon zhao
368. Ton Zijlstra
369. Anonymous × 338

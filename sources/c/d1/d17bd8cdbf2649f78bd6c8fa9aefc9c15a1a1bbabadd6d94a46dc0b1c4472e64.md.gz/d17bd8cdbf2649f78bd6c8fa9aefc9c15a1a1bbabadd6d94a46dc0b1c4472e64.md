# The most reliableuptime monitoring

Get 10 monitors, 10 heartbeats and a status page with 3-minute checks totally free.

## Best-in-class uptime monitoring. No false positives.

Get a screenshot of the error and a second-by-second timeline with our fastest 30-second checks.

[Explore website monitoring](/website-monitoring.md)

### Traceroute & MTR for timeouts

Understand connection timeouts and request timeouts with edge-based traceroute and MTR outputs.

#### Screenshots & error logs

We record your API's error message and take a screenshot of your website being down so that you know exactly what happened.

#### Playwright transaction monitoring

We test all vital interactions by running a real Chrome browser instance, with a full-fledged JavaScript runtime.

##### From SSL to domain expiration

Monitor everything. Whether it's your web page, API, ping, SSL, domain expiration, POP3, IMAP, SMTP, DNS, or generic network monitoring. We've got you covered.

##### 30s checks from around the world

Get a screenshot of the error and a second-by-second timeline with our fastest 30-second checks.

##### Cron monitoring

Never lose a database backup again. Track your CRON jobs and serverless workers and get alerted if they don't run correctly.

## A lot more than uptime monitoring. Batteries included.

Get all the debug data you need and collaborate with your colleagues on fixing the root cause of the incident.

[Explore incident management](/incident-management.md)

### Smart incident merging

30 incidents get created at the same time. Acknowledge them with a single tap and stop your phone from ringing.

#### Flexible incident escalations

Configure complex rules for escalating incidents based on time, team availability, and incident origin.

#### Unlimited voice call alerts

As well as SMS, e-mail, Slack, Teams, and push notifications with our all-you-can-alert pricing.

## Elegant status page

Build confidence in your product by sharing your system status at status.yourdomain.com.

[Explore status page](/status-page.md)

### Share incident updates

Communicate ongoing incidents, planned maintenance, and service degradations.

#### Custom status.yourdomain.com

Host a branded status page on your own custom subdomain and build confidence in your brand.

#### Subscribe to updates

Let your customers subscribe to email updates so that they always know what's going on.

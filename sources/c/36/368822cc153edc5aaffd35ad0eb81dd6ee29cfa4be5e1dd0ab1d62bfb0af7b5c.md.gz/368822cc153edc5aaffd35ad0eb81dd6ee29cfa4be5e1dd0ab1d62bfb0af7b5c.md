# pricing

Pay for what you use: a small base fee for every hour a machine is running — the isolated slot itself, not reserved vCPU/RAM — plus what your workload actually consumes on top. Sit idle and the consumption lines fall to near zero; stop the machine and even the base fee stops. New accounts start with **$100.00 of free credit**.

## rates

| Resource | Unit | Price |
| --- | --- | --- |
| Base (running machine) | per machine-hour running (1-minute minimum) | $0.04 |
| Compute (active vCPU) | per vCPU-hour consumed | $0.05 |
| Memory (active RSS) | per GB-hour in use | $0.0162 |
| Disk (used) | per GB-hour used (~$0.073/GB-month) | $0.0001 |
| Network egress | per GB out | $0.05 |

beta 10% off the spend above $2,000.00 a month. The threshold and rate may still change.

## compare plans

|  | standard | pro | startup | enterprise |
| --- | --- | --- | --- | --- |
| Monthly fee | $0 | $20 + usage | $150 + usage | custom |
| Machines | 20 | 100 | 1,000 | per contract |
| vCPU per machine | 8 | 16 | 32 | per contract |
| Memory per machine | 16 GB | 24 GB | 32 GB | per contract |
| Disk per machine | not published | 200 GB | 200 GB | per contract |
| Usage rates | same rates | same rates | same rates | volume rates |
| Always-on apps | idle apps scale to zero | yes | yes | yes |
| Priority support | — | — | yes | yes |
| Uptime SLA | — | 99.95% | 99.95% | 99.95% |
| SSO/SAML | — | — | — | yes |
| Dedicated nodes | — | — | — | yes |

"Not published" means that plan's limit is not stated here yet.

Every plan bills the rates above — a plan buys limits and support, never a different price per unit, and a monthly fee is added on top of usage rather than exchanged for credit — and machines start from warm pools on all of them, free included. A machine larger than your plan allows is refused at create time with the limit in the reply, so nothing is charged for it.

**Machines bill a one-minute minimum.** Creating, booting and tearing down a machine costs the same whether it lives ten seconds or an hour, so every machine bills at least one minute at the size you asked for. A machine that runs longer than a minute is billed for what it actually used, to the second. Forking an existing machine is far cheaper than creating a new one, so a fan-out that branches off one prepared machine pays the minimum once rather than once per clone.

**Sign-up credit is granted once.** New accounts receive $100.00 of credit when they are created. It is ordinary prepaid balance: it is drawn down as you use the platform, it does not reset monthly, and whatever is left stays yours. When it runs out you top up and keep going.

[Start free](https://smolmachines.com/console), and change plan any time from your [billing page](https://smolmachines.com/console/usage). For enterprise, [email us](https://smolmachines.com/cdn-cgi/l/email-protection#5b333e3737341b28363437363a383332353e2875383436).

## estimate your bill

Describe a steady workload and see what a month costs at today's rates. Compute is billed only while machines run; disk is held, and billed, around the clock.

Machines running at once

Hours running per day

h

vCPU in use per machine

Memory in use per machine

GB

Disk per machine

GB

Egress per month

GB

Plan

standard pro startup

Base: 243 machine-hours × $0.04 $9.7333

Compute: 0.25 vCPU × $0.05/h $3.0417

Memory: 0.25 GB × $0.0162/h $0.9855

Disk: 1 × 1 GB × 730h × $0.0001 $0.073

Egress: 0 GB × $0.05 $0

standard plan fee $0

Estimated total $13.8335/mo

New accounts also get $100.00 of credit once, at sign-up. It pays bills like this one until it runs out; it is not a monthly discount.

## faq

### Do stopped machines cost anything?

A stopped machine pays **no base fee and no CPU or memory** — those meters stop the moment it stops. Its disk still occupies space on the host, so that held storage keeps billing at the disk rate (a few cents per GB-month). Delete the machine to stop that too.

### How does the estimate work?

It multiplies a steady workload by the live rates above: base, CPU and memory for the hours machines run, disk for every hour of the month, and egress per GB. The graduated volume discount and your plan's fee are applied last. Real bills follow actual use, measured continuously, so a bursty workload costs less than its peak.

### How is usage tracked?

The control plane samples each machine's live CPU, memory, and disk continuously and accumulates a durable per-account total. View it in real-time at [/console/usage](https://smolmachines.com/console/usage).

### What isolation do I get?

Every machine runs in its own hardware-isolated microVM. Not a container — a real virtual machine with its own kernel. Your code can't see other tenants.

### Can I use the API directly?

Yes. The dashboard uses the same REST API you can call from your code. Generate an API key at [/console/keys](https://smolmachines.com/console/keys).

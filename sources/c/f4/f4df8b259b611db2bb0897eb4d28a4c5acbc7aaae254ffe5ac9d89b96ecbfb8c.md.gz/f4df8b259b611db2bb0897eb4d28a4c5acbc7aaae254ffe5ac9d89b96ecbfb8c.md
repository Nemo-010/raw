HTTP/1.1 200 OK
Date: Fri, 30 Oct 2026 18:12:43 GMT
Content-Type: text/html
Transfer-Encoding: chunked
Connection: keep-alive
Access-Control-Allow-Origin: *
Last-Modified: Fri, 30 Oct 2026 09:50:01 GMT
Server: cloudflare
Vary: accept-encoding
Cf-Placement: [redacted]
access-control-expose-headers: *, x-web-egress, x-web-form, x-web-provider, x-web-account, x-web-body, x-web-snapshot-at, x-web-cache, x-web-headers, x-web-origin-status, x-web-provider-origin-status, x-web-final-url, x-web-providers, x-web-corpus, x-web-store, allow, retry-after, location, memento-datetime
expect-ct: max-age=86400, enforce
nel: {"report_to":"cf-nel","success_fraction":0.0,"max_age":604800}
referrer-policy: same-origin
report-to: {"group":"cf-nel","max_age":604800,"endpoints":[{"url":"https://a.nel.cloudflare.com/report/v4?s=Vcp1cveiFMBSeEFHMio01ZYMedct3EIM58Vsm6fpcuzLRcW3y40p%2B1I6ZTwWmvECVJB1lO4403EGSu19bDzNRD%2F17FvufATUMqIvwZexqbVow10T%2BMdN8iNbw%2Bkp%2B4IXRMT5FI%2FkEpSkZLmz"}]}
x-content-type-options: nosniff
x-frame-options: SAMEORIGIN
x-web-corpus: W/"c5e9e64342a33f898201763b7422e7f35f8503b673ae043cb409af3787ae5c74"
x-web-egress: egress=cf-fetch tried=cf-fetch identity=fixed tls=platform headers=partial dialFailureObservable=true responseFramingModified=false
x-web-form: path-scheme
x-xss-protection: 1; mode=block
CF-RAY: a52c63c7bc2cff1b-[redacted]
alt-svc: h3=":443"; ma=86400


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link href="https://console.linkstatic.com/favicon.ico" rel="shortcut icon" type="image/x-icon" />
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">

    
    <title>Sale of IP Subnet | Independent, Controllable Network · pure ISP IPs</title>
    <meta name="description" content="Delivered as a dedicated, contiguous IP subnet for exclusive use by your business; bandwidth and server configurations are fully customizable." />
    <meta name="keywords" content="" />
    

    <link rel="stylesheet" href="/static/common/nav/css/nav.min.css">
    <link rel="stylesheet" href="/static/common/footer/css/footer.min.css">

    

    <script>
        var requestApi = 'https:\/\/api.linkstatic.com';
        var centerUrl = 'https:\/\/console.linkstatic.com';
        var centerAppUrl = 'https:\/\/app.linkstatic.com';
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth <= 768) {
            centerUrl = centerAppUrl;
        }
        
        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('[data-center-url]').forEach(function (el) {
                el.setAttribute('href', centerUrl);
            });
        });
        var webDomain = 'https:\/\/linkstatic.com\/';
        const language = 'en' == 'zh' ? '' : 'en/';
        const langInterface = 'en';
        const copyTexts = 'Copy Success';
    </script>
</head>

<body>

    <script type="text/javascript" src="/static/js/jquery.min.js"></script>
    <script src="/static/js/cookie.js"></script>
    <script src="/static/js/request.js?v=1541"></script>
    <script src="/static/common/nav/js/nav.js?v=1541"></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-18124996381"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'AW-18124996381');

        function gtag_report_conversion(url) {
            var callback = function () {
                if (typeof (url) != 'undefined') {
                    window.location = url;
                }
            };
            gtag('event', 'conversion', {
                'send_to': 'AW-18124996381/rIoKCPmR464cEJ3-1cJD',
                'value': 1.0,
                'currency': 'USD',
                'event_callback': callback
            });
            return false;
        }
    </script>

    <div class="connect_us">
    <div class="service">
        <div class="may-email chart-telegram">
            <a href="javascript:;" class="tlinks online-chat" id="online-chat"></a>
        </div>
        <div class="may-email may-telegram">
            <a href="https://telegram.me/LinkStaticSupport" class="tlinks" target="_blank"></a>
            <div class="may-email-tips">
                <div class="cu-email-tips-cont tgcontent">
                    <div class="tg-group">

                        <div class="tg-img-title">
                            <p class="title">TG</p>
                            <p class="warn-tips" style="color: #FF1F93;">Buy only from official website. No private payments.</p>

                        </div>
                        <div class="tg-img-container">
                            <img src="/static/common/footer/img/tg_icons.png" alt="">
                            <p onclick="copyText('LinkStaticSupport')">@LinkStaticSupport <img src="/static/common/footer/img/copy_service.png" alt="" ></p>
                        </div>
                        <p class="tips1" style="margin-top: 12px;"><a href="https://telegram.me/LinkStaticSupport"
                                target="_blank">https://telegram.me/LinkStaticSupport</a>
                           
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="may-email email-tips">
            
            <a href="mailto:support@linkstatic.com"></a>
            <div class="may-email-tips">
                <div class="cu-email-tips-cont tgcontent">
                    <p class="title">Emai</p>
                    <p class="tips2" style="margin-top: 12px;color: #FF1F93;">Contact our email address</p>
                    <p class="tips1" style="margin-top: 12px;" onclick="copyText('support@linkstatic.com')">support@linkstatic.com <img src="/static/common/footer/img/copy_service.png" alt=""></p>
                </div>
            </div>
        </div>
    </div>

</div>
<div class="may-top">
    <p></p>
</div>


<script>
    window.__twt__config = { appid: "2080148c2f2764a36fbf2b8a225eabdb", lang: "zh-cn", theme: "light", sbs: "", sbs_mm: "", ranstr: "", name: "", nickname: "", email: "", phone: "", icon: "2", }; (function (n, t) { var e = { init: function () { var n = t.createElement("script"); n.async = !0; n.type = "text/javascript"; n.src = "https://visitorchat.twt.com/install/core.js?version=v1.2"; t.head.appendChild(n) }, }; e.init() })(window, document);
</script>

<script>
    $(window).scroll(function () {
        var sTop = $(window).scrollTop();
        if (sTop >= 500) {

            $(".may-top").fadeIn(200);
        } else {
            $(".may-top").fadeOut(200);
        }
    });
    $(document).on("click", ".may-top", function () {
        $("body,html").animate({ scrollTop: 0 }, 500);
    });


    
    if (window.__twt__config) {
        window.__twt__config.icon = '2'
    }
    $(document).on('click', '.online-chat', () => {
        if (window.__twt__api && window.__twt__api.open) {
            window.__twt__api.open()
        }
        if (window.__twt__api && window.__twt__api.setLanguage) {
            window.__twt__api.setLanguage('en' == 'zh' ? 'zh-cn' : 'en')
        }
    })
   
</script>
</body>

</html>



<section class="header_container">
    
    <header class="nav_header">
        <div class="header_content">
            <a href="/en/">
                <img src="/static/img/link_logo_white.png" alt="">
            </a>

            <div class="header_inner">
                <div class="header_menu">
                    <div>
                        <a href="javascript:;">Pricing</a>
                        <i></i>
                        <div>
                            <div class="package-box">
                                <div class="package-box-item">
                                    <a href="/en/pricing/isp-proxy/" class="package-item">
                                        
                                        <div class="img_1">

                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>ISP Proxies</span><span
                                                    class="package-tag new-user-tag">New User <em> 50% OFF</em></span>
                                            </p>
                                            <p class="package-subtitle">
                                                Premium dedicated IPs for business use at competitive prices.
                                            </p>
                                        </div>
                                        <div class="package-price">
                                            <div class="rise">
                                                from
                                            </div>
                                            <div class="price-num">
                                                <p>$</p> <span>2.40</span>
                                                <p>/ mo</p>
                                            </div>

                                        </div>
                                    </a>
                                    <a href="/en/pricing/isp-enterprise/" class="package-item">
                                        
                                        <div class="img_2">

                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>Enterprise ISP Proxies</span> <span
                                                    class="package-tag">Upgradeable bandwidth</span>
                                            </p>
                                            <p class="package-subtitle">
                                                Select high-end exclusive IP, pure and stable online, the bandwidth can be upgraded
                                            </p>
                                        </div>
                                        <div class="package-price">
                                            <div class="rise">
                                                from
                                            </div>
                                            <div class="price-num">
                                                <p>$</p> <span>6.00</span>
                                                <p>/ mo</p>
                                            </div>

                                        </div>
                                    </a>

                                </div>

                                <div class="package-box-item">

                                    <a href="/en/pricing/isp-tiktok/" class="package-item">
                                        
                                        <div class="img_3">
                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>TikTok  Live Streaming Line</span>
                                                
                                            </p>
                                            <p class="package-subtitle">
                                                Dedicated IPs and high bandwidth for low-latency, smooth live streaming.
                                            </p>
                                        </div>
                                        <div class="package-price">
                                            <div class="rise">
                                                from
                                            </div>
                                            <div class="price-num">
                                                <p>$</p> <span>68.00</span>
                                                <p>/ mo</p>
                                            </div>

                                        </div>
                                    </a>
                                    <a href="/en/pricing/isp-subnet/" class="package-item">
                                        
                                        <div class="img_4">
                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>Whole C segment native IP</span>
                                                
                                            </p>
                                            <p class="package-subtitle">
                                                Premium native IP blocks, independently allocated and fully network-controlled.
                                            </p>
                                        </div>
                                        <div class="package-price">
                                            <div class="rise">
                                                from
                                            </div>
                                            <div class="price-num">
                                                <p>$</p> <span>500.00</span>
                                                <p>/ mo</p>
                                            </div>

                                        </div>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                    

                    
                    
                    
                    <div>
                        <a href="javascript:;">Use Cases</a>
                        <i></i>
                        <div>
                            
                            <div class="package-box case-box">
                                <div class="package-box-item">
                                    <a href="/en/case/ai/" class="package-item case-item">
                                        <div class="img_case_ai">

                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>AI Software Usage</span>
                                            </p>
                                            <p class="package-subtitle">
                                                Long-term ISP networks support AI creation and R&amp;D collaboration.
                                            </p>
                                        </div>
                                    </a>
                                    <a href="/en/case/social-media" class="package-item case-item">
                                        <div class="img_case1">

                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>Social Media Matrix</span>
                                            </p>
                                            <p class="package-subtitle">
                                                Independent multi account operation to support global social media matrix deployment.
                                            </p>
                                        </div>
                                    </a>

                                    <a href="/en/case/temu" class="package-item case-item">
                                        <div class="img_case2">

                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>Temu Proxy</span>
                                            </p>
                                            <p class="package-subtitle">
                                                Native IP for stable access to conduct cross border commodity market research.
                                            </p>
                                        </div>
                                    </a>

                                  
                                </div>
                                <div class="package-box-item">
                                    <a href="/en/case/store-operations/" class="package-item case-item">
                                        <div class="img_case_store">

                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>Store Operations</span>
                                            </p>
                                            <p class="package-subtitle">
                                                Native ISP networks for stable long-term cross-border multi-store operations.
                                            </p>
                                        </div>
                                    </a>

                                    <a href="/en/case/accounts/" class="package-item case-item">
                                        <div class="img_case_account">

                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>Multi-account Management</span>
                                            </p>
                                            <p class="package-subtitle">
                                                Isolated account environments for scalable matrix account operations.
                                            </p>
                                        </div>
                                    </a>

                                    <a href="/en/case/shopee" class="package-item case-item">
                                        <div class="img_case3">

                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>Shopee Proxy</span>
                                            </p>
                                            <p class="package-subtitle">
                                                Residential local proxies to support cross regional price comparison and competitive analysis.
                                            </p>
                                        </div>
                                    </a>
                                </div>
                                <div class="package-box-item">
                                    <a href="/en/case/tiktok" class="package-item case-item">
                                        <div class="tiktok-content-bg">
                                            <div class="content">
                                                <div>
                                                    <p>TikTok Live Streaming</p>
                                                    <img src="/static/common/nav/img/arrow-right.png" alt="">
                                                    </div>
                                                    <p>Dedicated live streaming lines for low-latency, HD, and stable live broadcasting.</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <a href="javascript:;">Region</a>
                        <i></i>
                        <div class="nav-country-dropdown">
                            <div class="nav-country-content">
                                <p class="nav-item-title">
                                    Popular Regions
                                </p>
                                <div>
                                    <div style="display: flex;flex-direction: column;">
                                        <a href="/en/topic/us">
                                            <img src="/static/common/nav/img/us.png" alt="" />
                                            <div>
                                                <p>United States</p>

                                            </div>
                                        </a>
                                        <a href="/en/topic/fr">
                                            <img src="/static/common/nav/img/fr.png" alt="" />
                                            <div>
                                                <p>France</p>

                                            </div>
                                        </a>

                                        <a href="/en/topic/de">
                                            <img src="/static/common/nav/img/de.png" alt="" />
                                            <div>
                                                <p>Germany</p>

                                            </div>
                                        </a>

                                        <a href="/en/topic/ca">
                                            <img src="/static/common/nav/img/ca.png" alt="" />
                                            <div>
                                                <p>Canada</p>

                                            </div>
                                        </a>
                                    </div>
                                    <div style="display: flex;flex-direction: column;">
                                        <a href="/en/topic/uk">
                                            <img src="/static/common/nav/img/uk.png" alt="" />
                                            <div>
                                                <p>United Kingdom</p>

                                            </div>
                                        </a>
                                        <a href="/en/topic/jp">
                                            <img src="/static/common/nav/img/jp.png" alt="" />
                                            <div>
                                                <p>Japan</p>

                                            </div>
                                        </a>
                                        <a href="/en/topic/kr">
                                            <img src="/static/common/nav/img/kr.png" alt="" />
                                            <div>
                                                <p>South Korea</p>

                                            </div>
                                        </a>
                                        <a href="/en/topic/au">
                                            <img src="/static/common/nav/img/au.png" alt="" />
                                            <div>
                                                <p>Australia</p>

                                            </div>
                                        </a>

                                    </div>
                                    <div style="display: flex;flex-direction: column;">
                                        <a href="/en/topic/sg">
                                            <img src="/static/common/nav/img/sg.png" alt="" />
                                            <div>
                                                <p>Singapore</p>

                                            </div>
                                        </a>

                                        <a href="/en/topic/hk">
                                            <img src="/static/common/nav/img/hk.png" alt="" />
                                            <div>
                                                <p>Hong Kong, China</p>

                                            </div>
                                        </a>
                                        <a href="/en/topic/tw">
                                            <img src="/static/common/nav/img/tw.png" alt="" />
                                            <div>
                                                <p>Taiwan, China</p>

                                            </div>
                                        </a>

                                        <a href="/en/topic/th">
                                            <img src="/static/common/nav/img/th.png" alt="" />
                                            <div>
                                                <p>Thailand</p>

                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    

                    <div>
                        <a href="javascript:;">Resource</a>
                        <i></i>
                        <div>
                            <div class="package-box">
                                <div class="package-box-item">
                                    <a href="/en/partner/" class="package-item case-item">
                                        <div class="img_case4">

                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>Partners</span>
                                            </p>
                                            <p class="package-subtitle">
                                                Provide high-quality IP resources and technical support, and customize exclusive solutions and exclusive benefits for partners.
                                            </p>
                                        </div>
                                    </a>
                                    <a href="/en/global-resources" class="package-item case-item">
                                        <div class="img_case5">

                                        </div>
                                        <div class="package-text">
                                            <p class="package-title">
                                                <span>Global Resources</span>
                                            </p>
                                            <p class="package-subtitle">
                                                Covering network nodes in multiple regions worldwide, supporting global business expansion
                                            </p>
                                        </div>
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="nav-info">
                    <div class="infolanguage-nav">
                        <div class="infol-text">
                            <span id="selected-language">
                                
                                EN-English
                                
                            </span>
                            <i></i>
                        </div>
                        <ul class="infol-drop">
                            <li data-lang="zh" data-name="ZH"><a href="/pricing/isp-subnet"
                                    onclick="sessionStorage.setItem('language_switched', 'true')">ZH-简体中文</a><i></i>
                            </li>
                            <li data-lang="en" data-name="EN"><a href="/pricing/isp-subnet"
                                    onclick="sessionStorage.setItem('language_switched', 'true')">EN-English</a> <i></i>
                            </li>
                        </ul>
                    </div>
                    <div class="infobtn haveinfo user">
                        <img src="/static/common/nav/img/userLogo.png" alt="" />
                        <a href="https://console.linkstatic.com" data-center-url></a>
                        <i class="select-down"></i>
                        <div class="user-panel">
                            <a href="https://console.linkstatic.com" data-center-url><span class="layout"></span>Console</a>
                            <a href="javascript:;" class="logout-nav"><span
                                    class="logout"></span>Logout</a>
                        </div>
                    </div>
                    <div class="infobtn noinfo user">

                        
                        <a href="/en/sign-in?r=%2fpricing%2fisp-subnet">Sign in</a>
                        <a class="register_btn"
                            href="/en/sign-up?r=%2fpricing%2fisp-subnet">Sign up</a>
                        
                    </div>
                </div>
            </div>

            <div class="mobile_menu">
                <img class="langp_logo online-chat" style="width: 24px;height: 24px;margin-right: 8px;" id="online-chat" src="/static/common/nav/img/service_icon.png" alt="novproxy">
                <img class="mlang_logo langp_logo" src="/static/common/nav/img/mnavw_lang.png" alt="">
                <img class="mmore_icon langp_logo" src="/static/common/nav/img/menuw.png" alt="">

                <img class="mlang_logo langm_logo" src="/static/common/nav/img/mnavw_lang.png" alt="">

                <div></div>
            </div>
        </div>
    </header>

    
    <div class="m-menu-list">
        <div class="m-menu-list-hesder">
            <img src="/static/common/nav/img/nav-close.png" alt>
        </div>
        <main>
            <div class="m-menu-list-main">
                <div class="m-menu-list-item">
                    <span>Pricing</span>
                    <i></i>
                </div>
                <div class="m-menu-list-item-main">
                    <div class="m-l-item-main white">
                        <a class="m-l-item-main-i" href="/en/pricing/isp-proxy/m">
                            <img src="/static/common/nav/img/nav_small_pricing1.svg"
                                alt=""><span>ISP Proxies</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/pricing/isp-enterprise/m">
                            <img src="/static/common/nav/img/nav_small_pricing2.svg"
                                alt=""><span>Enterprise ISP Proxies</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/pricing/isp-tiktok/m">
                            <img src="/static/common/nav/img/nav_small_pricing3.svg"
                                alt=""><span>TikTok  Live Streaming Line</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/pricing/isp-subnet/m">
                            <img src="/static/common/nav/img/nav_small_pricing4.svg"
                                alt=""><span>Whole C segment native IP</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="m-menu-list-main">
                <div class="m-menu-list-item">
                    <span>Resource</span>
                    <i></i>
                </div>
                <div class="m-menu-list-item-main">
                    <div class="m-l-item-main white">
                        
                        <a class="m-l-item-main-i" href="/en/partner/">
                            <span>Partners</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/global-resources/m">
                            <span>Global Resources</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="m-menu-list-main">
                <div class="m-menu-list-item">
                    <span>Popular Regions</span>
                    <i></i>
                </div>
                <div class="m-menu-list-item-main">
                    <div class="m-l-item-main white">
                        <a class="m-l-item-main-i" href="/en/topic/us">
                            <img src="/static/common/nav/img/us.png"
                                alt=""><span>United States</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/topic/uk">
                            <img src="/static/common/nav/img/uk.png"
                                alt=""><span>United Kingdom</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/topic/de">
                            <img src="/static/common/nav/img/de.png"
                                alt=""><span>Germany</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/topic/ca">
                            <img src="/static/common/nav/img/ca.png"
                                alt=""><span>Canada</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/topic/jp">
                            <img src="/static/common/nav/img/jp.png"
                                alt=""><span>Japan</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/topic/fr">
                            <img src="/static/common/nav/img/fr.png"
                                alt=""><span>France</span>
                        </a>

                        <a class="m-l-item-main-i" href="/en/topic/kr">
                            <img src="/static/common/nav/img/kr.png"
                                alt=""><span>South Korea</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/topic/au">
                            <img src="/static/common/nav/img/au.png"
                                alt=""><span>Australia</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/topic/sg">
                            <img src="/static/common/nav/img/sg.png"
                                alt=""><span>Singapore</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/topic/hk">
                            <img src="/static/common/nav/img/hk.png"
                                alt=""><span>Hong Kong, China</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/topic/tw">
                            <img src="/static/common/nav/img/tw.png"
                                alt=""><span>Taiwan, China</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="m-menu-list-main">
                <div class="m-menu-list-item">
                    <span>Use Cases</span>
                    <i></i>
                </div>
                <div class="m-menu-list-item-main">
                    <div class="m-l-item-main white">
                        <a class="m-l-item-main-i" href="/en/case/social-media">
                            <span>Social Media Matrix</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/case/temu">
                            <span>Temu Proxy</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/case/shopee">
                            <span>Shopee Proxy</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/case/ai">
                            <span>AI Software Usage</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/case/store-operations">
                            <span>Store Operations</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/case/tiktok">
                            <span>TikTok Live Streaming</span>
                        </a>
                        <a class="m-l-item-main-i" href="/en/case/accounts">
                            <span>Multi-account Management</span>
                        </a>
                    </div>
                </div>
            </div>


            <div class="m-menu-list-main">
                <div class="m-menu-list-item">
                    <span>Language</span>
                    <i></i>
                </div>
                <div class="m-menu-list-item-main">
                    <div class="m-l-item-main white">
                        <a class="m-l-item-main-i" href="/?lang=zh">
                            <span>ZH-简体中文</span>
                        </a>
                        <a class="m-l-item-main-i" href="/?lang=en">
                            <span>EN-English</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="m-menu-list-main">
                <a href="https://console.linkstatic.com" class="m-menu-list-item" data-center-url>
                    <span>Console</span>
                    
                </a>
            </div>
            <div class="m-l-item-btn">
                <section class="m-no-login">
                    <a class="btn m-login" href="/en/sign-in?r=%2fpricing%2fisp-subnet">Sign in</a>
                    <a class="btn m-reg" href="/en/sign-up?r=%2fpricing%2fisp-subnet">Sign up</a>
                    

                </section>
                <section class="m-have-login">
                    <a class="btn" href="https://console.linkstatic.com" data-center-url></a>
                    <p class="m-logout">Log out</p>
                </section>
            </div>
        </main>
    </div>

    
    <div class="mobile-language-select">
        <div class="m-menu-list-hesder">
            <img src="/static/common/nav/img/nav-close.png" alt>
        </div>
        <ul class="infol-drop">
            <li data-lang="zh" data-name="ZH"><a href="/pricing/isp-subnet">ZH-简体中文</a><i></i></li>
            <li data-lang="en" data-name="EN"><a href="/pricing/isp-subnet">EN-English</a> <i></i></li>
        </ul>
    </div>
</section>


<link rel="stylesheet" href="/static/common/package/css/isp_subnet.min.css?v=">

<div class="isp-subnet-container">
    <section class="isp-subnet-header">
        <p class="active"></p>
        <div class="isp-subnet-content">

            <h1>Whole C segment native IP Pricing</h1>
            <p class="isp-subnet-desc">Carefully selected native static ISP, entire segment exclusively held, IP fixed long-term, unlimited traffic and concurrency, enjoying a unified high-quality network environment.</p>

            <div class="isp-subnet-feature-list">
                <div class="isp-subnet-feature-item item1">
                    <img src="/static/common/package/img/isp_subnet/check.png" alt="">
                    <span>Carefully Selected Native IP Resources</span>
                </div>
                <div class="isp-subnet-feature-item item2">
                    <img src="/static/common/package/img/isp_subnet/check.png" alt="">
                    <span>Ultra-fast and Stable Bandwidth Experience</span>
                </div>
                <div class="isp-subnet-feature-item item3">
                    <img src="/static/common/package/img/isp_subnet/check.png" alt="">
                    <span>Complete network segment held independently</span>
                </div>
                <div class="isp-subnet-feature-item item4">
                    <img src="/static/common/package/img/isp_subnet/check.png" alt="">
                    <span>Ultra-high concurrency with unlimited capacity</span>
                </div>
            </div>

            <p class="isp-subnet-note">For longer durations and greater bandwidth, reach online support anytime. We tailor exclusive solutions for various business scenarios.</p>
            <a class="isp-subnet-cta online-chat" href="javascript:void(0)">Customer Manager</a>
        </div>
    </section>

    <section class="isp-pricing-container">
        <div class="isp-pricing-grid">
            <div class="isp-pricing-left">
                <div class="isp-country-tabs">
                    <p>Country/Region</p>
                    
                    <button type="button" data-id="AM"  class="active"
                        >America</button>
                    
                    <button type="button" data-id="AS" >Asia</button>
                    
                    <button type="button" data-id="EU" >Europe</button>
                    
                    <button type="button" data-id="OA" >Oceania</button>
                    
                </div>

                <div class="isp-country-list">
                    
                    <div data-cateid="AM" class="isp-country-card partdetailAM" data-code="US"
                        data-country="United States" data-price="500" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/us.png" alt="">
                                <p class="country-name">United States</p>
                            </div>
                            <span
                                class="isp-country-tag">Hot</span>
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$500.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="EU" class="isp-country-card partdetailEU" data-code="ES"
                        data-country="Spain" data-price="700" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/es.png" alt="">
                                <p class="country-name">Spain</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$700.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="EU" class="isp-country-card partdetailEU" data-code="NL"
                        data-country="Netherlands" data-price="700" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/nl.png" alt="">
                                <p class="country-name">Netherlands</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$700.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="OA" class="isp-country-card partdetailOA" data-code="AU"
                        data-country="Australia" data-price="700" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/au.png" alt="">
                                <p class="country-name">Australia</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$700.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AM" class="isp-country-card partdetailAM" data-code="BR"
                        data-country="Brazil" data-price="700" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/br.png" alt="">
                                <p class="country-name">Brazil</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$700.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AM" class="isp-country-card partdetailAM" data-code="CA"
                        data-country="Canada" data-price="700" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/ca.png" alt="">
                                <p class="country-name">Canada</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$700.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="EU" class="isp-country-card partdetailEU" data-code="GB"
                        data-country="United Kingdom" data-price="700" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/gb.png" alt="">
                                <p class="country-name">United Kingdom</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$700.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="EU" class="isp-country-card partdetailEU" data-code="FR"
                        data-country="France" data-price="700" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/fr.png" alt="">
                                <p class="country-name">France</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$700.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="EU" class="isp-country-card partdetailEU" data-code="DE"
                        data-country="Germany" data-price="700" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/de.png" alt="">
                                <p class="country-name">Germany</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$700.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="JP"
                        data-country="Japan" data-price="750" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/jp.png" alt="">
                                <p class="country-name">Japan</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$750.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="EU" class="isp-country-card partdetailEU" data-code="IT"
                        data-country="Italy" data-price="750" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/it.png" alt="">
                                <p class="country-name">Italy</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$750.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="ID"
                        data-country="Indonesia" data-price="800" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/id.png" alt="">
                                <p class="country-name">Indonesia</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$800.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="IN2"
                        data-country="India" data-price="800" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/in.png" alt="">
                                <p class="country-name">India</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$800.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="HK2"
                        data-country="Hong Kong" data-price="850" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/hk2.png" alt="">
                                <p class="country-name">Hong Kong</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$850.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="VN"
                        data-country="Vietnam" data-price="850" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/vn.png" alt="">
                                <p class="country-name">Vietnam</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$850.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="AE"
                        data-country="Dubai" data-price="900" data-day="30"
                        data-bandwidth="50">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/ae.png" alt="">
                                <p class="country-name">Dubai</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>50 Mbps</span>
                            <p>$900.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="TW"
                        data-country="Taiwan,CN" data-price="950" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/tw.png" alt="">
                                <p class="country-name">Taiwan,CN</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$950.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="PH"
                        data-country="Philippines" data-price="950" data-day="30"
                        data-bandwidth="50">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/ph.png" alt="">
                                <p class="country-name">Philippines</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>50 Mbps</span>
                            <p>$950.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="MY2"
                        data-country="Malaysia" data-price="950" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/my.png" alt="">
                                <p class="country-name">Malaysia</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$950.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="TH"
                        data-country="Thailand" data-price="950" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/th.png" alt="">
                                <p class="country-name">Thailand</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$950.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AM" class="isp-country-card partdetailAM" data-code="MX"
                        data-country="Mexico" data-price="1000" data-day="30"
                        data-bandwidth="50">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/mx.png" alt="">
                                <p class="country-name">Mexico</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>50 Mbps</span>
                            <p>$1000.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="KR"
                        data-country="Korea" data-price="1100" data-day="30"
                        data-bandwidth="50">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/kr.png" alt="">
                                <p class="country-name">Korea</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>50 Mbps</span>
                            <p>$1100.00/mo</p>
                        </div>
                    </div>
                    
                    <div data-cateid="AS" class="isp-country-card partdetailAS" data-code="SG2"
                        data-country="Singapore" data-price="1100" data-day="30"
                        data-bandwidth="100">
                        <div class="isp-country-top">
                            <div class="isp-country-info">
                                <img src="https://img.linkstatic.com/country/logo/sg.png" alt="">
                                <p class="country-name">Singapore</p>
                            </div>
                            
                        </div>
                        <div class="isp-country-bottom">
                            <span>100 Mbps</span>
                            <p>$1100.00/mo</p>
                        </div>
                    </div>
                    
                </div>
            </div>
            
            <aside class="isp-pricing-right">
                <div class="isp-order-card">
                    <h2>Order Summary <span
                            class="clear-all">Clear</span></h2>
                    <div class="isp-order-summary">
                        <div class="no-data">
                            <img src="/static/common/package/img/high_nodata.png" alt="">

                            <p class="no-data-subtitle">
                                Please select a region to purchase
                            </p>
                        </div>
                    </div>

                    <div class="isp-order-row isp-order-discount ">
                        <span>Discount</span>
                        <strong>-$0.00</strong>
                    </div>
                    <div class="isp-order-total">
                        <span>Total Price</span>
                        <strong class="total-price">$ 0.00</strong>
                    </div>
                    <button class="isp-order-btn" type="button">Buy Now</button>
                    <div class="isp-order-note">
                        <img src="/static/common/package/img/isp_subnet/customer_icon.png" alt="">
                        <p>Delivery will be completed within one week after purchase. Please contact <span
                                class="online-chat">Customer Manager</span> for details.
                        </p>
                    </div>
                </div>
            </aside>
        </div>
    </section>


    <section class="pricing-intruct-container">
        <h2>LinkStatic Premium Subnet Line Helps You Scale Faster</h2>
        <div>
            <img src="/static/common/package/img/isp_subnet/business01.png" alt="">
            <div>
                <h3>Premium Native IP Ranges for Enterprise Networks</h3>
                <p>Dedicated native C-class IP ranges provide enterprises with independent network resources for large-scale overseas operations. Complete IP ranges, no traffic or concurrency limits, and support for simultaneous multi-task operations.</p>
            </div>
        </div>
        <div>
            <div>
                <h3>Dedicated Full C-Class IP Range</h3>
                <p>Complete IP ranges are exclusively allocated for flexible IP management, eliminating the need for fragmented purchases and improving operational efficiency.</p>
            </div>
            <img src="/static/common/package/img/isp_subnet/business02.png" alt="">
        </div>
        <div>
            <img src="/static/common/package/img/isp_subnet/business03.png" alt="">
            <div>
                <h3>Global Native IP Ranges</h3>
                <p>Clean native IP resources across key global regions support localized operations, regional campaigns, and large-scale business deployment.</p>
            </div>
        </div>
        <div>
            <div>
                <h3>Isolated Dedicated Network</h3>
                <p>Dedicated IP ranges minimize cross-business interference and provide a secure, independent network environment for enterprise operations.</p>
            </div>
            <img src="/static/common/package/img/isp_subnet/business04.png" alt="">
        </div>


    </section>

    <div class="bottom-container">

        <div class="faq-container">
            <div>
                <h2>FAQ</h2>

                <div class="faq-list">
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Do you offer free trials or refunds?</span>
                            <i></i>
                        </div>
                        <div class="faq-answer">
                            We offer free trials for some plans. You can contact customer service to claim a trial for free. All paid services are non-refundable unless there is an IP quality issue. If you think our proxy service is not working properly, contact customer service directly or reach us via the official email on the website.
                        </div>
                    </div>
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Which protocols are supported?</span>
                            <i></i>
                        </div>
                        <div class="faq-answer">We support HTTP, HTTPS, and SOCKS5. If you need other protocols, please consult customer service.</div>
                    </div>
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Why does the IP I extract not match the region I purchased?</span>
                            <i></i>
                        </div>
                        <div class="faq-answer">When you check IPs on some websites, the detected region may differ from the region you purchased. Different data sources, processing algorithms, and update frequencies can affect detection. We use IPinfo results as the reference. If the results still do not match, contact our customer service.</div>
                    </div>
                </div>
            </div>

        </div>


    </div>
</div>
<script>
    let noDataSubtitle = 'Please select a region to purchase';
</script>
<script type="text/javascript" src="/static/common/package/js/isp_subnet.js?v="></script>


<link rel="stylesheet" href="/static/common/index/css/pay.min.css">

<div class="pay-modal-mask" style="display:none;">
    <div class="pay-container">
        <span class="pay-close" id="payClose">&times;</span>
        <div class="pay-content">
            <div class="pay-left">
                <div class="pay-left-title">
                    Payment methods
                </div>

                <div class="pay-left-subtitle">
                    Please select your payment method. If payment fails, please close the agent.
                </div>

                <div class="pay-type-list">
                    <div class="pay-type-item active" id="alipay" data-value="alipay">
                        <img src="/static/common/index/img/pay/alipay.png" alt="linkStatic">
                        <p class="type-name">
                            Alipay
                        </p>
                    </div>
                    <div class="pay-type-item active pay-type-hide" id="alipay2" data-value="alipay2">
                        <img src="/static/common/index/img/pay/alipay.png" alt="linkStatic">
                        <p class="type-name">
                            Alipay2
                        </p>
                    </div>
                    <div class="pay-type-item" id="cryptocurrency" data-value="coin">
                        <img src="/static/common/index/img/pay/cryptocurrency.png" alt="linkStatic">
                        <p class="type-name">
                            Cryptocurrency
                        </p>
                    </div>
                    
                    <div class="pay-type-item" id="balance" data-value="balance">
                        <img src="/static/common/index/img/pay/wallet.png" alt="linkStatic">
                        <p class="type-name">
                            Balance
                        </p>

                        <p class="balance-value" id="balanceValue">
                            （$0.00）
                        </p>
                    </div>
                </div>

                <p class="pay-category-title">
                    Payment categories
                </p>

                <div class="encryption-category" id="encryptionCategoryList">
                </div>

                

                <div class="discounts-box">
                    <p class="discounts-title">
                        Select coupon
                    </p>

                    <div class="discounts-type">
                        <div style="display: flex;gap: 10px;">
                            <input type="radio" id="code" name="code" value="code" checked>
                            <label for="code">Coupon Code</label>
                        </div>
                        <div style="display: flex;gap: 10px;">
                            <input type="radio" id="coupon" name="code" value="coupon">
                            <label for="coupon">Coupon</label>
                        </div>
                    </div>

                    <div class="coupon-container-type">
                        <div class="coupon-input-area">
                            <input type="text" id="couponCode" class="coupon-input"
                                placeholder="Enter coupon code">
                            <button type="button" id="confirmBtn"
                                class="confirm-btn">Use</button>
                        </div>

                        <div class="coupon-select" style="display:none;">
                            <div class="select-header">
                                <span class="selected-text">Select coupon</span>
                                <img src="./public/images/coupon-select.png" alt="">
                            </div>

                            <div class="select-options" id="couponSelectOptions">
                            </div>
                        </div>
                    </div>

                    <p class="coupon-tips" style="display:none;"></p>
                </div>
            </div>

            <div class="pay-right">
                <p class="pay-right-title">
                    Payment details
                </p>

                <div class="pay-right-content">
                    <div class="order-info-item">
                        <span class="order-lable">
                            Order No.
                        </span>

                        <span class="order-value" id="orderSnLabel">
                            --
                        </span>
                    </div>

                    <div class="order-info-item">
                        <span class="order-lable">
                            Type
                        </span>

                        <span class="order-value" id="orderTypeLabel">
                            --
                        </span>
                    </div>

                    <div class="order-info-item">
                        <span class="order-lable">
                            Unit Price
                        </span>

                        <div class="order-value info-value-price" id="orderSubItems">
                        </div>
                    </div>

                    <div class="order-info-item">
                        <span class="order-lable">
                            Quantity
                        </span>

                        <span class="order-value">
                            <div class="quantity-country" id="orderQuantity">
                            </div>
                        </span>
                    </div>

                    <div class="order-info-item">
                        <span class="order-lable">
                            Time
                        </span>

                        <span class="order-value" id="orderCreateTime">
                            --
                        </span>
                    </div>

                    <div class="division-line"></div>

                    
                    <div id="couponDiscount" style="display: none;">
                        <div class="order-info-item">
                            <span class="order-lable">Discount</span>
                            <span class="order-value val" style="color: #ff4d4f;"></span>
                        </div>
                    </div>
                    
                    <div id="couponGive" style="display: none;" data-unit="IP">
                        <div class="order-info-item">
                            <span class="order-lable">Giveaway</span>
                            <span class="order-value val" style="color: #52c41a;"></span>
                        </div>
                    </div>

                    <div class="order-info-item">
                        <span class="order-lable">
                            Total Payment
                        </span>

                        <span class="order-value" id="finalPayment">
                            $10.00
                        </span>
                    </div>

                    <button class="order-confirm-btn" id="OrderNow">Confirm Payment <span
                            id="countdown"></span></button>

                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal-mask" id="cryptoModalMask" style="display:none;">
    <div class="crypto-container">
        <h2 id="coinTitle"><img src="" alt=""> <span></span></h2>
        <i class="close"></i>
        <div class="code">
            <div>
                <div>
                    <p>Receive Address</p>
                    <p>
                        <span id="address"></span>
                        <i data-txt="" id="copy1"></i>
                    </p>
                </div>
                <div>
                    <p>Amount</p>
                    <p>
                        <span id="amount"></span>
                        <i data-txt="" id="copy2"></i>
                    </p>
                </div>
            </div>
            <p>
                <img id="addressQrcode" src="" alt="">
            </p>
            <div class="tips"></div>
        </div>
    </div>
</div>

<script src="/static/common/index/js/pay.js"></script>


<div class="modal-mask" id="payResultModal" style="display:none;" data-order-sn="">
    <div class="result-container" id="payResultContainer">
        <span class="result-close">&times;</span>
        <div class="result-header">
            <div class="result-logo">
                <img src="/static/common/index/img/pay/static_logo.png" alt="">
            </div>
            <div class="result-title">Payment Result</div>
        </div>

        <div class="result-status-section">
            <div class="result-status-icon">
                <img class="result-success-icon" src="/static/common/index/img/pay/pay_success.png" alt="">
                <img class="result-fail-icon" src="/static/common/index/img/pay/pay_error.png" alt="">
            </div>
            <div class="result-status-text" id="resultStatusText">Payment successful</div>
        </div>

        <div class="result-divider"></div>

        <div class="result-info-section">
            <div class="result-info-row">
                <div class="result-info-label">Order No.</div>
                <div class="result-info-value" id="resultOrderNo">--</div>
            </div>
            <div class="result-info-row">
                <div class="result-info-label">Order Name</div>
                <div class="result-info-value" id="resultOrderName">--</div>
            </div>
            <div class="result-info-row">
                <div class="result-info-label">Order Time</div>
                <div class="result-info-value" id="resultCreateTime">--</div>
            </div>
            <div class="result-info-row">
                <div class="result-info-label">Payment Time</div>
                <div class="result-info-value" id="resultPayTime">--</div>
            </div>
            <div class="result-info-row result-total-row">
                <div class="result-total-label">Total</div>
                <div class="result-total-value-wrap">
                    <div class="result-total-value" id="resultTotalMoney">--</div>
                </div>
            </div>
        </div>

        <div class="result-dashed-divider"></div>

        <div class="result-action-section result-success-btn" id="resultSuccessBtn">
            <a id="resultInvoiceUrl" class="result-btn result-btn-outline" href="#"
                target="_blank">Download Receipt</a>
            <a id="resultDashboardUrl" class="result-btn result-btn-primary" href="#"
                target="_blank">Enter Dashboard</a>
        </div>
        <div class="result-action-section result-fail-btn" id="resultFailBtn">
            <a class="result-btn result-btn-primary" href="javascript:void(0)">Back to Plans</a>
        </div>
    </div>
</div>

<div class="footer-desktop">
    
<footer class="footer">
    <div class="footer-inner">
        <div class="footer-horizontal">
            <div class="footer-left">
                <div class="footer-logo">
                    <a style="display: inline-block;" href="/en/">
                        <img src="/static/img/link_logo_white.png" alt="">
                    </a>
                </div>
                <div class="contact">
                    <h3>Contact us</h3>
                    <p class="email-text" onclick="copyText('support@linkstatic.com')">
                        <img src="/static/common/footer/img/femail.png" alt="">
                        Emai: <span >support@linkstatic.com</span> 
                    </p>
                    <p>
                        
                </div>
            </div>

            <div class="footer-middle">
                <div class="footer-column">
                    <p class="category-title">Pricing</p>
                    <ul>
                        <li><a href="/en/pricing/isp-proxy/">Static ISP</a></li>
                        <li><a href="/en/pricing/isp-enterprise/">Enterprise ISP Proxies</a></li>
                        <li><a href="/en/pricing/isp-tiktok/">TikTok  Live Streaming Line</a></li>
                        <li><a href="/en/pricing/isp-subnet/">Whole C segment native IP</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <p class="category-title">Resource</p>
                    <ul>
                        <li><a href="/en/partner/">Partners</a></li>
                        <li><a href="/en/live-stream-land/">Live broadcast line</a></li>
                        <li><a href="/en/global-resources">Global Resources</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <p class="category-title">Use Cases</p>
                    <ul>
                        <li><a href="/en/case/social-media">Social Media Matrix</a></li>
                        <li><a href="/en/case/temu">Temu Proxy</a></li>
                        <li><a href="/en/case/shopee">Shopee Proxy</a></li>
                        <li><a href="/en/case/ai">AI Software Usage</a></li>
                        <li><a href="/en/case/store-operations">Store Operations</a></li>
                        <li><a href="/en/case/tiktok">TikTok Live Streaming</a></li>
                        <li><a href="/en/case/accounts">Multi-account Management</a></li>
                    </ul>

                </div>
                <div class="footer-column">
                    <p class="category-title">Popular Regions</p>
                    <ul class="footer-country">
                        <li>
                            <a href="/en/topic/us"><img src="/static/common/footer/img/us.png" alt=""></a>
                            <a href="/en/topic/uk"><img src="/static/common/footer/img/end.png" alt=""></a>
                            <a href="/en/topic/sg"><img src="/static/common/footer/img/sg.png" alt=""></a>
                            
                        </li>
                        <li>
                            <a href="/en/topic/fr"><img src="/static/common/footer/img/fr.png" alt=""></a>
                            <a href="/en/topic/jp"><img src="/static/common/footer/img/jp.png" alt=""></a>
                            <a href="/en/topic/hk"><img src="/static/common/footer/img/hk.png" alt=""></a>
                            
                        </li>
                        <li>
                            <a href="/en/topic/ca"><img src="/static/common/footer/img/ca.png" alt=""></a>
                            <a href="/en/topic/kr"><img src="/static/common/footer/img/kr.png" alt=""></a>
                            <a href="/en/topic/tw"><img src="/static/common/footer/img/tw.png" alt=""></a>
                        </li>
                        <li>
                            <a href="/en/topic/de"><img src="/static/common/footer/img/de.png" alt=""></a>
                            <a href="/en/topic/au"><img src="/static/common/footer/img/aus.png" alt=""></a>
                            <a href="/en/topic/th"><img src="/static/common/footer/img/th.png" alt=""></a>
                        </li>
                       
                    </ul>
                    

                </div>
                
            </div>

            <div class="footer-right">
                <p class="category-title">Legal Terms</p>
                <ul>
                    <li><a href="/en/terms/">Terms of Service</a></li>
                    <li><a href="/en/privacy/">Privacy Policy</a></li>
                    <li><a href="/en/refund/">Refund policy</a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="footer-tip" style="padding-bottom: 28px;">
        <p class="copyright">RM P11, FLAT 2C, 2/F, HUNG TO CTR., 94-96 HOW MING ST.,KWUN TONG HONG KONG© 2026  LINKSTATIC.LTD</p>
        <p style="margin-top: 4px;">Due to policy reasons, the proxy service of this website is not available for use in the Chinese mainland</p>
    </div>
</footer>

</div>
<div class="footer-mobile">
    
<link rel="stylesheet" href="/static/common/footer/css/m_footer.min.css">
<footer class="m-footer">
    <div class="m-footer-logo">
        <a href="/en/"><img src="/static/img/link_logo_white.png" alt="Linkstatic"></a>
    </div>
    
    <p class="m-footer-email">
        <img src="/static/common/footer/img/meamil.png" alt="">
        <span>support@linkstatic.com</span>
    </p>
    <p class="m-footer-email">
        <img src="/static/common/footer/img/m-tg.png" alt="">
        <a href="https://telegram.me/LinkStaticSupport" target="_blank">https://telegram.me/LinkStaticSupport</a>
    </p>
    <div class="m-footer-divider"></div>
    <p class="m-footer-notice">Due to policy reasons, the proxy service of this website is not available for use in the Chinese mainland</p>
    <p class="m-footer-copyright">RM P11, FLAT 2C, 2/F, HUNG TO CTR., 94-96 HOW MING ST.,KWUN TONG HONG KONG© 2026  LINKSTATIC.LTD</p>
</footer>

</div>
<style>
    .footer-desktop {
        display: block;
    }
    .footer-mobile {
        display: none;
    }
    @media (max-width: 960px) {
        .footer-desktop {
            display: none;
        }
        .footer-mobile {
            display: block;
        }
         
        .footer-mobile .m-footer {
            display: block;
        }
    }
</style>
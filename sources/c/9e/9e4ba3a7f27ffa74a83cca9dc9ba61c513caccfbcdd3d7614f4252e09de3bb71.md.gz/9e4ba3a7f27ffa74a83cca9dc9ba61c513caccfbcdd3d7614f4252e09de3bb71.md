![ph24 status](blob:https://status.ph24.io/4d47a16c-a2a2-4270-a440-51692cd304ea)

[ph24](https://ph24.io/)

Keep track of planned events and incidents that affect ph24 services.

All Resources are Operational

WebOperational

Frontend ProHosting24

97.55% uptime

Backend ProHosting24

100% uptime

Frontend ph24

100% uptime

90 days ago

Today

ServicesOperational

Cloud API eu-central

100% uptime

KVM FRA1

100% uptime

Backup FRA1

98.9% uptime

Web Hosting

88% uptime

E-Mail Hosting

88% uptime

Domains

100% uptime

90 days ago

Today

InfrastructureOperational

Datacenter FRA1

100% uptime

Network FRA1

100% uptime

90 days ago

Today
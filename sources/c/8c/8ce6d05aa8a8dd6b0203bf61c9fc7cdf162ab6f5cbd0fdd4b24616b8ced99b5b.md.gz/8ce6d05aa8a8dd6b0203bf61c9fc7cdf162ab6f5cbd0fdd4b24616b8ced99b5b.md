##### What is your proxies location?

Our proxies are located in **Europe** (Italy).

##### Can I get a test?

We do offer 72-hours trials at 9.90€ from [this page](https://airproxy.io/en/accounts/profile/purchase/trial/) after having created an account.

##### Can I change my mind and get a refund?

We can and will refund the first payment for your account in full up to 48 hours from the payment should you not be satisfied or find the proxy to be not compatible with your use case or software.

##### How can I rotate the proxy IP?

All proxies can rotate the IP at a custom interval (e.g.: every 15-60 minutes), at specific times (e.g.: every day at 08:00 and 14:30 UTC) or by clicking the "change IP" button.  
An API which lets you change the IP each time you load a special link is also available.

##### Which payment methods do you accept?

We accept Credit/Debit Cards (instant and automatic delivery).  
Crypto payments are enabled automatically after the first non-crypto payment of your account.  
Wire Transfers are also accepted, but require a manual delivery.

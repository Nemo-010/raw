## Gemini platform pricing

Prices are listed in US Dollars (USD). If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

## Gemini platform pricing compared to legacy product pricing

The costs for Gemini platform remain the same as they are for the legacy AI Platform and AutoML products that Gemini platform supersedes, with the following exceptions:

- Legacy Inference in Gemini platform and AutoML Tables predictions supported lower-cost, lower-performance machine types that aren't supported for Inference in Gemini platform and AutoML tabular.
- Legacy Inference in Gemini platform supported [scale-to-zero](https://cloud.google.com/ai-platform/prediction/docs/machine-types-online-prediction#automatic_scaling), which isn't supported for Inference in Gemini platform.

Gemini platform also offers more ways to optimize costs, such as the following:

- [Optimized TensorFlow runtime](https://cloud.google.com/blog/topics/developers-practitioners/speed-model-inference-vertex-ai-predictions-optimized-tensorflow-runtime).
- Support for [co-hosting models](https://cloud.google.com/vertex-ai/docs/predictions/model-co-hosting).
- No minimum usage duration for Training and Prediction. Instead, usage is charged in 30 second increments.

## Pricing for Generative AI in Gemini platform

For Generative AI in Gemini platform pricing information, see [Pricing for Generative AI in Gemini platform](https://cloud.google.com/gemini-enterprise-agent-platform/generative-ai/pricing).

## Pricing for AutoML models

For AutoML models in Gemini platform, you pay for three main activities:

- Training the model
- Deploying the model to an endpoint
- Using the model to make predictions

Gemini platform uses predefined machine configurations for AutoML models in Gemini platform, and the hourly rate for these activities reflects the resource usage.

The time required to train your model depends on the size and complexity of your training data. Models must be deployed before they can provide online predictions or online explanations.

You pay for each model deployed to an endpoint, even if no prediction is made. You must undeploy your model to stop incurring further charges. Models that are not deployed or have failed to deploy are not charged.

You pay only for compute hours used; if training fails for any reason other than a user-initiated cancellation, you are not billed for the time. You are charged for training time if you cancel the operation.

Select a model type below for pricing information.

### Image data

Show discount options

HourlyHourly

MonthlyMonthly

| Operation | Price (classification) (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 | Price (object detection) (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| Training | $3.465 / 1 hour | $3.1185 / 1 hour | $2.772 / 1 hour | $3.465 / 1 hour | $3.1185 / 1 hour | $2.772 / 1 hour |
| Training (Edge on-device model) | $18.00 / 1 hour | $16.20 / 1 hour | $14.40 / 1 hour | $18.00 / 1 hour | $16.20 / 1 hour | $14.40 / 1 hour |
| Deployment and online prediction | $1.375 / 1 hour | $1.2375 / 1 hour | $1.10 / 1 hour | $2.002 / 1 hour | $1.8018 / 1 hour | $1.6016 / 1 hour |
| Batch prediction | $2.222 / 1 hour | $1.9998 / 1 hour | $1.7776 / 1 hour | $2.222 / 1 hour | $1.9998 / 1 hour | $1.7776 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### Tabular data

Show discount options

HourlyHourly

MonthlyMonthly

| Operation | Price per node hour for classification/regression<br>\* (USD)_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 | Price for forecasting |
| Training | $21.252 / 1 hour | $19.1268 / 1 hour | $17.0016 / 1 hour | Refer to [Forecasting in Gemini platform](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#forecasting-on-agent-platform) |
| Inference | Same price as [inference for custom-trained models](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#prediction-and-explanation).<br>Gemini platform performs batch inference using 40 n1-highmem-8 machines. | Refer to [Forecasting in Gemini platform](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#forecasting-on-agent-platform) |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

**Inference charges for Explainable AI in Gemini platform**

Compute associated with Explainable AI in Gemini platform is charged at same rate as inference. However, explanations take longer to process than normal inferences, so heavy usage of Explainable AI in Gemini platform along with auto-scaling could result in more nodes being started, which would increase inference charges.

## Forecasting in Gemini platform

### AutoML

Show discount options

HourlyHourly

MonthlyMonthly

| Stage | Pricing<br>\* (USD)_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| Prediction | 0 count to 1,000,000 count<br>$0.20 / 1,000 count, per 1 month / account<br>1,000,000 count to 50,000,000 count<br>$0.10 / 1,000 count, per 1 month / account<br>50,000,000 count and above<br>$0.02 / 1,000 count, per 1 month / account | 0 count to 1,000,000 count<br>$0.18 / 1,000 count, per 1 month / account<br>1,000,000 count to 50,000,000 count<br>$0.09 / 1,000 count, per 1 month / account<br>50,000,000 count and above<br>$0.018 / 1,000 count, per 1 month / account | 0 count to 1,000,000 count<br>$0.16 / 1,000 count, per 1 month / account<br>1,000,000 count to 50,000,000 count<br>$0.08 / 1,000 count, per 1 month / account<br>50,000,000 count and above<br>$0.016 / 1,000 count, per 1 month / account |
| Training | $21.252 / 1 hour | $19.1268 / 1 hour | $17.0016 / 1 hour |
| Explainable AI | Explainability using Shapley values. Refer to [Inference and Explanation in Gemini platform](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#prediction-and-explanation) pricing page. | - | - |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

\\* A prediction data point is one time point in the forecast horizon. For example, with daily granularity a 7-day horizon is 7 points per each time series.

- Up to 5 prediction quantiles can be included at no additional cost.
- The number of data points consumed per tier is refreshed monthly.

### ARIMA+

Show discount options

| Stage | Pricing<br>\* (USD)_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| Prediction | $5.00 / 1,000 count | $4.50 / 1,000 count | $4.00 / 1,000 count |
| Training | [$250.00 per TB](https://cloud.google.com/bigquery/pricing#bigquery-ml-pricing) x Number of Candidate Models x Number of Backtesting Windows\* | - | - |
| Explainable AI | Explainability with time series decomposition does not add any additional cost. Explainability using Shapley values is not supported. | - | - |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

Refer to the [BigQuery ML pricing page](https://cloud.google.com/bigquery/pricing#bigquery-ml-pricing) for additional details. Each training and prediction job incurs the cost of 1 managed pipeline run, as described in [Gemini platform pricing](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#pipelines).

\\* A backtesting window is created for each period in the test set. The AUTO\_ARIMA\_MAX\_ORDER used determines the number of candidate models. It ranges from 6-42 for models with multiple time series.

## Custom-trained models

### Training

The tables below provide the approximate _price per hour_ of various training configurations. You can choose a custom configuration of selected [machine types](https://cloud.google.com/vertex-ai/docs/training/configure-compute). To calculate pricing, sum the costs of the virtual machines you use.

If you use Compute Engine machine types and attach accelerators, the cost of the accelerators is separate. To calculate this cost, multiply the prices in the table of accelerators below by how many machine hours of each type of accelerator you use.

### Machine types

You can use Spot VMs with custom training in Gemini platform. [Spot VMs](https://cloud.google.com/compute/docs/instances/spot) are billed according to [Compute Engine Spot VMs pricing](https://cloud.google.com/spot-vms/pricing). There are custom training in Gemini platform management fees in addition to your infrastructure usage, captured in the following tables.

You can use Compute Engine reservations with custom training in Gemini platform. When using Compute Engine reservations, you're billed according to [Compute Engine Pricing](https://cloud.google.com/compute/all-pricing), including any applicable committed use discounts (CUDs). There are custom training in Gemini platform management fees in addition to your infrastructure usage, captured in the following tables.

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Bangkok (asia-southeast3)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Stockholm (europe-north2)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Berlin (europe-west10)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Galaxy Frankfurt (europe-west5)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Mexico (northamerica-south1)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Alabama (us-east7)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)
- Phoenix (us-west8)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| g4-standard-48 | $5.1749195 / 1 hour | $4.65742755 / 1 hour | $4.1399356 / 1 hour |
| ﻿g4-standard-96 | $10.349839 / 1 hour | $9.3148551 / 1 hour | $8.2798712 / 1 hour |
| g4-standard-192 | $20.699678 / 1 hour | $18.6297102 / 1 hour | $16.5597424 / 1 hour |
| g4-standard-384 | $41.399356 / 1 hour | $37.2594204 / 1 hour | $33.1194848 / 1 hour |
| n1-standard-4 | $0.21849885 / 1 hour | $0.196648965 / 1 hour | $0.17479908 / 1 hour |
| n1-standard-8 | $0.4369977 / 1 hour | $0.39329793 / 1 hour | $0.34959816 / 1 hour |
| n1-standard-16 | $0.8739954 / 1 hour | $0.78659586 / 1 hour | $0.69919632 / 1 hour |
| n1-standard-32 | $1.7479908 / 1 hour | $1.57319172 / 1 hour | $1.39839264 / 1 hour |
| n1-standard-64 | $3.4959816 / 1 hour | $3.14638344 / 1 hour | $2.79678528 / 1 hour |
| n1-standard-96 | $5.2439724 / 1 hour | $4.71957516 / 1 hour | $4.19517792 / 1 hour |
| n1-highmem-2 | $0.13604845 / 1 hour | $0.122443605 / 1 hour | $0.10883876 / 1 hour |
| n1-highmem-4 | $0.2720969 / 1 hour | $0.24488721 / 1 hour | $0.21767752 / 1 hour |
| n1-highmem-8 | $0.5441938 / 1 hour | $0.48977442 / 1 hour | $0.43535504 / 1 hour |
| n1-highmem-16 | $1.0883876 / 1 hour | $0.97954884 / 1 hour | $0.87071008 / 1 hour |
| n1-highmem-32 | $2.1767752 / 1 hour | $1.95909768 / 1 hour | $1.74142016 / 1 hour |
| n1-highmem-64 | $4.3535504 / 1 hour | $3.91819536 / 1 hour | $3.48284032 / 1 hour |
| n1-highmem-96 | $6.5303256 / 1 hour | $5.87729304 / 1 hour | $5.22426048 / 1 hour |
| n1-highcpu-16 | $0.65180712 / 1 hour | $0.586626408 / 1 hour | $0.521445696 / 1 hour |
| n1-highcpu-32 | $1.30361424 / 1 hour | $1.173252816 / 1 hour | $1.042891392 / 1 hour |
| n1-highcpu-64 | $2.60722848 / 1 hour | $2.346505632 / 1 hour | $2.085782784 / 1 hour |
| n1-highcpu-96 | $3.91084272 / 1 hour | $3.519758448 / 1 hour | $3.128674176 / 1 hour |
| a2-highgpu-1g\* | $4.425248914 / 1 hour | $3.982724023 / 1 hour | $3.540199132 / 1 hour |
| a2-highgpu-2g\* | $8.850497829 / 1 hour | $7.965448046 / 1 hour | $7.080398263 / 1 hour |
| a2-highgpu-4g\* | $17.700995658 / 1 hour | $15.930896092 / 1 hour | $14.160796526 / 1 hour |
| a2-highgpu-8g\* | $35.401991315 / 1 hour | $31.861792184 / 1 hour | $28.321593052 / 1 hour |
| a2-megagpu-16g\* | $65.707278915 / 1 hour | $59.136551024 / 1 hour | $52.565823132 / 1 hour |
| a3-highgpu-8g\* | $101.007352832 / 1 hour | $90.906617632 / 1 hour | $80.805882432 / 1 hour |
| a3-megagpu-8g\* | $106.046424032 / 1 hour | $95.441781712 / 1 hour | $84.837139392 / 1 hour |
| a3-ultragpu-8g\* | $99.773930496 / 1 hour | $89.796537536 / 1 hour | $79.819144576 / 1 hour |
| a4-highgpu-8g\* | $148.212 / 1 hour | $133.3908 / 1 hour | $118.5696 / 1 hour |
| e2-standard-4 | $0.154126276 / 1 hour | $0.138713648 / 1 hour | $0.12330102 / 1 hour |
| e2-standard-8 | $0.308252552 / 1 hour | $0.277427296 / 1 hour | $0.24660204 / 1 hour |
| e2-standard-16 | $0.616505104 / 1 hour | $0.554854592 / 1 hour | $0.49320408 / 1 hour |
| e2-standard-32 | $1.233010208 / 1 hour | $1.109709184 / 1 hour | $0.98640816 / 1 hour |
| e2-highmem-2 | $0.103959618 / 1 hour | $0.093563656 / 1 hour | $0.083167694 / 1 hour |
| e2-highmem-4 | $0.207919236 / 1 hour | $0.187127312 / 1 hour | $0.166335388 / 1 hour |
| e2-highmem-8 | $0.415838472 / 1 hour | $0.374254624 / 1 hour | $0.332670776 / 1 hour |
| e2-highmem-16 | $0.831676944 / 1 hour | $0.748509248 / 1 hour | $0.665341552 / 1 hour |
| e2-highcpu-16 | $0.455126224 / 1 hour | $0.4096136 / 1 hour | $0.364100976 / 1 hour |
| e2-highcpu-32 | $0.910252448 / 1 hour | $0.8192272 / 1 hour | $0.728201952 / 1 hour |
| n2-standard-4 | $0.2233714 / 1 hour | $0.20103426 / 1 hour | $0.17869712 / 1 hour |
| n2-standard-8 | $0.4467428 / 1 hour | $0.40206852 / 1 hour | $0.35739424 / 1 hour |
| n2-standard-16 | $0.8934856 / 1 hour | $0.80413704 / 1 hour | $0.71478848 / 1 hour |
| n2-standard-32 | $1.7869712 / 1 hour | $1.60827408 / 1 hour | $1.42957696 / 1 hour |
| n2-standard-48 | $2.6804568 / 1 hour | $2.41241112 / 1 hour | $2.14436544 / 1 hour |
| n2-standard-64 | $3.5739424 / 1 hour | $3.21654816 / 1 hour | $2.85915392 / 1 hour |
| n2-standard-80 | $4.467428 / 1 hour | $4.0206852 / 1 hour | $3.5739424 / 1 hour |
| n2-highmem-2 | $0.1506661 / 1 hour | $0.13559949 / 1 hour | $0.12053288 / 1 hour |
| n2-highmem-4 | $0.3013322 / 1 hour | $0.27119898 / 1 hour | $0.24106576 / 1 hour |
| cloud-tpu | Pricing is determined by the accelerator type. See 'Accelerators'. | - | - |
| n2-highmem-8 | $0.6026644 / 1 hour | $0.54239796 / 1 hour | $0.48213152 / 1 hour |
| n2-highmem-16 | $1.2053288 / 1 hour | $1.08479592 / 1 hour | $0.96426304 / 1 hour |
| n2-highmem-32 | $2.4106576 / 1 hour | $2.16959184 / 1 hour | $1.92852608 / 1 hour |
| n2-highmem-48 | $3.6159864 / 1 hour | $3.25438776 / 1 hour | $2.89278912 / 1 hour |
| n2-highmem-64 | $4.8213152 / 1 hour | $4.33918368 / 1 hour | $3.85705216 / 1 hour |
| n2-highmem-80 | $6.026644 / 1 hour | $5.4239796 / 1 hour | $4.8213152 / 1 hour |
| n2-highcpu-16 | $0.6596032 / 1 hour | $0.59364288 / 1 hour | $0.52768256 / 1 hour |
| n2-highcpu-32 | $1.3192064 / 1 hour | $1.18728576 / 1 hour | $1.05536512 / 1 hour |
| n2-highcpu-48 | $1.9788096 / 1 hour | $1.78092864 / 1 hour | $1.58304768 / 1 hour |
| n2-highcpu-64 | $2.6384128 / 1 hour | $2.37457152 / 1 hour | $2.11073024 / 1 hour |
| n2-highcpu-80 | $3.298016 / 1 hour | $2.9682144 / 1 hour | $2.6384128 / 1 hour |
| n4-standard-2 | $0.104305 / 1 hour | $0.0938745 / 1 hour | $0.083444 / 1 hour |
| n4-standard-4 | $0.20861 / 1 hour | $0.187749 / 1 hour | $0.166888 / 1 hour |
| n4-standard-8 | $0.41722 / 1 hour | $0.375498 / 1 hour | $0.333776 / 1 hour |
| n4-standard-16 | $0.83444 / 1 hour | $0.750996 / 1 hour | $0.667552 / 1 hour |
| n4-standard-32 | $1.66888 / 1 hour | $1.501992 / 1 hour | $1.335104 / 1 hour |
| n4-standard-48 | $2.50332 / 1 hour | $2.252988 / 1 hour | $2.002656 / 1 hour |
| n4-standard-64 | $3.33776 / 1 hour | $3.003984 / 1 hour | $2.670208 / 1 hour |
| n4-standard-80 | $4.1722 / 1 hour | $3.75498 / 1 hour | $3.33776 / 1 hour |
| n4-highcpu-2 | $0.088021 / 1 hour | $0.0792189 / 1 hour | $0.0704168 / 1 hour |
| n4-highcpu-4 | $0.176042 / 1 hour | $0.1584378 / 1 hour | $0.1408336 / 1 hour |
| n4-highcpu-8 | $0.352084 / 1 hour | $0.3168756 / 1 hour | $0.2816672 / 1 hour |
| n4-highcpu-16 | $0.704168 / 1 hour | $0.6337512 / 1 hour | $0.5633344 / 1 hour |
| n4-highcpu-32 | $1.408336 / 1 hour | $1.2675024 / 1 hour | $1.1266688 / 1 hour |
| n4-highcpu-48 | $2.112504 / 1 hour | $1.9012536 / 1 hour | $1.6900032 / 1 hour |
| n4-highcpu-64 | $2.816672 / 1 hour | $2.5350048 / 1 hour | $2.2533376 / 1 hour |
| n4-highcpu-80 | $3.52084 / 1 hour | $3.168756 / 1 hour | $2.816672 / 1 hour |
| n4-highmem-2 | $0.088021 / 1 hour | $0.0792189 / 1 hour | $0.0704168 / 1 hour |
| n4-highmem-4 | $0.273746 / 1 hour | $0.2463714 / 1 hour | $0.2189968 / 1 hour |
| n4-highmem-8 | $0.547492 / 1 hour | $0.4927428 / 1 hour | $0.4379936 / 1 hour |
| n4-highmem-16 | $1.094984 / 1 hour | $0.9854856 / 1 hour | $0.8759872 / 1 hour |
| n4-highmem-48 | $3.284952 / 1 hour | $2.9564568 / 1 hour | $2.6279616 / 1 hour |
| n4-highmem-64 | $4.379936 / 1 hour | $3.9419424 / 1 hour | $3.5039488 / 1 hour |
| n4-highmem-80 | $5.47492 / 1 hour | $4.927428 / 1 hour | $4.379936 / 1 hour |
| c2-standard-4 | $0.2401292 / 1 hour | $0.21611628 / 1 hour | $0.19210336 / 1 hour |
| c2-standard-8 | $0.4802584 / 1 hour | $0.43223256 / 1 hour | $0.38420672 / 1 hour |
| c2-standard-16 | $0.9605168 / 1 hour | $0.86446512 / 1 hour | $0.76841344 / 1 hour |
| c2-standard-30 | $1.800969 / 1 hour | $1.6208721 / 1 hour | $1.4407752 / 1 hour |
| c2-standard-60 | $3.601938 / 1 hour | $3.2417442 / 1 hour | $2.8815504 / 1 hour |
| m1-ultramem-40 | $7.237065 / 1 hour | $6.5133585 / 1 hour | $5.789652 / 1 hour |
| m1-ultramem-80 | $14.47413 / 1 hour | $13.026717 / 1 hour | $11.579304 / 1 hour |
| m1-ultramem-160 | $28.94826 / 1 hour | $26.053434 / 1 hour | $23.158608 / 1 hour |
| m1-megamem-96 | $12.249984 / 1 hour | $11.0249856 / 1 hour | $9.7999872 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

\*This amount includes GPU price, since this instance type always requires a fixed number of GPU accelerators.

If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

### Accelerators

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Berlin (europe-west10)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)
- Phoenix (us-west8)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 | Management Fee<br>\* (USD)_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| NVIDIA\_TESLA\_A100 | $2.933908 / 1 hour | - | - | $0.4400862 / 1 hour | $0.39607758 / 1 hour | $0.35206896 / 1 hour |
| NVIDIA\_TESLA\_A100\_80GB | $3.92808 / 1 hour | - | - | $0.589212 / 1 hour | $0.5302908 / 1 hour | $0.4713696 / 1 hour |
| NVIDIA\_H100\_80GB | $9.79655057 / 1 hour | - | - | $1.4694826 / 1 hour | $1.32253434 / 1 hour | $1.17558608 / 1 hour |
| NVIDIA\_H200\_141GB | $10.708501 / 1 hour | $9.6376509 / 1 hour | $8.5668008 / 1 hour | Unavailable | - | - |
| NVIDIA\_H100\_MEGA\_80GB | $11.8959171 / 1 hour | $10.70632539 / 1 hour | $9.51673368 / 1 hour | Unavailable | - | - |
| NVIDIA\_TESLA\_L4 | $0.644046276 / 1 hour | $0.579641648 / 1 hour | $0.515237021 / 1 hour | Unavailable | - | - |
| NVIDIA\_TESLA\_P4 | $0.69 / 1 hour | $0.621 / 1 hour | $0.552 / 1 hour | Unavailable | - | - |
| NVIDIA\_TESLA\_P100 | $1.679 / 1 hour | $1.5111 / 1 hour | $1.3432 / 1 hour | Unavailable | - | - |
| NVIDIA\_TESLA\_T4 | $0.4025 / 1 hour | $0.36225 / 1 hour | $0.322 / 1 hour | Unavailable | - | - |
| NVIDIA\_TESLA\_V100 | $2.852 / 1 hour | $2.5668 / 1 hour | $2.2816 / 1 hour | Unavailable | - | - |
| TPU\_V2 Single (8 cores) | $5.175 / 1 hour | $4.6575 / 1 hour | $4.14 / 1 hour | Unavailable | - | - |
| TPU\_V2 Pod (32 cores)\* | $27.60 / 1 hour | $24.84 / 1 hour | $22.08 / 1 hour | Unavailable | - | - |
| TPU\_V3 Single (8 cores) | $9.20 / 1 hour | $8.28 / 1 hour | $7.36 / 1 hour | Unavailable | - | - |
| TPU\_V3 Pod (32 cores)\* | $36.80 / 1 hour | $33.12 / 1 hour | $29.44 / 1 hour | Unavailable | - | - |
| tpu7x-standard-4t (1 chip) | $13.80 / 1 hour | $12.42 / 1 hour | $11.04 / 1 hour | Unavailable | - | - |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

\\* The price for training using a Cloud TPU Pod is based on the number of cores in the Pod. The number of cores in a pod is always a multiple of 32. To determine the price of training on a Pod that has more than 32 cores, take the price for a 32-core Pod, and multiply it by the number of cores, divided by 32. For example, for a 128-core Pod, the price is (32-core Pod price) \* (128/32). For information about which Cloud TPU Pods are available for a specific region, see [System Architecture](https://cloud.google.com/tpu/docs/system-architecture-tpu-vm) in the Cloud TPU documentation.

### Disks

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| pd-standard | $0.000063014 / 1 gibibyte hour | $0.000056712 / 1 gibibyte hour | $0.000050411 / 1 gibibyte hour |
| pd-ssd | $0.000267808 / 1 gibibyte hour | $0.000241027 / 1 gibibyte hour | $0.000214247 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

- All use is subject to the [Gemini platform quota](https://cloud.google.com/vertex-ai/docs/quotas) policy.
- You are required to store your data and program files in Google Cloud Storage buckets during the Gemini platform lifecycle. See [more about Cloud Storage usage](https://cloud.google.com/vertex-ai/pricing#gcs).

You are charged for training your models from the moment when resources are provisioned for a job until the job finishes.

**Warning:** Your training jobs are limited by the Gemini platform quota policy. If you choose a very powerful processing cluster for your first training jobs, it's likely you will exceed your quota.

**Scale tiers for predefined configurations (AI Platform Training)**

You can control the type of processing cluster to use when training your model. The simplest way is to choose from one of the predefined configurations called _scale tiers_. Read more about [scale tiers](https://cloud.google.com/ai-platform/training/docs/machine-types).

**Machine types for custom configurations**

If you use Gemini platform or select CUSTOM as your scale tier for AI Platform Training, you have control over the number and type of virtual machines to use for the cluster's master, worker and parameter servers. Read more about [machine types for Gemini platform](https://cloud.google.com/vertex-ai/docs/training/configure-compute) and [machine types for AI Platform Training](https://cloud.google.com/ai-platform/training/docs/machine-types).

The cost of training with a custom processing cluster is the sum of all the machines you specify. You are charged for the total time of the job, not for the active processing time of individual machines.

## Gen AI Evals

For model-based metrics, charges are applied only for the prediction costs associated with the underlying autorater model. They are billed based on the input tokens that you provide in your evaluation dataset and the autorater output.

Gen AI Evals is generally available (GA). Pricing change took effect on April 14, 2025.

| Metric | Pricing |
| Pointwise | Default autorater model<br>Gemini 2.0 Flash |
| Pairwise | Default autorater model<br>Gemini 2.0 Flash |

Computation-based metrics are charged at $0.00003 per 1k characters for input and $0.00009 per 1k characters for output. They are referred to as Automatic Metric in SKU.

| Metric Name | Type |
| Exact Match | Computation-based |
| Bleu | Computation-based |
| Rouge | Computation-based |
| Tool Call Valid | Computation-based |
| Tool Name Match | Computation-based |
| Tool Parameter Key Match | Computation-based |
| Tool Parameter KV Match | Computation-based |

Prices are listed in US Dollars (USD). If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

Legacy model-based metrics are charged at $0.005 per 1k characters for input and $0.015 per 1k characters for output.

| Metric Name | Type |
| Coherence | Pointwise |
| Fluency | Pointwise |
| Fulfillment | Pointwise |
| Safety | Pointwise |
| Groundedness | Pointwise |
| Summarization Quality | Pointwise |
| Summarization Helpfulness | Pointwise |
| Summarization Verbosity | Pointwise |
| Question Answering Quality | Pointwise |
| Question Answering Relevance | Pointwise |
| Question Answering Helpfulness | Pointwise |
| Question Answering Correctness | Pointwise |
| Pairwise Summarization Quality | Pairwise |
| Pairwise Question Answering Quality | Pairwise |

Prices are listed in US Dollars (USD). If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

## Agents

Gemini platform products to Scale have a unified pricing structure, using 3 resource types: Compute, Memory and Storage. All Scale products are billed on these SKUs. Some services are _measured_ by number of requests, but _billed_ under Agent Compute vCPU-h, at the rates described in the sections below.

Show discount options

HourlyHourly

MonthlyMonthly

| Resource | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| Agent Compute | $0.085 / 1 hour | $0.0765 / 1 hour | $0.068 / 1 hour |
| Agent Memory (RAM) | $0.009 / 1 gibibyte hour | $0.0081 / 1 gibibyte hour | $0.0072 / 1 gibibyte hour |
| Agent Storage | $0.000410959 / 1 gibibyte hour | $0.000369863 / 1 gibibyte hour | $0.000328767 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### Agent Compute

Runtime and Sandbox environments, including Code Execution and Computer Use, are billed on Agent Compute (vCPU-hours) and Agent Memory (GiB-hours) resource usage.

- **Compute**: vCPU resources allocated to the agent, billed as Agent Compute ($0.085/vCPU-h)
- **Memory**: Memory (RAM) resources allocated to the agent, billed as Agent Memory ($0.009/GiB-h)

All usage is rounded to the nearest second. For Runtime, idle time spent waiting for the next prompt between turns is not billed.

Agent Gateway (Agent-to-Anywhere) is billed on Agent Compute (vCPU-Hours) resource usage.

- Agent Compute vCPU-h ($0.085) corresponds to 15,000 API calls or Authorization requests processed via Agent Gateway (Agent-to-Anywhere) during agent execution.
- This applies to all agents on Agent Runtime and Gemini.
- Billing is prorated to your actual usage per hour, per project.

**Note:** Billing for usage of Agent Gateway (Agent-to-Anywhere) will be effective July 13th 2026.

### Memory Bank

**Note**: Memory Bank billing on this pricing structure will commence on September 1st, 2026.

Memory Bank is a fully managed service for agent memory generation, storage, retrieval and embedding. You are billed for:

- **Storage**: Total data stored (including revisions), billed as Agent Storage ($0.30/GiB-month).
- **Operations**: Read and write operations
- **Read API requests**: 1 Agent Compute vCPU-h ($0.085) for every 3 million read operations. Includes any API request that retrieves stored information, such as searching the memory bank, or fetching state variables (if the request also writes data, it is only billed as a write operation).
- **Write API requests**: 1 Agent Compute vCPU-h ($0.085) for every 1 million write operations. Includes any API request that creates or updates data, such publishing new long-term memories, or deleting expired data. All amounts are pro-rated to your actual usage.
- **Tokens**: model tokens used for memory generation and embeddings are billed separately under their respective model SKUs. New embedding skus were implemented on 9/1/2026

### Semantic Governance Policy

**Note:** Semantic Governance Policy billing on this pricing structure will commence later in 2026.

Semantic Governance Policies are natural language constraints that you configure to govern AI agents through their tool calls.

You are billed for:

- **Compute**: 1 Agent Compute vCPU-h ($0.085) for every 15,000 agent-model response evaluations
- **Evaluation-model tokens**: tokens used for agent-model response evaluations under their [respective model SKUs](https://cloud.google.com/gemini-enterprise-agent-platform/generative-ai/pricing).

This applies to all agents on Agent Runtime. All amounts are pro-rated to your actual usage.

### Sessions

**Note**: Sessions billing on this pricing structure will commence on September 1st, 2026.

Sessions manages conversation history and state. You are billed for:

- **Storage**: Total data stored, billed as Agent Storage ($0.30/GiB-month).
- **Operations**: Read and write operations
- **Read API requests**: 1 Agent Compute vCPU-h ($0.085) for every 3 million read operations. Includes any operation that retrieves stored information, such as loading conversation history and listing sessions.
- **Write API requests**: 1 Agent Compute vCPU-h ($0.085) for every 1 million write operations. Includes any API request that creates or updates data, such as saving new chat turns, updating session states, or deleting expired data.

### Skill Registry﻿

**Note**: Skills Registry billing will commence on September 1st, 2026.

Skill Registry pricing is based on the following components.

- **Storage**: Total data stored, billed as Agent Storage ($0.30/GiB-month).
- **Operations**: Read and write operations
- **Read API requests**: 1 Agent Compute vCPU-h ($0.085) for every 3 million read operations. Includes searching, reading, dynamically loading skills
- **Write API requests**: 1 Agent Compute vCPU-h ($0.085) for every 1 million write operations. Includes creating, updating, deleting skills.
- **Tokens**: model tokens used for Vulnerability Analysis are billed separately under their [respective model SKUs](https://cloud.google.com/gemini-enterprise-agent-platform/generative-ai/pricing#embedding-models).

## Ray in Gemini platform

### Training

The tables below provide the approximate _price per hour_ of various training configurations. You can choose a custom configuration of selected [machine types](https://cloud.google.com/vertex-ai/docs/training/configure-compute). To calculate pricing, sum the costs of the virtual machines you use.

If you use Compute Engine machine types and attach accelerators, the cost of the accelerators is separate. To calculate this cost, multiply the prices in the table of accelerators below by how many machine hours of each type of accelerator you use.

### Machine types

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)
- Phoenix (us-west8)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| n1-standard-4 | $0.2279988 / 1 hour | $0.20519892 / 1 hour | $0.18239904 / 1 hour |
| n1-standard-8 | $0.4559976 / 1 hour | $0.41039784 / 1 hour | $0.36479808 / 1 hour |
| n1-standard-16 | $0.9119952 / 1 hour | $0.82079568 / 1 hour | $0.72959616 / 1 hour |
| n1-standard-32 | $1.8239904 / 1 hour | $1.64159136 / 1 hour | $1.45919232 / 1 hour |
| n1-standard-64 | $3.6479808 / 1 hour | $3.28318272 / 1 hour | $2.91838464 / 1 hour |
| n1-standard-96 | $5.4719712 / 1 hour | $4.92477408 / 1 hour | $4.37757696 / 1 hour |
| n1-highmem-2 | $0.1419636 / 1 hour | $0.12776724 / 1 hour | $0.11357088 / 1 hour |
| n1-highmem-4 | $0.2839272 / 1 hour | $0.25553448 / 1 hour | $0.22714176 / 1 hour |
| n1-highmem-8 | $0.5678544 / 1 hour | $0.51106896 / 1 hour | $0.45428352 / 1 hour |
| n1-highmem-16 | $1.1357088 / 1 hour | $1.02213792 / 1 hour | $0.90856704 / 1 hour |
| n1-highmem-32 | $2.2714176 / 1 hour | $2.04427584 / 1 hour | $1.81713408 / 1 hour |
| n1-highmem-64 | $4.5428352 / 1 hour | $4.08855168 / 1 hour | $3.63426816 / 1 hour |
| n1-highmem-96 | $6.8142528 / 1 hour | $6.13282752 / 1 hour | $5.45140224 / 1 hour |
| n1-highcpu-16 | $0.68014656 / 1 hour | $0.612131904 / 1 hour | $0.544117248 / 1 hour |
| n1-highcpu-32 | $1.36029312 / 1 hour | $1.224263808 / 1 hour | $1.088234496 / 1 hour |
| n1-highcpu-64 | $2.72058624 / 1 hour | $2.448527616 / 1 hour | $2.176468992 / 1 hour |
| n1-highcpu-96 | $4.08087936 / 1 hour | $3.672791424 / 1 hour | $3.264703488 / 1 hour |
| a2-highgpu-1g\* | $4.408062 / 1 hour | $3.9672558 / 1 hour | $3.5264496 / 1 hour |
| a2-highgpu-2g\* | $8.816124 / 1 hour | $7.9345116 / 1 hour | $7.0528992 / 1 hour |
| a2-highgpu-4g\* | $17.632248 / 1 hour | $15.8690232 / 1 hour | $14.1057984 / 1 hour |
| a2-highgpu-8g\* | $35.264496 / 1 hour | $31.7380464 / 1 hour | $28.2115968 / 1 hour |
| a2-highgpu-16g\* | $70.528992 / 1 hour | $63.4760928 / 1 hour | $56.4231936 / 1 hour |
| a3-highgpu-8g\* | $105.39898088 / 1 hour | $94.859082792 / 1 hour | $84.319184704 / 1 hour |
| a3-megagpu-8g\* | $110.65714224 / 1 hour | $99.591428016 / 1 hour | $88.525713792 / 1 hour |
| a4-highgpu-8g\* | $148.212 / 1 hour | $133.3908 / 1 hour | $118.5696 / 1 hour |
| e2-standard-4 | $0.16082748 / 1 hour | $0.144744732 / 1 hour | $0.128661984 / 1 hour |
| e2-standard-4 | $0.32165496 / 1 hour | $0.289489464 / 1 hour | $0.257323968 / 1 hour |
| e2-standard-16 | $0.64330992 / 1 hour | $0.578978928 / 1 hour | $0.514647936 / 1 hour |
| e2-standard-32 | $1.28661984 / 1 hour | $1.157957856 / 1 hour | $1.029295872 / 1 hour |
| e2-highmem-2 | $0.10847966 / 1 hour | $0.097631694 / 1 hour | $0.086783728 / 1 hour |
| e2-highmem-4 | $0.21695932 / 1 hour | $0.195263388 / 1 hour | $0.173567456 / 1 hour |
| e2-highmem-8 | $0.43391864 / 1 hour | $0.390526776 / 1 hour | $0.347134912 / 1 hour |
| e2-highmem-16 | $0.86783728 / 1 hour | $0.781053552 / 1 hour | $0.694269824 / 1 hour |
| e2-highcpu-16 | $0.4749144 / 1 hour | $0.42742296 / 1 hour | $0.37993152 / 1 hour |
| e2-highcpu-32 | $0.9498288 / 1 hour | $0.85484592 / 1 hour | $0.75986304 / 1 hour |
| n2-standard-4 | $0.2330832 / 1 hour | $0.20977488 / 1 hour | $0.18646656 / 1 hour |
| n2-standard-8 | $0.4661664 / 1 hour | $0.41954976 / 1 hour | $0.37293312 / 1 hour |
| n2-standard-16 | $0.9323328 / 1 hour | $0.83909952 / 1 hour | $0.74586624 / 1 hour |
| n2-standard-32 | $1.8646656 / 1 hour | $1.67819904 / 1 hour | $1.49173248 / 1 hour |
| n2-standard-48 | $2.7969984 / 1 hour | $2.51729856 / 1 hour | $2.23759872 / 1 hour |
| n2-standard-64 | $3.7293312 / 1 hour | $3.35639808 / 1 hour | $2.98346496 / 1 hour |
| n2-standard-80 | $4.661664 / 1 hour | $4.1954976 / 1 hour | $3.7293312 / 1 hour |
| n2-highmem-2 | $0.1572168 / 1 hour | $0.14149512 / 1 hour | $0.12577344 / 1 hour |
| n2-highmem-4 | $0.3144336 / 1 hour | $0.28299024 / 1 hour | $0.25154688 / 1 hour |
| n2-highmem-8 | $0.6288672 / 1 hour | $0.56598048 / 1 hour | $0.50309376 / 1 hour |
| n2-highmem-16 | $1.2577344 / 1 hour | $1.13196096 / 1 hour | $1.00618752 / 1 hour |
| n2-highmem-32 | $2.5154688 / 1 hour | $2.26392192 / 1 hour | $2.01237504 / 1 hour |
| n2-highmem-48 | $3.7732032 / 1 hour | $3.39588288 / 1 hour | $3.01856256 / 1 hour |
| n2-highmem-64 | $5.0309376 / 1 hour | $4.52784384 / 1 hour | $4.02475008 / 1 hour |
| n2-highmem-80 | $6.288672 / 1 hour | $5.6598048 / 1 hour | $5.0309376 / 1 hour |
| n2-highcpu-16 | $0.6882816 / 1 hour | $0.61945344 / 1 hour | $0.55062528 / 1 hour |
| n2-highcpu-32 | $1.3765632 / 1 hour | $1.23890688 / 1 hour | $1.10125056 / 1 hour |
| n2-highcpu-48 | $2.0648448 / 1 hour | $1.85836032 / 1 hour | $1.65187584 / 1 hour |
| n2-highcpu-64 | $2.7531264 / 1 hour | $2.47781376 / 1 hour | $2.20250112 / 1 hour |
| n2-highcpu-80 | $3.441408 / 1 hour | $3.0972672 / 1 hour | $2.7531264 / 1 hour |
| c2-standard-4 | $0.2505696 / 1 hour | $0.22551264 / 1 hour | $0.20045568 / 1 hour |
| c2-standard-8 | $0.5011392 / 1 hour | $0.45102528 / 1 hour | $0.40091136 / 1 hour |
| c2-standard-16 | $1.0022784 / 1 hour | $0.90205056 / 1 hour | $0.80182272 / 1 hour |
| c2-standard-30 | $1.879272 / 1 hour | $1.6913448 / 1 hour | $1.5034176 / 1 hour |
| c2-standard-60 | $3.758544 / 1 hour | $3.3826896 / 1 hour | $3.0068352 / 1 hour |
| m1-ultramem-40 | $7.55172 / 1 hour | $6.796548 / 1 hour | $6.041376 / 1 hour |
| m1-ultramem-80 | $15.10344 / 1 hour | $13.593096 / 1 hour | $12.082752 / 1 hour |
| m1-ultramem-160 | $30.20688 / 1 hour | $27.186192 / 1 hour | $24.165504 / 1 hour |
| m1-megamem-96 | $12.782592 / 1 hour | $11.5043328 / 1 hour | $10.2260736 / 1 hour |
| cloud-tpu | Pricing is determined by the accelerator type. See 'Accelerators'. | - | - |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

### Accelerators

Iowa (us-central1)

- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Finland (europe-north1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Montreal (northamerica-northeast1)
- Sao Paulo (southamerica-east1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| GPU type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| NVIDIA\_TESLA\_A100 | $3.5206896 / 1 hour | $3.16862064 / 1 hour | $2.81655168 / 1 hour |
| NVIDIA\_TESLA\_A100\_80GB | $4.517292 / 1 hour | $4.0655628 / 1 hour | $3.6138336 / 1 hour |
| NVIDIA\_H100\_80GB | $11.75586073 / 1 hour | $10.580274657 / 1 hour | $9.404688584 / 1 hour |
| NVIDIA\_TESLA\_P4 | $0.72 / 1 hour | $0.648 / 1 hour | $0.576 / 1 hour |
| NVIDIA\_TESLA\_P100 | $1.752 / 1 hour | $1.5768 / 1 hour | $1.4016 / 1 hour |
| NVIDIA\_TESLA\_T4 | $0.42 / 1 hour | $0.378 / 1 hour | $0.336 / 1 hour |
| NVIDIA\_TESLA\_V100 | $2.976 / 1 hour | $2.6784 / 1 hour | $2.3808 / 1 hour |
| TPU\_V2 Single (8 cores) | $5.40 / 1 hour | $4.86 / 1 hour | $4.32 / 1 hour |
| TPU\_V2 Pod (32 cores)\* | $28.80 / 1 hour | $25.92 / 1 hour | $23.04 / 1 hour |
| TPU\_V3 Single (8 cores) | $9.60 / 1 hour | $8.64 / 1 hour | $7.68 / 1 hour |
| TPU\_V3 Pod (32 cores)\* | $38.40 / 1 hour | $34.56 / 1 hour | $30.72 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

\\* The price for training using a Cloud TPU Pod is based on the number of cores in the Pod. The number of cores in a pod is always a multiple of 32. To determine the price of training on a Pod that has more than 32 cores, take the price for a 32-core Pod, and multiply it by the number of cores, divided by 32. For example, for a 128-core Pod, the price is (32-core Pod price) \* (128/32). For information about which Cloud TPU Pods are available for a specific region, see [System Architecture](https://cloud.google.com/tpu/docs/system-architecture-tpu-vm) in the Cloud TPU documentation.

### Disks

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Disk type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| pd-standard | $0.000065753 / 1 gibibyte hour | $0.000059178 / 1 gibibyte hour | $0.000052603 / 1 gibibyte hour |
| pd-ssd | $0.000279452 / 1 gibibyte hour | $0.000251507 / 1 gibibyte hour | $0.000223562 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

- All use is subject to the [Gemini platform quota](https://cloud.google.com/vertex-ai/docs/quotas) policy.
- You are required to store your data and program files in Google Cloud Storage buckets during the Gemini platform lifecycle. See [more about Cloud Storage usage](https://cloud.google.com/vertex-ai/pricing#gcs).

You are charged for training your models from the moment when resources are provisioned for a job until the job finishes.

**Warning:** Your training jobs are limited by the Gemini platform quota policy. If you choose a very powerful processing cluster for your first training jobs, it's likely you will exceed your quota.

## Prediction and explanation

The following tables provide the prices of batch prediction, online prediction, and online explanation per _node hour_. A node hour represents the time a virtual machine spends running your prediction job or waiting in an active state (an endpoint with one or more models deployed) to handle prediction or explanation requests.

You can use Spot VMs with Inference in Gemini platform. [Spot VMs](https://cloud.google.com/compute/docs/instances/spot) are billed according to [Compute Engine Spot VMs pricing](https://cloud.google.com/spot-vms/pricing). There are Inference in Gemini platform management fees in addition to your infrastructure usage, captured in the following tables.

You can use Compute Engine reservations with Inference in Gemini platform. When using Compute Engine reservations, you're billed according to [Compute Engine Pricing](https://cloud.google.com/compute/all-pricing), including any applicable committed use discounts (CUDs). There are Inference in Gemini platform management fees in addition to your infrastructure usage, captured in the following tables.

### E2 Series

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| e2-standard-2 | $0.0770564 / 1 hour | $0.06935076 / 1 hour | $0.06164512 / 1 hour |
| e2-standard-4 | $0.1541128 / 1 hour | $0.13870152 / 1 hour | $0.12329024 / 1 hour |
| e2-standard-8 | $0.3082256 / 1 hour | $0.27740304 / 1 hour | $0.24658048 / 1 hour |
| e2-standard-16 | $0.6164512 / 1 hour | $0.55480608 / 1 hour | $0.49316096 / 1 hour |
| e2-standard-32 | $1.2329024 / 1 hour | $1.10961216 / 1 hour | $0.98632192 / 1 hour |
| e2-highmem-2 | $0.1039476 / 1 hour | $0.09355284 / 1 hour | $0.08315808 / 1 hour |
| e2-highmem-4 | $0.2078952 / 1 hour | $0.18710568 / 1 hour | $0.16631616 / 1 hour |
| e2-highmem-8 | $0.4157904 / 1 hour | $0.37421136 / 1 hour | $0.33263232 / 1 hour |
| e2-highmem-16 | $0.8315808 / 1 hour | $0.74842272 / 1 hour | $0.66526464 / 1 hour |
| e2-highcpu-2 | $0.056888 / 1 hour | $0.0511992 / 1 hour | $0.0455104 / 1 hour |
| e2-highcpu-4 | $0.113776 / 1 hour | $0.1023984 / 1 hour | $0.0910208 / 1 hour |
| e2-highcpu-8 | $0.227552 / 1 hour | $0.2047968 / 1 hour | $0.1820416 / 1 hour |
| e2-highcpu-16 | $0.455104 / 1 hour | $0.4095936 / 1 hour | $0.3640832 / 1 hour |
| e2-highcpu-32 | $0.910208 / 1 hour | $0.8191872 / 1 hour | $0.7281664 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### N1 Series

Iowa (us-central1)

- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Milan (europe-west8)
- Paris (europe-west9)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| n1-standard-2 | $0.1095 / 1 hour | $0.09855 / 1 hour | $0.0876 / 1 hour |
| n1-standard-4 | $0.219 / 1 hour | $0.1971 / 1 hour | $0.1752 / 1 hour |
| n1-standard-8 | $0.438 / 1 hour | $0.3942 / 1 hour | $0.3504 / 1 hour |
| n1-standard-16 | $0.876 / 1 hour | $0.7884 / 1 hour | $0.7008 / 1 hour |
| n1-standard-32 | $1.752 / 1 hour | $1.5768 / 1 hour | $1.4016 / 1 hour |
| n1-highmem-2 | $0.137 / 1 hour | $0.1233 / 1 hour | $0.1096 / 1 hour |
| n1-highmem-4 | $0.274 / 1 hour | $0.2466 / 1 hour | $0.2192 / 1 hour |
| n1-highmem-8 | $0.548 / 1 hour | $0.4932 / 1 hour | $0.4384 / 1 hour |
| n1-highmem-16 | $1.096 / 1 hour | $0.9864 / 1 hour | $0.8768 / 1 hour |
| n1-highcpu-2 | $0.081 / 1 hour | $0.0729 / 1 hour | $0.0648 / 1 hour |
| n1-highcpu-4 | $0.162 / 1 hour | $0.1458 / 1 hour | $0.1296 / 1 hour |
| n1-highcpu-8 | $0.324 / 1 hour | $0.2916 / 1 hour | $0.2592 / 1 hour |
| n1-highcpu-16 | $0.648 / 1 hour | $0.5832 / 1 hour | $0.5184 / 1 hour |
| n1-highcpu-32 | $1.296 / 1 hour | $1.1664 / 1 hour | $1.0368 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### N2 Series

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| n2-standard-2 | $0.1116854 / 1 hour | $0.10051686 / 1 hour | $0.08934832 / 1 hour |
| n2-standard-4 | $0.2233708 / 1 hour | $0.20103372 / 1 hour | $0.17869664 / 1 hour |
| n2-standard-8 | $0.4467416 / 1 hour | $0.40206744 / 1 hour | $0.35739328 / 1 hour |
| n2-standard-16 | $0.8934832 / 1 hour | $0.80413488 / 1 hour | $0.71478656 / 1 hour |
| n2-standard-32 | $1.7869664 / 1 hour | $1.60826976 / 1 hour | $1.42957312 / 1 hour |
| n2-highmem-2 | $0.1506654 / 1 hour | $0.13559886 / 1 hour | $0.12053232 / 1 hour |
| n2-highmem-4 | $0.3013308 / 1 hour | $0.27119772 / 1 hour | $0.24106464 / 1 hour |
| n2-highmem-8 | $0.6026616 / 1 hour | $0.54239544 / 1 hour | $0.48212928 / 1 hour |
| n2-highmem-16 | $1.2053232 / 1 hour | $1.08479088 / 1 hour | $0.96425856 / 1 hour |
| n2-highcpu-2 | $0.0824504 / 1 hour | $0.07420536 / 1 hour | $0.06596032 / 1 hour |
| n2-highcpu-4 | $0.1649008 / 1 hour | $0.14841072 / 1 hour | $0.13192064 / 1 hour |
| n2-highcpu-8 | $0.3298016 / 1 hour | $0.29682144 / 1 hour | $0.26384128 / 1 hour |
| n2-highcpu-16 | $0.6596032 / 1 hour | $0.59364288 / 1 hour | $0.52768256 / 1 hour |
| n2-highcpu-32 | $1.3192064 / 1 hour | $1.18728576 / 1 hour | $1.05536512 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### N2D Series

Iowa (us-central1)

- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Sao Paulo (southamerica-east1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| n2d-standard-2 | $0.0971658 / 1 hour | $0.08744922 / 1 hour | $0.07773264 / 1 hour |
| n2d-standard-4 | $0.1943316 / 1 hour | $0.17489844 / 1 hour | $0.15546528 / 1 hour |
| n2d-standard-8 | $0.3886632 / 1 hour | $0.34979688 / 1 hour | $0.31093056 / 1 hour |
| n2d-standard-16 | $0.7773264 / 1 hour | $0.69959376 / 1 hour | $0.62186112 / 1 hour |
| n2d-standard-32 | $1.5546528 / 1 hour | $1.39918752 / 1 hour | $1.24372224 / 1 hour |
| n2d-highmem-2 | $0.131077 / 1 hour | $0.1179693 / 1 hour | $0.1048616 / 1 hour |
| n2d-highmem-4 | $0.262154 / 1 hour | $0.2359386 / 1 hour | $0.2097232 / 1 hour |
| n2d-highmem-8 | $0.524308 / 1 hour | $0.4718772 / 1 hour | $0.4194464 / 1 hour |
| n2d-highmem-16 | $1.048616 / 1 hour | $0.9437544 / 1 hour | $0.8388928 / 1 hour |
| n2d-highcpu-2 | $0.0717324 / 1 hour | $0.06455916 / 1 hour | $0.05738592 / 1 hour |
| n2d-highcpu-4 | $0.1434648 / 1 hour | $0.12911832 / 1 hour | $0.11477184 / 1 hour |
| n2d-highcpu-8 | $0.2869296 / 1 hour | $0.25823664 / 1 hour | $0.22954368 / 1 hour |
| n2d-highcpu-16 | $0.5738592 / 1 hour | $0.51647328 / 1 hour | $0.45908736 / 1 hour |
| n2d-highcpu-32 | $1.1477184 / 1 hour | $1.03294656 / 1 hour | $0.91817472 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### C2 Series

Iowa (us-central1)

- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Sydney (australia-southeast1)
- Finland (europe-north1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Montreal (northamerica-northeast1)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| c2-standard-4 | $0.240028 / 1 hour | $0.2160252 / 1 hour | $0.1920224 / 1 hour |
| c2-standard-8 | $0.480056 / 1 hour | $0.4320504 / 1 hour | $0.3840448 / 1 hour |
| c2-standard-16 | $0.960112 / 1 hour | $0.8641008 / 1 hour | $0.7680896 / 1 hour |
| c2-standard-30 | $1.80021 / 1 hour | $1.620189 / 1 hour | $1.440168 / 1 hour |
| c2-standard-60 | $3.60042 / 1 hour | $3.240378 / 1 hour | $2.880336 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### C2D Series

Iowa (us-central1)

- Taiwan (asia-east1)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Oregon (us-west1)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| c2d-standard-2 | $0.1044172 / 1 hour | $0.09397548 / 1 hour | $0.08353376 / 1 hour |
| c2d-standard-4 | $0.2088344 / 1 hour | $0.18795096 / 1 hour | $0.16706752 / 1 hour |
| c2d-standard-8 | $0.4176688 / 1 hour | $0.37590192 / 1 hour | $0.33413504 / 1 hour |
| c2d-standard-16 | $0.8353376 / 1 hour | $0.75180384 / 1 hour | $0.66827008 / 1 hour |
| c2d-standard-32 | $1.6706752 / 1 hour | $1.50360768 / 1 hour | $1.33654016 / 1 hour |
| c2d-standard-56 | $2.9236816 / 1 hour | $2.63131344 / 1 hour | $2.33894528 / 1 hour |
| c2d-standard-112 | $5.8473632 / 1 hour | $5.26262688 / 1 hour | $4.67789056 / 1 hour |
| c2d-highmem-2 | $0.1408396 / 1 hour | $0.12675564 / 1 hour | $0.11267168 / 1 hour |
| c2d-highmem-4 | $0.2816792 / 1 hour | $0.25351128 / 1 hour | $0.22534336 / 1 hour |
| c2d-highmem-8 | $0.5633584 / 1 hour | $0.50702256 / 1 hour | $0.45068672 / 1 hour |
| c2d-highmem-16 | $1.1267168 / 1 hour | $1.01404512 / 1 hour | $0.90137344 / 1 hour |
| c2d-highmem-32 | $2.2534336 / 1 hour | $2.02809024 / 1 hour | $1.80274688 / 1 hour |
| c2d-highmem-56 | $3.9435088 / 1 hour | $3.54915792 / 1 hour | $3.15480704 / 1 hour |
| c2d-highmem-112 | $7.8870176 / 1 hour | $7.09831584 / 1 hour | $6.30961408 / 1 hour |
| c2d-highcpu-2 | $0.086206 / 1 hour | $0.0775854 / 1 hour | $0.0689648 / 1 hour |
| c2d-highcpu-4 | $0.172412 / 1 hour | $0.1551708 / 1 hour | $0.1379296 / 1 hour |
| c2d-highcpu-8 | $0.344824 / 1 hour | $0.3103416 / 1 hour | $0.2758592 / 1 hour |
| c2d-highcpu-16 | $0.689648 / 1 hour | $0.6206832 / 1 hour | $0.5517184 / 1 hour |
| c2d-highcpu-32 | $1.379296 / 1 hour | $1.2413664 / 1 hour | $1.1034368 / 1 hour |
| c2d-highcpu-56 | $2.413768 / 1 hour | $2.1723912 / 1 hour | $1.9310144 / 1 hour |
| c2d-highcpu-112 | $4.827536 / 1 hour | $4.3447824 / 1 hour | $3.8620288 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### C3 Series

Iowa (us-central1)

- Singapore (asia-southeast1)
- Belgium (europe-west1)
- Netherlands (europe-west4)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| c3-highcpu-4 | $0.19824 / 1 hour | $0.178416 / 1 hour | $0.158592 / 1 hour |
| c3-highcpu-8 | $0.39648 / 1 hour | $0.356832 / 1 hour | $0.317184 / 1 hour |
| c3-highcpu-22 | $1.09032 / 1 hour | $0.981288 / 1 hour | $0.872256 / 1 hour |
| c3-highcpu-44 | $2.18064 / 1 hour | $1.962576 / 1 hour | $1.744512 / 1 hour |
| c3-highcpu-88 | $4.36128 / 1 hour | $3.925152 / 1 hour | $3.489024 / 1 hour |
| c3-highcpu-176 | $8.72256 / 1 hour | $7.850304 / 1 hour | $6.978048 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### C4 Series

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| c4-standard-2 | $0.1113959 / 1 hour | $0.10025631 / 1 hour | $0.08911672 / 1 hour |
| c4-standard-4 | $0.2273205 / 1 hour | $0.20458845 / 1 hour | $0.1818564 / 1 hour |
| c4-standard-8 | $0.454641 / 1 hour | $0.4091769 / 1 hour | $0.3637128 / 1 hour |
| c4-standard-16 | $0.909282 / 1 hour | $0.8183538 / 1 hour | $0.7274256 / 1 hour |
| c4-standard-24 | $1.363923 / 1 hour | $1.2275307 / 1 hour | $1.0911384 / 1 hour |
| c4-standard-32 | $1.818564 / 1 hour | $1.6367076 / 1 hour | $1.4548512 / 1 hour |
| c4-standard-48 | $2.727846 / 1 hour | $2.4550614 / 1 hour | $2.1822768 / 1 hour |
| c4-standard-96 | $5.455692 / 1 hour | $4.9101228 / 1 hour | $4.3645536 / 1 hour |
| c4-standard-144 | $8.183538 / 1 hour | $7.3651842 / 1 hour | $6.5468304 / 1 hour |
| c4-standard-192 | $10.911384 / 1 hour | $9.8202456 / 1 hour | $8.7291072 / 1 hour |
| c4-standard-288 | $16.367076 / 1 hour | $14.7303684 / 1 hour | $13.0936608 / 1 hour |
| c4-highcpu-2 | $0.0978098 / 1 hour | $0.08802882 / 1 hour | $0.07824784 / 1 hour |
| c4-highcpu-4 | $0.1956196 / 1 hour | $0.17605764 / 1 hour | $0.15649568 / 1 hour |
| c4-highcpu-8 | $0.3912392 / 1 hour | $0.35211528 / 1 hour | $0.31299136 / 1 hour |
| c4-highcpu-16 | $0.7824784 / 1 hour | $0.70423056 / 1 hour | $0.62598272 / 1 hour |
| c4-highcpu-24 | $1.1737176 / 1 hour | $1.05634584 / 1 hour | $0.93897408 / 1 hour |
| c4-highcpu-32 | $1.5649568 / 1 hour | $1.40846112 / 1 hour | $1.25196544 / 1 hour |
| c4-highcpu-48 | $2.3474352 / 1 hour | $2.11269168 / 1 hour | $1.87794816 / 1 hour |
| c4-highcpu-96 | $4.6948704 / 1 hour | $4.22538336 / 1 hour | $3.75589632 / 1 hour |
| c4-highcpu-144 | $7.0423056 / 1 hour | $6.33807504 / 1 hour | $5.63384448 / 1 hour |
| c4-highcpu-192 | $9.3897408 / 1 hour | $8.45076672 / 1 hour | $7.51179264 / 1 hour |
| c4-highcpu-288 | $14.0846112 / 1 hour | $12.67615008 / 1 hour | $11.26768896 / 1 hour |
| c4-highmem-2 | $0.1476255 / 1 hour | $0.13286295 / 1 hour | $0.1181004 / 1 hour |
| c4-highmem-4 | $0.2997797 / 1 hour | $0.26980173 / 1 hour | $0.23982376 / 1 hour |
| c4-highmem-8 | $0.5995594 / 1 hour | $0.53960346 / 1 hour | $0.47964752 / 1 hour |
| c4-highmem-16 | $1.1991188 / 1 hour | $1.07920692 / 1 hour | $0.95929504 / 1 hour |
| c4-highmem-24 | $1.7941495 / 1 hour | $1.61473455 / 1 hour | $1.4353196 / 1 hour |
| c4-highmem-32 | $2.3982376 / 1 hour | $2.15841384 / 1 hour | $1.91859008 / 1 hour |
| c4-highmem-48 | $3.5973564 / 1 hour | $3.23762076 / 1 hour | $2.87788512 / 1 hour |
| c4-highmem-96 | $7.1947128 / 1 hour | $6.47524152 / 1 hour | $5.75577024 / 1 hour |
| c4-highmem-144 | $10.7920692 / 1 hour | $9.71286228 / 1 hour | $8.63365536 / 1 hour |
| c4-highmem-192 | $14.3894256 / 1 hour | $12.95048304 / 1 hour | $11.51154048 / 1 hour |
| c4-highmem-288 | $21.5841384 / 1 hour | $19.42572456 / 1 hour | $17.26731072 / 1 hour |
| c4-highmem-288-metal | $21.5841384 / 1 hour | $19.42572456 / 1 hour | $17.26731072 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### A2 Series

Iowa (us-central1)

- Tokyo (asia-northeast1)
- Seoul (asia-northeast3)
- Singapore (asia-southeast1)
- Netherlands (europe-west4)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Oregon (us-west1)
- Salt Lake City (us-west3)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| a2-highgpu-1g | $4.2244949 / 1 hour | $3.80204541 / 1 hour | $3.37959592 / 1 hour |
| a2-highgpu-2g | $8.4489898 / 1 hour | $7.60409082 / 1 hour | $6.75919184 / 1 hour |
| a2-highgpu-4g | $16.8979796 / 1 hour | $15.20818164 / 1 hour | $13.51838368 / 1 hour |
| a2-highgpu-8g | $33.7959592 / 1 hour | $30.41636328 / 1 hour | $27.03676736 / 1 hour |
| a2-megagpu-16g | $64.1020592 / 1 hour | $57.69185328 / 1 hour | $51.28164736 / 1 hour |
| a2-ultragpu-1g | $5.7818474 / 1 hour | $5.20366266 / 1 hour | $4.62547792 / 1 hour |
| a2-ultragpu-2g | $11.5636948 / 1 hour | $10.40732532 / 1 hour | $9.25095584 / 1 hour |
| a2-ultragpu-4g | $23.1273896 / 1 hour | $20.81465064 / 1 hour | $18.50191168 / 1 hour |
| a2-ultragpu-8g | $46.2547792 / 1 hour | $41.62930128 / 1 hour | $37.00382336 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

When consuming from a reservation or spot capacity, billing is spread across two SKUs: the GCE SKU with the label 'vertex-ai-online-prediction' and the Gemini platform Management Fee SKU. This enables you to use your Committed Use Discounts (CUDs) in Gemini platform.

### A3 Series

Iowa (us-central1)

- Tokyo (asia-northeast1)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Sydney (australia-southeast1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Toronto (northamerica-northeast2)
- Iowa (us-central1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| a3-ultragpu-8g | $96.015616 / 1 hour | $86.4140544 / 1 hour | $76.8124928 / 1 hour |
| a3-megagpu-8g | $106.65474 / 1 hour | $95.989266 / 1 hour | $85.323792 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

When consuming from a reservation or spot capacity, billing is spread across two SKUs: the GCE SKU with the label 'vertex-ai-online-prediction' and the Gemini platform Management Fee SKU. This enables you to use your Committed Use Discounts (CUDs) in Gemini platform.

### A4 Series

Iowa (us-central1)

- Singapore (asia-southeast1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Los Angeles (us-west2)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| a4-highgpu-8g | $148.212 / 1 hour | $133.3908 / 1 hour | $118.5696 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

When consuming from a reservation or spot capacity, billing is spread across two SKUs: the GCE SKU with the label 'vertex-ai-online-prediction' and the Gemini platform Management Fee SKU. This enables you to use your Committed Use Discounts (CUDs) in Gemini platform.

### A4X Series

Iowa (us-central1)

- Netherlands (europe-west4)
- Iowa (us-central1)
- Northern Virginia (us-east4)
- Columbus (us-east5)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| a4x-highgpu-4g | $74.75 / 1 hour | $67.275 / 1 hour | $59.80 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

When consuming from a reservation or spot capacity, billing is spread across two SKUs: the GCE SKU with the label 'vertex-ai-online-prediction' and the Gemini platform Management Fee SKU. This enables you to use your Committed Use Discounts (CUDs) in Gemini platform.

**a4x-highgpu-4g** requires at least 18 VMs.

### G2 Series

Iowa (us-central1)

- Taiwan (asia-east1)
- Tokyo (asia-northeast1)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Dammam (me-central2)
- Toronto (northamerica-northeast2)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Oregon (us-west1)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| g2-standard-4 | $0.81293 / 1 hour | $0.731637 / 1 hour | $0.650344 / 1 hour |
| g2-standard-8 | $0.98181 / 1 hour | $0.883629 / 1 hour | $0.785448 / 1 hour |
| g2-standard-12 | $1.15069 / 1 hour | $1.035621 / 1 hour | $0.920552 / 1 hour |
| g2-standard-16 | $1.31957 / 1 hour | $1.187613 / 1 hour | $1.055656 / 1 hour |
| g2-standard-24 | $2.30138 / 1 hour | $2.071242 / 1 hour | $1.841104 / 1 hour |
| g2-standard-32 | $1.99509 / 1 hour | $1.795581 / 1 hour | $1.596072 / 1 hour |
| g2-standard-48 | $4.60276 / 1 hour | $4.142484 / 1 hour | $3.682208 / 1 hour |
| g2-standard-96 | $9.20552 / 1 hour | $8.284968 / 1 hour | $7.364416 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

When consuming from a reservation or spot capacity, billing is spread across two SKUs: the GCE SKU with the label 'vertex-ai-online-prediction' and the Gemini platform Management Fee SKU. This enables you to use your Committed Use Discounts (CUDs) in Gemini platform.

### G4 Series

Iowa (us-central1)

- Taiwan (asia-east1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Finland (europe-north1)
- Belgium (europe-west1)
- Netherlands (europe-west4)
- Milan (europe-west8)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Alabama (us-east7)
- Oregon (us-west1)
- Salt Lake City (us-west3)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| g4-standard-48 | $5.1749195 / 1 hour | $4.65742755 / 1 hour | $4.1399356 / 1 hour |
| g4-standard-96 | $10.349839 / 1 hour | $9.3148551 / 1 hour | $8.2798712 / 1 hour |
| g4-standard-192 | $20.699678 / 1 hour | $18.6297102 / 1 hour | $16.5597424 / 1 hour |
| g4-standard-384 | $41.399356 / 1 hour | $37.2594204 / 1 hour | $33.1194848 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### TPU v5e pricing

Iowa (us-central1)

- Singapore (asia-southeast1)
- Netherlands (europe-west4)
- Iowa (us-central1)
- South Carolina (us-east1)
- Oregon (us-west1)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| ct5lp-hightpu-1t | $1.38 / 1 hour | $1.242 / 1 hour | $1.104 / 1 hour |
| ct5lp-hightpu-4t | $5.52 / 1 hour | $4.968 / 1 hour | $4.416 / 1 hour |
| ct5lp-hightpu-8t | $5.52 / 1 hour | $4.968 / 1 hour | $4.416 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### TPU v6e pricing

Iowa (us-central1)

- Tokyo (asia-northeast1)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- London (europe-west2)
- Netherlands (europe-west4)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| ct6e-standard-1t | $3.105 / 1 hour | $2.7945 / 1 hour | $2.484 / 1 hour |
| ct6e-standard-4t | $12.42 / 1 hour | $11.178 / 1 hour | $9.936 / 1 hour |
| ct6e-standard-8t | $24.84 / 1 hour | $22.356 / 1 hour | $19.872 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

Each [machine type](https://cloud.google.com/vertex-ai/docs/predictions/configure-compute) is charged as the following SKUs on your Google Cloud bill:

- **vCPU cost:** measured in _vCPU hours_
- **RAM cost:** measured in _GB hours_
- **GPU cost:** if either built into the machine or optionally configured, measured in _GPU hours_

The [prices for machine types](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#prediction-and-explanation) are used to approximate the total hourly cost for each prediction node of a model version using that machine type.

For example, a machine type of n1-highcpu-32 includes 32 vCPUs and 32 GB of RAM. Therefore, the hourly pricing equals 32 vCPU hours + 32 GB hours.

### E2 Series

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Item | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| vCPU | $0.0250826 / 1 hour | $0.02257434 / 1 hour | $0.02006608 / 1 hour |
| RAM | $0.0033614 / 1 gibibyte hour | $0.00302526 / 1 gibibyte hour | $0.00268912 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### N1 Series

Iowa (us-central1)

- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Item | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| vCPU | $0.036 / 1 hour | $0.0324 / 1 hour | $0.0288 / 1 hour |
| RAM | $0.005 / 1 gibibyte hour | $0.0045 / 1 gibibyte hour | $0.004 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### N2 Series

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Item | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| vCPU | $0.0363527 / 1 hour | $0.03271743 / 1 hour | $0.02908216 / 1 hour |
| RAM | $0.0048725 / 1 gibibyte hour | $0.00438525 / 1 gibibyte hour | $0.003898 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### N2D Series

Iowa (us-central1)

- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Sao Paulo (southamerica-east1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Item | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| vCPU | $0.0316273 / 1 hour | $0.02846457 / 1 hour | $0.02530184 / 1 hour |
| RAM | $0.0042389 / 1 gibibyte hour | $0.00381501 / 1 gibibyte hour | $0.00339112 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### C2 Series

Iowa (us-central1)

- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Sydney (australia-southeast1)
- Finland (europe-north1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Montreal (northamerica-northeast1)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Item | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| vCPU | $0.039077 / 1 hour | $0.0351693 / 1 hour | $0.0312616 / 1 hour |
| RAM | $0.0052325 / 1 gibibyte hour | $0.00470925 / 1 gibibyte hour | $0.004186 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### C2D Series

Iowa (us-central1)

- Taiwan (asia-east1)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Oregon (us-west1)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Item | Price (USD) |
| vCPU | $0.0339974 / 1 hour | $0.03059766 / 1 hour | $0.02719792 / 1 hour |
| RAM | $0.0045528 / 1 gibibyte hour | $0.00409752 / 1 gibibyte hour | $0.00364224 / 1 gibibyte hour |

### C3 Series

Iowa (us-central1)

- Tokyo (asia-northeast1)
- Singapore (asia-southeast1)
- Belgium (europe-west1)
- Netherlands (europe-west4)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)

Show discount options

HourlyHourly

MonthlyMonthly

| Item | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| vCPU | $0.03908 / 1 hour | $0.035172 / 1 hour | $0.031264 / 1 hour |
| RAM | $0.00524 / 1 gibibyte hour | $0.004716 / 1 gibibyte hour | $0.004192 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### C4 Series

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Item | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| vCPU | $0.0398475 / 1 hour | $0.03586275 / 1 hour | $0.031878 / 1 hour |
| RAM | $0.0045287 / 1 gibibyte hour | $0.00407583 / 1 gibibyte hour | $0.00362296 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### A2 Series

Iowa (us-central1)

- Tokyo (asia-northeast1)
- Seoul (asia-northeast3)
- Singapore (asia-southeast1)
- Netherlands (europe-west4)
- Tel Aviv (me-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Oregon (us-west1)
- Salt Lake City (us-west3)

Show discount options

HourlyHourly

MonthlyMonthly

| Item | Price (USD) |
| vCPU | $0.0363527 / 1 hour | $0.03271743 / 1 hour | $0.02908216 / 1 hour |
| RAM | $0.0048725 / 1 gibibyte hour | $0.00438525 / 1 gibibyte hour | $0.003898 / 1 gibibyte hour |
| GPU (A100 40 GB) | $3.3741 / 1 hour | $3.03669 / 1 hour | $2.69928 / 1 hour |
| GPU (A100 80 GB) | $4.51729 / 1 hour | $4.065561 / 1 hour | $3.613832 / 1 hour |

### A3 Series

Iowa (us-central1)

- Tokyo (asia-northeast1)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Toronto (northamerica-northeast2)
- Iowa (us-central1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Item | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| vCPU | $0.0293227 / 1 hour | $0.02639043 / 1 hour | $0.02345816 / 1 hour |
| RAM | $0.0025534 / 1 gibibyte hour | $0.00229806 / 1 gibibyte hour | $0.00204272 / 1 gibibyte hour |
| GPU (H100 80 GB) | $11.2660332 / 1 hour | $10.13942988 / 1 hour | $9.01282656 / 1 hour |
| GPU (H200) | $10.708501 / 1 hour | $9.6376509 / 1 hour | $8.5668008 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### G2 Series

Iowa (us-central1)

- Taiwan (asia-east1)
- Tokyo (asia-northeast1)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Dammam (me-central2)
- Toronto (northamerica-northeast2)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Oregon (us-west1)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Item | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| vCPU | $0.02874 / 1 hour | $0.025866 / 1 hour | $0.022992 / 1 hour |
| RAM | $0.00337 / 1 gibibyte hour | $0.003033 / 1 gibibyte hour | $0.002696 / 1 gibibyte hour |
| GPU (L4) | $0.64405 / 1 hour | $0.579645 / 1 hour | $0.51524 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

Some machine types allow you to add optional [GPU accelerators for prediction](https://cloud.google.com/vertex-ai/docs/predictions/configure-compute#gpus). Optional GPUs incur an additional charge, separate from those described in the previous table. View each pricing table, which describes the pricing for each type of optional GPU.

### Accelerators - price per hour

Iowa (us-central1)

- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Sao Paulo (southamerica-east1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| GPU type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| NVIDIA\_TESLA\_P4 | $0.69 / 1 hour | $0.621 / 1 hour | $0.552 / 1 hour |
| NVIDIA\_TESLA\_P100 | $1.679 / 1 hour | $1.5111 / 1 hour | $1.3432 / 1 hour |
| NVIDIA\_TESLA\_T4 | $0.402 / 1 hour | $0.3618 / 1 hour | $0.3216 / 1 hour |
| NVIDIA\_TESLA\_V100 | $2.852 / 1 hour | $2.5668 / 1 hour | $2.2816 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

Pricing is per GPU. If you use multiple GPUs per prediction node (or if your version scales to use multiple nodes),the costs scale accordingly.

Inference in Gemini platform serves predictions from your model by running a number of virtual machines ("nodes"). By default, Gemini platform automatically scales the number of nodes running at any time. For online prediction, the number of nodes scales to meet demand. Each node can respond to multiple prediction requests. For batch prediction, the number of nodes scales to reduce the total time it takes to run a job. You can customize how prediction nodes scale.

You are charged for the time that each node runs for your model, including:

- When the node is processing a batch prediction job.
- When the node is processing an online prediction request.
- When the node is in a ready state for serving online predictions.

The cost of one node running for one hour is a _node hour_. The [table of prediction prices](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#prediction-and-explanation) describes the price of a node hour, which varies across regions and between online prediction and batch prediction.

You can consume node hours in fractional increments. For example, one node running for 30 minutes costs 0.5 node hours.

**Cost calculations for Compute Engine (N1) machine types**

- The running time of a node is billed in 30-second increments. This means that every 30 seconds, your project is billed for 30 seconds worth of whatever vCPU, RAM, and GPU resources that your node is using at that moment.

**More about automatic scaling of prediction nodes**

| Online prediction | Batch prediction |
| The priority of the scaling is to reduce the latency of individual requests. The service keeps your model in a ready state for a few idle minutes after servicing a request. | The priority of the scaling is to reduce the total elapsed time of the job. |
| Scaling affects your total charges each month: the more numerous and frequent your requests, the more nodes will be used. | Scaling should have little effect on the price of your job, though there is some overhead involved in bringing up a new node. |
| You can choose to let the service scale in response to traffic _(automatic scaling)_ or you can specify a number of nodes to run constantly to avoid latency _(manual scaling)_.<br>- If you choose automatic scaling, the number of nodes scales automatically. For Inference in Gemini platform legacy (MLS1) machine type deployments, the number of nodes can scale down to zero for no-traffic durations. Gemini platform deployments and other types of Inference in Gemini platform deployments cannot scale down to zero nodes.<br>- If you choose manual scaling, you specify a number of nodes to keep running all the time. You are charged for all of the time that these nodes are running, starting at the time of deployment and persisting until you delete the model version. | You can affect scaling by setting a maximum number of nodes to use for a batch prediction job, and by setting the number of nodes to keep running for a model when you deploy it. |

**Batch prediction jobs are charged after job completion**

Batch prediction jobs are charged after job completion, not incrementally during the job. Any Cloud Billing budget alerts that you have configured aren't triggered while a job is running. Before starting a large job, consider running some cost benchmark jobs with small input data first.

**Example of a prediction calculation**

A real-estate company in an Americas region runs a weekly prediction of housing values in areas it serves. In one month, it runs predictions for four weeks in batches of 3920, 4277, 3849, and 3961. Jobs are limited to one node and each instance takes an average of 0.72 seconds of processing.

First calculate the length of time that each job ran:

Calculations

- Calculations

1

```
3920 instances * (0.72 seconds / 1 instance) * (1 minute / 60 seconds) = 47.04 minutes
```

2

```
4277 instances * (0.72 seconds / 1 instance) * (1 minute / 60 seconds) = 51.324 minutes
```

3

```
3849 instances * (0.72 seconds / 1 instance) * (1 minute / 60 seconds) = 46.188 minutes
```

4

```
3961 instances * (0.72 seconds / 1 instance) * (1 minute / 60 seconds) = 47.532 minutes
```

_content\_copy_

Each job ran for more than ten minutes, so it is charged for each minute of processing:

Calculations

- Calculations

1

```
($0.0909886 / 1 node hour) * (1 hour / 60 minutes) * 48 minutes * 1 node = $0.0632964
```

2

```
($0.0909886 / 1 node hour) * (1 hour / 60 minutes) * 52 minutes * 1 node = $0.0685711
```

3

```
($0.0909886 / 1 node hour) * (1 hour / 60 minutes) * 47 minutes * 1 node = $0.061977725
```

4

```
($0.0909886 / 1 node hour) * (1 hour / 60 minutes) * 48 minutes * 1 node = $0.0632964
```

_content\_copy_

The total charge for the month is $0.26.

This example assumed jobs ran on a single node and took a consistent amount of time per input instance. In real usage, make sure to account for multiple nodes and use the actual amount of time each node spends running for your calculations.

### Charges for Explainable AI in Gemini platform

**Feature-based explanations**

[Feature-based explanations](https://cloud.google.com/vertex-ai/docs/explainable-ai/overview#feature-based) come at no extra charge to prediction prices. However, explanations take longer to process than normal predictions, so heavy usage of Explainable AI in Gemini platform along with auto-scaling could result in more nodes being started, which would increase prediction charges.

**Example-based explanations**

Pricing for [example-based explanations](https://cloud.google.com/vertex-ai/docs/explainable-ai/overview#example-based) consists of the following:

- When you upload a model or update a model's dataset, you are billed:
- per node hour for the batch prediction job that is used to generate the latent space representations of examples. This is billed at the same rate as [prediction](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#prediction-and-explanation).
- a cost for building or updating indexes. This cost is the same as the indexing costs for [Vector Search](https://cloud.google.com/vertex-ai/pricing#vectorsearch), which is **number of examples \* number of dimensions \* 4 bytes per float \* $3.00 per GB**. For example, if you have 1 million examples and 1,000 dimension latent space, the cost is $12 (1,000,000 \* 1,000 \* 4 \* 3.00 / 1,000,000,000).
- When you deploy to an endpoint, you are billed per node hour for each node in your endpoint. All compute associated with the endpoint is charged at same rate as [prediction](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#prediction-and-explanation). However, because Example-based explanations require additional compute resources to serve the Vector Search index, this results in more nodes being started which increases prediction charges.

## Neural Architecture Search in Gemini platform

The following tables summarize the pricing in each region where Neural Architecture Search is available.

### Prices

The following tables provide the _price per hour_ of various configurations.

You can choose a predefined scale tier or a custom configuration of selected machine types. If you choose a custom configuration, sum the costs of the virtual machines you use.

Accelerator-enabled legacy machine types include the cost of the accelerators in their pricing. If you use Compute Engine machine types and attach accelerators, the cost of the accelerators is separate. To calculate this cost, multiply the prices in the following table of accelerators by the number of each type of accelerator you use.

### Machine types

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| n1-standard-4 | $0.2849985 / 1 hour | $0.25649865 / 1 hour | $0.2279988 / 1 hour |
| n1-standard-8 | $0.569997 / 1 hour | $0.5129973 / 1 hour | $0.4559976 / 1 hour |
| n1-standard-16 | $1.139994 / 1 hour | $1.0259946 / 1 hour | $0.9119952 / 1 hour |
| n1-standard-32 | $2.279988 / 1 hour | $2.0519892 / 1 hour | $1.8239904 / 1 hour |
| n1-standard-64 | $4.559976 / 1 hour | $4.1039784 / 1 hour | $3.6479808 / 1 hour |
| n1-standard-96 | $6.839964 / 1 hour | $6.1559676 / 1 hour | $5.4719712 / 1 hour |
| n1-highmem-2 | $0.1774545 / 1 hour | $0.15970905 / 1 hour | $0.1419636 / 1 hour |
| n1-highmem-4 | $0.1774545 / 1 hour | $0.15970905 / 1 hour | $0.1419636 / 1 hour |
| n1-highmem-8 | $0.709818 / 1 hour | $0.6388362 / 1 hour | $0.5678544 / 1 hour |
| n1-highmem-16 | $1.419636 / 1 hour | $1.2776724 / 1 hour | $1.1357088 / 1 hour |
| n1-highmem-32 | $2.839272 / 1 hour | $2.5553448 / 1 hour | $2.2714176 / 1 hour |
| n1-highmem-64 | $5.678544 / 1 hour | $5.1106896 / 1 hour | $4.5428352 / 1 hour |
| n1-highmem-96 | $8.517816 / 1 hour | $7.6660344 / 1 hour | $6.8142528 / 1 hour |
| n1-highcpu-16 | $0.8501832 / 1 hour | $0.76516488 / 1 hour | $0.68014656 / 1 hour |
| n1-highcpu-32 | $1.7003664 / 1 hour | $1.53032976 / 1 hour | $1.36029312 / 1 hour |
| n1-highcpu-64 | $3.4007328 / 1 hour | $3.06065952 / 1 hour | $2.72058624 / 1 hour |
| n1-highcpu-96 | $5.1010992 / 1 hour | $4.59098928 / 1 hour | $4.08087936 / 1 hour |
| a2-highgpu-1g | $5.641070651 / 1 hour | $5.076963586 / 1 hour | $4.512856521 / 1 hour |
| a2-highgpu-2g | $11.282141301 / 1 hour | $10.153927171 / 1 hour | $9.025713041 / 1 hour |
| a2-highgpu-4g | $22.564282603 / 1 hour | $20.307854342 / 1 hour | $18.051426082 / 1 hour |
| a2-highgpu-8g | $45.128565205 / 1 hour | $40.615708685 / 1 hour | $36.102852164 / 1 hour |
| a2-highgpu-16g | $90.257130411 / 1 hour | $81.23141737 / 1 hour | $72.205704329 / 1 hour |
| e2-standard-4 | $0.20103426 / 1 hour | $0.180930844 / 1 hour | $0.160827408 / 1 hour |
| e2-standard-8 | $0.40206852 / 1 hour | $0.361861688 / 1 hour | $0.321654816 / 1 hour |
| e2-standard-16 | $0.80413704 / 1 hour | $0.723723376 / 1 hour | $0.643309632 / 1 hour |
| e2-standard-32 | $1.60827408 / 1 hour | $1.447446752 / 1 hour | $1.286619264 / 1 hour |
| e2-highmem-2 | $0.13559949 / 1 hour | $0.12203955 / 1 hour | $0.108479592 / 1 hour |
| e2-highmem-4 | $0.27119898 / 1 hour | $0.2440791 / 1 hour | $0.216959184 / 1 hour |
| e2-highmem-8 | $0.54239796 / 1 hour | $0.4881582 / 1 hour | $0.433918368 / 1 hour |
| e2-highmem-16 | $1.08479592 / 1 hour | $0.9763164 / 1 hour | $0.867836736 / 1 hour |
| e2-highcpu-16 | $0.59364288 / 1 hour | $0.534278608 / 1 hour | $0.474914304 / 1 hour |
| e2-highcpu-32 | $1.18728576 / 1 hour | $1.068557216 / 1 hour | $0.949828608 / 1 hour |
| n2-standard-4 | $0.291354 / 1 hour | $0.2622186 / 1 hour | $0.2330832 / 1 hour |
| n2-standard-8 | $0.582708 / 1 hour | $0.5244372 / 1 hour | $0.4661664 / 1 hour |
| n2-standard-16 | $1.165416 / 1 hour | $1.0488744 / 1 hour | $0.9323328 / 1 hour |
| n2-standard-32 | $2.330832 / 1 hour | $2.0977488 / 1 hour | $1.8646656 / 1 hour |
| n2-standard-48 | $3.496248 / 1 hour | $3.1466232 / 1 hour | $2.7969984 / 1 hour |
| n2-standard-64 | $4.661664 / 1 hour | $4.1954976 / 1 hour | $3.7293312 / 1 hour |
| n2-standard-80 | $5.82708 / 1 hour | $5.244372 / 1 hour | $4.661664 / 1 hour |
| n2-highmem-2 | $0.196521 / 1 hour | $0.1768689 / 1 hour | $0.1572168 / 1 hour |
| n2-highmem-4 | $0.393042 / 1 hour | $0.3537378 / 1 hour | $0.3144336 / 1 hour |
| n2-highmem-8 | $0.786084 / 1 hour | $0.7074756 / 1 hour | $0.6288672 / 1 hour |
| n2-highmem-16 | $1.572168 / 1 hour | $1.4149512 / 1 hour | $1.2577344 / 1 hour |
| n2-highmem-32 | $3.144336 / 1 hour | $2.8299024 / 1 hour | $2.5154688 / 1 hour |
| n2-highmem-48 | $4.716504 / 1 hour | $4.2448536 / 1 hour | $3.7732032 / 1 hour |
| n2-highmem-64 | $6.288672 / 1 hour | $5.6598048 / 1 hour | $5.0309376 / 1 hour |
| n2-highmem-80 | $7.86084 / 1 hour | $7.074756 / 1 hour | $6.288672 / 1 hour |
| n2-highcpu-16 | $0.860352 / 1 hour | $0.7743168 / 1 hour | $0.6882816 / 1 hour |
| n2-highcpu-32 | $1.720704 / 1 hour | $1.5486336 / 1 hour | $1.3765632 / 1 hour |
| n2-highcpu-64 | $3.441408 / 1 hour | $3.0972672 / 1 hour | $2.7531264 / 1 hour |
| n2-highcpu-80 | $4.30176 / 1 hour | $3.871584 / 1 hour | $3.441408 / 1 hour |
| c2-standard-4 | $0.313212 / 1 hour | $0.2818908 / 1 hour | $0.2505696 / 1 hour |
| c2-standard-8 | $0.626424 / 1 hour | $0.5637816 / 1 hour | $0.5011392 / 1 hour |
| c2-standard-16 | $1.252848 / 1 hour | $1.1275632 / 1 hour | $1.0022784 / 1 hour |
| c2-standard-30 | $2.34909 / 1 hour | $2.114181 / 1 hour | $1.879272 / 1 hour |
| c2-standard-60 | $4.69818 / 1 hour | $4.228362 / 1 hour | $3.758544 / 1 hour |
| c4-standard-2 | $0.1113959 / 1 hour | $0.10025631 / 1 hour | $0.08911672 / 1 hour |
| c2-standard-4 | $0.2273205 / 1 hour | $0.20458845 / 1 hour | $0.1818564 / 1 hour |
| c4-standard-8 | $0.454641 / 1 hour | $0.4091769 / 1 hour | $0.3637128 / 1 hour |
| c4-standard-16 | $0.909282 / 1 hour | $0.8183538 / 1 hour | $0.7274256 / 1 hour |
| c4-standard-24 | $1.363923 / 1 hour | $1.2275307 / 1 hour | $1.0911384 / 1 hour |
| c4-standard-32 | $1.818564 / 1 hour | $1.6367076 / 1 hour | $1.4548512 / 1 hour |
| c4-standard-48 | $2.727846 / 1 hour | $2.4550614 / 1 hour | $2.1822768 / 1 hour |
| c4-standard-96 | $5.455692 / 1 hour | $4.9101228 / 1 hour | $4.3645536 / 1 hour |
| c4-standard-144 | $8.183538 / 1 hour | $7.3651842 / 1 hour | $6.5468304 / 1 hour |
| c4-standard-192 | $10.911384 / 1 hour | $9.8202456 / 1 hour | $8.7291072 / 1 hour |
| c4-standard-288 | $16.367076 / 1 hour | $14.7303684 / 1 hour | $13.0936608 / 1 hour |
| c4-highcpu-2 | $0.0978098 / 1 hour | $0.08802882 / 1 hour | $0.07824784 / 1 hour |
| c4-highcpu-4 | $0.1956196 / 1 hour | $0.17605764 / 1 hour | $0.15649568 / 1 hour |
| c4-highcpu-8 | $0.3912392 / 1 hour | $0.35211528 / 1 hour | $0.31299136 / 1 hour |
| c4-highcpu-16 | $0.7824784 / 1 hour | $0.70423056 / 1 hour | $0.62598272 / 1 hour |
| c4-highcpu-24 | $1.1737176 / 1 hour | $1.05634584 / 1 hour | $0.93897408 / 1 hour |
| c4-highcpu-32 | $0.3912392 / 1 hour | $0.35211528 / 1 hour | $0.31299136 / 1 hour |
| c4-highcpu-48 | $2.3474352 / 1 hour | $2.11269168 / 1 hour | $1.87794816 / 1 hour |
| c4-highcpu-96 | $4.6948704 / 1 hour | $4.22538336 / 1 hour | $3.75589632 / 1 hour |
| c4-highcpu-144 | $7.0423056 / 1 hour | $6.33807504 / 1 hour | $5.63384448 / 1 hour |
| c4-highcpu-192 | $9.3897408 / 1 hour | $8.45076672 / 1 hour | $7.51179264 / 1 hour |
| c4-highcpu-288 | $14.0846112 / 1 hour | $12.67615008 / 1 hour | $11.26768896 / 1 hour |
| c4-highmem-2 | $0.1476255 / 1 hour | $0.13286295 / 1 hour | $0.1181004 / 1 hour |
| c4-highmem-4 | $0.2997797 / 1 hour | $0.26980173 / 1 hour | $0.23982376 / 1 hour |
| c4-highmem-8 | $0.5995594 / 1 hour | $0.53960346 / 1 hour | $0.47964752 / 1 hour |
| c4-highmem-16 | $1.1991188 / 1 hour | $1.07920692 / 1 hour | $0.95929504 / 1 hour |
| c4-highmem-24 | $1.7941495 / 1 hour | $1.61473455 / 1 hour | $1.4353196 / 1 hour |
| c4-highmem-32 | $2.3982376 / 1 hour | $2.15841384 / 1 hour | $1.91859008 / 1 hour |
| c4-highmem-48 | $3.5973564 / 1 hour | $3.23762076 / 1 hour | $2.87788512 / 1 hour |
| c4-highmem-96 | $7.1947128 / 1 hour | $6.47524152 / 1 hour | $5.75577024 / 1 hour |
| c4-highmem-144 | $10.7920692 / 1 hour | $9.71286228 / 1 hour | $8.63365536 / 1 hour |
| c4-highmem-192 | $14.3894256 / 1 hour | $12.95048304 / 1 hour | $11.51154048 / 1 hour |
| c4-highmem-288 | $21.5841384 / 1 hour | $19.42572456 / 1 hour | $17.26731072 / 1 hour |
| c4-highmem-288-metal | $21.5841384 / 1 hour | $19.42572456 / 1 hour | $17.26731072 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

Prices for a2-highgpu instances include the charges for the attached NVIDIA\_TESLA\_A100 Accelerators.

### Accelerators

Iowa (us-central1)

- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Finland (europe-north1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Montreal (northamerica-northeast1)
- Sao Paulo (southamerica-east1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| GPU type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| NVIDIA\_TESLA\_A100 | $4.400862 / 1 hour | $3.9607758 / 1 hour | $3.5206896 / 1 hour |
| NVIDIA\_TESLA\_P4 | $0.90 / 1 hour | $0.81 / 1 hour | $0.72 / 1 hour |
| NVIDIA\_TESLA\_P100 | $2.19 / 1 hour | $1.971 / 1 hour | $1.752 / 1 hour |
| NVIDIA\_TESLA\_T4 | $0.525 / 1 hour | $0.4725 / 1 hour | $0.42 / 1 hour |
| NVIDIA\_TESLA\_V100 | $3.72 / 1 hour | $3.348 / 1 hour | $2.976 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

### Disks

Iowa (us-central1)

- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Finland (europe-north1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Montreal (northamerica-northeast1)
- Sao Paulo (southamerica-east1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Disk type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| pd-standard | $0.000082192 / 1 gibibyte hour | $0.000073973 / 1 gibibyte hour | $0.000065753 / 1 gibibyte hour |
| pd-ssd | $0.000349315 / 1 gibibyte hour | $0.000314384 / 1 gibibyte hour | $0.000279452 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

Notes:

1. All use is subject to the Neural Architecture Search quota policy.
2. You are required to store your data and program files in Cloud Storage buckets during the Neural Architecture Search lifecycle. See [more about Cloud Storage usage](https://cloud.google.com/vertex-ai/pricing#gcs).
3. For volume-based discounts, [contact the Sales team](https://cloud.google.com/contact).
4. The disk price is only charged when you configure the disk size of each VM to be larger than 100 GB. There is no charge for the first 100 GB (the default disk size) of disk for each VM. For example, if you configure each VM to have 105 GB of disk, then you are charged for 5 GB of disk for each VM.

### Required use of Cloud Storage

In addition to the costs described in this document, you are required to store data and program files in Cloud Storage buckets during the Neural Architecture Search lifecycle. This storage is subject to the [Cloud Storage pricing policy](https://cloud.google.com/storage/pricing).

Required use of Cloud Storage includes:

- Staging your training application package.
- Storing your training input data.

**Note:** You can use another Google Cloud service to store your input data, such as BigQuery, which has its own associated [pricing](https://cloud.google.com/bigquery/pricing).

- Storing the output of your jobs. Neural Architecture Search doesn't require long-term storage of these items. You can remove the files as soon as the operation is complete.

### Free operations for managing your resources

The resource management operations provided by Neural Architecture Search are available free of charge. The Neural Architecture Search quota policy does limit some of these operations.

| Resource | Free operations |
| jobs | get, list, cancel |
| operations | get, list, cancel, delete |

## Pipelines in Gemini platform

Pipelines in Gemini platform charges a run execution fee of $0.03 per Pipeline Run. You are not charged the execution fee during the Preview release. You also pay for Google Cloud resources you use with Pipelines in Gemini platform, such as Compute Engine resources consumed by pipeline components (charged at the same rate as for [Managed Training in Gemini platform](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#training)). Finally, you are responsible for the cost of any services (such as Dataflow) called by your pipeline.

## Feature Store in Gemini platform

Feature Store in Gemini platform is Generally Available (GA) since November 2023. For information on the previous version of the product go to [Feature Store (Legacy) in Gemini platform](https://cloud.google.com/vertex-ai/docs/featurestore/overview).

### New Feature Store in Gemini platform

The new Feature Store in Gemini platform supports functionality across 2 types of operations:

- **Offline operations** are operations to transfer, store, retrieve and transform data in the offline store (BigQuery)
- **Online operations** are operations to transfer data into the online store(s) and operations on data while it is in the online store(s).

**Offline Operations Pricing**

Since BigQuery is used for offline operations, please refer to [BigQuery pricing](https://cloud.google.com/bigquery/pricing) for functionality such as ingestion to the offline store, querying the offline store, and offline storage.

**Online Operations Pricing﻿**

For online operations, Feature Store in Gemini platform charges for any GA features to transfer data into the online store, serve data or store data. A _node-hour_ represents the time a virtual machine spends to complete an operation, charged to the minute.

Iowa (us-central1)

- Johannesburg (africa-south1)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Warsaw (europe-central2)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Milan (europe-west8)
- Doha (me-central1)
- Dammam (me-central2)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)

Show discount options

HourlyHourly

MonthlyMonthly

| Operation | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| Data processing node<br>_Data processing (e.g. ingesting into any online_<br>_store, monitoring, etc.)_ | $0.08 / 1 hour | $0.072 / 1 hour | $0.064 / 1 hour |
| Optimized online serving node<br>_Low latency serving and embeddings serving_<br>_Each node includes 200GB of storage_ | $0.30 / 1 hour | $0.27 / 1 hour | $0.24 / 1 hour |
| Bigtable online serving node<br>_Serving with Cloud Bigtable_ | $0.94 / 1 hour | $0.846 / 1 hour | $0.752 / 1 hour |
| Bigtable online serving storage<br>_Storage for serving with Cloud Bigtable_ | $0.000342466 / 1 gibibyte hour | $0.000308219 / 1 gibibyte hour | $0.000273973 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

Optimized online serving and Bigtable online serving use different architectures, so their nodes are not comparable.

If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

**Online Operations Workload Estimates**

Consider the following guidelines when estimating your workloads. The number of nodes required for a given workload may differ across each serving approach.

- Data processing:
- Ingestion - One node can ingest approximately a minimum of 100 MiB of data per hour into a Bigtable Online Store or an Optimized Online Store if no analytical functions are used.
- Bigtable online serving: Each node can support approximately 15,000 QPS and up to 5 TB of storage.
- Optimized online serving: Performance is based on the machine type and replicas, which are automatically configured to minimize costs subject to the workload. Each node can have a minimum of 2 and a maximum of 6 replicas for high availability and autoscaling. You're charged for the number of replicas accordingly. For more details, see the [example monthly scenarios](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#example-monthly-scenarios).
- For non embeddings-related workloads, each node can support approximately 500 QPS and up to 200 GB of storage.
- For embeddings-related workloads, each node can support approximately 500 QPS and up to 4 GB of storage of 512 dimensional data.

You can view the number of nodes (with replicas) in the Metric Explorer:

![Metric Explorer to figure out the number of nodes been used.](https://www.gstatic.com/bricks/image/bcc4aa38-4e03-4550-a5ed-6e9529063a7e.png)

Metric Explorer to figure out the number of nodes been used.

**Example Monthly Scenarios (assuming us-central1)**

**﻿** Data streaming workload - Bigtable online serving with 2.5 TB of data (1 GB refreshed daily) and 1200 QPS

| Operations | Monthly Usage | Monthly Cost |
| Data processing node | (1 GB/day) \* (30 days/month) \* (1,000 MB/GB) \* (1 node-hr / 100 MB) = 300 node-hr | 300 node-hr \* ($0.08 per node-hr) = $24 |
| Optimized online serving node | N/A | N/A |
| Bigtable online serving node | (1 node) \* (24 hr/day) \* (30 days/month) = 720 node-hr | 720 node-hr \* ($0.94 per node-hr) = $677 |
| Bigtable online serving storage | (2.5 TB-month) \* (1000 GB/TB) = 2500 GB-month | 2500 GB-month \* ($0.25 per GB-month) = $625 |
| _Total_ |  | _$1,326_ |

High QPS workload - Optimized online serving with 10GB of non-embedding data (5GB refreshed daily) and 2000QPS

| Operations | Monthly Usage | Monthly Cost |
| Data processing node | (5 GB/day) \* (30 days/month) \* (1,000 MB/GB) \* (1 node-hr / 100MB) = 1500 node-hr | 1500 node-hr \* ($0.08 per node-hr) = $120 |
| Optimized online serving node | Roundup(10GB \* (1 node / 200 GB)) = 1 \* max(2 default replicas, 2000 QPS \* (1 replica / 500 QPS)) = 4 total nodes \* (24 hr/day) \* (30days/month) =2880 node-hr | 2880 node-hr \* (0.30 per node-hr) = $864 |
| Bigtable online serving node | N/A | N/A |
| Bigtable online serving storage | N/A | N/A |
| _Total_ |  | _$984_ |

Embeddings serving workload - Optimized online serving with 20GB of embeddings data (2GB refreshed daily) and 800QPS

| Operations | Monthly Usage | Monthly Cost |
| Data processing node | (2 GB/day) \* (30 days/month) \* (1,000 MB/GB) \* (1 node-hr / 100MB) = 600 node-hr | 600 node-hr \* ($0.08 per node-hr) = $48 |
| Optimized online serving node | Roundup(20GB\* (1 node / 4GB) = 5 \* max(2 default replicas, 800 QPS \* (1 replica / 500 QPS)) = 10 total nodes \* (24 hr/day) \* (30days/month) = 7200 node-hr | 7200 node-hr \* (0.30 per node-hr) = $2160 |
| Bigtable online serving node | N/A | N/A |
| Bigtable online serving storage | N/A | N/A |
| _Total_ |  | _$2,208_ |

### Feature Store (Legacy) in Gemini platform

Prices for Feature Store (Legacy) in Gemini platform are based on the amount of feature data in online and offline storage as well as the availability of online serving. A _node per hour_ represents the time a virtual machine spends serving feature data or waiting in a ready state to handle feature data requests.

| Operation | Price (USD) |
| Online storage | $0.25 per GB-month |
| Offline storage | $0.023 per GB-month |
| Online serving | $0.94 per node per hour |
| Batch export | $0.005 per GB |
| Streaming ingestion | $0.10 per GB of ingestion |

If you pay in a currency other than USD, the prices listed in your currency on [Cloud Platform SKUs](https://cloud.google.com/skus/) apply.

When you enable feature value monitoring, billing includes applicable charges above in addition to applicable charges that follow:

- $3.50 per GB for all data analyzed. With snapshot analysis enabled, snapshots taken for data in Feature Store (Legacy) in Gemini platform are included. With import feature analysis enabled, batches of ingested data are included.
- Additional charges for other Feature Store (Legacy) in Gemini platform operations used with feature value monitoring include the following:
- The snapshot analysis feature periodically takes a snapshot of the feature values based on your configuration for the monitoring interval.
- The charge for a snapshot export is the same as a regular batch export operation.

**Snapshot Analysis Example**

A data scientist enables feature value monitoring for their Feature Store (Legacy) in Gemini platform and turns on monitoring for a daily snapshot analysis. A pipeline runs daily for the entity types monitoring. The pipeline scans 2GB of data in Feature Store (Legacy) in Gemini platform and exports a snapshot containing 0.1GB of data. The total charge for one day's analysis is:

(0.1 GB \* $3.50) + (2 GB \* $0.005) = $0.36

**Ingestion Analysis Example**

A data scientist enables feature value monitoring for their Feature Store (Legacy) in Gemini platform and turns on monitoring for ingestion operations. An ingestion operation imports 1GB of data into Feature Store (Legacy) in Gemini platform. The total charge for feature value monitoring is:

(1 GB \* $3.50) = $3.50

## ML Metadata in Gemini platform

Metadata storage is measured in binary gigabytes (GiB), where 1 GiB is 1,073,741,824 bytes. This unit of measurement is also known as a gibibyte.

ML Metadata in Gemini platform charges $10 per gibibyte (GiB) per month for metadata storage. Prices are pro-rated per megabyte (MB). For example, if you store 10 MB of metadata, you are charged $0.10 per month for that 10 MB of metadata.

Prices are the same in all regions where ML Metadata in Gemini platform is supported.

## TensorBoard in Gemini platform

To use TensorBoard in Gemini platform, request that the IAM administrator of the project assign you to the role ["Gemini platform TensorBoard Web App User"](https://cloud.google.com/vertex-ai/docs/general/access-control?_gl=1*z5or5y*_ga*MjEyMDg4MTg1MS4xNjgwMjg5NjA4*_ga_4LYFWVHBEB*MTY4MTI0NzgzMi4zLjEuMTY4MTI0Nzg0Mi4wLjAuMA#aiplatform.tensorboardWebAppUser). The Gemini platform Administrator role also has access.

Beginning in August 2023, TensorBoard in Gemini platform pricing changed from a per-user monthly license of $300/month to $10 GiB/month for data storage of logs and metrics. This means no more subscription fees. You will only pay for the storage you’ve used. See the [TensorBoard in Gemini platform: Delete Outdated TensorBoard Experiments](https://github.com/GoogleCloudPlatform/vertex-ai-samples/blob/main/notebooks/official/experiments/delete_outdated_tensorboard_experiments.ipynb) tutorial for how to manage storage.

## Vizier in Gemini platform

Vizier in Gemini platform is a black-box optimization service inside Gemini platform. The Vizier in Gemini platform pricing model consists of the following:

- There is no charge for trials that use RANDOM\_SEARCH and GRID\_SEARCH. [Learn more about the search algorithms](https://cloud.google.com/vertex-ai/docs/vizier/overview#search_algorithms).
- The first 100 Vizier in Gemini platform trials per calendar month are available at no charge (trials using RANDOM\_SEARCH and GRID\_SEARCH do not count against this total).
- After 100 Vizier in Gemini platform trials, subsequent trials during the same calendar month are charged at $1 per trial (trials that use RANDOM\_SEARCH or GRID\_SEARCH incur no charges).

## Agent Retrieval

Agent Retrieval is a fully managed retrieval engine that unifies vector indexing and payload storage into a single service. Pricing is based on two main components: **Index Serving** (the compute resources provisioned for Approximate Nearest Neighbor or ANN search) and the **Payload Database** (the storage and operations for your vectors and documents).

**1\. Index Serving (ANN)**

Index Serving Capacity Units (CUs) are used exclusively for Approximate Nearest Neighbor (ANN) indexes.

Show discount options

HourlyHourly

MonthlyMonthly

| Component | Price<br>\* (USD)_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 | Description |
| **Storage-Optimized CU** | $2.30 / 1 hour | $2.07 / 1 hour | $1.84 / 1 hour | Includes 1TB SSD. Designed for large datasets. |
| **Performance-Optimized CU** | $0.065 / 1 hour | $0.0585 / 1 hour | $0.052 / 1 hour | Includes 2GB RAM. |
| **Data Write / Update** | $0.45 / 1 gibibyte | $0.405 / 1 gibibyte | $0.36 / 1 gibibyte | Applies to any index updates (writing/updating data in the ANN index) including initial index build and full index overwrite. |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

**2\. Payload Database (Storage & Operations)**

The integrated database stores your data and can be also queried directly for exact K-Nearest Neighbor (KNN) searches.

Show discount options

HourlyHourly

MonthlyMonthly

| **Component** | **Price**<br>\* (USD)_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 | **Description** |
| **Data Stored** | $0.000410959 / 1 gibibyte hour | $0.000369863 / 1 gibibyte hour | $0.000328767 / 1 gibibyte hour | Monthly storage cost for vectors and metadata. |
| **Read Operations** | $0.06 / 100,000 count | $0.054 / 100,000 count | $0.048 / 100,000 count | Charged for search queries and direct reads. _(See calculation details below)._ |
| **Write/Update/Delete Operations** | $0.18 / 100,000 count | $0.162 / 100,000 count | $0.144 / 100,000 count | Charged for data modification. _(1 document = 1 write operation)._ |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

**3\. Additional Search Components﻿**

| **Component** | **Price** |
| **Embedding Model** | Billed separately based on the price of the customer-selected embedding model. |

**Understanding Database Operations Metering**

Database operations are calculated based on how you interact with your data:

- **Search Queries:** When executing a search query, the total number of read operations is calculated as the sum of the **Index Scan Cost** plus the **Document Retrieval Cost**.
- _Index Scan Cost:_ 1 read operation for each batch of up to 100 data objects in the index.
- _Document Retrieval Cost:_ 1 read operation for each individual document returned.
- **Direct Document Reads:** When reading documents directly from the database, 1 document = 1 read operation.
- **Writes / Updates / Deletes:** 1 document = 1 write operation.

## Vector Search

Pricing for Vector Search **Approximate Nearest Neighbor** service consists of:

- Per node hour pricing for each VM used to host a deployed index.
- A cost for building new indexes, updating existing indexes, and using streaming index updates.

Data processed during building and updating indexes is measured in binary gigabytes (GiB), where 1 GiB is 1,073,741,824 bytes. This unit of measurement is also known as a gibibyte.

Vector Search charges $3.00 per gibibyte (GiB) of data processed in all regions. Vector Search charges $0.45/GiB ingested for Streaming Update inserts.

The following tables summarize the pricing of an index serving in each region where the Vector Search is available. The price corresponds to the machine type, by region, and is charged per node hour.

Iowa (us-central1)

- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| e2-standard-2 | $0.0938084 / 1 hour | $0.08442756 / 1 hour | $0.07504672 / 1 hour |
| e2-standard-16 | $0.7504672 / 1 hour | $0.67542048 / 1 hour | $0.60037376 / 1 hour |
| e2-highmem-16 | $1.012368 / 1 hour | $0.9111312 / 1 hour | $0.8098944 / 1 hour |
| n2d-standard-32 | $1.8926208 / 1 hour | $1.70335872 / 1 hour | $1.51409664 / 1 hour |
| n1-standard-16 | $1.0639944 / 1 hour | $0.95759496 / 1 hour | $0.85119552 / 1 hour |
| n1-standard-32 | $2.1279888 / 1 hour | $1.91518992 / 1 hour | $1.70239104 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### Vector Search pricing examples

Vector Search pricing is determined by the size of your data, the amount of queries per second (QPS) you want to run, and the number of nodes you use. To get your estimated serving cost, you need to calculate your total data size. Your data size is the number of your embeddings/vectors\* the number of dimensions you have\* 4 bytes per dimension. After you have the size of your data you can calculate the serving cost and the building cost. The serving cost plus the building cost equals your monthly total cost.

Dataset size and restricts (filtering) affect shard count. A high number of restricts increases memory usage and causes more shards to be created in order to distribute memory load.

- Serving cost: # replicas/shard \* # shards (~data size/shard size) \* hourly cost \* 730 hours
- Building cost: data size(in GiB) \* $3/GiB \* # of updates/month

**Streaming update:** Vector Search uses heuristics-based metrics to determine when to trigger compaction. If the oldest uncompacted data is five days old, compaction is always triggered. You are billed for the cost of rebuilding the index at the same rate of a batch update, in addition to the streaming update costs.

| Number of embeddings/vectors | Number of dimensions | Queries per second (QPS) | Machine Type | Nodes | Estimated monthly serving cost (USD) |
| 2 million | 128 | 100 | e2-standard-2 | 1 | $68 |
| 20 million | 256 | 1,000 | e2-standard-16 | 1 | $547 |
| 20 million | 256 | 3,000 | e2-standard-16 | 3 | $1,642 |
| 100 million | 256 | 500 | e2-highmem-16 | 2 | $1,477 |
| 1 billion | 100 | 500 | e2-highmem-16 | 8 | $5,910 |

All examples are based on machine types in us-central1. The cost you incur will vary with recall rate and latency requirements. The estimated monthly serving cost is directly related to the number of nodes used in the console. To learn more about configuration parameters that affect cost, see [Configuration parameters which affect recall and latency.](https://cloud.google.com/vertex-ai/docs/vector-search/configuring-indexes)

If you have high queries per second (QPS), batching these queries can reduce total costs up to 30%-40%.

### Storage-optimized Vector Search tier

Instead of managing and paying for individual VMs and separate compaction jobs, there are two SKUs:

- Capacity Units (CUs): This is the primary meter for serving. A CU is a bundled unit of compute and active SSD storage, up to 1 TiB each, priced at $2.30 per CU, per hour, per replica. This single rate includes the cost of serving and ongoing index management. The service auto-scales and additional CUs are added, as the index size grows.
- Write Units: To add data, there is a charge of $0.45 per GiB. Create Index and Complete Overwrite would be charged for the full index size. The charge applies to both batch and streaming index updates.

Show discount options

HourlyHourly

MonthlyMonthly

| Unit | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| Storage-Optimized Capacity Unit | $2.30 / 1 hour | $2.07 / 1 hour | $1.84 / 1 hour |
| Write Unit | $0.45 / 1 gibibyte | $0.405 / 1 gibibyte | $0.36 / 1 gibibyte |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

## Model Registry

The Model Registry is a central repository which tracks and lists your models and model versions. You can import models into Gemini platform and they appear in the Model Registry. There is no cost associated with having your models in the Model Registry. Cost is only incurred when you deploy the model to an endpoint or perform a batch prediction on the model. This cost is determined by the type of model you are deploying.

To learn more about pricing for deploying custom models from the Model Registry, see [Custom-trained models](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#custom-trained-models). To learn more about pricing for deploying AutoML models, see [Pricing for AutoML models](https://cloud.google.com/products/gemini-enterprise-agent-platform/pricing#pricing-for-automl-models).

## Model Monitoring in Gemini platform

Gemini platform enables you to monitor the continued effectiveness of your model after you deploy it to production. For more information, see [Introduction to Model Monitoring in Gemini platform](https://cloud.google.com/vertex-ai/docs/model-monitoring/overview).

When you use Model Monitoring in Gemini platform, you are billed for the following:

- $3.50 per GB for all data analyzed, including the training data provided and prediction data logged in a BigQuery table.
- Charges for other Google Cloud products that you use with Model Monitoring, such as BigQuery storage or Batch Explain when attribution monitoring is enabled.

Model Monitoring in Gemini platform is supported in the following regions: us-central1, europe-west4, asia-east1, and asia-southeast1. Prices are the same for all regions.

Data sizes are measured after they are converted to TfRecord format.

Training datasets incur a one-time charge when you set up a Model Monitoring in Gemini platform job.

Prediction Datasets consist of logs collected from the Online Prediction service. As prediction requests arrive during different time windows, the data for each time window is collected and the sum of the data analyzed for each prediction window is used to calculate the charge.

Example: A data scientist runs model monitoring on the prediction traffic belonging to their model.

- The model is trained from a BigQuery dataset. The data size after converting to TfRecord is 1.5GB.
- Prediction data logged between 1:00 - 2:00 p.m. is 0.1 GB, between 3:00 - 4:00 p.m. is 0.2 GB.
- The total price for setting up the model monitoring job is:
- (1.5 GB \* $3.50) + ((0.1 GB + 0.2 GB) \* $3.50) = $6.30

## Workbench in Gemini platform

Select the instance configuration for pricing information.

### Instances

The tables below provide the approximate price per hour of various VM configurations. You can choose a custom configuration of selected machine types. To calculate pricing, sum the costs of the virtual machines you use.

If you use Compute Engine machine types and attach accelerators, the cost of the accelerators is separate. To calculate this cost, multiply the prices in the table of accelerators below by how many machine hours of each type of accelerator you use.

To calculate cost for machine types where a price isn't listed here, use the [Compute Engine Price](https://cloud.google.com/products/compute/pricing) for that machine type and add the corresponding Management Fee(s) shown in the tables below (CPU, Memory and Disk, plus the accelerator table for GPUs).

### CPUs

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Stockholm (europe-north2)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Berlin (europe-west10)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)
- Phoenix (us-west8)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price per vCPU (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 | Management Fee<br>\* (USD)_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| N1 | $0.0379332 / 1 hour | $0.03413988 / 1 hour | $0.03034656 / 1 hour | $0.0063222 / 1 hour | $0.00568998 / 1 hour | $0.00505776 / 1 hour |
| N2 | $0.0379332 / 1 hour | $0.03413988 / 1 hour | $0.03034656 / 1 hour | $0.0063222 / 1 hour | $0.00568998 / 1 hour | $0.00505776 / 1 hour |
| E2 | $0.026173908 / 1 hour | $0.023556517 / 1 hour | $0.020939126 / 1 hour | $0.004362318 / 1 hour | $0.003926086 / 1 hour | $0.003489854 / 1 hour |
| A2 | $0.0379332 / 1 hour | $0.03413988 / 1 hour | $0.03034656 / 1 hour | $0.006322 / 1 hour | $0.0056898 / 1 hour | $0.0050576 / 1 hour |
| N4 | Unavailable | - | - | $0.006238 / 1 hour | $0.0056142 / 1 hour | $0.0049904 / 1 hour |
| G4 | Unavailable | - | - | $0.009782 / 1 hour | $0.0088038 / 1 hour | $0.0078256 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### Memory

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Stockholm (europe-north2)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Berlin (europe-west10)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)
- Phoenix (us-west8)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 | Management Fee<br>\* (USD)_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| N1 | $0.0050844 / 1 gibibyte hour | $0.00457596 / 1 gibibyte hour | $0.00406752 / 1 gibibyte hour | $0.0008474 / 1 gibibyte hour | $0.00076266 / 1 gibibyte hour | $0.00067792 / 1 gibibyte hour |
| N2 | $0.0050844 / 1 gibibyte hour | $0.00457596 / 1 gibibyte hour | $0.00406752 / 1 gibibyte hour | $0.0008474 / 1 gibibyte hour | $0.00076266 / 1 gibibyte hour | $0.00067792 / 1 gibibyte hour |
| E2 | $0.003508236 / 1 gibibyte hour | $0.003157412 / 1 gibibyte hour | $0.002806589 / 1 gibibyte hour | $0.000584706 / 1 gibibyte hour | $0.000526235 / 1 gibibyte hour | $0.000467765 / 1 gibibyte hour |
| A2 | $0.0050844 / 1 gibibyte hour | $0.00457596 / 1 gibibyte hour | $0.00406752 / 1 gibibyte hour | $0.0008474 / 1 gibibyte hour | $0.00076266 / 1 gibibyte hour | $0.00067792 / 1 gibibyte hour |
| N4 | Unavailable | - | - | $0.000708 / 1 gibibyte hour | $0.0006372 / 1 gibibyte hour | $0.0005664 / 1 gibibyte hour |
| G4 | Unavailable | - | - | $0.001174 / 1 gibibyte hour | $0.0010566 / 1 gibibyte hour | $0.0009392 / 1 gibibyte hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### Accelerators

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Berlin (europe-west10)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)
- Phoenix (us-west8)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 | Management Fee<br>\* (USD)_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| Nvidia Tesla A100 | $4.400862 / 1 hour | $3.9607758 / 1 hour | $3.5206896 / 1 hour | $0.5867816 / 1 hour | $0.52810344 / 1 hour | $0.46942528 / 1 hour |
| Nvidia Tesla A100 80GB | $4.51729 / 1 hour | $4.065561 / 1 hour | $3.613832 / 1 hour | $0.785616 / 1 hour | $0.7070544 / 1 hour | $0.6284928 / 1 hour |
| Nvidia Tesla T4 | $0.525 / 1 hour | $0.4725 / 1 hour | $0.42 / 1 hour | $0.07 / 1 hour | $0.063 / 1 hour | $0.056 / 1 hour |
| Nvidia Tesla V100 | $3.72 / 1 hour | $3.348 / 1 hour | $2.976 / 1 hour | $0.496 / 1 hour | $0.4464 / 1 hour | $0.3968 / 1 hour |
| Nvidia Tesla P100 | $2.19 / 1 hour | $1.971 / 1 hour | $1.752 / 1 hour | $0.292 / 1 hour | $0.2628 / 1 hour | $0.2336 / 1 hour |
| Nvidia Rtx6000 | Unavailable | - | - | $0.21913 / 1 hour | $0.197217 / 1 hour | $0.175304 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

### Disks

Iowa (us-central1)

- Johannesburg (africa-south1)
- Taiwan (asia-east1)
- Hong Kong (asia-east2)
- Tokyo (asia-northeast1)
- Osaka (asia-northeast2)
- Seoul (asia-northeast3)
- Mumbai (asia-south1)
- Delhi (asia-south2)
- Singapore (asia-southeast1)
- Jakarta (asia-southeast2)
- Sydney (australia-southeast1)
- Melbourne (australia-southeast2)
- Warsaw (europe-central2)
- Finland (europe-north1)
- Stockholm (europe-north2)
- Madrid (europe-southwest1)
- Belgium (europe-west1)
- Berlin (europe-west10)
- Turin (europe-west12)
- London (europe-west2)
- Frankfurt (europe-west3)
- Netherlands (europe-west4)
- Zurich (europe-west6)
- Milan (europe-west8)
- Paris (europe-west9)
- Doha (me-central1)
- Dammam (me-central2)
- Tel Aviv (me-west1)
- Montreal (northamerica-northeast1)
- Toronto (northamerica-northeast2)
- Sao Paulo (southamerica-east1)
- Santiago (southamerica-west1)
- Iowa (us-central1)
- South Carolina (us-east1)
- Northern Virginia (us-east4)
- Columbus (us-east5)
- Alabama (us-east7)
- Dallas (us-south1)
- Oregon (us-west1)
- Los Angeles (us-west2)
- Salt Lake City (us-west3)
- Las Vegas (us-west4)
- Phoenix (us-west8)

Show discount options

HourlyHourly

MonthlyMonthly

| Machine type | Price (USD)<br>\*_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 | Management Fee<br>\* (USD)_info_<br>## Consumption model ID:<br>7754-699E-0EBF | Gemini Enterprise Flexible Savings Plan - 1 Year\* (USD)_info_<br>## Consumption model ID:<br>BBB5-D209-3835 | Gemini Enterprise Flexible Savings Plan - 3 Year\* (USD)_info_<br>## Consumption model ID:<br>C109-C9C0-A044 |
| Hyperdisk Extreme provisioned space | $0.000205479 / 1 gibibyte hour | $0.000184932 / 1 gibibyte hour | $0.000164384 / 1 gibibyte hour | $0.000034247 / 1 gibibyte hour | $0.000030822 / 1 gibibyte hour | $0.000027397 / 1 gibibyte hour |
| Balanced provisioned space | $0.000164384 / 1 gibibyte hour | $0.000147945 / 1 gibibyte hour | $0.000131507 / 1 gibibyte hour | $0.000027397 / 1 gibibyte hour | $0.000024658 / 1 gibibyte hour | $0.000021918 / 1 gibibyte hour |
| Extreme provisioned space | $0.000205479 / 1 gibibyte hour | $0.000184932 / 1 gibibyte hour | $0.000164384 / 1 gibibyte hour | $0.000034247 / 1 gibibyte hour | $0.000030822 / 1 gibibyte hour | $0.000027397 / 1 gibibyte hour |
| SSD provisioned space | $0.000279452 / 1 gibibyte hour | $0.000251507 / 1 gibibyte hour | $0.000223562 / 1 gibibyte hour | $0.000046575 / 1 gibibyte hour | $0.000041918 / 1 gibibyte hour | $0.00003726 / 1 gibibyte hour |
| Standard provisioned space | $0.000065753 / 1 gibibyte hour | $0.000059178 / 1 gibibyte hour | $0.000052603 / 1 gibibyte hour | $0.000010959 / 1 gibibyte hour | $0.000009863 / 1 gibibyte hour | $0.000008767 / 1 gibibyte hour |
| Hyperdisk Balanced provisioned space | Unavailable | - | - | $0.000021918 / 1 gibibyte hour | $0.000019726 / 1 gibibyte hour | $0.000017534 / 1 gibibyte hour |
| Hyperdisk Balanced provisioned IOPS | Unavailable | - | - | $0.00000137 / 1 hour | $0.000001233 / 1 hour | $0.000001096 / 1 hour |
| Hyperdisk Balanced provisioned throughput | Unavailable | - | - | $0.000010959 / 1 hour | $0.000009863 / 1 hour | $0.000008767 / 1 hour |

\* Each consumption model has a unique ID. You may need to opt-in to be eligible for consumption model discounts. Click [here](https://cloud.google.com/docs/cuds-multiprice#how-to-opt-in) to learn more.

Your Workbench in Gemini platform instance incurs charges as follows:

- For CPU and accelerator usage, you're charged when the instance is in the following states:
- STARTING
- PROVISIONING
- ACTIVE
- UPGRADING
- ROLLBACKING
- RESTORING
- STOPPING
- SUSPENDING
- For disk storage, you're charged when the instance is in the following states:
- STARTING
- PROVISIONING
- ACTIVE
- UPGRADING
- ROLLBACKING
- RESTORING
- STOPPING
- STOPPED
- SUSPENDING
- SUSPENDED

### Compute and storage resources

Compute and storage resources are charged at the same rate you currently pay for [Compute Engine](https://cloud.google.com/compute/all-pricing) and [Cloud Storage.](https://cloud.google.com/storage/pricing)

### Management fees

There are Workbench in Gemini platform management fees in addition to your infrastructure usage, captured in the tables below.

| SKU | Price (USD) |
| vCPU | $0.05 per vCPU |
| T4 and P4 (Standard GPU) | $0.35 per GPU |
| P100, V100, L4, and A100 GPU (Premium GPU) | $2.48 per GPU |

### Compute and storage resources

Compute and storage resources are charged at the same rate you currently pay for [Compute Engine](https://cloud.google.com/compute/all-pricing) and [Cloud Storage.](https://cloud.google.com/storage/pricing)

### Management fees

There are Workbench in Gemini platform management fees in addition to your infrastructure usage, captured in the tables below.

| SKU | Price (USD) |
| vCPU | $0.005 per vCPU |
| T4 and P4 (Standard GPU) | $0.035 per GPU |
| P100, V100, and A100 GPU (Premium GPU) | $0.25 per GPU |

### Additional Google Cloud resources

In addition to the costs mentioned previously, you also pay for any Google Cloud resources that you use. For example:

- Data analysis services: You incur BigQuery costs when you issue SQL queries within a notebook (see [BigQuery pricing](https://cloud.google.com/bigquery/pricing)).
- Customer-managed encryption keys: You incur costs when you use customer-managed encryption keys. Each time your instance uses a Cloud Key Management Service key, that operation is billed at the rate of Cloud KMS key operations (see [Cloud Key Management Service pricing](https://cloud.google.com/kms/pricing)).

## Colab Enterprise

For Colab Enterprise pricing information, see [Colab Enterprise pricing](https://cloud.google.com/colab/pricing).

## Deep Learning Containers, Deep Learning VM, and AI Platform Pipelines

For Deep Learning Containers, Deep Learning VM Images, and AI Platform Pipelines, pricing is calculated based on the compute and storage resources that you use. These resources are charged at the same rate you currently pay for [Compute Engine](https://cloud.google.com/compute/all-pricing) and [Cloud Storage](https://cloud.google.com/storage/pricing).

In addition to the compute and storage costs, you also pay for any Google Cloud resources that you use. For example:

- Data analysis services: You incur BigQuery costs when you issue SQL queries within a notebook (see [BigQuery pricing](https://cloud.google.com/bigquery/pricing)).
- Customer-managed encryption keys: You incur costs when you use customer-managed encryption keys. Each time your instance uses a Cloud Key Management Service key, that operation is billed at the rate of Cloud KMS key operations (see [Cloud Key Management Service pricing](https://cloud.google.com/kms/pricing)).

## Data labeling

Gemini platform enables you to request human labeling for a collection of data that you plan to use to train a custom machine learning model. Prices for the service are computed based on the type of labeling task.

- For regular labeling tasks, the prices are determined by the number of annotation units.
- For an image classification task, units are determined the number of images and the number of human labelers. For example, an image with 3 human labelers counts for 1 \* 3 = 3 units. The price for single-label and multi-label classification are the same.
- For an image bounding box task, units are determined by the number of bounding boxes identified in the images and the number of human labelers. For example, if an image with 2 bounding boxes and 3 human labelers counts for 2 \* 3 = 6 units. Images without bounding boxes will not be charged.
- For an image segmentation/rotated box/polyline/polygon task, units are determined in the same way as a image bounding box task.
- For a video classification task, units are determined by the video length (every 5 seconds is a price unit) and the number of human labelers. For example, a 25 seconds video with 3 human labelers counts for 25 / 5 \* 3 = 15 units. The price for single-label and multi-label classification are the same.
- For a video object tracking task, unit are determined by the number of objects identified in the video and the number of human labelers. For example, for a video with 2 objects and 3 human labelers, it counts for 2 \* 3 = 6 units. Video without objects will not be charged.
- For a video action recognition task, units are determined in the same way as a video object tracking task.
- For a text classification task, units are determined by text length (every 50 words is a price unit) and the number of human labelers. For example, one piece of text with 100 words and 3 human labelers counts for 100 / 50 \* 3 = 6 units. The price for single-label and multi-label classification is the same.
- For a text sentiment task, units are determined in the same way as a text classification task.
- For a text entity extraction task, units are determined by text length (every 50 words is a price unit), the number of entities identified, and the number of human labelers. For example, a piece of text with 100 words, 2 entities identified, and 3 human labelers counts for 100 / 50 \* 2 \* 3 = 12 units. Text without entities will not be charged.
- For image/video/text classification and text sentiment tasks, human labelers may lose track of classes if the label set size is too large. As a result, we send at most 20 classes to the human labelers at a time. For example, if the label set size of a labeling task is 40, each data item will be sent for human review 40 / 20 = 2 times, and we will charge 2 times of the price (calculated above) accordingly.
- For a labeling task that enables the custom labeler feature, each data item is counted as 1 custom labeler unit.
- For an active learning labeling task for data items with annotations that are generated by models (without a human labeler's help), each data item is counted as 1 active learning unit.
- For an active learning labeling task for data items with annotations that are generated by human labelers, each data item is counted as a regular labeling task as described above.

The table below provides the price per 1,000 units per human labeler, based on the unit listed for each objective. Tier 1 pricing applies to the first 50,000 units per month in each Google Cloud project; Tier 2 pricing applies to the next 950,000 units per month in the project, up to 1,000,000 units. [Contact us](https://cloud.google.com/contact/) for pricing above 1,000,000 units per month.

| Data type | Objective | Unit | Tier 1 price (USD) | Tier 2 price (USD) |
| Image | Classification | Image | $35 | $25 |
| Bounding box | Bounding box | $63 | $49 |
| Segmentation | Segment | $870 | $850 |
| Rotated box | Bounding box | $86 | $60 |
| Polygon/polyline | Polygon/Polyline | $257 | $180 |
| Video | Classification | 5 sec video | $86 | $60 |
| Object tracking | Bounding box | $86 | $60 |
| Action recognition | Event in 30 sec video | $214 | $150 |
| Text | Classification | 50 words | $129 | $90 |
| Sentiment | 50 words | $200 | $140 |
| Entity extraction | Entity | $86 | $60 |
| Active Learning | All | Data item | $80 | $56 |
| Custom Labeler | All | Data item | $80 | $56 |

## Required use of Cloud Storage

In addition to the costs described in this document, you are required to store data and program files in Cloud Storage buckets during the Gemini platform lifecycle. This storage is subject to the [Cloud Storage pricing policy](https://cloud.google.com/storage/pricing).

Required use of Cloud Storage includes:

- Staging your training application package for custom-trained models.
- Storing your training input data.
- Storing the output of your training jobs. Gemini platform does not require long-term storage of these items. You can remove the files as soon as the operation is complete.

## Free operations for managing your resources

The resource management operations provided by AI Platform are available free of charge. The AI Platform quota policy does limit some of these operations.

| Resource | Free operations |
| models | create, get, list, delete |
| versions | create, get, list, delete, setDefault |
| jobs | get, list, cancel |
| operations | get, list, cancel, delete |

## Google Cloud costs

If you store images to be analyzed in Cloud Storage or use other Google Cloud resources in tandem with Gemini platform, then you will also be billed for the use of those services.

To view your current billing status in the Google Cloud console, including usage and your current bill, see the [Billing page](https://console.cloud.google.com/billing). For more details about managing your account, see the [Cloud Billing Documentation](https://cloud.google.com/billing/docs) or [Billing and Payments Support](https://cloud.google.com/support/billing).

## What's next

- Read the [Gemini platform documentation](https://docs.cloud.google.com/gemini-enterprise-agent-platform).
- Learn about [Gemini platform solutions and use cases](https://cloud.google.com/architecture?text=Vertex%20AI).

## Request a custom quote

With Google Cloud's pay-as-you-go pricing, you only pay for the services you use. Connect with our sales team to get a custom quote for your organization.

Contact sales [Contact sales](https://cloud.google.com/contact?direct=true)
Free

For individuals exploring web automation

$0/mo

3 compute hours included

5 API machines (1 per project)

10 job runs included

Unlimited standalone runs

$5 trial AI credit

Advanced stealth mode

7-day data retention

[Start for free](https://app.intuned.io/?utm_source=LandingPage)

Developer

For developers building at scale

$25/mo

100 compute hours included

25 API machines (5 per project)

100 job runs included

Unlimited standalone runs

$10/mo AI credit

Large & XL machines available

30-day data retention

[Start building](https://app.intuned.io/?planSelected=developer&utm_source=LandingPage)

Most Popular

Startup

For teams with production workloads

$120/mo

500 compute hours included

100 API machines (15 per project)

400 job runs included

Unlimited standalone runs

$40/mo AI credit

Large & XL machines available

30-day data retention

[Start building](https://app.intuned.io/?planSelected=startup&utm_source=LandingPage)

Enterprise

For teams with custom scale, security, and support needs

Custom

Custom compute and machine limits

Volume pricing for runs and AI usage

Unlimited standalone runs

Dedicated solutions and onboarding support

SSO / SAML and advanced access controls

Custom retention, regions, and compliance setup

Priority architecture reviews and escalation paths

[Talk to sales](https://app.intuned.io/?promptChange=true&utm_source=LandingPage)

# Detailed comparison of plans

Compare pricing, limits, and support across every plan.

| Features ListUsage, limits, and included support | Free PlanFor individuals exploring web automation[Start for free](https://app.intuned.io/?utm_source=LandingPage) | Developer PlanFor developers building at scale[Start a free trial](https://app.intuned.io/?planSelected=developer&utm_source=LandingPage) | Startup PlanFor teams with production workloads[Start a free trial](https://app.intuned.io/?planSelected=startup&utm_source=LandingPage) | Enterprise PlanFor teams with custom scale, security, and support needs[Talk to sales](https://app.intuned.io/?promptChange=true&utm_source=LandingPage) |
| --- | --- | --- | --- | --- |
| Monthly price | $0 | $25 | $120 | Custom |
| Included compute hours | 3 | 100 | 500 (standard) | Custom |
| Compute overage rate | -- | $0.12 / hour | $0.10 / hour | Volume pricing |
| API Machines (workspace total) | 5 | 25 | 100 | Custom |
| Max API machines per project/app | 1 | 5 | 15 | Custom |
| Job Runs included | 10 | 100 | 400 | Custom |
| Job Run overage rate | -- | $0.12 / run | $0.10 / run | Volume pricing |
| Monthly AI credit | $5 (trial credit) | $5 | $40 | Custom |
| Large machine surcharge | Not available | +$0.18 / hour | $0.15 / hour | Custom |
| X-Large machine surcharge | Not available | +$0.48 / hour | $0.40 / hour | Custom |
| Access to Large/XL machines | No | Yes | Yes | Yes |
| Data retention | 7 days | 30 days | 30 days | Custom |
| Advanced stealth mode | -- | Included | Included | Included |
| SSO / SAML | -- | -- | -- | Included |
| Support | Community | Email | Priority email | Dedicated team |

Intuned

Intuned is a code-first browser automation platform. Deploy scrapers, RPA, and automations at scale built by you or by Intuned Agent.

[HIPAA compliance badge](https://trust.intunedhq.com/)[SOC 2 - Security Controls compliance badge](https://trust.intunedhq.com/)

#### Use cases

[Integrations](https://intunedhq.com/integrations)[RPA](https://intunedhq.com/rpa)[Scrapers](https://intunedhq.com/scrapers)

#### Product

[Docs](https://intunedhq.com/docs)[Pricing](https://intunedhq.com/pricing)[Blog](https://intunedhq.com/blog)

#### Social

[X/Twitter](https://x.com/IntunedHQ)[LinkedIn](https://www.linkedin.com/company/intunedhq)[YouTube](https://www.youtube.com/@IntunedHQ/featured)[Discord](https://discord.com/invite/cRAtnKH4jf)

#### Legal

[Privacy Policy](https://intunedhq.com/docs/main/06-resources/privacy-policy#privacy-policy)[Terms](https://intunedhq.com/docs/main/06-resources/terms-of-service)

[All Systems Operational](https://status.intunedhq.com/)

Intuned © 2026

# FAQ

## Are you related with Killer Shell?

Yes, more [here](https://killercoda.com/killer-shell).

---

## Can I get updates on new features and current progress?

For sure! Just follow us on [X](https://x.com/killercoda).

---

## Can I use Killercoda to learn?

Yes!  
  
 With our FREE membership you can use all scenarios as much as you want (excluding [Courses](https://killercoda.com/courses)).

---

## Can I use Killercoda to teach?

Yes!  
  
 You can create your own scenarios and share these with others. More further down.

---

## How much does Killercoda cost?

You can use Killercoda completely for free!  
 For more paid features please check our [Pricing Page](https://killercoda.com/pricing).

---

## Which membership should I choose?

Start with [FREE](https://killercoda.com/pricing) to:

- Use all scenarios as much as you want (excluding [Courses](https://killercoda.com/courses)).
- Create public scenarios and share with others.

Choose [PLUS](https://killercoda.com/pricing) to:

- Includes all from **FREE**
- Use scenarios for **up to 4 hours** instead of just one (info)
- Open up to **3 scenarios at the same time**
- Open [CKS](https://killercoda.com/cks) and [Playgrounds](https://killercoda.com/playgrounds) in the [Remote Desktop](https://killercoda.com/linux-foundation-exam-remote-desktop)
- Unlimited [Brain](https://killercoda.com/brain) usage
- Proof you're human and have **no Captcha bot challenges**
- Faster load times and **skip queues**
- Show us you like what we're doing
- Have prioritized support

Choose [COURSE](https://killercoda.com/pricing) to:

- Get everything from PLUS.
- Access the Scenario [Courses](https://killercoda.com/courses): CKA, CKAD and CNPE.

---

## What is the difference between PLUS and COURSE Membership?

The PLUS membership provides access to all PLUS features like longer session times, multiple open scenarios, and the Exam Desktop.

The COURSE membership includes everything from PLUS and adds access to the Scenario Courses: CKA, CKAD and CNPE.

If you already have an active PLUS membership, your remaining paid PLUS months are credited when you upgrade to COURSE.

---

## Where can I find the Exam Desktop / Remote Desktop?

With a PLUS membership you can use the [CKS](https://killercoda.com/cks) scenarios and the CKA, CKAD, CKS, CNPE and CKNE [Playgrounds](https://killercoda.com/playgrounds) with the Exam Desktop.  
 All [Courses](https://killercoda.com/courses) (COURSE membership) have the Exam Desktop too.  
 Select the Exam Desktop from the top left menu in the right side area:

---

## How does the hourly access limit work?

If you open any scenario then you can use it for one hour max, after which the environment of the scenario is deleted.  
 Then you can reload your browser tab to get a new environment which you can use for one hour.  
 This one hour limit is raised to four hours with a paid membership.  
 There are no daily or monthly usage limits.

---

## Do you offer bulk or voucher purchases?

Yes, see [Teams](https://killercoda.com/teams).

---

## Do you have a Bug Bounty program?

Yes, more [here](https://killercoda.com/bug-bounty).

---

## Are there IP address access, registration or rate limits?

There is no limit on how many users can use the scenarios of a creator, so you can share your scenarios with as many people as you like.  
 To protect the platform there are short-term rate limits, for example on how often you can start environments. And if too many users connect from the same IP address there will be Captcha Bot Detection challenges shown.

---

## Are some email domains blocked?

Yes, certain email domains are blocked due to security measures.  
Read more in our [security](https://killercoda.com/security) section.

---

## How secure are Killercoda environments?

All environments are ephemeral, isolated from each other, and deleted once the browser tab is closed.  
 Access URLs contain unique IDs but are not password protected.   
Read more on our [Security](https://killercoda.com/security) section.

---

## What is Brain?

All Killercoda scenarios have a Brain, so talk with them! Ask what's required or anything about your solution.  
 In (default) hint mode the scenario will provide only tips when you're stuck, switch to solution mode for full answers.  
 More [here](https://killercoda.com/brain).

---

## Can I rate scenarios?

Yes, after completing a scenario you can rate it with 1-5 stars and optionally leave a comment. Ratings are only visible to the scenario creator and help them improve their content.

---

## More Questions?

[Support](https://killercoda.com/support)

## For Creators

## Can I contribute to and help maintaining existing scenarios?

Yes, check [here](https://killercoda.com/creators/contribute).

---

## How can I use Killercoda to interactively teach?

You can create your own scenarios and share these with anyone.  
 Users wanting to use your scenarios will just need to register for free on Killercoda.

---

## How does the scenario creation work?

- You add a Github repository to your Killercoda profile.
- Everytime you push into your repository and the specified branch, your Killercoda scenarios will be updated.
- You'll write for example JSON, Markdown and Bash (for possible verification of user input).

For more check [Get Started](https://killercoda.com/creators/get-started).

---

## Is there documentation?

Please visit the [Creators](https://killercoda.com/creators) page.  
 Please visit the [Get Started](https://killercoda.com/creators/get-started) page.  
 Check out our example [Github Repository](https://github.com/killercoda/scenario-examples).

---

## How much does Killercoda cost?

Please check our [Pricing Page](https://killercoda.com/pricing).

---

## Do you schedule scenarios close to users for low latency?

Yes, please check our [Locations](https://killercoda.com/locations) page.

---

## How do scenario ratings work for creators?

Users can rate your scenarios after completing them. Ratings are only visible to you and provide a way to receive feedback. You can filter by time period and sort by score. Use lower ratings and their comments to identify areas for improvement. After making updates, filter by "1 week" to see if recent ratings reflect the changes.

---

## What about data security in environments?

All environments are ephemeral, isolated, and access URLs are public but not guessable. Never use production secrets in Killercoda environments. Read more on our [Security](https://killercoda.com/security) page.

---

## Can I use Killercoda as the interactive backend for my external course platform?

Not really. Every scenario on Killercoda needs to be solvable on Killercoda. The full task description, the expected result, and the solution must be available to any user without requiring them to visit another platform, sign up for a different service, or purchase a course elsewhere. You are welcome to link to your own blog, book, video course, or community for additional context, as long as the scenario itself can be completed standalone.

---

## More Questions?

[Support](https://killercoda.com/support)

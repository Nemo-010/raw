# Prisma Postgres FAQ

Common questions and answers about Prisma Postgres

Common questions about how Prisma Postgres works, how queries are billed, and how it integrates with the Prisma ORM.

## General

### Can I use Prisma Postgres without Prisma ORM?

Yes, you can use Prisma Postgres with any database library or tool via a [direct connection](https://www.prisma.io/docs/postgres/database/connection-pooling).

You can find examples of using Prisma Postgres with various ORMs below:

- [Prisma ORM](https://github.com/prisma/prisma-examples/tree/latest/databases/prisma-postgres)
- [Drizzle](https://github.com/prisma/prisma-examples/tree/latest/databases/drizzle-prisma-postgres)
- [Kysely](https://github.com/prisma/prisma-examples/tree/latest/databases/kysely-prisma-postgres)
- [TypeORM](https://github.com/prisma/prisma-examples/tree/latest/databases/typeorm-prisma-postgres)

### Can I host my app next to Prisma Postgres?

Yes, on [Prisma Compute](https://www.prisma.io/docs/compute), which runs TypeScript apps built for Node.js, Bun or Next.js; deployed apps run on Bun. Each Compute service runs in one region, so create it in the same region as its database. The Free plan includes 1M requests, 360 GB-hours of memory, 4 active vCPU-hours and 10 GB of outbound bandwidth a month for Compute, with no usage billing. Paid plans include 5M, 20M or 100M requests a month (Starter, Pro, Business), charge $1 per million requests above that, and meter Compute memory, active CPU and bandwidth on top of the plan's base price. The [Compute FAQ](https://www.prisma.io/docs/compute/faq) covers who Compute is for, where it has trade-offs and how to deploy an existing repository.

### How do I move a local Postgres database online?

In three steps: create a Prisma Postgres database, `pg_dump` the local database, and `pg_restore` the dump over the direct connection, whose host is `db.prisma.io`. The copy is a snapshot, so stop writing to the local database before the final dump, and resume writes only on Prisma Postgres, after you have verified the restored database and pointed the app at it. [Migrate a local Postgres database to the cloud](https://www.prisma.io/docs/postgres/import-from-existing-database) has the commands and the checks to run first: PostgreSQL 17 tools, extensions, and the roles that row-level security policies name.

### Can I create my own database roles?

Prisma Postgres doesn't support custom roles. The database user in your connection string can't create roles, so `CREATE ROLE` fails with this error:

```
ERROR: restricted superuser cannot create roles
```

If you wanted a role to give one part of your application read-only access, enforce that in your application instead. When that part sends its queries through Prisma ORM 8, a [middleware can refuse any query that isn't a read](https://www.prisma.io/docs/orm/middleware/how-middleware-works#beforeencode-validate-or-block) before it reaches the database.

### How do I switch from GitHub login to email and password login?

If you previously signed up using GitHub and want to switch to email and password login, follow these steps:

1. Verify Your GitHub Email Address

    - Check the primary email address associated with your GitHub account (e.g., from your GitHub profile or notification settings).
2. Create a New Email/Password Account

    - Go to the email/password sign-up page.
    - Use the *same email address* linked to your GitHub account to create the new account.
    - Our system will automatically connect your new email/password account to your existing data.
3. Test Your Login

    - Log out and try logging in with your email and the password you just created.

If you encounter any issues, please contact our support team for help linking your accounts.

### VS Code does not recognize the `$extends` method

If you add the Prisma Client extension for Accelerate to an existing project that is currently open in VS Code, the editor might not immediately recognize the `$extends` method.

This might be an issue with the TypeScript server not yet recognizing the regenerated Prisma Client. To resolve this, you need to restart TypeScript.

1. In VS Code, open the Command Palette. You can do so when you press F1 or select **View** > **Command Palette**.
2. Enter `typescript` and select and run the **TypeScript: Restart TS server** command.

VS Code should now recognize the `$extends` method.

## What regions is Prisma Postgres available in?

Prisma Postgres is currently available in the following regions:

| Region Code | Location |
| --- | --- |
| `us-west-1` | San Francisco |
| `us-east-1` | North Virginia |
| `eu-west-3` | Paris |
| `eu-central-1` | Frankfurt |
| `ap-northeast-1` | Tokyo |
| `ap-southeast-1` | Singapore |

We're continuously working to expand regional support. If you'd like to request a specific region, reach out to us via [Discord](https://pris.ly/discord).

## Pricing

Prisma Postgres bills based on *operations* and *storage* consumed. It does not charge for egress traffic. Visit the [pricing page](https://www.prisma.io/pricing) for details and our [blog post explaining operations-based billing](https://www.prisma.io/blog/operations-based-billing) for a detailed explanation on what an operation is and how this pricing model works.

### What happens if I exceed the included queries on the Free tier?

When you use all the queries included in your Free plan, your Prisma Postgres database stops accepting read and write requests. You can upgrade to a [paid plan](https://www.prisma.io/pricing) to restore access, usually within a minute, or wait until your query allowance resets at the start of the next calendar month.

If you need to export your data or need more time before upgrading, you can activate a grace period for 24 hours. In the [Prisma Console](https://console.prisma.io/?utm_source=docs&utm_medium=content&utm_content=postgres), open the workspace that groups your projects and databases, then select **Restore access for 24 hours** in the warning about your query limit. This lifts the query limit for all Prisma Postgres databases in the workspace. The grace period is available only once per workspace and does not renew each month. When the 24 hours end, queries are blocked again until you upgrade or your included queries reset at the start of the next month. The warning won't offer to restore access again. While queries are blocked, your data is not deleted.

### What is an operation?

An operation is counted each time you interact with your database. A read or a write, simple or complex, counts as one operation.

An operation can be:

- a Prisma ORM query (when using Prisma ORM)
- a SQL query (when using a [direct connection](https://www.prisma.io/docs/postgres/database/connecting-to-your-database))

### Does query execution time affect pricing in Prisma Postgres?

No, cost for Prisma Postgres is based solely on the *number of operations*, not the amount of compute required to execute them.

Whether a query takes 10ms or 10sec to execute, its pricing impact remains the same.

### How does pricing differ between using Prisma ORM and direct TCP connections?

The fundamental principle of operations-based pricing remains the same for Prisma ORM and [direct connections](https://www.prisma.io/docs/postgres/database/connecting-to-your-database). However, depending on whether you use Prisma ORM or direct SQL to interact with your database, an operation is something different:

- when using Prisma ORM: a query sent with Prisma Client (e.g. `prisma.user.findMany()`)
- when using another tool: a SQL query sent via the direct connection (e.g. `SELECT * from "User"`)

Note that a single Prisma ORM query may translate into multiple SQL queries which may make using Prisma ORM more economical than direct SQL.

### Do read and write queries cost the same?

Yes, read and write queries are counted equally as *operations* and are billed the same way.

### Does a `SELECT 1` query count as a billable operation?

Yes, a query like `SELECT 1` counts as an operation and will be billed accordingly (even if no actual data is accessed in the query).

### How can I estimate the number of operations in Prisma ORM?

You can estimate your operation usage in Prisma ORM by integrating an application performance monitoring tool like Prometheus.

### What strategies can I use to optimize cost per operation?

Prisma Postgres bills by operation, so the more you can perform using a single operation, the lower your bill. Some tips to reduce the number of operations:

- [**Batch your writes**](https://www.prisma.io/docs/orm/v7/prisma-client/queries/transactions#bulk-operations) with `createMany`, `updateMany`, or `deleteMany` instead of looping over single-row calls.

  ```
  // One operation, three users
  await prisma.user.createMany({
    data: [{ name: "Alice" }, { name: "Bob" }, { name: "Carol" }],
  });
  ```
- **Use nested-relation helpers** such as [`connectOrCreate`](https://www.prisma.io/docs/orm/v7/reference/prisma-client-reference#connectorcreate) or [`set`](https://www.prisma.io/docs/orm/v7/reference/prisma-client-reference#set) to create or link related records in a single operation.

  ```
  // Post and (if needed) its author, all in one request
  await prisma.post.create({
    data: {
      title: "Hello World",
      author: {
        connectOrCreate: {
          where: { email: "alice@example.com" },
          create: { name: "Alice", email: "alice@example.com" },
        },
      },
    },
  });
  ```
- **Prefer regular (array) [transactions](https://www.prisma.io/docs/orm/v7/prisma-client/queries/transactions#transaction-api) over [interactive transactions](https://www.prisma.io/docs/orm/v7/prisma-client/queries/transactions#interactive-transactions)** when the individual queries don't depend on each other.

  ```
  // Interactive transaction: counted as 2 operations
  await prisma.$transaction(async (tx) => {
    await tx.user.create({ data: { name: "Alice" } });
    await tx.post.create({ data: { title: "Hello", authorId: 1 } });
  });

  // Array transaction: counted as 1 operation
  await prisma.$transaction([
    prisma.user.create({ data: { name: "Alice" } }),
    prisma.post.create({ data: { title: "Hello", authorId: 1 } }),
  ]);
  ```

If a later query needs the result of an earlier one (for example, you need the user ID you just created), stick with an interactive transaction for correctness. Otherwise, batching and array transactions let you collapse multiple queries into a single billed operation, keeping both your operation count, and your cost down.

### Is there a sample workload to estimate my expected charges?

We will demonstrate three example workloads and estimate bills for small, medium, and large workloads. Each combine a realistic number of monthly active users (MAUs), a typical level of daily activity per user, and a rounded storage footprint.

We will use the following equations to estimate the monthly bill:

```
total_ops            = MAUs x actions_per_user_per_day x 30
billable_ops         = total_ops - included_ops_for_plan
ops_cost             = (billable_ops ÷ 1_000_000) x plan_rate

billable_storage_GB  = storage_used_GB - free_storage_for_plan
storage_cost         = billable_storage_GB x storage_rate_for_plan

total_monthly_cost   = ops_cost + storage_cost + base_plan_fee
```

You can use your own MAU count, activity level, and storage used to project costs on any plan using the equations above.

We will associate each workload with a paid plan and its corresponding pricing details, for example, the **Starter plan** for the small workload, the **Pro plan** for the medium workload, and the **Business plan** for the large workload. Then we will apply the equations to the example workloads to generate a rough estimate of a monthly bill. For example:

Pricing details

Here are the details for each pricing plan:

- **Starter plan** - $8 per million operations

    - Base plan fee - $10 per month
    - Included operations - 1,000,000
    - Storage - 10 GB free then $2 per additional GB
- **Pro plan** - $2 per million operations

    - Base plan fee - $49.00 per month
    - Included operations - 10,000,000
    - Storage - 50 GB free then $1.5 per additional GB
- **Business plan** - $1 per million operations

    - Base plan fee - $129.00 per month
    - Included operations - 50,000,000
    - Storage - 100 GB free then $1 per additional GB

We also have a Free plan, but we are leaving it out in the following calculations because it's intended for evaluation only and is not meant for production workloads. You can also learn more about the pricing details for each plan on the [pricing page](https://www.prisma.io/pricing?utm_source=docs).

**Example of a small workload on the Starter plan**:

A hobby or early-stage side-project with ~`500` MAUs. Each user performs ~`10` actions per day, and the entire database uses ~`0.5` GB of storage. Based on the assumptions, you would calculate the monthly bill using the following equations:

- `total_ops` = `500` x `10` x `30` = `150000`
- `billable_ops` = `0` (150,000 operations is below the 1 million free operations)
- `ops_cost` = $`0`
- `storage_cost` = $`0` (0.5 GB is below the 10 GB storage already included)
- `base_plan_fee` = $`10`

`total_monthly_cost` = $`10.00` per month

**Example of a medium workload on the Pro plan**:

A growing SaaS product serving ~`5000` MAUs. Power users average ~`40` actions per day, and the app stores ~`6` GB of data. Based on the assumptions, you would calculate the monthly bill using the following equations:

- `total_ops` = `5000` x `40` x `30` = `6000000`
- `billable_ops` = `0` (6 million operations is below the 10 million free operations)
- `ops_cost` = $`0`
- `storage_cost` = $`0` (6 GB is below the 50 GB storage already included)
- `base_plan_fee` = $`49.00`

`total_monthly_cost` = $`49.00` per month

**Example of a large workload on the Business plan**:

A production-grade, consumer-facing application handling ~`50000` MAUs. Heavy usage with ~`60` actions per user per day drives significant traffic, and the dataset reaches ~`40` GB. Based on the assumptions, you would calculate the monthly bill using the following equations:

- `total_ops` = `50000` x `60` x `30` = `90000000`
- `billable_ops` = `90000000` - `50000000` = `40000000`
- `ops_cost` = (`40000000` ÷ `1000000`) = `40.00` x $`1` = $`40.00`
- `storage_cost` = $`0.00` (40 GB is below the 100 GB storage already included)
- `base_plan_fee` = $`129.00`

`total_monthly_cost` = $`40.00` + $`129.00` = $`169.00` per month

### How do I upgrade my plan if I am using Prisma Postgres via Vercel?

If you installed Prisma Postgres through the [Vercel Marketplace integration](https://www.prisma.io/docs/guides/postgres/vercel), the same [Prisma Postgres pricing plans](https://www.prisma.io/pricing) apply and your usage is billed through your Vercel account. To upgrade your plan via Vercel, follow these steps:

- Open your [Vercel](https://vercel.com/) Dashboard.
- Go to the **Integrations** tab in your Vercel Team.
- Click **Manage** on the Prisma Integration.
- Navigate to the **Settings** tab.
- Under Current Installation Plan Level, click **Change Plan**.
- Select the plan you want to upgrade to.

### How do I delete a Prisma Postgres database I created through Vercel?

Delete it in your Vercel dashboard. The Prisma Console has no delete option for databases created through Vercel, and deleting the Vercel project that was connected to the database leaves the database in place.

Deleting a database is permanent, so before you start, [export any data you want to keep with `pg_dump`](https://www.prisma.io/docs/postgres/database/backups#manually-creating-a-backup-file-via-pg_dump).

1. Open your [Vercel](https://vercel.com/) Dashboard and select the team that owns the database.
2. Open **Storage** in the sidebar and select the database.
3. In the database's **Settings**, choose the option to delete the database, then confirm.

Usage charges for the database stop when you delete it. Usage from before that still appears on your Vercel invoice.

Deleting a database doesn't cancel a paid plan, so you keep paying the monthly plan fee until you either change the plan or uninstall the integration:

- Follow the steps in the previous answer and select the Free plan. The change takes effect at the end of the current billing period.
- Uninstall the integration: in **Integrations**, click **Manage** on the Prisma integration, then click **Uninstall Integration** at the bottom of the page. This deletes the Prisma workspace the integration created and all its databases, so export first. A final Vercel invoice covers the usage up to that point.

If you restored a backup to a new database in a workspace created through Vercel, that new database doesn't appear in your Vercel dashboard, and the Console shows only a **Manage in Vercel** button for it. Delete it with the Prisma CLI or the REST API instead, as described in [Deleting a restored copy in a Vercel workspace](https://www.prisma.io/docs/postgres/database/backups#deleting-a-restored-copy-in-a-vercel-workspace).

## Caching

### Does Prisma Postgres cache query results?

Prisma Postgres includes connection pooling but has no query cache of its own, and query caching is not on our immediate roadmap. `cacheStrategy` works with a Prisma Postgres database only through a hosted Accelerate connection.

If your application passes `cacheStrategy` through a hosted Accelerate connection, that connection will be retired on December 1, 2026. [Connect to Prisma Postgres without Accelerate](https://www.prisma.io/docs/postgres/database/switch-from-accelerate) shows how to remove the caching APIs and replace the connection. After the switch, cached queries become ordinary database queries. A query served from the cache already counted as one operation, so removing caching does not change how operations are counted. Database load and response latency can change, so test the affected paths under representative traffic.

## Query Insights

[Query Insights](https://www.prisma.io/docs/query-insights) is built into Prisma Postgres and helps you identify slow queries, understand their cost, and decide what to fix.

### I only see raw SQL. How do I see my Prisma ORM queries?

By default, Query Insights shows raw SQL. To also see the Prisma ORM operation that generated each query (model name, action, and query shape), install the `@prisma/sqlcommenter-query-insights` package:

```
npm install @prisma/sqlcommenter-query-insights
```

Then pass it to the `comments` option in your `PrismaClient` constructor:

```
import { prismaQueryInsights } from "@prisma/sqlcommenter-query-insights";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient({
  adapter: myAdapter,
  comments: [prismaQueryInsights()],
});
```

This annotates every query with a SQL comment containing the model, action, and parameterized query shape. Query Insights uses these annotations to map SQL back to the Prisma call that generated it.

#### Let your AI agent handle setup

Copy this prompt into your AI coding assistant:

```
Install and configure @prisma/sqlcommenter-query-insights in my project so I can
see Prisma ORM queries in Query Insights. Docs: https://www.prisma.io/docs/query-insights
```

### Does Query Insights alter my queries or schema?

No, Query Insights is read-only: it observes query behavior but does not rewrite queries or modify your Prisma schema.

### Can I use Query Insights in production?

Query Insights is designed primarily for development and debugging. Running it in production is possible but not recommended, as the SQL comment annotations add a small overhead to every query.

[Edit on GitHub](https://github.com/prisma/docs/edit/main/apps/docs/content/docs/postgres/faq.mdx)

Last updated on

[TroubleshootingResolve common issues with Prisma Postgres](https://www.prisma.io/docs/postgres/troubleshooting)

[Migrate from EA to GANext Page](https://www.prisma.io/docs/postgres/migrate-from-ea-to-ga)

# News

## Thu, Dec 11th, 2025 - Staff

## Sat, Nov 15th, 2025 - Staff

Great news for easier payments! We now accept payments via Stripe for instant account upgrades. Automatic cryptocurrency processing is coming soon, expanding on our existing support for Bitcoin, Ethereum, Tether, LiteCoin, USDCoin, and XRP. Lifetime members can still donate to support the site. For questions or issues, email us at [email protected].

## Sat, Oct 4th, 2025 - Staff

We're excited to announce a new Account Upgrade process! You can now use PayPal's expanded checkout or pay with cryptocurrencies like Bitcoin, Ethereum, Tether, LiteCoin, USDCoin, and XRP. Lifetime members can also donate to support the site if they wish. For any questions or issues, please email us at [email protected].

## Sat, Sept 13th, 2025- Staff

We upgraded the software on our database server. This required a reboot. For some reason the server did not reboot correctly. The host tools did not work so we had to wait for the hosting company to fix the issue.

## Sun, Nov 26th, 2023 - Staff

We are running on new servers. Please email us at [email protected] if you have any issues with the site.

## Tue, Nov 15th, 2022 - Staff

If you are scraping ebooks you will be banned. No one needs to download 500+ ebooks in a few days. We are watching closely. 1st round of bans have already gone out.

# Are You Having Issues Processing Releases?

## Sunday October 3rd, 2022 - Staff

Some people are reporting issues with processing releases. There appears to be some issues with nzbget and our releases. The easiest fix is to switch to SABnzbd sabnzbd.org   
There is a guide on how to configure it with Miatrix Here

# Changes to some releases

## Sunday June 27th, 2021- Staff

We should have a lot more releases coming very soon, however due to the new way we are getting them there is a password for the rar files. This will be automatically handled by the latest versions of sabnzb and nzbget. If you are not using these tools the password is in the header of the nzb file. You can open them up with notepad and just copy and paste them into your decompression tool.

# What we are working on

## Wed, Aug 9th, 2017- Staff

Around 2pm last night our hosting provider started having issues with our IP address for our web site. They are still trying to resolve the issue, but for now i have assigned a new IP address to the site. This might cause linux users issues so make sure you flush your dns if you cannot reach the site via one of the automated tools.

## Tuesday, Aug 8th, 2017- Staff

During a move of the servers to new computers, we had some issues that caused us more downtime than expected but we are be back to normal.

## Sunday, July 7, 2013- Staff

It might appear that things have been quite for a while now, however we have been working on big things. We are not ready with the change yet, however we are getting closer day by day. We are currently working on a complete backend and frontend overhaul. This will allow some posts to actually show a 5-10 second clip of the show, more previews if posted with the release, and better overall performance. There are a number of things left on the todo, but as soon as we get a bit closer we will open up a test server for everyone to provide feedback on.

# Hardware Issues

## Thursday, April 24, 2013 - Staff

We are currently experiencing hardware issues on our processing node. It appears that both hard drives are having issues. Luckily with our setup no important data was lost. We are waiting for our service provider to replace the hard drives so we can start the recovery of our node. Expect the main node to go down at some point to allow us to get replication going again. Until our node is recovered we are not processing anything since it would slow down the frontend too much  
Update: Hard drives replaced and database setup and populated. We are now moving the nzbfiles & images to the server. Once that completes we should be able to start processing releases again.  
Update #2:Everything back to normal... Backfilling is disabled for now. Things might be slow for a few days

# Current Processing Status

## Monday, March 18, 2013 - Staff

Here are our current status on backfills and general processing:

|  |  |  |  |
| --- | --- | --- | --- |
| Category | In Process | Processed | Notes |
| TV Shows | 0 | 594,644 | All TV Shows have been processed, though we still need to backfill some |
| Movies | 0 | 144,028 | There are no movies that need to be processed. There are some that are labeled wrong by the automation. We will be adding a report option sometime in the future to allow them to get resolved. |
| Audio | 0 | 534,115 | There are no Audio releases needing processing at this time |
| Console | 0 | 34,977 | There are no console games needing processing at this time |
| Books | 0 | 598,840 | There are no books needing processing at this time |
| Misc | 901,354 | 131,951 | These are all the files that need to have passwords checked and/or samples generated, determine if their is a preview, etc. Again the new items take priority, but this will take a while since it has to download the release to get the information. |
| NFO's | 0 | 1,075,390 | NFO files are complete.  Any release with a NFO should have it listed |
| Releases | N/A | 2,276,532 | We are currently at just under 2.3 million releases. We went down in the number of releases due to the removal of all the passworded releases. |
| Backfill Status | N/A | 42% Done | Out of the 141 groups we are currently processing: 60 (42.6%) are done backfilling, 20 (14.2%) are between 120 - 200 days, 25 (17.7%) are between 100 - 120 days, 27 (19.1%) Between 50 - 100 Days, 11 (7.8%) Groups are under 50 days.  We should be starting this back up soon |

# Increased API Requests for all Users

## Thursday, March 14, 2013 - Staff

We have decided to bump up the number of API reuqests for everyone. (All amounts are based on a rolling 24 hour window) Trials now get 40 requests / Members get 400 / VIP get 1000 / Lifetime gets 2000

# Current Processing Status

## Monday, February 25, 2013 - Staff

Group Processing Changes: We are now processing the top 5 groups (by # of downloads) as fast as possible (This means they are downloaded within a minute or two from when a release is posted), the next 25 groups are being processed a bit slower but faster then before, and the lest common groups are being processed like before

# Current Processing Status

## Thursday, February 21, 2013 - Staff

Here are our current status on backfills and general processing:

|  |  |  |  |
| --- | --- | --- | --- |
| Category | In Process | Processed | Notes |
| TV Shows | 0 | 585,118 | All TV Shows have been processed. Once NFOs are processed I'll update any that were not found to make them reprocess, but that will be a couple of weeks. |
| Movies | 0 | 141,505 | There are no movies that need to be processed. There are some that are labeled wrong by the automation. We will be adding a report option sometime in the future to allow them to get resolved. |
| Audio | 0 | 533,118 | There are no Audio releases needing processing at this time |
| Console | 0 | 34,701 | There are no console games needing processing at this time |
| Books | 0 | 608,466 | There are no books needing processing at this time |
| Misc | 1,643,485 | 133,622 | These are all the files that need to have samples generated, determine if their is a preview, etc. Again the new items take priority, but this will take a while since it has to download the release to get the information. We have gone backwards in this category due to the length of time and the number of backfills processed. |
| NFO's | 880,710 | 559,122 | NFO files are being gathered as quick as possible yet with the huge import we did we are going to have a huge backlog. New releases should get NFOs pretty quickly |
| Releases | N/A | 2,323,623 | We are currently at almost 2.3 million releases. Just in the last 11 days of processing we have added almost 150k new releases from new stuff and the backfills we are doing |
| Backfill Status | N/A | 42% Done | Out of the 141 groups we are currently processing: 60 (42.6%) are done backfilling, 20 (14.2%) are between 120 - 200 days, 25 (17.7%) are between 100 - 120 days, 27 (19.1%) Between 50 - 100 Days, 11 (7.8%) Groups are under 50 days. |

# Top Downloads Added

## Thursday, February 14, 2013 - Staff

Ever wonder what is being download by other users? Click on the new Top Downloads link to see

# Miatrix Added to NZBMonster

## Thursday, February 14, 2013 - Staff

Got an android phone or tablet? Check out NZBMonster, its a great for browsing and searching NZB's and sending it to your sabnzbd. NZBMonster has added native support for Miatrix.com, so its easier than ever to use this site!

# Current Processing Status

## Sunday, February 10, 2013 - Staff

What a difference 10 days makes. Here are our current status on backfills and general processing:

|  |  |  |  |
| --- | --- | --- | --- |
| Category | In Process | Processed | Notes |
| TV Shows | 0 | 571,038 | All TV Shows have been processed. Once NFOs are processed I'll update any that were not found to make them reprocess, but that will be a couple of weeks. |
| Movies | 0 | 134,522 | There are no movies that need to be processed. There are some that are labeled wrong by the automation. We will be adding a report option sometime in the future to allow them to get resolved. |
| Audio | 0 | 522,819 | There are no Audio releases needing processing at this time |
| Console | 0 | 33,418 | There are no console games needing processing at this time |
| Books | 0 | 550,633 | There are no books needing processing at this time |
| Misc | 1,576,299 | 113,959 | These are all the files that need to have samples generated, determine if their is a preview, etc. Again the new items take priority, but this will take a while since it has to download the release to get the information. We have gone backwards in this category due to the length of time and the number of backfills processed. |
| NFO's | 1,082,163 | 449,106 | NFO files are being gathered as quick as possible yet with the huge import we did we are going to have a huge backlog. New releases should get NFOs pretty quickly |
| Releases | N/A | 2,175,425 | We are currently at almost 2.2 million releases. Just in the last 10 days of processing we have added 81k new releases from new stuff and the backfills we are doing |
| Backfill Status | N/A | N/A | We are currently at 50+ days processing for a majority of the groups. We are shooting for around 210 days of backfill to catch up with the gap in imports we processed |

# Problems Getting New Releases

## Wednesday, February 06, 2013 - Staff

We're running into some problems pulling down new releases. We apologize for the interruption of service, and are working to resolve it asap!

UPDATE: Everything is back on track and new releases are processing correctly!

# Current Processing Status

## Thursday, January 31, 2013 - Staff

Here is our current status on backfills and general processing:

|  |  |  |  |
| --- | --- | --- | --- |
| Category | In Process | Processed | Notes |
| TV Shows | 177,495 | 564,576 | The remaing shows are getting devided into the series and episode based on the title or NFO. Once all the NFO files have been processed we will run any TV Shows that are missing series/episode information thru again. Also note that all current TV shows are processed First. |
| Movies | 0 | 131,211 | There are no movies that need to be processed. There are some that are labeled wrong by the automation. We will be adding a report option sometime in the future to allow them to get resolved. |
| Audio | 209,559 | 518,584 | There are 209k audio files that need to be sampled to determine the quality and generate covers. Again new ones are processed as soon as possible. |
| Console | 0 | 32,979 | There are no console games needing processed at this time. |
| Books | 76,972 | 540,767 | There are 77k books that are still having information generated for them. |
| Misc | 1,496,757 | 88,795 | These are all the files that need to have samples generated, determine if their is a preview, etc. Again the new items take priority, but this will take a while since it has to download the release to get the information. |
| NFO's | 1,635,567 | 177,621 | NFO files are being gathered as quick as possible yet with the huge import we did we are going to have a huge backlog. New releases should get NFOs pretty quickly |
| Releases | N/A | 2,094,357 | We are currently at almost 2.1 million releases. Just in the last 4 days of processing we have added 20k new releases from new stuff and the backfills we are doing |
| Backfill Status | N/A | N/A | Due to issues we have had to restart backfilling the releases several times, but it appears all of those issues have been resovled. We are currently at about 30 days for most groups, however some groups have much less since they have a huge number of releases. Considering we restarted the backlog 5 days ago we are making great progress. |

# Search Gremlin Found and Squashed

## Tuesday, January 22, 2013 - Staff

We have squashed the search Gremlin so searches should be working again.

# New Server Online!!!

## Saturday, January 19, 2013 - Staff

Our second server is now online. We have the two servers setup for replication and will restart newsgroup processing later today after some tables and files finish moving over.

UPDATE:

Everything back to normal updates are processing and backfills will start once we catch up with current updates. Server should be much faster now.

# New Server On The Way!!!

## Wednesday, January 16, 2013 - Staff

We have purchased a second server for the site. This will allow us to run the processing and backfills without slowing the site down. Hopefully we will have this server running in the next day or two.

# Site Improvements

## Monday, January 14, 2013 - Staff

We have added News, Guides, and Chat today. Come join us on IRC

# Normal processing resuming.

## Sunday, January 13, 2013 - Staff

We are caught up on all groups and are continuing to backfill groups as processing times allows

# Database Died

## Saturday, January 12, 2013 - Staff

Database died on us and we had to restore the database. I was able to manually recover most everything but if you don't have the access you should have use the contact us to let us know and we will get you fixed up. We don't believe any paid user information was lost. The cause was that MySQL died when we tried to abort a query that was running for a long time.

# Heavy Backloading

## Friday, January 11, 2013 - Staff

We are starting some heavy back loading of TV Series. If the site becomes too slow lets us know and we will slow it down.

# Miatrix.com Goes Live!

## Thursday, January 10, 2013 - Staff

Today Miatrix goes live. Please keep in mind that we are constantly working to improve the site and make things run smoother. If you have any questions, please click the 'contact us' link.
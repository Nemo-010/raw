# NOUS41 KWBC 172020 PNSWSH Service Change Notice 21-32 National Weather Service Headquarters Silver Spring MD 420 PM EDT Wed Mar 17 2021 To: Subscribers: -NOAA Weather Wire Service -Emergency Managers Weather Information Network -NOAAPort Other NWS Partners, Users and Employees From: Ben Kyger, Direc

NOUS41 KWBC 172020 PNSWSH

Service Change Notice 21-32 National Weather Service Headquarters Silver Spring MD 420 PM EDT Wed Mar 17 2021

To: Subscribers: -NOAA Weather Wire Service -Emergency Managers Weather Information Network -NOAAPort Other NWS Partners, Users and Employees

From: Ben Kyger, Director NCEP Central Operations

Subject: NOMADS/FTP Website User Access Changes: Effective April 20, 2021

On or about April 20, 2021, the NWS National Centers for Environmental Prediction (NCEP) will be making a change to the user access policy for the following websites only:

https://nomads.ncep.noaa.gov https://ftp.ncep.noaa.gov https://ftpprd.ncep.noaa.gov ftp://ftp.ncep.noaa.gov ftp://ftpprd.ncep.noaa.gov

After reviewing user feedback from the Public Information Statement issued on November 18, 2020, NCEP has modified our proposal to be limited in scope to only the NOAA National Operational Model Archive and Distribution System (NOMADS)/ftp Web Services:

https://www.weather.gov/media/notification/pdf2/pns20- 85ncep_web_access.pdf

The mitigation will reduce the strain on our infrastructure, ensuring a more robust level of service for all of our users. This action protects and prevents our dissemination system from crashing during peak demand times.

While we continue upgrading our data server and network architecture, we must implement reasonable rate limiting on the Integrated Dissemination Program (IDP) to ensure that our dissemination system can continue to handle the Weather Enterprise's growing demand for data and as the amount of data available from our new models continues to increase. We will continue to evolve and strengthen our IDP and follow our four-phased approach as highlighted in the IDP Plan here:

https://www.weather.gov/media/wrn/NOAA-NWS-ODIS-Future-Needs-of-IDP.pdf

The usage policy will restrict individual user access to 120 hits/minute for only the websites listed above. All other website usage policies will

remain as they are today. This policy is applied as a sum of hits per user Internet Protocol (IP) address across all sites listed above.

Questions and comments regarding usage or the overall plan should be directed to:

Carissa Klemmer Chief, NCO Implementation and Data Services Branch idp.feedback@noaa.gov

National Service Change Notices are online at:

https://www.weather.gov/notification/

NNNN

> Agent-friendly representation of <https://container-registry.com/signup/index.md>. Site index: <https://container-registry.com/llms.txt>.


# Container Registry


## Offer Details

* Ideal for teams, organizations, agencies, and software vendors.
* Your own dedicated Harbor-based Container Registry fully managed.
* Full control and admin access
* Unlimited users, teams, groups
* Unlimited public or private repositories
* 100 GB of storage included
* 0.1€ GB/month for additional storage
* Unlimited inbound and outbound traffic
* Your custom domain like hub.company.com with an SSL/TLS certificate


## Trial Period

* 14 days of free trial at no cost.
* Subscription can be canceled any time, no artificial barriers

All prices are listed as VAT exclusive. Prices are in EUR, other currencies are for reference only.


## Not Yet Convinced?

[Contact](/contact) us, <a href="#" onclick="window.HubSpotConversations.widget.open()">chat with us</a> or give us a call for an individual consultation.



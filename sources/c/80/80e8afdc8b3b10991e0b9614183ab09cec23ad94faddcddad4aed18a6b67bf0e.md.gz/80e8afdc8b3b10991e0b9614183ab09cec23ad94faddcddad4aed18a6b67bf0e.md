> ## Documentation Index
> Fetch the complete documentation index at: https://docs.baseten.co/llms.txt
> Use this file to discover all available pages before exploring further.

# Baseten Delivery Network

> Mirror and cache model weights to reduce deployment and cold-start download time.

Baseten Delivery Network (BDN) mirrors model weights to Baseten and caches them near your replicas. Replicas can read from these caches instead of downloading weights from the original source during each scale-up.

Configure BDN with the `weights` key in `config.yaml` to mirror and cache model weights, or with the `bdn` key to mount existing BDN volumes. Both approaches support `Model` class deployments and [custom Docker servers](https://docs.baseten.co/development/model/custom-server.md).

> [card] [Get started](#quick-start)
>
> Add weights to a new model

> [card] [Custom servers](#custom-servers)
>
> Use with vLLM, SGLang, and more

> [card] [Migrate](#migration-from-model_cache)
>
> Move from `model_cache`

> [!TIP]
>
> BDN can mirror any [supported source](#source-types-and-authentication). If the weights exist only on local disk, publish them as a [volume](https://docs.baseten.co/development/volumes/overview.md) with `baseten volume push`, [bundle them with your Truss](https://docs.baseten.co/development/model/model-class.md#bundled-data) for small models, or upload them to a supported object store or private Hugging Face repository.

## Weights or volumes

| | `weights` | [Volumes](https://docs.baseten.co/development/volumes/overview.md) (`bdn.mounts`) |
| - | - | - |
| You provide | A source BDN mirrors: Hugging Face, S3, GCS, Azure, R2, CoreWeave, or Baseten Training | A volume you publish with `baseten volume push` or `baseten volume sync` |
| Versioning | Pin the source, such as a Hugging Face commit SHA | Immutable versions with digests and tags |
| At startup | Files download before the container starts | Files stream in as your model reads them |
| Sharing | Configured per deployment | One volume mounted by many deployments |
| Availability | All organizations and accelerators | All organizations; not on T4 or L4 GPUs |

Use `weights` to deploy a model by mirroring a public or private source with no extra steps. Prefer volumes when you publish your own files: use `bdn.mounts` whenever you can, since it gives you immutable versions, rollbacks by digest, and one set of files shared across many deployments. `weights` remains supported for mirroring a source you don't control into a deployment.

## Quick start

Add a `weights` section to `config.yaml`. The example highlights the section within a complete configuration:

```yaml config.yaml expandable {5-12} theme={"system"}
model_name: qwen-3-8b
resources:
  accelerator: H100
  use_gpu: true
weights:
  - source: "hf://Qwen/Qwen3-8B@b968826d9c46dd6066d109eabc6255188de91218"  # Pin a commit SHA for reproducible deploys
    mount_location: "/models/qwen"
    auth:
      auth_method: CUSTOM_SECRET
      auth_secret_name: "hf_access_token"
    allow_patterns: ["*.safetensors", "*.json", "tokenizer.*"]
    ignore_patterns: ["*.md", "*.txt"]
```

* [`source`](#param-source): Where to fetch weights from. Supports [Hugging Face](#hugging-face), [Baseten Training](#baseten-training), [S3](#aws-s3), [GCS](#google-cloud-storage), [R2](#cloudflare-r2), [CoreWeave](#coreweave-ai-object-storage), and [Azure Blob Storage](#azure-blob-storage).
* [`mount_location`](#param-mount-location): Absolute path where the weights appear in your container.
* [`auth`](#param-auth): Credentials for private or gated sources.
* [`allow_patterns`](#param-allow-patterns): Include files that match these patterns.
* [`ignore_patterns`](#param-ignore-patterns): Exclude files that match these patterns.

> [!NOTE]
>
> For private or gated sources, set `auth` on the weight source. With `CUSTOM_SECRET`, store your Hugging Face token as `hf_access_token` in [workspace settings](https://app.baseten.co/settings/secrets). You can also use [Hugging Face OIDC](#hugging-face-oidc). Public sources need no `auth`.

### Access weights in your model

When your model starts, weights are already downloaded and available at your `mount_location`.
The directory structure from the source is preserved:

```text theme={"system"}
/models/qwen/   # your mount_location
├── config.json
├── model-00001-of-00004.safetensors
├── model-00002-of-00004.safetensors
├── ...
├── model.safetensors.index.json
├── tokenizer.json
└── tokenizer_config.json
```

Load weights from this path in your `load()` method:

```python model.py theme={"system"}
from transformers import AutoModelForCausalLM

class Model:
    def load(self):
        # Weights are already available at mount_location
        self._model = AutoModelForCausalLM.from_pretrained(
            "/models/qwen",
            dtype="auto",
            device_map="auto"
        )
```

The mount is read-only.
Weights are fetched during `baseten model push` and cached, so cold starts only read from local or nearby caches.

## Custom servers

[Custom Docker servers](https://docs.baseten.co/development/model/custom-server.md), including vLLM and SGLang, can use BDN. BDN mounts files at `mount_location` before the container starts, so `start_command` can read the weights from that path.

```yaml config.yaml theme={"system"}
base_image:
  image: lmsysorg/sglang:v0.5.19
docker_server:
  start_command: python3 -m sglang.launch_server --model-path /models/qwen
    --served-model-name Qwen/Qwen2.5-3B-Instruct --host 0.0.0.0 --port 8000
  readiness_endpoint: /health
  liveness_endpoint: /health
  predict_endpoint: /v1/chat/completions
  server_port: 8000
weights:
  - source: "hf://Qwen/Qwen2.5-3B-Instruct@aa8e72537993ba99e69dfaafa59ed015b17504d1"
    mount_location: "/models/qwen"
```

For complete worked examples, see [Deploy LLMs with SGLang](https://docs.baseten.co/examples/sglang.md) or [Deploy LLMs with vLLM](https://docs.baseten.co/examples/vllm.md).

## Volumes

To publish, sync, and manage volumes, see [Volumes](https://docs.baseten.co/development/volumes/overview.md). The Management API can also [list volumes](https://docs.baseten.co/reference/management-api/volumes/list-volumes.md), [list volume versions](https://docs.baseten.co/reference/management-api/volumes/list-volume-versions.md), and [start a volume sync](https://docs.baseten.co/reference/management-api/volumes/create-a-volume-sync.md).

## Configuration reference

### `weights`

A list of weight sources to mount into your model container.

Every source must select at least one file after `allow_patterns` and `ignore_patterns` are applied. An empty source fails the deployment. For diagnosis and recovery, see [Weight mirroring errors](https://docs.baseten.co/troubleshooting/deployments.md#weight-mirroring).

```yaml config.yaml theme={"system"}
weights:
  - source: "hf://Qwen/Qwen3-8B@main"
    mount_location: "/models/qwen"
    auth:
      auth_method: CUSTOM_SECRET
      auth_secret_name: "hf_access_token"
    allow_patterns: ["*.safetensors", "*.json", "tokenizer.*"]
    ignore_patterns: ["*.md", "*.txt"]
```

**source** `string` *required*

URI specifying where to fetch weights from. Supported schemes:

* `hf://`: Hugging Face Hub.
* `bt://`: Baseten Training.
* `s3://`: AWS S3.
* `gs://`: Google Cloud Storage.
* `r2://`: Cloudflare R2.
* `cw://`: CoreWeave AI Object Storage.
* `azure://`: Azure Blob Storage.

For Hugging Face sources, specify a revision using `@revision` suffix (branch, tag, or commit SHA).

**mount\_location** `string` *required*

Absolute path where weights will be mounted in your container. **Must start with `/`**.

```yaml theme={"system"}
mount_location: "/models/qwen"  # Correct
mount_location: "models/qwen"   # Wrong - not absolute
```

**auth** `object`

Authentication configuration for accessing private weight sources. See [Source types and authentication](#source-types-and-authentication) for the expected format for each source type.

* `auth_method`: The authentication method. Use `CUSTOM_SECRET` for secret-based auth, `AWS_OIDC` for AWS OIDC, `AWS_ASSUME_ROLE` for AWS AssumeRole, `GCP_OIDC` for GCP OIDC, or `HF_OIDC` for [Hugging Face OIDC](#hugging-face-oidc).
* `auth_secret_name`: Name of a [Baseten secret](https://docs.baseten.co/development/model/secrets.md) holding the credentials. Required when `auth_method` is `CUSTOM_SECRET`.
* `hf_oidc_resource`: Required for `HF_OIDC` with an `hf://` source. Use the private repository ID (`namespace/name`) or the Hugging Face username with access to the gated repository.

**allow\_patterns** `string[]`

File patterns to include. Uses Unix shell-style wildcards. Only matching files will be downloaded.

```yaml theme={"system"}
allow_patterns:
  - "*.safetensors"
  - "config.json"
  - "tokenizer.*"
```

Patterns like `*.safetensors` only match files at the top level. Use `**/*.safetensors` to match files in subdirectories.

**ignore\_patterns** `string[]`

File patterns to exclude. Uses Unix shell-style wildcards. Matching files will be skipped.

```yaml theme={"system"}
ignore_patterns:
  - "*.md"
  - "*.txt"
  - "*.bin"  # Skip PyTorch .bin files if using safetensors
```

### `bdn`

Mount existing BDN [volumes](https://docs.baseten.co/development/volumes/overview.md) into your model container. Unlike [`weights`](#weights), which mirrors files from an external source, `bdn` mounts volumes that are already published to BDN. Use this when you have pre-published BDN volumes that multiple deployments can share. Volume mounts aren't available on T4 or L4 GPUs.

```yaml config.yaml theme={"system"}
bdn:
  mounts:
    - source: bdn:weights/llama-8b:prod
      path: /models/llama
      include: ["*.safetensors", "config.json"]
      exclude: ["training/"]
```

Use `include` to mount only the files the model needs, and `exclude` to remove matching files from that selection. Patterns are relative to the volume root; exclusions win. The example includes safetensors files and configuration files at any depth, and excludes the `training` directory and its descendants.

A BDN volume reference uses the format `bdn:namespace/volume[:tag|@digest]`:

* **Namespace** (`weights`): Groups volumes within your organization. Names are lowercase alphanumeric plus hyphens, at least two characters, and may not begin with a digit.
* **Volume** (`llama-8b`): One versioned collection of files. Every published version is immutable and identified by its content digest.
* **Tag** (`prod`): A mutable, case-sensitive name pointing at one version. A reference carrying neither tag nor digest resolves to the volume's head, its latest version.

**mounts** `object[]`

A list of BDN volume mounts. Each entry mounts an existing BDN volume at a specified path in your container.

**source** `string` *required*

A BDN volume reference. Format: `bdn:namespace/volume[:tag|@digest]`. The source must use the `bdn:` scheme.

**path** `string` *required*

Absolute path where the volume will be mounted at runtime. Must start with `/` and must not be the filesystem root. Each mount must have a unique path, and some system and runtime paths are rejected. See [Mount paths](https://docs.baseten.co/development/volumes/manage.md#mount-paths).

**include** `string[]` (default: \[])

Relative glob patterns selecting files from the volume. An empty list includes all files. Patterns without a slash, such as `*.safetensors`, match at any depth. A directory pattern includes its descendants.

**exclude** `string[]` (default: \[])

Relative glob patterns removing files from the mount. Exclusions win when a file matches both lists. An empty list excludes nothing.

Patterns must be non-empty relative paths without `.` or `..` segments, backslashes, or leading or trailing whitespace.

**access** `object[]`

Grants operations in BDN namespaces. Each entry requires a `namespace` and a nonempty `grants` list. Supported grants are `pull`, `push`, `tag`, `inspect`, and `delete`. Grant only the operations your deployment needs.

**hotload.enabled** `boolean` (default: false)

Enables loading BDN data while the deployment runs. [Contact us](mailto:support@baseten.co) to enable Hotload for your organization. This setting doesn't grant namespace access by itself.

## Source types and authentication

For private weight sources, create a [Baseten secret](https://docs.baseten.co/development/model/secrets.md) with the appropriate credentials.
Manage secrets in your [Baseten settings](https://app.baseten.co/settings/secrets).

### Hugging Face

To mirror a Hugging Face repository, set `source` to `hf://<owner>/<repository>@<revision>`. The revision can be a branch, tag, or commit SHA.

For a private or gated repository, use a stored access token or [Hugging Face OIDC](#hugging-face-oidc).

Baseten resolves a branch such as `@main` to a commit at deploy time. Push a new deployment to pick up newer weights.

#### Hugging Face access token

Store a [Hugging Face access token](https://huggingface.co/settings/tokens) as a [Baseten secret](https://docs.baseten.co/development/model/secrets.md) named `hf_access_token`. Reference the secret in the weight source's `auth` block.

```yaml config.yaml theme={"system"}
weights:
  - source: "hf://Qwen/Qwen3-8B@main"
    mount_location: "/models/qwen"
    auth:
      auth_method: CUSTOM_SECRET
      auth_secret_name: "hf_access_token"
    allow_patterns: ["*.safetensors", "config.json"]
```

#### Hugging Face OIDC

[Set up Hugging Face trust](https://docs.baseten.co/organization/oidc.md#authenticate-to-hugging-face) with the `type` claim set to `model_build`. In the weight source's `auth` block, set `auth_method` to `HF_OIDC` and `hf_oidc_resource` to the private repository ID or the Hugging Face username with access to the gated repository.

```yaml config.yaml theme={"system"}
weights:
  - source: "hf://acme/private-model@main"
    mount_location: "/models/private-model"
    auth:
      auth_method: HF_OIDC
      hf_oidc_resource: acme/private-model
```

### Baseten Training

Load weights from a [Baseten Training](https://docs.baseten.co/training/overview.md) checkpoint.

```yaml config.yaml theme={"system"}
weights:
  - source: "bt://my-training-project@job123/checkpoint-1"
    mount_location: "/models/trained"
```

**Format:** `bt://project[@revision][/checkpoint]`

* `project`: The name of your Baseten Training project.
* `@revision`: Optional. A training job ID or `latest`. Defaults to `latest`.
* `/checkpoint`: Optional. The checkpoint name within the training job. If omitted, uses the latest checkpoint.

> [!NOTE]
>
> Baseten automatically authenticates with your training project.

### AWS S3

Download weights from a private S3 bucket.

> [!TIP]
>
> If your model is small (a few GB or less), you can also [bundle weights directly with your Truss](https://docs.baseten.co/development/model/model-class.md#bundled-data) instead of fetching them from a remote source.

#### Pick an auth method

AWS S3 supports three authentication methods:

* **IAM credentials**: Use this if you have an AWS access key pair and want the simplest setup. Skip ahead to the [quick start](#quick-start-with-iam-credentials).
* **AWS OIDC**: Use this if you want short-lived, narrowly scoped tokens and are comfortable configuring an IAM trust policy in your AWS account. See [AWS OIDC](#aws-oidc-recommended).
* **AWS AssumeRole**: Use this to grant access by adding an IAM trust policy to a role in your AWS account. See [AWS AssumeRole](#aws-assumerole).

#### Quick start with IAM credentials

Use this path when you already have an AWS access key pair for an IAM user or role with read access to your bucket.

**To authenticate to S3 with IAM credentials**:

1. Create the secret in Baseten: in your [secrets settings](https://app.baseten.co/settings/secrets), add a secret named `aws_credentials` with this JSON value:

   ```json theme={"system"}
   {
     "aws_access_key_id": "AKIA...",
     "aws_secret_access_key": "...",
     "aws_region": "us-west-2"
   }
   ```

   Use these exact key names. Common variations like `access_key_id` (without the `aws_` prefix) cause authentication failures.

2. Reference the secret from your `config.yaml`:

   ```yaml config.yaml theme={"system"}
   weights:
     - source: "s3://my-bucket/models/custom-weights"
       mount_location: "/models/custom"
       auth:
         auth_method: CUSTOM_SECRET
         auth_secret_name: "aws_credentials"
   ```

3. Grant the IAM user the minimum required permissions on the bucket:

   ```json theme={"system"}
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Action": ["s3:ListBucket"],
         "Resource": "arn:aws:s3:::my-bucket"
       },
       {
         "Effect": "Allow",
         "Action": ["s3:GetObject"],
         "Resource": "arn:aws:s3:::my-bucket/models/custom-weights/*"
       }
     ]
   }
   ```

   The mirror lists objects under your prefix and downloads each file once. No write permissions are needed.

4. Push the model. The first deploy mirrors weights to Baseten's blob storage; subsequent deploys reuse the mirror unless the source or filters change.

For the full IAM credentials field reference, including optional fields, see [IAM credentials](#iam-credentials).

#### AWS OIDC (recommended)

OIDC provides short-lived, narrowly scoped tokens for secure authentication without managing long-lived credentials.

**To authenticate to S3 with AWS OIDC**:

1. [Configure AWS to trust the Baseten OIDC provider](https://docs.baseten.co/organization/oidc.md#aws) and create an IAM role with S3 permissions.

2. Add the OIDC configuration to your `config.yaml`:

   ```yaml config.yaml theme={"system"}
   weights:
     - source: "s3://my-bucket/models/custom-weights"
       mount_location: "/models/custom"
       auth:
         auth_method: AWS_OIDC
         aws_oidc_role_arn: arn:aws:iam::<account-id>:role/baseten-s3-access
         aws_oidc_region: us-west-2
   ```

> [!NOTE]
>
> No secrets needed. The `aws_oidc_role_arn` and `aws_oidc_region` are not sensitive and can be committed to your repository.

See the [OIDC authentication guide](https://docs.baseten.co/organization/oidc.md) for detailed setup instructions and best practices.

#### AWS AssumeRole

AWS AssumeRole provides short-lived credentials through an IAM trust policy in
your AWS account. The trust policy grants access at the Baseten organization
level, not the workload level.

**To authenticate to S3 with AWS AssumeRole**:

Before you configure S3 authentication, complete the [AWS AssumeRole
setup](https://docs.baseten.co/organization/aws-assume-role.md#set-up-aws-assumerole): get the Baseten
role ARN and your external ID, create an IAM role with a trust policy, and
attach S3 read permissions.

Add the AssumeRole configuration to your `config.yaml`:

```yaml config.yaml theme={"system"}
weights:
  - source: "s3://my-bucket/models/custom-weights"
    mount_location: "/models/custom"
    auth:
      auth_method: AWS_ASSUME_ROLE
      aws_assume_role_arn: arn:aws:iam::<account-id>:role/baseten-customer-access
      aws_assume_role_region: us-west-2
```

> [!NOTE]
>
> The `aws_assume_role_arn` and `aws_assume_role_region` values contain no
> credentials, so you can commit them to your repository.

See the [AWS AssumeRole guide](https://docs.baseten.co/organization/aws-assume-role.md) for trust policy setup and best practices.

#### IAM credentials

```yaml config.yaml theme={"system"}
weights:
  - source: "s3://my-bucket/models/custom-weights"
    mount_location: "/models/custom"
    auth:
      auth_method: CUSTOM_SECRET
      auth_secret_name: "aws_credentials"
```

**Format:** `s3://bucket/path`

**Authentication:** JSON with AWS credentials

| Field | Required | Description |
| - | - | - |
| `aws_access_key_id` | Yes | Access key ID for the IAM user or role. |
| `aws_secret_access_key` | Yes | Secret access key paired with the access key ID. |
| `aws_region` | No | Region of the bucket. Defaults to `us-east-1`. |
| `aws_session_token` | No | Session token for temporary credentials, such as those issued by AWS STS or `aws sso`. |

Example secret value with all fields:

```json theme={"system"}
{
  "aws_access_key_id": "AKIA...",
  "aws_secret_access_key": "...",
  "aws_region": "us-west-2",
  "aws_session_token": "..."
}
```

> [!WARNING]
>
> The required fields must use the exact names `aws_access_key_id` and `aws_secret_access_key`. Using `access_key_id` or `secret_access_key` (without the `aws_` prefix) causes authentication failures.

For the minimum required IAM policy, see the [quick start](#quick-start-with-iam-credentials).

### Google Cloud Storage

Download weights from a GCS bucket.

GCP supports using either [service accounts](https://cloud.google.com/iam/docs/service-account-overview) or OIDC for GCS authentication.

#### GCP OIDC (recommended)

OIDC provides short-lived, narrowly scoped tokens for secure authentication without managing long-lived credentials.

**To authenticate to GCS with GCP OIDC**:

1. [Configure GCP Workload Identity](https://docs.baseten.co/organization/oidc.md#gcp) to trust the Baseten OIDC provider and grant GCS permissions.

2. Add the OIDC configuration to your `config.yaml`:

   ```yaml config.yaml theme={"system"}
   weights:
     - source: "gs://my-bucket/models/weights"
       mount_location: "/models/gcs-weights"
       auth:
         auth_method: GCP_OIDC
         gcp_oidc_service_account: baseten-oidc@my-project.iam.gserviceaccount.com
         gcp_oidc_workload_id_provider: projects/123456789/locations/global/workloadIdentityPools/baseten-pool/providers/baseten-provider
   ```

> [!NOTE]
>
> No secrets needed. The service account and workload identity provider are not sensitive and can be committed to your repository.

See the [OIDC authentication guide](https://docs.baseten.co/organization/oidc.md) for detailed setup instructions and best practices.

#### Service account

```yaml config.yaml theme={"system"}
weights:
  - source: "gs://my-bucket/models/weights"
    mount_location: "/models/gcs-weights"
    auth:
      auth_method: CUSTOM_SECRET
      auth_secret_name: "gcp_service_account"
```

**Format:** `gs://bucket/path`

**Authentication:** GCP service account JSON key

| Secret Name | Secret Value |
| - | - |
| `gcp_service_account` | `{"type": "service_account", "project_id": "...", ...}` |

Download from GCP Console under IAM & Admin > Service Accounts.

### Cloudflare R2

Download weights from a Cloudflare R2 bucket.

```yaml config.yaml theme={"system"}
weights:
  - source: "r2://abc123def.eu.my-bucket/models/weights"
    mount_location: "/models/r2-weights"
    auth:
      auth_method: CUSTOM_SECRET
      auth_secret_name: "r2_credentials"
```

**Format:** `r2://account_id[.jurisdiction].bucket[/path]`

* `account_id`: Your Cloudflare account ID.
* `jurisdiction`: Optional. `eu` or `fedramp`. Omit for the default jurisdiction.
* `bucket`: R2 bucket name, separated from the account ID (and jurisdiction, if present) by periods.
* `path`: Optional. Path prefix within the bucket.

**Authentication:** JSON with R2 API credentials

| Secret Name | Secret Value |
| - | - |
| `r2_credentials` | `{"aws_access_key_id": "...", "aws_secret_access_key": "..."}` |

Get your R2 API tokens from the Cloudflare dashboard under R2 > Manage R2 API Tokens.

### CoreWeave AI Object Storage

Download weights from CoreWeave AI Object Storage (CAIOS), an S3-compatible object store.

```yaml config.yaml theme={"system"}
weights:
  - source: "cw://my-bucket/models/weights"
    mount_location: "/models/cw-weights"
    auth:
      auth_method: CUSTOM_SECRET
      auth_secret_name: "cw_credentials"
```

**Format:** `cw://bucket/path`

* `bucket`: Your CoreWeave AI Object Storage bucket name.
* `path`: Path prefix within the bucket.

Unlike R2, the CoreWeave URI has no account ID.

**Authentication:** JSON with S3-style credentials

| Secret Name | Secret Value |
| - | - |
| `cw_credentials` | `{"aws_access_key_id": "...", "aws_secret_access_key": "...", "aws_region": "..."}` |

`aws_region` is required. CoreWeave uses availability-zone-style regions such as `US-EAST-04A`. OIDC is not supported for CoreWeave sources; use a secret.

### Azure Blob Storage

Download weights from Azure Blob Storage.

```yaml config.yaml theme={"system"}
weights:
  - source: "azure://myaccount/container/weights"
    mount_location: "/models/azure-weights"
    auth:
      auth_method: CUSTOM_SECRET
      auth_secret_name: "azure_credentials"
```

**Format:** `azure://account/container/path`

* `account`: Your Azure storage account name.
* `container`: Blob container name within the storage account.
* `path`: Path prefix within the container. Optional.

**Authentication:** JSON with account key

| Secret Name | Secret Value |
| - | - |
| `azure_credentials` | `{"account_key": "..."}` |

The account name comes from the URI, so the secret needs only `account_key`. Azure sources don't support OIDC, and the secret is required even for public containers.

Get your [account key](https://learn.microsoft.com/en-us/azure/storage/common/storage-account-keys-manage) from the Azure portal under Security + networking > Access keys.

## Best practices

### Pin to specific commits

> [!WARNING]
>
> Avoid using branch names like `@main` in production. While Baseten pins to the commit SHA at deploy time, using `@main` means each new deployment may get different weights, making debugging and rollbacks difficult.

Always pin to a specific commit SHA for reproducible deployments:

```yaml config.yaml theme={"system"}
# Recommended - reproducible across deploys
weights:
  - source: "hf://Qwen/Qwen3-8B@<commit-sha>"
    mount_location: "/models/qwen"

# Not recommended for production - each new deployment resolves to a different commit
weights:
  - source: "hf://Qwen/Qwen3-8B@main"
    mount_location: "/models/qwen"
```

To find the current commit SHA for a Hugging Face repo:

```bash Terminal theme={"system"}
# Using the Hugging Face CLI
huggingface-cli repo-info Qwen/Qwen3-8B --revision main
```

### Filter files with patterns

Only download what you need to minimize cold start time:

```yaml config.yaml theme={"system"}
weights:
  - source: "hf://Qwen/Qwen3-8B@main"
    mount_location: "/models/qwen"
    allow_patterns:
      - "*.safetensors"    # Model weights
      - "config.json"      # Model config
      - "tokenizer.*"      # Tokenizer files
    ignore_patterns:
      - "*.bin"            # Skip PyTorch format if using safetensors
      - "*.md"             # Skip documentation
      - "*.txt"            # Skip text files
```

> [!WARNING]
>
> Patterns like `*.safetensors` only match files at the top level of the source. To match files in subdirectories, use `**/*.safetensors`.

### Use absolute mount paths

The `mount_location` must be an absolute path (starting with `/`):

```yaml config.yaml theme={"system"}
# Correct
mount_location: "/models/qwen"
mount_location: "/app/model_cache/my-model"

# Wrong - will fail validation
mount_location: "models/qwen"
mount_location: "./my-model"
```

### Keep mount locations unique

Each weight source must have a unique `mount_location`:

```yaml config.yaml theme={"system"}
# Correct - different paths
weights:
  - source: "hf://Qwen/Qwen3-8B@main"
    mount_location: "/models/qwen"
  - source: "hf://sentence-transformers/all-MiniLM-L6-v2@main"
    mount_location: "/models/embeddings"

# Wrong - duplicate paths will fail
weights:
  - source: "hf://model-a@main"
    mount_location: "/models/shared"
  - source: "hf://model-b@main"
    mount_location: "/models/shared"
```

### When weights are re-mirrored

Baseten caches weights based on a hash of their configuration and reuses cached weights when possible to avoid redundant downloads.

**Deduplication and mutation detection:**

Baseten deduplicates files based on their etag (a content hash), not just filename, and only re-mirrors files that have been mutated since the last pull. Unchanged files are reused from blob storage, even across deployments.

#### Weight access

A deployment reads only the weight sources it declares in its `weights` config. Caching and deduplication happen behind the scenes and never grant another deployment or organization access to your data. Private sources like S3, GCS, R2, CoreWeave, and Azure stay within your organization. Public sources like Hugging Face are already public, so Baseten can serve them from a shared cache across organizations.

**Changes that trigger re-mirroring:**

| Field | Re-mirrors? | Why |
| - | - | - |
| `source` | ✅ Yes | Different repository, revision, or path |
| `allow_patterns` | ✅ Yes | Different files will be downloaded |
| `ignore_patterns` | ✅ Yes | Different files will be downloaded |
| `auth` | ✅ Yes | Changing the auth secret name or method changes the configuration hash |

**Changes that do NOT trigger re-mirroring:**

| Field | Re-mirrors? | Why |
| - | - | - |
| `mount_location` | ❌ No | Only affects where weights appear in your container |

> [!TIP]
>
> To force a fresh download of weights that haven't changed, modify the `source` to point to a specific commit SHA instead of a branch name, or add a trivial change to `allow_patterns`.

## How it works

You own the source, and Baseten holds a mirror of it. On `baseten model push`, BDN reads your `weights` config, mirrors the files into Baseten's secure blob storage, and writes a manifest of content hashes. Files are keyed by hash, so a file BDN already holds is never transferred again, and each deployment mounts only the files in its own manifest.

Your `baseten model push` returns immediately. Mirroring runs in the background, and your model deploys to the workload plane only after mirroring completes, so weights are in place before your replica starts.

### What happens on cold start

Baseten runs workload planes across regions and clusters, each with its own cache tiers. When a replica starts, weights flow from blob storage through the in-cluster cache and the node cache, then are mounted read-only. Each tier serves the one below it, so later replicas read from a warm cache instead of downloading again.

### Key benefits

* **Non-blocking push:** `baseten model push` returns while mirroring continues in the background.
* **One-time mirroring:** BDN mirrors weights to Baseten storage instead of fetching them from the source for each cold start.
* **No upstream runtime dependency:** After mirroring, scale-ups and inference do not contact the original source.
* **Multi-tier caching:** An in-cluster cache prevents repeated downloads, and a node cache serves weights to subsequent replicas.
* **Deduplication:** BDN stores identical weight files once and shares them through hard links.
* **Parallel downloads:** Concurrent chunk fetching reduces download time for large models.

## BDN proxy

> [!NOTE]
>
> BDN proxy is available by request. [Contact us](mailto:support@baseten.co) to enable it for your organization.

If your model downloads weights in application code rather than through the `weights` config, BDN proxy can accelerate those downloads. When enabled, your container can route downloads through a distributed caching proxy that caches them across cluster nodes, so later replicas and scale-ups read from cache instead of re-downloading from the origin.

Baseten sets these environment variables on your container:

| Environment variable | Purpose |
| - | - |
| `BDN_PROXY` | Proxy address. |
| `REQUESTS_CA_BUNDLE` | CA bundle for Python `requests` and other TLS clients. |
| `SSL_CERT_FILE` | CA bundle for general SSL/TLS clients. |
| `PIP_CERT` | CA bundle for pip. |

Downloads only go through the proxy when your HTTP client points at it. Baseten doesn't set `HTTP_PROXY` or `HTTPS_PROXY`, so set them to the proxy address in your model code before downloading:

```python model.py theme={"system"}
import os

os.environ["HTTP_PROXY"] = os.environ["HTTPS_PROXY"] = os.environ["BDN_PROXY"]
```

Any client that honors `HTTP_PROXY` and `HTTPS_PROXY`, including `requests`, `huggingface_hub`, and `curl`, then downloads through the cache. You don't need to configure TLS trust: the CA bundle variables above already trust the proxy.

## Migration from `model_cache`

> [!WARNING]
>
> `model_cache` is deprecated. Migrate to `weights` for faster cold starts through multi-tier caching.

### Automated migration with `truss migrate`

The `truss migrate` CLI command automatically converts `model_cache` configurations:

```bash Terminal theme={"system"}
# Run in your Truss directory
truss migrate

# Or specify a directory
truss migrate /path/to/truss
```

The command will:

1. Show a colorized diff of the proposed changes.
2. Prompt for confirmation before applying.
3. Create a backup of your original `config.yaml`.
4. Warn about any `model.py` path changes needed.

### Manual migration reference

**From `model_cache` to `weights`:**

| `model_cache` | `weights` |
| - | - |
| `repo_id: "owner/repo"` | `source: "hf://owner/repo@rev"` |
| `revision: "main"` | Included in source URI as `@main` |
| `kind: "s3"` | Prefix: `s3://bucket/path` |
| `kind: "gcs"` | Prefix: `gs://bucket/path` |
| `kind: "azure"` | Prefix: `azure://account/container/path` |
| `volume_folder: "name"` | `mount_location: "/app/model_cache/name"` |
| `runtime_secret_name` | `auth_secret_name` |
| `allow_patterns` | `allow_patterns` (same) |
| `ignore_patterns` | `ignore_patterns` (same) |

**Example migration:**

> [tab] After (weights)
>
> ```yaml config.yaml theme={"system"}
> weights:
>   - source: "hf://Qwen/Qwen3-8B@main"
>     mount_location: "/app/model_cache/qwen"
>     allow_patterns:
>       - "*.safetensors"
>       - "config.json"
>     auth:
>       auth_method: CUSTOM_SECRET
>       auth_secret_name: hf_access_token
> ```

> [tab] Before (model\_cache)
>
> ```yaml config.yaml theme={"system"}
> model_cache:
>   - repo_id: Qwen/Qwen3-8B
>     revision: main
>     use_volume: true
>     volume_folder: qwen
>     allow_patterns:
>       - "*.safetensors"
>       - "config.json"
>     runtime_secret_name: hf_access_token
> ```

### Chains migration

For Truss Chains, update `Assets.cached` to `Assets.weights` in your Python code:

> [tab] After (weights)
>
> ```python theme={"system"}
> import truss_chains as chains
> from truss.base import truss_config
>
> class MyChainlet(chains.ChainletBase):
>     remote_config = chains.RemoteConfig(
>         assets=chains.Assets(
>             weights=[
>                 truss_config.WeightsSource(
>                     source="hf://Qwen/Qwen3-8B@main",
>                     mount_location="/app/model_cache/qwen",
>                     auth_secret_name="hf_access_token",
>                     allow_patterns=["*.safetensors", "config.json"],
>                 )
>             ],
>             secret_keys=["hf_access_token"],
>         ),
>     )
> ```

> [tab] Before (cached)
>
> ```python theme={"system"}
> import truss_chains as chains
> from truss.base import truss_config
>
> class MyChainlet(chains.ChainletBase):
>     remote_config = chains.RemoteConfig(
>         assets=chains.Assets(
>             cached=[
>                 truss_config.ModelRepo(
>                     repo_id="Qwen/Qwen3-8B",
>                     revision="main",
>                     use_volume=True,
>                     volume_folder="qwen",
>                     allow_patterns=["*.safetensors", "config.json"],
>                     runtime_secret_name="hf_access_token",
>                 )
>             ],
>             secret_keys=["hf_access_token"],
>         ),
>     )
> ```

**Key changes:**

* Replace `ModelRepo` with `WeightsSource`.
* Replace `repo_id` and `revision` with a `source` URI that has an `@revision` suffix.
* Replace `volume_folder` with an absolute `mount_location` path.
* Replace `runtime_secret_name` with `auth.auth_secret_name` inside an `auth` block that sets `auth_method: CUSTOM_SECRET`.
* Remove `use_volume` and `kind` (inferred from URI scheme).

### Custom server migration

When migrating an existing custom server deployment from `model_cache` to `weights`:

1. **Remove `truss-transfer-cli`** from your `start_command`. Files are pre-mounted before the container starts.
2. **Update file paths** from `/app/model_cache/{volume_folder}` to your new `mount_location`.

> [tab] After (weights)
>
> ```yaml config.yaml theme={"system"}
> docker_server:
>   # No truss-transfer-cli needed - weights are pre-mounted
>   start_command: text-embeddings-router --port 7997
>     --model-id /models/jina --max-client-batch-size 128
> weights:
>   - source: "hf://jinaai/jina-embeddings-v2-base-code@516f4baf..."
>     mount_location: "/models/jina"
>     ignore_patterns: ["*.onnx"]
> ```

> [tab] Before (model\_cache)
>
> ```yaml config.yaml theme={"system"}
> docker_server:
>   # Required truss-transfer-cli to download weights
>   start_command: bash -c "truss-transfer-cli && text-embeddings-router --port 7997
>     --model-id /app/model_cache/my_jina --max-client-batch-size 128"
> model_cache:
>   - repo_id: jinaai/jina-embeddings-v2-base-code
>     revision: 516f4baf13dec4ddddda8631e019b5737c8bc250
>     use_volume: true
>     volume_folder: my_jina
>     ignore_patterns: ["*.onnx"]
> ```

The [Custom servers](#custom-servers) section shows the pattern for new deployments.

## Automatic use with engine builders

Engine-builder deployments use BDN automatically. No `weights` block is required, and no configuration changes are needed when migrating an existing engine-builder deployment.

| Engine | When BDN is used |
| - | - |
| [BEI](https://docs.baseten.co/engines/bei/overview.md) | Every deploy. |
| [Briton (Engine-Builder-LLM)](https://docs.baseten.co/engines/engine-builder-llm/overview.md) | Every deploy. |
| [BIS-LLM (V2)](https://docs.baseten.co/engines/bis-llm/overview.md) | Every deploy. |

Build artifacts are mirrored once and served from the same multi-tier caches described in [How it works](#how-it-works).

## Hotload: attach BDN volumes while a deployment runs

Hotload lets a running deployment attach a published BDN volume for read-only access without a redeploy.

> [!NOTE]
>
> [Contact us](mailto:support@baseten.co) to enable Hotload for your organization.

Hotload isn't supported on T4 or L4 GPUs, customer or private workload planes, or organizations with weights in a private bucket.

Before starting, [publish a volume](https://docs.baseten.co/development/volumes/manage.md#publish-a-new-version). The example uses `bdn:weights/custom-model:prod`; replace it with your volume reference and set `namespace` to its namespace.

1. Add namespace access, enable Hotload, and install the [BDN SDK](https://pypi.org/project/baseten-bdn/) in `config.yaml`. The SDK requires Python 3.11 or later:

   ```yaml config.yaml theme={"system"}
   python_version: py311
   requirements:
     - baseten-bdn
   bdn:
     access:
       - namespace: weights
         grants:
           - pull
     hotload:
       enabled: true
   ```

2. Attach the volume inside your model code. This example lists the files in the attached directory, then detaches it:

   ```python model/model.py theme={"system"}
   from pathlib import Path
   from uuid import uuid4

   from baseten.bdn.hotload import HotLoadClient


   class Model:
       def __init__(self, **kwargs):
           pass

       def predict(self, request):
           with HotLoadClient() as hotload:
               attachment = hotload.attach(
                   "bdn:weights/custom-model:prod",
                   target=f"custom-model-{uuid4().hex}",
               )
               try:
                   return sorted(path.name for path in Path(attachment.path).iterdir())
               finally:
                   hotload.detach(attachment.id)
   ```

3. [Deploy or redeploy your model](https://docs.baseten.co/development/model/deploy-and-iterate.md), then [send a prediction request](https://docs.baseten.co/inference/calling-your-model.md). The response lists your volume's files. Changes to `bdn.access` and `bdn.hotload` take effect on deployment.

`attach()` returns once the directory at `attachment.path` is readable under `/bdn/mounts`. This example attaches on every request. For files your model reuses across requests, attach once in `load()` and keep the attachment while the model uses the files. Each target name holds one attachment at a time.

Detach the attachment when your model stops using the files. Closing the client without detaching leaves the volume attached to the replica.

If `attach()` raises `HotLoadTimeoutError`, the daemon may still complete the attachment. Check `list_attachments()` for the target and detach any matching attachment before retrying. The daemon reports rejected attach requests as `HotLoadAPIError`.

## Next steps

* [Weight mirroring errors](https://docs.baseten.co/troubleshooting/deployments.md#weight-mirroring): Diagnose deployment failures and missing weight files.

* [Secrets](https://docs.baseten.co/development/model/secrets.md): Store credentials for private weight sources.

* [Custom Docker images](https://docs.baseten.co/development/model/custom-server.md): Deploy vLLM, SGLang, and other inference servers.

* [Autoscaling](https://docs.baseten.co/deployment/autoscaling.md): Configure replica scaling and cold start behavior.

* [Configuration reference](https://docs.baseten.co/reference/truss-configuration.md#weights): Full list of `weights` options.

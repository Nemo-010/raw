[Box](https://www.box.org/home) Main Navigation

- [Our impact](https://www.box.org/our-impact)
- [How we work](https://www.box.org/how-we-work)
- [Get started](https://www.box.org/use-box)
- [Resources](https://www.box.org/resources)
- [Box Impact Fund](https://www.box.org/impact-fund)

## Get started with Box

### Intelligent Content Management for nonprofits

![volunteer sorting donations and team collaboration with shared files](https://www.box.org/sites/box.org/files/styles/288xauto/public/2025-12/01_get_started_header.png?itok=5yMrhfTa)

### Three simple steps to get started with Box

We’ll get you set up quickly so you can get on with delivering your mission and generating support for your organization. With donated or discounted access, you get a single place to collaborate, manage, and secure all your content, simplify your processes, and take advantage of AI-driven insights and workflow automation. By integrating seamlessly with the apps you already use, it couldn’t be easier to work with Box.

### Here’s how to get set up:

![user](https://www.box.org/sites/box.org/files/2021-08/box-org-icon-1.svg)

#### 1. Review the Box.org eligibility criteria

Nonprofit organizations are eligible for discounted Box products if the organization has a recognized legal status in its respective country equal to [501(c)(3) status under the United States Internal Revenue Code](https://www.irs.gov/charities-non-profits/charitable-organizations/exemption-requirements-501c3-organizations), with certain exceptions listed below in the FAQ. In addition, organizations must be verified by TechSoup Global Network or the local TechSoup partner via a Validation Token.

![validation token](https://www.box.org/sites/box.org/files/2021-08/box-org-icon-2.svg)

#### 2. Collect your TechSoup Global Network Validation Token

To acquire your TechSoup Validation Token please register (for free) via [this page](https://app.ngok.techsoup.org/Default.aspx?vendorAppId=95e5f45a-13f0-4737-9797-05dcd9ec149b) (process may take 2-5 business days). After validation review, you will have access to your TechSoup Validation Token. You are now ready to return to the  [Box.org](http://box.org/) Get Started page and select a Box plan.

![features](https://www.box.org/sites/box.org/files/2021-08/box-org-icon-3.svg)

#### 3. Get started with the right plan for your organization

See the features and comparison chart below to choose the best plan for your organization. Choose from our six offering options: Starter, Business, Business Plus, Enterprise, Enterprise Plus, and Enterprise Advanced. All Box plans are at a minimum 50% discount for eligible nonprofit organizations. 

# Choose the best plan for your business

# AI-powered content management for your business

Donated Plan Nonprofit Enterprise Plans

Donated PlanNonprofit Enterprise Plans

Monthly Annually Save 25%

### Starter

Secure file collaboration, storage and native e-signatures for up to 10 users

100 GB of storage

2 GB file upload

25 file versions

**Box Sign: 10 docs for e-sign per user per month; Unlimited templates**

Technical Support during local business hours

**Show features****Hide features**

**$8 $0$5.80 $0*** per user/month paid annually*minimum of 3 users

[Get started](https://account.box.com/signup/starter/nonprofit/?tc=annual)

Free

##### All the plans include these features

Secure File sharing

Shared folders and links

2-factor authentication

Anytime, anywhere access

Built-in integrations with Microsoft 365  
and Google Workspace

**Box Canvas**

Box Mobile App Collaboration

Integrated desktop experience

Online/self-paced training

Note-taking and project management

Box Community access

Show more featuresShow less features

### Business

Essentials for team collaboration, with Box AI

Unlimited storage

5GB file upload

External collaborators (pay per each)

![AI](https://www.box.org/themes/custom/box_shiny/assets/ai.svg)Integrated Box AI

Unlimited e-sign requests

1,500+ integrations

Built-in security and SOC 1/2/3 compliance support

50K API calls per month\*

**Show features****Hide features**

**$24 $11.53$17.30 $8.31*** per user/month paid annually*minimum of 3 users

[Get started](https://account.box.com/signup/business/nonprofit/?tc=annual)

50% off

### Business Plus

Content management & unlimited collaboration, with Box AI

Unlimited storage

15GB file upload

Unlimited external collaborators

![AI](https://www.box.org/themes/custom/box_shiny/assets/ai.svg)Integrated Box AI

Unlimited e-sign requests

1,500+ integrations

Built-in security and SOC 1/2/3 compliance support

Advanced admin controls

50K API calls per month\*

**Show features****Hide features**

**$39 $19.01$28.70 $13.99*** per user/month paid annually*minimum of 3 users

[Get started](https://account.box.com/signup/business-plus/nonprofit/?tc=annual)

50% off

### Enterprise

Content management & advanced compliance, with Box AI

Unlimited storage

50GB file upload

Unlimited external collaborators

![AI](https://www.box.org/themes/custom/box_shiny/assets/ai.svg)Integrated Box AI

Content portals with Box Hubs

![AI](https://www.box.org/themes/custom/box_shiny/assets/ai.svg)1K AI Units per month

Unlimited e-sign requests

1,500+ integrations

Advanced workflows

Advanced security

FedRAMP Moderate, HIPAA, SOC 1/2/3 compliance support

100K API calls per month\*

**Show features****Hide features**

**$54 $26.99$40.30 $20.14*** per user/month paid annually*minimum of 3 users

[Get started](https://account.box.com/signup/enterprise-plan/nonprofit/?tc=annual)

50% off

Enhanced Box AI

### Enterprise Plus

Advanced content management, security, & Box AI

Unlimited storage

150GB file upload

Unlimited external collaborators

![AI](https://www.box.org/themes/custom/box_shiny/assets/ai.svg)Integrated Box Agent

![AI](https://www.box.org/themes/custom/box_shiny/assets/ai.svg)Content portals with Box Hubs

![AI](https://www.box.org/themes/custom/box_shiny/assets/ai.svg)2K AI Units per month

Unlimited e-sign requests

1,500+ integrations

FedRAMP Moderate, HIPAA, SOC 1/2/3 compliance support

Advanced workflows

Advanced security

Threat detection rules and alerts

100K API calls per month\*

Enhanced support 24 hour coverage

**Show features****Hide features**

**Switch to Annual billing to view Enterprise Plus pricing$57.50 $28.75*** per user/month paid annually*minimum of 3 users

[Get started](https://account.box.com/signup/enterprise-plus/nonprofit/?tc=annual)

50% off

##

## Enterprise Advanced

AI-powered workflows, automation, and agents to transform your business

[Buy now](https://account.box.com/signup/enterprise-advanced/nonprofit/?tc=annual) [Contact us](https://www.box.com/about-us/contact-us)

- **Multi-step execution with extended context limits**
- Tackle complex RFPs and create ready to share communications with Box Agent in Pro Mode
- Create custom AI agents for specific business needs
- Connected forms for business processes with Box Forms
- Automated document generation\*
- Agentic metadata extraction\*
- Higher API allowances
- Large file uploads up to 500GB
- Compliant long-term data preservation with Box Archive
- Agentic workflows
- ***All Enterprise Plus capabilities included***

\* via AI Agents. [Learn More Here](https://www.box.org/extract)

## Plan comparison

-
-

  

Business

<a href="https://account.box.com/signup/business/nonprofit/?tc=annual">Get started</a>



Business Plus

<a href="https://account.box.com/signup/business-plus/nonprofit/?tc=annual">Get started</a>



Enterprise

<a href="https://account.box.com/signup/enterprise-plan/nonprofit/?tc=annual">Get started</a>



Enterprise Plus

<a href="https://account.box.com/signup/enterprise-plus/nonprofit/?tc=annual">Get started</a>



Enterprise Advanced

<a href="https://account.box.com/signup/enterprise-advanced/nonprofit/?tc=annual">Buy now</a>



  

Business

<a href="https://account.box.com/signup/business/nonprofit/?tc=annual">Get started</a>



Business Plus

<a href="https://account.box.com/signup/business-plus/nonprofit/?tc=annual">Get started</a>



Enterprise

<a href="https://account.box.com/signup/enterprise-plan/nonprofit/?tc=annual">Get started</a>



Enterprise Plus

<a href="https://account.box.com/signup/enterprise-plus/nonprofit/?tc=annual">Get started</a>



Enterprise Advanced

<a href="https://account.box.com/signup/enterprise-advanced/nonprofit/?tc=annual">Buy now</a>



##### STORAGE &amp; FILE UPLOAD  

Storage  

Unlimited


Unlimited


Unlimited


Unlimited


Unlimited


Single file upload limit  

5 GB


15 GB


50 GB


150 GB


500 GB


Desktop &amp; Mobile Access  











##### USERS &amp; ADMIN CONTROLS  

Minimum users  

3


3


3


3


3


Maximum users  

Unlimited


Unlimited


Unlimited


Unlimited


Unlimited


External collaborators  

Require paid account


Unlimited


Unlimited


Unlimited


Unlimited


User management  











Advanced user &amp; security reporting  











Sharing permissions &amp; access controls  











Advanced admin &amp; controls  











Admin role delegation  











##### SUPPORT  

Standard business support  











Optional: Premier Support  

$


$


$






Enhanced support 24 hour coverage  











##### AI SOLUTIONS  

AI-powered Search  











Conversational AI orchestrated by Box Agent  











Pro Mode for Box Agent  











Box AI Q&amp;A  

Single File


Single File


Single File


Multi-File


Multi-File


Box AI content generation  







Enhanced


Enhanced


Box AI Q&amp;A for Hubs  









Unlimited


Box AI Units included per month#  

$


$


1,000


2,000


20,000


Standard and Enhanced Extract Agents#  

Via APIs


Via APIs


Via APIs


Via APIs


Via web app and APIs


Custom Extract Agents#  









Via web app


Custom Box Agents with expanded context and enterprise knowledge  











##### SECURITY AND COMPLIANCE  

Data loss protection  











SSL &amp; at-rest encryption  











Two-factor authentication  

User opt-in


User opt-in


Organization setting


Organization setting


Organization setting


Active directory &amp; SSO (Single Sign-On) integration  











Mobile security controls  











SOC 1/SOC 2/SOC 3 compliance  











PCI DSS  











HIPAA/HITECH-eligible  











FedRAMP Moderate  











Device trust (advanced mobile requirements)  











Password policy enforcement  











FedRAMP High  





Additional Cost


Additional Cost


Additional Cost


Threat detection rules and alerts  





$ Via Shield Add On






Native security classifications  





$ Via Shield Add On






Classification-based access policies  





$ Via Shield Add On






Compliant Archive  











GxP compliance with 21 CFR Part 11  







Additional Cost


Additional Cost


##### FILE &amp; VERSION CONTROL  

Version history  

50


50


100


Unlimited


Unlimited


Full content visibility &amp; management  











Full user activity tracking  











Document watermarking  











##### APPS &amp; INTEGRATIONS  

Built-in integrations with Microsoft 365, Google Workspace and Slack  











MCP server for third party AI agents<br>Additional charges may apply for API calls generated and AI units consumed  











Enterprise app integrations  

1


10


Unlimited


Unlimited


Unlimited


API calls per month  

50,000\*


50,000\*


100,000\*


100,000\*


200,000\*


Unlimited integrations, including DLP &amp; eDiscovery  











No-code apps with custom dashboards  









Unlimited


##### eSIGNATURE WITH BOX SIGN  

Workflows for Box Sign via Box Relay  











eSignatures via Box Sign  

Unlimited


Unlimited


Unlimited


Unlimited


Unlimited


Included Box Sign signature requests for e-signatures via 3rd party &amp; custom integrations (per year)  

100\*


150\*


250\*


Unlimited (3rd party), 1,000\* (custom)


Unlimited (3rd party), 1,000\* (custom)


##### BRANDING &amp; CUSTOMIZATIONS  

Custom branding  











Metadata &amp; custom templates  











Custom terms of service  











##### COLLABORATION TOOLS  

Notes via Box Notes  











Whiteboards via Box Canvas  











Box Hubs  











Box Forms: web and mobile forms  









Unlimited


##### DOCUMENT GENERATION  

Generate documents natively in Box  









Unlimited


Generate documents in Salesforce  









Unlimited


Generate documents via custom integrations with the Doc Gen API  









2,000\*


##### OPTIONAL ADD-ONS  

Optional: Box Governance, Box Zones  

$


$


$






Optional: Box Keysafe  

$


$


$


$


$


Optional: Box Shield  





$






Optional: Box Shield Pro*<br>Box Shield Pro requires Box Shield to purchase  





$


$


$


Show more featuresShow fewer features

\*Additional volume available for purchase.

### Box supports thousands of nonprofits to advance their mission

**We proudly offer software discounts and donations that power nonprofits. With Box, you can streamline workflows, tap into AI automation and insights, and collaborate securely on mission-critical content in real time. We’d love your organization to be part of our nonprofit community.**

### FAQ

##### Is my organization eligible for the Box.org product offers?

Nonprofit organizations are eligible for discounted Box products if the organization has a recognized legal status in their respective country equal to [501(c)(3) status under the United States Internal Revenue Code](https://www.irs.gov/charities-non-profits/charitable-organizations/exemption-requirements-501c3-organizations), with certain exceptions (listed below). In addition, organizations must be verified by TechSoup or the local TechSoup partner.

**The following are ineligible for Box software discounts and donations:**

- **Hospitals and health insurance plans.** Exceptions include: healthcare co-ops, substance abuse and mental health services, emergency services, blood banks and clinics, health research entities, and reproductive health services
- **Schools, colleges, and trade schools**
- **Organizations within countries sanctioned by the US.** This includes organizations within any sanctioned countries included on the US Department of Treasury's Office of Foreign Assets [control list](https://home.treasury.gov/policy-issues/financial-sanctions/sanctions-programs-and-country-information), which is updated periodically

##### Why do I need a TechSoup Validation Token to be eligible for Box.org discounts?

In order to receive Box.org discounts, nonprofit, charitable organizations must meet Box.org's eligibility criteria per country and complete the eligibility process through our partner, TechSoup Global Network. Please follow the instructions above on this page to get your TechSoup Validation Token to start this process. To learn more about TechSoup Validation Tokens, please visit [TechSoup's Validation FAQ](https://www.techsoup.org/support/validation-tokens). 

##### How are other nonprofits using Box?

Read the overview of [Box for Nonprofits](https://www.box.com/industries/non-profit) to learn how thousands of nonprofits around the world use Box to execute and scale programs, generate support, and streamline administration enabling them to spend more time focused on their missions. You can also review our [customer stories](https://www.box.com/customers?industry=1986) to learn more about how nonprofits use Box to power their mission. Lastly, here's a [grid](https://cloud.box.com/s/mr1mit6q16zxm09bsnai65jia4kpqoku) that breaks down Box use cases that benefit nonprofits.

##### What is Box.org's pricing for nonprofits?

We donate up to 10 perpetual licenses for Box Starter edition or offer 50% discount on monthly or annual subscriptions to any Box Enterprise plan. Additionally we offer 75% off add-ons (including, but not limited to: Box Relay, Box Shield, Box Governance, and many others), 50% off Enterprise Plus\*, 20% off Box Consulting services, and 15% off Premier Support services.

If you're interested in upgrading your current Box plan, please work with our billing team by contacting them [here](https://www.box.org/contact-us). Under "Contact Reason" select "Purchase or Learn More About Box Products & Services".  This way, your message will get directly routed to the correct team to address your needs.

\*If you are interested in Enterprise Plus, please contact us [here](https://www.box.com/quote?tc=monthly) for more info.

##### How do I purchase Box's Enterprise Plus or Enterprise Advanced plan?

Box.org offers 50% off Nonprofit Enterprise plans for eligible organizations. If you are interested in Enterprise Plus or Enterprise Advanced, please contact us [here](https://www.box.com/quote?tc=monthly) for more info.

##### Who can I reach out to if I have further questions?

If you would like to learn more about the Box.org discount or donation program, contact us [here](https://www.box.org/contact-us) and select “product offerings” in the dropdown. For billing, support, or account-related inquiries, log a ticket directly [here](https://support.box.com/hc/en-us/requests/new) or visit our Box Support page [here](https://support.box.com/) for product help and information.

\# Subject to [Box AI Unit consumption](https://cloud.box.com/v/box-ai-units-consumption-table). Additional volume available for purchase   
\* Additional volume available for purchase.

- [YouTube](https://www.youtube.com/box)
- [Blog](https://blog.box.com)
- [Twitter](https://twitter.com/Box_Org)
- [LinkedIn](https://www.linkedin.com/company/box)

- ©2026 Box
- [Privacy Policy](https://www.box.com/legal/privacypolicy)
- [Cookie Notification](https://www.box.com/legal/cookie-notification)

English (US) English (US) 日本語
API overview - Document - Coze

API overview

Coze is a next-generation AI application and agent development platform. Regardless of your programming experience, Coze enables you to effortlessly create various agents and deploy them across different social platforms and messaging apps.​

Coze allows you to publish your agent as an API service to integrate into your applications. You can make an HTTP request to interact with the created AI agent.​

Limits​

Rate limit​

The rate limit of the Coze chat API is related to the accumulated number of Coze tokens.​

| Accumulated purchased Coze tokens​ | RPS (Requests per second)​ | RPM (Requests per minute)​ | RPD (Requests per day)​ |
| --- | --- | --- | --- |
| Less than 2M (2,000,000)​ | 5​ | 300​ | 20,000​ |
| Reach or exceed 2M (2,000,000)​ | 15​ | 1,000​ | Unlimited​ |

Request body limits​

Limits for API request body size are as follows:​

- For workflow API requests: 50MB​

- For other API requests: 15MB​

Pricing​

When calling a Coze API, it will consume tokens if LLM is used. After the free token quota is used, you can purchase tokens on the Coze Token page. For more information, refer to ​ Coze tokens.​

Coze provides a free API call quota for all registered users, of which the free quotas for API services and SDK services are accumulated separately. The free quota for the API service is 30 Coze API calls, and the deduction of the free quota includes all APIs of all agents under the current account, regardless of whether these APIs consume tokens. If your API call count exceeds 30 times, Coze will deduct tokens based on the actual number of tokens consumed by API calls.​

Make a request​

You can paste the command below into your terminal to run your first API request.​

Replace the following values before running the command:​

- Authorization: The personal access token used for authentication. Click here to generate your personal access token.​

- bot_id: The ID of the agent. Obtain it from the Develop page URL of your agent in Coze. The number after the bot parameter is the agent ID. For example: https://www.coze.com/space/12345****/bot/73428668*****. The agent ID is 73428668*****.​

- Note

Make sure the agent is published as an API service. For more information, see ​ Before you begin.​

​

- user_id: Identify the user who is currently interacting with the agent. This user must be defined, generated, and maintained within the business system.​

- content: The message to send to the agent.​

- ​

curl --location --request POST 'https://api.coze.c om/v3/chat' \​

--header 'Authorization: Bearer pat_OYDacMzM3WyOWV3Dtj2bHRMymzxP****' \​

--header 'Content-Type: application/json' \​

--data-raw '{​

 "bot_id": " 73428668*****",​

 "user_id": " 123123***",​

 "stream": false,​

 "auto_save_history":true,​

 "additional_messages": [​

 {​

 "role":"user",​

 "content":"早上好",​

 "content_type":"text"​

 }​

 ]​

}'​

​

Basic concepts​

| Concepts​ | Description​ |
| --- | --- |
| Conversation​ | An interaction between an agent and a user. A conversation includes one or more messages and can automatically handle truncation to fit the model's context content.​ |
| Message​ | A message created by a user or an agent, which includes text, images, or files. Messages are stored in a list within a conversation.​ |
| Chat​ | An invocation of an agent within a conversation. Upon receiving a request, the agent uses the user's input and a series of preset workflows to call models or tools to perform specific tasks. Each chat is part of a conversation, and the agent appends messages generated in the chat to the conversation.​ You can directly initiate a chat for a single interaction with an agent; alternatively, you can create a conversation and messages, and initiate a chat within a specified conversation, where other messages in the session will be passed to the large model as historical messages.​ |

Limits

Rate limit

Request body limits
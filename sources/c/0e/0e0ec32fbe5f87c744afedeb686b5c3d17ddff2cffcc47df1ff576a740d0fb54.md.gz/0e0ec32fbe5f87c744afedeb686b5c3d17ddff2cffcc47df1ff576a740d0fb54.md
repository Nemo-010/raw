---

# API v2 Overview

RESTful API for messaging, contacts, and account management

The Sendblue API v2 provides a new and improved RESTful interface for iMessage, SMS, and RCS messaging, supporting a variety of more advanced and robust features.

## V2 Features

Section titled “V2 Features”

| Feature | Description |
| --- | --- |
| [Messages](https://docs.sendblue.com/api-v2/messages) | Query, filter, and delete messages |
| [App Cards](https://docs.sendblue.com/api-v2/app-cards) | Send and continue interactive iMessage App Cards (V2 lines only) |
| [Media Upload](https://docs.sendblue.com/api-v2/media) | Upload images, video, and files |
| [Reactions](https://docs.sendblue.com/api-v2/reactions) | Send tapback reactions (six classic names or any single emoji) |
| [Carousel Messaging](https://docs.sendblue.com/api-v2/carousel) | Send swipeable multi-image carousels (V2 lines only) |
| [Read Receipts](https://docs.sendblue.com/api-v2/read-receipts) | Mark messages as read |
| [Typing Indicators](https://docs.sendblue.com/api-v2/typing-indicators) | Show typing status in conversations |
| [RCS Messaging](https://docs.sendblue.com/api-v2/rcs) | Rich Communication Services for Android |
| [Contacts](https://docs.sendblue.com/api-v2/contacts) | Full CRUD API for contact management |
| [Contact Sharing](https://docs.sendblue.com/api-v2/contact-sharing) | Configure Name & Photo Sharing profiles |
| [Line Provisioning](https://docs.sendblue.com/api-v2/line-provisioning) | Add and remove `inbound_only` / Agent plan phone lines via API |
| [Line Usage](https://docs.sendblue.com/api-v2/line-usage) | Get each line’s new-contact usage, limits, and remaining capacity |
| [Known Contacts per Line](https://docs.sendblue.com/api-v2/line-contact-status) | Check whether a contact is known or new on a specific Sendblue line |
| [Subaccounts](https://docs.sendblue.com/api-v2/subaccounts) | Create and manage child accounts for agency partners |
| [TOTP (Authenticator)](https://docs.sendblue.com/api-v2/totp) | Store encrypted TOTP secrets and generate 2FA codes programmatically |

See also: [FaceTime API](https://docs.sendblue.com/calling/facetime) (requires FaceTime line)

## Base URL

Section titled “Base URL”

```
https://api.sendblue.com
```

## Authentication

Section titled “Authentication”

All endpoints require API key headers:

```
sb-api-key-id: YOUR_API_KEYsb-api-secret-key: YOUR_API_SECRET
```

## Endpoints

Section titled “Endpoints”

### Messaging

Section titled “Messaging”

See the full guides: [Sending Messages](https://docs.sendblue.com/getting-started/sending-messages), [Receiving Messages](https://docs.sendblue.com/getting-started/receiving-messages)

| Method | Endpoint | Description |
| --- | --- | --- |
| `POST` | `/api/send-message` | Send a message |
| `POST` | `/api/messages/:handle/update-app-card` | Continue an App Card (V2) |
| `POST` | `/api/send-carousel` | Send image carousel (V2) |
| `GET` | `/api/status` | Get message status |
| `GET` | `/api/evaluate-service` | Check recipient service type |

### Groups

Section titled “Groups”

See the full guide: [Group Messages](https://docs.sendblue.com/getting-started/groups)

| Method | Endpoint | Description |
| --- | --- | --- |
| `POST` | `/api/create-group` | Create group chat |
| `POST` | `/api/send-group-message` | Send group message |
| `POST` | `/api/modify-group` | Add/remove group member |
| `GET` | `/api/v2/groups/{group_id}` | Get group membership |
| `POST` | `/api/v2/groups/{group_id}/name` | Rename or clear an iMessage group name ([guide](https://docs.sendblue.com/api-v2/group-names)) |
| `POST` | `/api/v2/groups/{group_id}/photo` | Set or clear an iMessage group photo ([guide](https://docs.sendblue.com/api-v2/group-photos)) |

### Messages

Section titled “Messages”

| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/api/v2/messages` | List messages with filters |
| `GET` | `/api/v2/messages/:id` | Get single message |
| `DELETE` | `/api/message/:handle` | Delete message from database |

### Reactions & Read Receipts

Section titled “Reactions & Read Receipts”

| Method | Endpoint | Description |
| --- | --- | --- |
| `POST` | `/api/send-reaction` | Send tapback reaction |
| `POST` | `/api/mark-read` | Send read receipt |
| `POST` | `/api/send-typing-indicator` | Send typing indicator |

### Media

Section titled “Media”

| Method | Endpoint | Description |
| --- | --- | --- |
| `POST` | `/api/upload-file` | Direct file upload |
| `POST` | `/api/upload-media-object` | Upload from URL |

### Contacts

Section titled “Contacts”

| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/api/v2/contacts` | List contacts |
| `GET` | `/api/v2/contacts/count` | Get contact count |
| `GET` | `/api/v2/contacts/:phone` | Get contact |
| `POST` | `/api/v2/contacts` | Create contact |
| `POST` | `/api/v2/contacts/bulk` | Bulk create contacts |
| `PUT` | `/api/v2/contacts/:phone` | Update contact |
| `DELETE` | `/api/v2/contacts/:phone` | Delete contact |
| `DELETE` | `/api/v2/contacts` | Bulk delete contacts |

### Webhooks

Section titled “Webhooks”

See the full guide: [Webhooks](https://docs.sendblue.com/getting-started/webhooks)

| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/api/account/webhooks` | List webhooks |
| `POST` | `/api/account/webhooks` | Add webhooks |
| `PUT` | `/api/account/webhooks` | Replace all webhooks |
| `DELETE` | `/api/account/webhooks` | Delete webhooks |

### Subaccounts

Section titled “Subaccounts”

| Method | Endpoint | Description |
| --- | --- | --- |
| `POST` | `/accounts/lines/request-child-account` | Create child account (agency) |
| `GET` | `/accounts/lines/available-area-codes` | List available area codes |

### TOTP (Authenticator)

Section titled “TOTP (Authenticator)”

| Method | Endpoint | Description |
| --- | --- | --- |
| `POST` | `/api/v2/totp/secrets` | Register a TOTP secret |
| `GET` | `/api/v2/totp/secrets` | List TOTP secrets |
| `GET` | `/api/v2/totp/code/:secret_id` | Get current TOTP code |
| `DELETE` | `/api/v2/totp/secrets/:secret_id` | Delete a TOTP secret |

### Account

Section titled “Account”

| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/api/lines` | List assigned phone numbers |
| `GET` | `/api/v2/lines/usage` | Get new-contact usage and remaining capacity for each line ([guide](https://docs.sendblue.com/api-v2/line-usage)) |
| `GET` | `/accounts/limits` | View account limits, including API line management limits |
| `POST` | `/accounts/lines/provision-preview` | Preview API line provisioning and receive a token |
| `POST` | `/accounts/lines/provision-confirm` | Confirm API line provisioning and purchase the line |
| `POST` | `/accounts/lines/deprovision-preview` | Preview API line deprovisioning and receive a token |
| `POST` | `/accounts/lines/deprovision-confirm` | Confirm API line deprovisioning and remove the line |

## Response Format

Section titled “Response Format”

**Success:**

```
{  "status": "OK",  "message": "Success message",  "data": { ... }}
```

**Error:**

```
{  "status": "ERROR",  "error_code": "ERROR_CODE",  "message": "Error description"}
```

## Service Types

Section titled “Service Types”

| Service | Description |
| --- | --- |
| `iMessage` | Apple messaging |
| `SMS` | Standard text |
| `RCS` | Rich messaging (Android) |

## Message Statuses

Section titled “Message Statuses”

| Status | Description |
| --- | --- |
| `QUEUED` | Waiting to send |
| `PENDING` | Being processed |
| `SENT` | Sent to carrier |
| `DELIVERED` | Delivered to device |
| `ERROR` | Delivery failed |
| `DECLINED` | Message rejected |
| `RECEIVED` | Inbound message |
| `ACCEPTED` | Accepted for processing |
| `REGISTERED` | Registered in system |

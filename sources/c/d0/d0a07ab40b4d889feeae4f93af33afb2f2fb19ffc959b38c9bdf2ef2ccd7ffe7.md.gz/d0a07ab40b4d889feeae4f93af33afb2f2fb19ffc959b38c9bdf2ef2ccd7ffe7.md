![Image 1: Arct Cloud](https://public-assets.arct.cloud/public-assets/arct-cloud-light.png)
# Create Your Account

Sign Up to Arct Cloud to continue to Arct Cloud Dashboard.

Email address * 

Please enter an email address

Email is not valid.

Password * Show password

Password is required

The password is too weak

*   
Your password must contain:
    *   At least 8 characters At least 8 characters: .At least 8 characters: .
    *   At least 3 of the following:At least 3 of the following:: .At least 3 of the following:: .

        *   Lower case letters (a-z)Lower case letters (a-z): .Lower case letters (a-z): .
        *   Upper case letters (A-Z)Upper case letters (A-Z): .Upper case letters (A-Z): .
        *   Numbers (0-9)Numbers (0-9): .Numbers (0-9): .
        *   Special characters (e.g. !@#$%^&*)Special characters (e.g. !@#$%^&*): .Special characters (e.g. !@#$%^&*): .

Continue

Already have an account? [Log in](https://auth.arct.cloud/u/login?state=hKFo2SBrbWtNWGxyZk93aHRPSTlVQWc5WjBBNFVLZ05hVk9BYqFur3VuaXZlcnNhbC1sb2dpbqN0aWTZIFptY1lTMVJJc0Q2b0FScnV6RGZ6QmMxcEthM1NMajcxo2NpZNkgakhuTEIweG9EQ0xLdElnSm1ZV2ZoRXNaZDczQVhEY0U)

Or

Continue with Google![Image 2: Connection icon](https://cdn.auth0.com/marketplace/catalog/content/assets/creators/discord/discord-avatar.png)Continue with Discord Continue with GitHub
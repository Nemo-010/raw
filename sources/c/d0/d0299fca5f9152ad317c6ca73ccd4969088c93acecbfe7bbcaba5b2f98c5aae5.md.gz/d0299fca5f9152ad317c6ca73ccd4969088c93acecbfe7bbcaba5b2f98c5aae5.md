thriveni

thriveni  posted  over 3 years ago   Admin Best Answer

Hello,

By default, Zyte Smart proxy manager has Datacentre IPs. We can provision Residential proxies for you and will be a different plan. Please note that the Residential Proxies plan start from $300 for 25GB. Please refer [https://www.zyte.com/smart-proxy-manager/residential-proxies/](https://www.zyte.com/smart-proxy-manager/residential-proxies/) to know more.

Thanks,

Thriveni.

1 Votes

1 Comments

thriveni

thriveni posted  over 3 years ago  Admin Answer

Hello,

By default, Zyte Smart proxy manager has Datacentre IPs. We can provision Residential proxies for you and will be a different plan. Please note that the Residential Proxies plan start from $300 for 25GB. Please refer [https://www.zyte.com/smart-proxy-manager/residential-proxies/](https://www.zyte.com/smart-proxy-manager/residential-proxies/) to know more.

Thanks,

Thriveni.

1 Votes

[Login](https://support.zyte.com/support/discussions/topics/22000015746/reply) to post a comment

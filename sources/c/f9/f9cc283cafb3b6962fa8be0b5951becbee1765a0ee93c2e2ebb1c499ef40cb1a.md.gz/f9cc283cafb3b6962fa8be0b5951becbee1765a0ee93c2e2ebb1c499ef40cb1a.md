### KIRO FREE

$0

per month

- 50 credits
- Access to open weight models* and Claude Sonnet 4.5

[Download now](https://kiro.dev/downloads/)

for teams from 2 to 500

### KIRO PRO

$20

per user / month

- 1,000 credits
- Access to premium models**
- Add-on credits ($0.04/credit)

[Download now](https://kiro.dev/downloads/)

for teams from 2 to 500

### KIRO PRO+

$40

per user / month

- 2,000 credits
- Access to premium models**
- Add-on credits ($0.04/credit)

[Download now](https://kiro.dev/downloads/)

for teams from 2 to 500

### KIRO PRO MAX

$100

per user / month

- 5,000 credits
- Access to premium models**
- Add-on credits ($0.04/credit)

[Download now](https://kiro.dev/downloads/)

for teams from 2 to 500

### KIRO POWER

$200

per user / month

- 10,000 credits
- Access to premium models**
- Add-on credits ($0.04/credit)

[Download now](https://kiro.dev/downloads/)

* Users on the Free Tier who signed up with social logins or AWS Builder ID have access to Claude Sonnet 4.5 and open weight models such as Qwen3 Coder Next, DeepSeek 3.2, and MiniMax M2.1. Access is subject to [rate limits](https://kiro.dev/docs/models/).

** Paid plan users have access to open weight and [premium models](https://kiro.dev/docs/models/), including Auto, Claude Sonnet 5 and Claude Opus 5. Not all premium models are available in all countries/regions.

Prices are exclusive of applicable taxes and duties, including VAT and applicable sales tax. For customers with a Japanese billing address, use of Kiro is subject to Japanese Consumption Tax.

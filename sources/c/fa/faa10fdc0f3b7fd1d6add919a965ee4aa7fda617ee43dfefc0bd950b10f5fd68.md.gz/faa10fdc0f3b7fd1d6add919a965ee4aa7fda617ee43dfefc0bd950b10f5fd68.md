# AIHubMix

## 文档

### 开始使用

- [产品介绍](https://docs.aihubmix.com/cn/index.md): 了解 AIHubMix 的模型调用、兼容接口和按量计费，查找模型选择、控制台、企业协作与通知使用指南。
- [快速开始](https://docs.aihubmix.com/cn/quick-start.md): 生成 API 密钥并进行首次调用
- [选择模型](https://docs.aihubmix.com/cn/guides/choose-models.md): 在模型广场按任务、输入类型、能力和价格缩小候选范围，使用列表、表格与收藏整理模型，再进入详情比较或试用。
- [智能搜索](https://docs.aihubmix.com/cn/guides/smart-search.md): 用自然语言描述任务，在模型广场寻找符合输入、能力和成本要求的候选模型，了解匹配分，并在无结果或搜索失败时调整条件。
- [模型详情与比较](https://docs.aihubmix.com/cn/guides/model-details.md): 读懂模型的输入输出、上下文、性能和计价单位，确认版本与模型 ID，在相同任务下比较候选并选择接入方式。
- [Skills](https://docs.aihubmix.com/cn/skills.md): AIHubMix Skill 为 Codex、Claude Code、Cursor、Cline 等 AI Agent 提供实时模型查询、接入配置、调用示例生成与错误排查能力。
- [Agent 接入](https://docs.aihubmix.com/cn/agents.md): AIHubMix 面向 AI Agent 的全部接入入口：agents.md 接入说明、llms.txt 机读索引、每模型 llms.txt 调用指南、Playground Skill、Playground 深链。每项一条可复制命令。
- [零数据存储说明](https://docs.aihubmix.com/cn/api/Data-Pravicy.md)
- [常见问题](https://docs.aihubmix.com/cn/FAQs/Faq.md): 高频问题请先查阅此文档
- [HTTP 状态码](https://docs.aihubmix.com/cn/FAQs/HTTP-Codes.md): 关键错误代码映射表
- [Status](https://docs.aihubmix.com/cn/api/Status.md)
- [提交反馈](https://docs.aihubmix.com/cn/FAQs/Feedback.md): 遇到问题时，可以通过工单表单向我们提交反馈，附上 Tid 可以帮助我们更快定位问题。

### 控制台使用

- [控制台概览](https://docs.aihubmix.com/cn/console/overview.md): 从控制台管理 API Key、查看用量与请求日志、充值和设置通知，了解账户与工作区范围，并快速找到常用功能入口。
- [API Key 管理](https://docs.aihubmix.com/cn/console/api-keys.md): 创建并管理模型调用凭证，配置模型范围与额度，使用映射和回退等高级功能，并安全完成停用、替换与删除。
- [用量看板](https://docs.aihubmix.com/cn/console/usage.md): 按账户、工作区和时间范围查看调用与消费趋势，理解费用、请求和 token 指标，并从汇总数据进入请求日志定位问题。
- [请求日志与排查](https://docs.aihubmix.com/cn/console/request-logs.md): 通过时间、模型、Key 和状态定位调用，查看 token、费用与耗时，配置日志表格并导出记录，使用 Tid 向支持团队反馈问题。
- [余额与账单](https://docs.aihubmix.com/cn/console/billing.md): 通过 Stripe 充值，单次最低 15 美元。了解付款、到账确认、交易记录，以及保存付款方式、自动充值和企业资金的关系。
- [保存与管理付款方式](https://docs.aihubmix.com/cn/console/payment-methods.md): 通过 Stripe 保存自动充值使用的银行卡，查看、替换或移除已保存的付款方式，理解存卡、充值授权与停止后续扣款的区别。
- [自动充值](https://docs.aihubmix.com/cn/console/auto-top-up.md): 配置余额触发条件与每次充值金额，使用已保存的银行卡自动补充额度，了解启停保存、固定金额和付款异常时的恢复方式。
- [消息中心](https://docs.aihubmix.com/cn/console/inbox.md): 通过消息中心查看模型动态、产品更新和账户通知，理解提示点与已查看状态，并从消息中的入口处理需要关注的问题。
- [通知设置](https://docs.aihubmix.com/cn/console/notifications.md): 设置低余额、模型上线、下线和调价提醒，选择网页、邮件或 Webhook 接收方式，并了解保存、关闭与必要账户通知的规则。
- [Webhook 通知接收设置](https://docs.aihubmix.com/cn/console/notification-webhooks.md): 把通知发送到飞书、Slack、Discord、Teams 或自有服务，了解目的地配置、签名、规则绑定、暂停与常见投递问题。

### 企业与团队

- [企业账户入门](https://docs.aihubmix.com/cn/enterprise/overview.md): 使用企业账户统一管理团队调用与资金，通过工作区组织资源，邀请成员并分配访问权限，查看用量、预算和管理记录。
- [工作区管理](https://docs.aihubmix.com/cn/enterprise/workspaces.md): 按业务创建和切换工作区，管理名称、标识和成员访问，了解默认工作区、删除限制，以及历史记录与组织余额的关系。
- [成员与权限](https://docs.aihubmix.com/cn/enterprise/members.md): 邀请组织成员、分配工作区访问权限，了解管理员和普通成员的管理范围，以及退出、移除成员时对 API Key 的影响。
- [成员 Key 与系统 Key](https://docs.aihubmix.com/cn/enterprise/keys.md): 在企业工作区选择成员 Key 或系统 Key，创建调用凭证、设置限额与到期时间，并安全完成启停、替换和删除。
- [预算与限额](https://docs.aihubmix.com/cn/enterprise/budgets.md): 设置工作区预算和 API Key 周期限额，区分硬限额与预警，了解 UTC 重置时间、修改额度的影响以及达到限制后的处理方式。
- [审计记录](https://docs.aihubmix.com/cn/enterprise/audit.md): 在企业账户中查看成员、工作区、密钥和设置的管理操作，通过操作者、资源、时间与结果追溯变化，并区分审计与请求日志。

### 网关能力

- [统一推理参数](https://docs.aihubmix.com/cn/api/unified-inference.md)
- [模型映射与回退](https://docs.aihubmix.com/cn/api/Model-Mapping-Fallback.md): 在 AIHubMix 控制台为每个 API Key 配置模型名映射与错误时回退：把客户端的模型别名改写为真实上游模型，主模型失败时自动切换到备用模型，按最终响应模型计费，客户端代码零改动。
- [模型智能路由](https://docs.aihubmix.com/cn/api/llm-router.md): AIHubMix 智能路由：把模型名填 auto，网关按请求内容自动选出最优模型，支持成本优先 / 质量优先 / 低延迟策略，按实际命中模型计费，客户端代码零改动。
- [结构化输出修复](https://docs.aihubmix.com/cn/api/structured-output-repair.md): 为 API Key 开启结构化输出修复：结构化输出请求返回的 JSON 存在截断、尾随逗号、代码块包裹等格式错误时，网关自动修复为可解析的合法 JSON，数值保持原样，支持 Chat Completions、Responses、Claude、Gemini，客户端零改动。
- [异步任务](https://docs.aihubmix.com/cn/api/async-tasks.md): AIHubMix 图片、视频与统一任务协议：创建媒体任务、查询状态、下载结果、接收 Webhook，以及恢复中断后的 LLM 响应。
- [Broadcast](https://docs.aihubmix.com/cn/api/Broadcast.md): Broadcast 将 AIHubMix API 请求的 Trace 发送到外部可观测性平台，支持配置 LangWatch 目的地、隐私模式、采样率和 API Key 范围。

### 模型能力

- [图像理解](https://docs.aihubmix.com/cn/api/vision.md): 了解如何使用视觉功能来理解图像。
- [视频理解](https://docs.aihubmix.com/cn/api/video-understanding.md): 通过 AIHubMix 的 Chat Completions 和 Responses API 调用 Qwen3.7 Plus，传入公网或本地 MP4 视频，获取场景描述、事件时间戳和 JSON 结果。
- [Gemini 新「智绘」](https://docs.aihubmix.com/cn/api/Multimodal-Interaction-with-Gemini.md): Gemini 绘图和视频生成指引
- [LLM 联网搜索](https://docs.aihubmix.com/cn/api/LLM-Search.md)
- [3D 生成接口](https://docs.aihubmix.com/cn/api/3D-Gen.md): AiHubMix 提供统一的 3D 模型生成 API，支持文生 3D 与图生 3D，异步任务模式，首批支持腾讯混元 3D（hy-3d-3.1），产物支持 obj / glb / stl / usdz / fbx 格式与 PBR 材质
- [TTS 文本转语音](https://docs.aihubmix.com/cn/api/TTS.md): 使用 AI 模型将文本转换为自然语音，支持多种语音风格和输出格式
- [STT 语音转文本](https://docs.aihubmix.com/cn/api/STT.md): 使用 Whisper 模型将音频文件转换为文本，支持转录和翻译功能
- [实时语音转录](https://docs.aihubmix.com/cn/api/realtime-transcription.md): 通过 WebSocket 建立持久连接，边说边出字，实现低延迟的流式语音转文本输出
- [实时对话](https://docs.aihubmix.com/cn/api/realtime-conversation.md): 通过 WebSocket 建立持久连接，与语音对话模型进行低延迟的双向语音／文本交互
- [向量嵌入](https://docs.aihubmix.com/cn/api/EBD.md): AIHubMix 提供兼容 OpenAI 标准的高效向量嵌入方案
- [重排序](https://docs.aihubmix.com/cn/api/Rerank.md): 通过 AIHubMix 的 /v1/rerank 接口调用 Jina、Cohere、Qwen 等重排模型，包含调用示例、请求参数、top_n 取值说明与可用模型列表。
- [FIM 补全](https://docs.aihubmix.com/cn/api/FIM.md)
- [结构化输出](https://docs.aihubmix.com/cn/api/Structured-Output.md): 通过 JSON Schema 约束模型输出格式（Structured Outputs），支持 OpenAI、Anthropic Claude、Gemini 等模型的 response_format 与 output_config.format，含自动降级与跨协议转换。
- [内容审查接口](https://docs.aihubmix.com/cn/api/moderation.md): 提供与 OpenAI 标准完全兼容的内容审查 API，开发者可以通过此接口，利用多模态审核模型自动识别文本或图片中的有害内容（如仇恨言论、暴力、违禁活动等），确保应用合规性。
- [提示词缓存](https://docs.aihubmix.com/cn/practices/prompt-caching.md)

#### 图片生成接口

- [图片生成](https://docs.aihubmix.com/cn/api/aihubmix-image-generation.md): 使用 AIHubMix 原生图片协议同步或异步生成图片，并查询任务和下载结果。
- [图片生成 OpenAI 兼容（遗留）](https://docs.aihubmix.com/cn/api/Image-Gen.md): 为了方便开发者调用不同的图像生成模型，AIHubMix 提供了统一的图片生成接口
- [GPT Image](https://docs.aihubmix.com/cn/api/GPT-Image-1.md): 使用 gpt-image-2 生成或编辑图片。
- [Ideogram AI 绘图支持](https://docs.aihubmix.com/cn/api/IdeogramAI.md)

#### 视频生成接口

- [视频生成](https://docs.aihubmix.com/cn/api/aihubmix-video-generation.md): 使用 AIHubMix 原生视频协议创建异步任务、查询状态并下载视频。
- [豆包真人素材使用指南](https://docs.aihubmix.com/cn/api/doubao-real-person-assets.md): 通过本人网页确认创建真人素材，使用 asset:// 引用调用豆包 Seedance 视频生成，并查询、重试和删除素材。
- [豆包私域虚拟人像素材使用指南](https://docs.aihubmix.com/cn/api/doubao-virtual-portrait-assets.md): 创建无需真人确认的虚拟人像素材组，上传图片并使用 asset:// 引用调用豆包 Seedance 视频生成。
- [视频生成 OpenAI 兼容（遗留）](https://docs.aihubmix.com/cn/api/Video-Gen.md): AiHubMix 提供统一的视频生成 API，兼容 OpenAI Sora 接口格式，后端支持多家厂商模型

### 协议参考

- [AIhubMix 一站式集成](https://docs.aihubmix.com/cn/api/Aihubmix-Integration.md): 了解 AIhubMix 的通用模型调用方式
- [Anthropic API 兼容（Beta）](https://docs.aihubmix.com/cn/api/Anthropic-Compatible.md)
- [Claude 原生接口调用](https://docs.aihubmix.com/cn/api/Claude-Native.md)
- [Claude 提示词缓存](https://docs.aihubmix.com/cn/api/Claude-Cache.md): 提示缓存显著减少了重复任务或包含一致元素的提示的处理时间，有效减低了 Token 成本。
- [GPT 提示词缓存](https://docs.aihubmix.com/cn/api/GPT-Cache.md): GPT 提示缓存（Prompt Caching）用法与计费：GPT-5.6 系列 gpt-5.6-sol / gpt-5.6-terra / gpt-5.6-luna 缓存写入按 1.25 倍输入价、读取按 0.1 倍计费，支持 prompt_cache_key 与显式缓存断点，含接口示例与命中排查。
- [Gemini 指南](https://docs.aihubmix.com/cn/api/Gemini-Guides.md): Gemini 漫游指南：关于本站的 Gemini 调用细节，在此汇总。
- [Gemini 原生 SDK 接入](https://docs.aihubmix.com/cn/api/Gemini-SDK.md): 通过 @google/genai SDK 接入 AIHubMix，调用 Interactions、Embeddings、Context Caching 等 Gemini API 全部原生能力
- [模型后缀能力说明](https://docs.aihubmix.com/cn/api/Capability-Suffix.md): 通过模型后缀，部分模型的高级能力已预先配置，用户可在统一的 OpenAI / Chat 接口下直接使用。
- [Openai Responses API 支持](https://docs.aihubmix.com/cn/api/Responses-API.md)
- [阿里通义系列](https://docs.aihubmix.com/cn/api/Qwen.md)
- [Jina AI 集成](https://docs.aihubmix.com/cn/api/Jina-AI.md)
- [Dify 插件](https://docs.aihubmix.com/cn/api/Dify-plugin.md): 在 Dify 中通过 Aihubmix 插件接入 Claude、GPT、Gemini 等模型，涵盖对话、向量、重排与语音，并支持为 Claude 开启提示词缓存。
- [AIHubMix Provider Benchmark Standard v2.0](https://docs.aihubmix.com/cn/guides/aihubmix-score.md): 了解 AIHubMix Provider Benchmark Standard 的四项评分维度、总分公式、原生能力与接口兼容性判定、响应速度与缓存测量，以及题集来源和统计边界。

#### Responses API

- [概述](https://docs.aihubmix.com/cn/api/responses/overview.md): OpenAI-compatible Responses API (Beta)
- [快速使用](https://docs.aihubmix.com/cn/api/responses/Basic-Usage.md): 开始使用 Responses API Beta
- [推理](https://docs.aihubmix.com/cn/api/responses/Reasoning.md): Responses API Beta 支持高级推理能力，允许模型在回答问题时展示其内部推理过程，并且可以通过参数配置推理努力程度。
- [工具调用](https://docs.aihubmix.com/cn/api/responses/Tool-Calling.md): 使用 Responses API Beta 进行函数调用与工具集成

### 平台管理

- [管理密钥](https://docs.aihubmix.com/cn/platform/management-keys.md): 使用管理密钥通过 CLI 或管理接口访问账户资源，了解它与模型调用 Key 的区别，以及创建、保管、到期和撤销操作。
- [AIHubMix CLI（命令行工具）](https://docs.aihubmix.com/cn/api/aihubmix-cli.md): AIHubMix CLI 是 AIHubMix 官方命令行工具，单一二进制、零依赖，在终端即可查询账户余额、管理 API Key、查看可用模型，并对脚本与 AI Agent 友好。
- [构建 AI 共赢生态](https://docs.aihubmix.com/cn/api/App-code.md): AIhubmix 推出应用标识码 APP-Code，为开发者们提供全部模型（除 claude 系列模型外）10%优惠!
- [OpenAI 与 Grok 模型请求封号说明](https://docs.aihubmix.com/cn/api/ban-notice.md)

## API 参考

### 模型端点

#### OpenAI Compatible

- [Create a Chat Completion](https://docs.aihubmix.com/cn/api-reference/openai-compatible/create-a-chat-completion.md): **Starting a new project?** We recommend trying [Responses](https://developers.openai.com/api/docs/api-reference/responses) to take advantage of the latest OpenAI platform features. Compare [Chat Completions with Responses](https://developers.openai.com/api/docs/guides/responses-vs-chat-completions?…
- [Create a Model Response](https://docs.aihubmix.com/cn/api-reference/openai-compatible/create-a-model-response.md): Creates a model response. Provide [text](https://developers.openai.com/api/docs/guides/text) or [image](https://developers.openai.com/api/docs/guides/images) inputs to generate [text](https://developers.openai.com/api/docs/guides/text) or [JSON](https://developers.openai.com/api/docs/guides/structur…
- [Create a Completion](https://docs.aihubmix.com/cn/api-reference/openai-compatible/create-a-completion.md): Creates a completion for the provided prompt and parameters.
- [Create an Embedding](https://docs.aihubmix.com/cn/api-reference/openai-compatible/create-an-embedding.md): Creates an embedding vector representing the input text.
- [Generate Images](https://docs.aihubmix.com/cn/api-reference/openai-compatible/generate-images.md): Creates an image given a prompt. [Learn more](https://developers.openai.com/api/docs/guides/images).
- [Create a Video](https://docs.aihubmix.com/cn/api-reference/openai-compatible/create-a-video.md): Create a new video generation job from a prompt and optional reference assets.
- [Retrieve a Video](https://docs.aihubmix.com/cn/api-reference/openai-compatible/retrieve-a-video.md): Fetch the latest metadata for a generated video.
- [Delete a Video](https://docs.aihubmix.com/cn/api-reference/openai-compatible/delete-a-video.md): Permanently delete a completed or failed video and its stored assets.
- [Download Video Content](https://docs.aihubmix.com/cn/api-reference/openai-compatible/download-video-content.md): Download the generated video bytes or a derived preview asset.
- [Remix a Video](https://docs.aihubmix.com/cn/api-reference/openai-compatible/remix-a-video.md): Create a remix of a completed video using a refreshed prompt.
- [Create Speech](https://docs.aihubmix.com/cn/api-reference/openai-compatible/create-speech.md): Generates audio from the input text.
- [Create Transcription](https://docs.aihubmix.com/cn/api-reference/openai-compatible/create-transcription.md): Transcribes audio into the input language.
- [Create Translation](https://docs.aihubmix.com/cn/api-reference/openai-compatible/create-translation.md): Translates audio into English.
- [Create Moderation](https://docs.aihubmix.com/cn/api-reference/openai-compatible/create-moderation.md): Classifies if text and/or image inputs are potentially harmful. Learn more in the [moderation guide](https://developers.openai.com/api/docs/guides/moderation).

#### Anthropic Compatible

- [Create a Message](https://docs.aihubmix.com/cn/api-reference/anthropic-compatible/create-a-message.md): Send a structured list of input messages with text and/or image content, and the model will generate the next message in the conversation.

#### Google Vertex AI Compatible

- [Generate Content](https://docs.aihubmix.com/cn/api-reference/google-vertex-ai-compatible/generate-content.md): Native Gemini protocol entry point. Mirrors the request and response shapes of `https://generativelanguage.googleapis.com` — clients may point the google-genai SDK at this gateway directly.

#### AIHubMix Unified API

- [Create an AIHubMix image generation](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/create-an-aihubmix-image-generation.md): Generates images with the AIHubMix native media protocol. Requests are synchronous by default and become asynchronous when `async` is `true`.
- [List AIHubMix image tasks](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/list-aihubmix-image-tasks.md): Returns snapshots of image tasks created by the current API key.
- [Get an AIHubMix image task](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/get-an-aihubmix-image-task.md): Returns the latest state of an image task. Poll this endpoint for asynchronous image generation.
- [Download an AIHubMix image result](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/download-an-aihubmix-image-result.md): Downloads one result from a completed image task. Clients normally use the `output[].content_url` returned by the task object.
- [List AIHubMix video tasks](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/list-aihubmix-video-tasks.md): Returns snapshots of video tasks created by the current API key.
- [Create an AIHubMix video task](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/create-an-aihubmix-video-task.md): Creates a video task with the AIHubMix native media protocol. Video generation is always asynchronous.
- [Get an AIHubMix video task](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/get-an-aihubmix-video-task.md): Returns the latest state of a video task. Poll this endpoint until the task reaches a terminal state.
- [Download an AIHubMix video](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/download-an-aihubmix-video.md): Downloads the primary video result from a completed video task.
- [List unified AIHubMix tasks](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/list-unified-aihubmix-tasks.md): Returns read-only snapshots of image, video, and recoverable LLM tasks created by the current API key.
- [Get a unified AIHubMix task](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/get-a-unified-aihubmix-task.md): Returns a read-only task snapshot. Poll active media through the image or video detail endpoint instead.
- [Get the primary unified task result](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/get-the-primary-unified-task-result.md): Downloads a single media artifact or returns an archived LLM response. Multi-result tasks require the result-specific endpoint.
- [Get a specific unified task result](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/get-a-specific-unified-task-result.md): Downloads one result from a task with multiple artifacts.
- [List models with media request Schemas](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/list-models-with-media-request-schemas.md): Lists image or video models from the public model directory. Use `schema_checked=true` to return models whose request Schema has been reviewed.
- [Get a model's supported endpoints and request Schemas](https://docs.aihubmix.com/cn/api-reference/aihubmix-unified-api/get-a-models-supported-endpoints-and-request-schemas.md): Returns all currently discoverable protocol endpoints for a media model. Select an endpoint by `path`; do not depend on array order.

### 平台 API

- [模型管理API](https://docs.aihubmix.com/cn/api/Models-API.md): 模型管理接口（GET /api/v1/models）说明：返回模型价格、上下文长度、可用接口协议、思考档位、限时优惠与生命周期等元数据，支持按类型、模态、功能特性、接口协议筛选。
- [获取当前用户信息与余额](https://docs.aihubmix.com/cn/api/CliEndpoints/get-self.md): 获取当前用户信息与账户余额
- [获取 KEY 列表](https://docs.aihubmix.com/cn/api/CliEndpoints/list-keys.md): 获取所有 KEY 列表，支持 num 参数控制数量
- [创建新 KEY](https://docs.aihubmix.com/cn/api/CliEndpoints/create-key.md): 创建一个新的 API KEY
- [更新 KEY](https://docs.aihubmix.com/cn/api/CliEndpoints/update-key.md): 更新现有 KEY 的名称、过期时间、额度、模型/IP 限制与状态等
- [获取单个 KEY 详情](https://docs.aihubmix.com/cn/api/CliEndpoints/get-key.md): 根据 token_id 获取 KEY 的详细信息
- [删除 KEY](https://docs.aihubmix.com/cn/api/CliEndpoints/delete-key.md): 根据 token_id 删除一个 KEY
- [搜索 KEY](https://docs.aihubmix.com/cn/api/CliEndpoints/search-keys.md): 通过 keyword 搜索 KEY
- [获取用户 KEY](https://docs.aihubmix.com/cn/api/CliEndpoints/get-user-token.md): 获取当前用户的 KEY 信息（若接口返回 token 字段）
- [获取当前用户可用模型列表](https://docs.aihubmix.com/cn/api/CliEndpoints/available-models.md): 返回当前用户允许使用的模型列表
- [获取自动路由策略对应模型范围](https://docs.aihubmix.com/cn/api/RouterEndpoints/leaderboard.md): 免登录获取智能路由榜单：5 大类 23 个子维度的模型评分，以及按厂商分组的在池模型池
- [获取模型厂商图标](https://docs.aihubmix.com/cn/api/RouterEndpoints/vendors.md): 免登录按模型厂商返回显示名与 icon，供榜单和模型卡片渲染

## 集成指南

- [三方接入技术指南](https://docs.aihubmix.com/cn/api/Third-PartyIntegrationTechnicalGuide.md): 基于 `@aihubmix/ai-sdk-provider`、`dify-plugin-aihubmix` 和 `cherry-studio` 三个项目的核心实现逻辑，本文档为开发者提供快速接入 aihubmix 统一网关的技术指南。

### 编程助手

- [Claude Code](https://docs.aihubmix.com/cn/api/Claude-Code.md): 在 Claude Code 中接入 AIHubMix：这款终端 AI 编程助手用单个 API key 即可跨厂商调用模型，享受稳定路由与统一计费。
- [Claude Code，模型自由](https://docs.aihubmix.com/cn/api/CC-any.md): 使用 Aihubmix 平台上的任何大模型为 Claude Code 提供强劲动力，彻底告别连接不稳定和额度难买的烦恼。
- [Codex CLI 与桌面端接入 AIHubMix 教程](https://docs.aihubmix.com/cn/api/Codex-CLI.md): 在 Codex（CLI 与桌面端）中接入 AIHubMix：用单个 API key 在 /model 列表自由切换 GLM、Claude、Gemini、DeepSeek 等模型。含 config.toml 配置、model_catalog_json 模型目录生成脚本与常见问题排查。
- [CodeBuddy](https://docs.aihubmix.com/cn/clients/CodeBuddy.md): 在 CodeBuddy 中配置 AIHubMix：添加 Custom 模型后使用 AIHubMix 支持的任意模型。
- [WorkBuddy](https://docs.aihubmix.com/cn/clients/WorkBuddy.md): 在 WorkBuddy 中配置 AIHubMix：添加 Custom 模型后使用 AIHubMix 支持的任意模型。
- [Gemini CLI](https://docs.aihubmix.com/cn/api/Gemini-Cli.md)
- [OpenCode](https://docs.aihubmix.com/cn/api/Opencode.md): 在 OpenCode 中接入 AIHubMix：安装、登录授权、选择模型、手动配置模型与自定义 Base URL 的完整步骤，覆盖 macOS、Linux 与 Windows。
- [DeepSeek Harness](https://docs.aihubmix.com/cn/api/DeepSeek-Harness.md): 在 DeepSeek Harness 中接入 AIHubMix：安装 npm 发布版、配置 OpenAI 兼容提供方、添加 auto 或指定模型并验证 Agent 请求。
- [Crush](https://docs.aihubmix.com/cn/api/Crush.md)
- [Gptme](https://docs.aihubmix.com/cn/clients/Gptme.md): 在 Gptme 中接入 AIHubMix：开源终端 AI 助手用单个 API key 写代码、跑脚本并自由切换模型。
- [OpenClaw](https://docs.aihubmix.com/cn/api/OpenClaw.md): 安装 OpenClaw，并通过 AIHubMix 插件或配置文件设置模型、测试连接和启动 Gateway。
- [Hermes Agent](https://docs.aihubmix.com/cn/api/hermes-agent-ai-hubmix.md): Hermes Agent 是 Nous Research 推出的开源 self-improving AI 智能体，它会自主学习、持续进化，并拥有持久记忆系统。
- [Qwen Code](https://docs.aihubmix.com/cn/api/Qwen-code.md)
- [Kilo Code](https://docs.aihubmix.com/cn/api/Kilo-Code.md)

### IDE 集成

- [Cursor](https://docs.aihubmix.com/cn/clients/Cursor.md): 在 Cursor 中配置 AIHubMix 的 OpenAI 兼容接口，使用 AIHubMix 支持的模型进行代码对话、补全和 Agent 编程。
- [Cline](https://docs.aihubmix.com/cn/clients/Cline.md): 在 Cline 中接入 AIHubMix：这款 VS Code / JetBrains AI 编码 Agent 用单个 API key 即可跨厂商调用模型。
- [CC Switch 配置指南](https://docs.aihubmix.com/cn/api/cc-switch.md): CC Switch 是开源跨平台桌面 GUI 工具，统一管理 Claude Code、Codex、Gemini CLI、OpenCode、OpenClaw 的 AIHubMix Provider 配置、API key 切换、MCP 服务器与用量统计，支持 Windows/macOS/Linux 全平台。
- [Avante.nvim](https://docs.aihubmix.com/cn/clients/Avante.nvim.md): 在 Avante.nvim 中接入 AIHubMix：在 Neovim 编辑器里用单个 API key 完成 AI 编程，自由切换模型。

### Agent / Workflow 平台

- [Dify](https://docs.aihubmix.com/cn/clients/Dify.md): 在 Dify 中接入 AIHubMix：让这个低代码 AI 应用平台用单个 API key 统一调度多家厂商模型。
- [n8n](https://docs.aihubmix.com/cn/clients/N8N.md): 在 n8n 中接入 AIHubMix：让这个工作流自动化平台在节点中用单个 API key 调用模型。
- [LiteLLM](https://docs.aihubmix.com/cn/clients/LiteLLM.md): 用 LiteLLM 接入 AIHubMix：通过统一代理层一行代码切换模型，覆盖流式输出与多轮对话。

### SDK 与框架

- [AI SDK](https://docs.aihubmix.com/cn/api/AISDK.md): 用 AI SDK 接入 AIHubMix：通过 OpenAI 兼容接口，在 TypeScript / JavaScript 代码中统一调度多家厂商模型。
- [LangChain](https://docs.aihubmix.com/cn/clients/LangChain.md): 用 LangChain 接入 AIHubMix：通过 OpenAI 兼容接口在 Python / JS 代码中调用模型，构建 AI 应用与 Agent。
- [通过接口获取账户信息](https://docs.aihubmix.com/cn/api/Cli.md): 通过 AiHubMix CLI 实用管理脚本在命令行中管理密钥、查看账户和可用模型列表等

## 应用集成

### 通用 Chat 客户端

- [Cherry Studio](https://docs.aihubmix.com/cn/clients/Cherry-Studio.md): 在 Cherry Studio 中通过自定义服务商接入 AIHubMix：完成初始化向导、添加模型，并启用 Claude 提示词缓存。
- [Open Design](https://docs.aihubmix.com/cn/clients/Open-Design.md): 用一把 AIHubMix Key 把 Claude Design 开源平替变成本地 AI 设计工作室
- [Chatbox](https://docs.aihubmix.com/cn/clients/ChatBox.md): 在 Chatbox 中配置 AIHubMix 的 OpenAI 兼容接口，并添加和使用 AIHubMix 模型。
- [RikkaHub](https://docs.aihubmix.com/cn/clients/RikkaHub.md): 在 RikkaHub 中配置 AIHubMix，添加并使用 AIHubMix 模型。
- [LobeChat](https://docs.aihubmix.com/cn/clients/Lobe-Chat.md)
- [Open WebUI](https://docs.aihubmix.com/cn/clients/Open-WebUI.md): 在 Open WebUI 中配置 AIHubMix 的 OpenAI 兼容连接，添加并使用 AIHubMix 模型。
- [Claude Desktop](https://docs.aihubmix.com/cn/api/claude-desktop.md): 在 Claude Desktop 中接入 AIHubMix：无需 Anthropic 账号登录，全程点击操作即可驱动客户端，通过单个 API key 统一调用 Claude、GPT、Gemini、DeepSeek 等多系列模型，按量计费、灵活可控。
- [NextChat](https://docs.aihubmix.com/cn/clients/ChatGPT-Next-Web.md): 在 NextChat（ChatGPT Next Web）中接入 AIHubMix：一键部署你的私人 AI 助手，用单个 API key 跨厂商调用模型。
- [AnythingLLM](https://docs.aihubmix.com/cn/clients/AnythingLLM.md): 在 AnythingLLM 中接入 AIHubMix：用单个 API Key 为本地私有 RAG 知识库统一接入对话与 Embedding 模型。
- [LobeHub](https://docs.aihubmix.com/cn/clients/lobe-hub.md)
- [Chatx](https://docs.aihubmix.com/cn/clients/Chatx.md)
- [ChatAll](https://docs.aihubmix.com/cn/clients/ChatAll.md)
- [ChatHub](https://docs.aihubmix.com/cn/clients/ChatHub.md)
- [LibreChat](https://docs.aihubmix.com/cn/clients/LibreChat.md): 在 LibreChat 中接入 AIHubMix：通过 OpenAI 兼容接口统一调用多家厂商模型。

### 笔记 / 写作 / 学术

- [Obsidian](https://docs.aihubmix.com/cn/clients/Obsidian.md): 在 Obsidian 中通过 Text Generator 配置 AIHubMix 模型，用于笔记续写、整理与内容生成。
- [NoteGen](https://docs.aihubmix.com/cn/clients/NoteGen.md): 在 NoteGen 中通过内置的 AIHubMix 模型平台配置模型，用于 AI 对话、笔记整理、写作辅助与知识库检索。
- [Zotero](https://docs.aihubmix.com/cn/clients/Zotero.md): 在 Zotero 中接入 AIHubMix：文献管理工具通过插件用单个 API key 调用模型，用于文献总结与问答。
- [GPT-Academic](https://docs.aihubmix.com/cn/clients/GPT-Academic.md): 在 GPT-Academic 中接入 AIHubMix：学术优化工具用单个 API key 调用模型，用于论文润色、翻译与解读。
- [FeelFish](https://docs.aihubmix.com/cn/clients/FeelFish.md): 在 FeelFish 中接入 AIHubMix：AI 小说写作客户端用单个 API key 接入模型辅助创作。

### 翻译工具

- [沉浸式翻译](https://docs.aihubmix.com/cn/clients/Immersive-Translate.md): 在沉浸式翻译中接入 AIHubMix：浏览器翻译扩展用单个 API key 完成高质量双语对照翻译。
- [NextAI Translator](https://docs.aihubmix.com/cn/clients/NextAITranslator.md): 在 NextAI Translator（原 OpenAI Translator）中接入 AIHubMix：用单个 API key 调用模型完成划词翻译。
- [Pot](https://docs.aihubmix.com/cn/clients/Pot-App.md): 在 Pot 中接入 AIHubMix：跨平台划词翻译工具用单个 API key 接入模型，完成多语种翻译。
- [欧路翻译](https://docs.aihubmix.com/cn/clients/Oulu.md): 在欧路翻译中接入 AIHubMix：用单个 API key 接入模型，增强词典与全文翻译能力。

### MCP / 模型路由

- [AIHubMix 图片生成 MCP](https://docs.aihubmix.com/cn/clients/AHM-mcp.md): AIHubMix 图片生成 MCP：在支持 MCP 协议的客户端中通过 AIHubMix 调用图片生成模型，统一计费。
- [GCMP](https://docs.aihubmix.com/cn/clients/GCMP.md)

### 业务场景

- [cc-connect](https://docs.aihubmix.com/cn/clients/ai-agent-tool-cc-connect.md): cc-connect 通过 AIHubMix 桥接 Claude Code、Codex、Gemini CLI 等 AI Agent，以单个 API key 统一调用主流模型。
- [懒人客服](https://docs.aihubmix.com/cn/clients/On-CS.md): 在懒人客服中接入 AIHubMix：用单个 API key 调用模型驱动智能客服自动回复。

### 启动器 / 划词

- [ChatGPT 好友 (uTools)](https://docs.aihubmix.com/cn/clients/Utools-ChatGPT.md): 在 uTools「ChatGPT 好友」中接入 AIHubMix：在快捷启动器里用单个 API key 调用模型，全局唤起即用。

### 其他

- [All API Hub x AIHubMix 配置指南](https://docs.aihubmix.com/cn/clients/all-api-hub.md): 本文介绍如何使用第三方开源浏览器扩展 All API Hub 辅助管理 AIHubMix API Key、账户余额、模型价格和模型列表，并支持导出至 Cherry Studio、Claude Code Router、Kilo Code 等 AI 工具。

## 博客

- [Kimi K3 实测调用指南：新参数与三接口支持矩阵](https://docs.aihubmix.com/cn/blogs/kimi-k3-guide.md): 2026 年 7 月 Kimi K3 调用指南：reasoning_effort max 档与思考历史回传、动态工具加载、结构化输出、自动缓存、partial 前缀续写与视觉输入，附 AIHubMix Chat / Responses / Messages 三接口示例。
- [GPT-5.6 系列上线：提示缓存计费变化解读](https://docs.aihubmix.com/cn/blogs/aihubmix-gpt-5-6-prompt-caching.md): 2026 年 7 月 GPT-5.6 系列 gpt-5.6-sol / gpt-5.6-terra / gpt-5.6-luna 上线 AIHubMix：105 万上下文、缓存写入 1.25 倍计费、prompt_cache_key 与显式缓存断点，并与 Claude 提示缓存逐项对比。
- [2026 年 6 月发布聚焦：近 20 款新模型上线](https://docs.aihubmix.com/cn/blogs/aihubmix-2026-06-recap.md): 2026 年 6 月 AIHubMix 新接入 claude-fable-5【已退役】、glm-5.2、minimax-m3、qwen3.7-plus、kimi-k2.7-code、可灵视频等近 20 款模型，并上线模型智能路由、模型映射与回退、AIHubMix CLI 与备用域名。
- [OpenAI 兼容接口深度适配 Claude](https://docs.aihubmix.com/cn/blogs/aihubmix-openai-upgrade-claude.md): AIHubMix 升级 OpenAI 兼容接口，深度适配 Claude：多轮交错思考无需额外传参、提示缓存自动命中，并支持开启 Anthropic beta 功能，让 Claude 在 OpenAI 协议下也能用满原生能力。
- [全球加速网络：延迟降 75%、可用性 99.99%](https://docs.aihubmix.com/cn/blogs/global-acceleration.md): AIHubMix 自建全球边缘节点与智能流量调度，响应延迟降低 75%、连接稳定性波动降低 60%、服务可用性达 99.99%，多区域探针每分钟实时健康监测并毫秒级自动切换，让 AI 应用调用更快更稳。
- [AIHubMix 上的免费 AI 模型](https://docs.aihubmix.com/cn/blogs/free-ai-models.md): 免费 AI 模型：2026 年在 AIHubMix 上零成本构建 AI 应用的终极指南
- [Claude Opus 4.7 新参数指南](https://docs.aihubmix.com/cn/blogs/Claude-Opus4.7.md): Claude Opus 4.7 推理控制实操指南：新增 xhigh 档位、思考内容默认隐藏，附 AIHubMix 原生 API 与 Chat 统一接口的完整调用示例。

## 更新日志

- [更新日志](https://docs.aihubmix.com/cn/update/News.md): AIHubMix 更新日志：实时跟踪平台新接入的 GPT、Claude、Gemini、Qwen、DeepSeek 等模型与功能更新，第一时间掌握最新模型支持、能力升级与平台动态。

## OpenAPI Specs

- [openapi](/openapi.json)

> The links below point to documentation indexes. Follow each `/_llms/` index recursively until you reach documentation pages.

## Indexes

- [English (181 pages)](https://docs.aihubmix.com/_llms/en.txt): Docs, API Reference, Integration Guide, Apps, Blog, Changelog.
- [Japanese (181 pages)](https://docs.aihubmix.com/_llms/ja.txt): ドキュメント, API リファレンス, 統合ガイド, アプリ, ブログ, アップデート.
- [Korean (181 pages)](https://docs.aihubmix.com/_llms/ko.txt): 문서, API 레퍼런스, 통합 가이드, 앱, 블로그, 업데이트.
- [Traditional Chinese (181 pages)](https://docs.aihubmix.com/_llms/zh-hant.txt): 文件, API 參考, 整合指南, 應用整合, 部落格, 更新日誌.
- [French (181 pages)](https://docs.aihubmix.com/_llms/fr.txt): Docs, Référence API, Guide d'intégration, Applications, Blog, Journal des modifications.
- [German (181 pages)](https://docs.aihubmix.com/_llms/de.txt): Docs, API-Referenz, Integrationsleitfaden, Anwendungen, Blog, Änderungsprotokoll.
- [Spanish (181 pages)](https://docs.aihubmix.com/_llms/es.txt): Docs, Referencia de API, Guía de integración, Aplicaciones, Blog, Registro de cambios.
- [Portuguese (181 pages)](https://docs.aihubmix.com/_llms/pt.txt): Docs, Referência da API, Guia de integração, Aplicativos, Blog, Registro de alterações.


This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.

# Our Billing System

- Billing This section of the document explains what Oblivus offers for managing the balance and expenses in your account.

We made our billing process transparent and easy to understand, providing you with full visibility of your usage and spending. Our billing system works by allowing you to top-up your account with any amount of credit using your preferred payment method. For each instance you use, you will be charged based on the specific configuration you have selected, with pricing calculated on a per-minute basis.

After specifying the amount of balance you want to top-up, which should be a minimum of $5, you can proceed to select your preferred payment method and complete the first step.

After selecting your payment method, you will be redirected to the necessary steps for payment using Revolut or Binance, and your transaction will be completed.

We would like to remind you that we do not store any critical information such as your credit card and account details.

After the payment process is completed, you can check your balance under Profile or in the bottom left corner of the console page.

---

Previous

[API Documentation](https://docs.oblivus.com/api/documentation/)

Next

[Payment Plans](https://docs.oblivus.com/billing/payment-plans/)

*Last updated 1 year ago*

# Free Plan   Follow Updates We try to keep our documentation up-to-date in response to any changes in our integration partner's systems.  Tap this button to get email alerts for changes in this document, and tap again to unfollow anytime.

SMTP2GO offers a free plan, with a sending limit of 1,000 emails per month, and 200 emails per day.   
The free plan is ideal for customers wanting to test the service, as well as those with lower sending needs. There’s no time limit with the free plan - you can have it for as long as it’s required.  
  
If you send emails at a faster rate than the daily limit, we'll store them in a queue and deliver them as allowed by your quota. Once you reach the 1,000 monthly limit, sending will stop and any further attempts to send will be rejected (these emails are not held in the queue and sent once your quota resets). If you need more email volume per month, [upgrading to a paid plan](https://support.smtp2go.com/hc/en-gb/articles/360009876993) will remove the daily limitation, increase your monthly quota and provide further paid plan benefits - view our [subscription differences article](https://support.smtp2go.com/hc/en-gb/articles/900002200943) for more information on the plan levels we offer.  
  
Customers on the free plan can access reporting on the [Activity](https://support.smtp2go.com/hc/en-gb/articles/360023548573) page for the past 5 days and paying customers can access reporting for 30 days, with the option to [extend that from 60 days to 2 years](https://support.smtp2go.com/hc/en-gb/articles/27243944323737). This includes reports for spam, bounces, opens, clicks, and unsubscribes and the ability to see full tracking details for every email.   
  
It is important to note that you are required to add and verify the [sender domain names](https://support.smtp2go.com/hc/en-gb/articles/115004408567) (recommended) or [single sender emails](https://support.smtp2go.com/hc/en-gb/articles/9150216032537-Verified-Senders-Sender-Domain-vs-Single-Sender-Emails) that you'll use to send emails on your account's 'Sending > Verified Senders' page. If you do not verify a sender domain, a 25-per-hour limitation will be applied to the account.   
The free plan allows up to 5 [sender domains or single sender email addresses](https://support.smtp2go.com/hc/en-gb/articles/9150216032537) to be added (paid plans do not have a limit).  
  
After 14 days, accounts on the free plan are limited to ticket support only.   
  
The free plan is limited to a maximum of two [team members](https://support.smtp2go.com/hc/en-gb/articles/900000030443) for login access (paid accounts are unlimited) and restricted to one [Webhook](https://support.smtp2go.com/hc/en-gb/articles/223087967) (paid plans can create up to ten).  
  
Features not available on the free plan include [SMS Messaging](https://support.smtp2go.com/hc/en-gb/articles/6352101968409), [Email Archiving](https://support.smtp2go.com/hc/en-gb/articles/115003599568), [Email Overage](https://support.smtp2go.com/hc/en-gb/articles/360023547593), [Scheduled Reporting](https://support.smtp2go.com/hc/en-gb/articles/24649751531673), [Activity Storage Duration](https://support.smtp2go.com/hc/en-gb/articles/27243944323737), [Subaccounts](https://support.smtp2go.com/hc/en-gb/articles/900004307303), [IP Authentication](https://support.smtp2go.com/hc/en-gb/articles/21149933711513), [Address Authentication](https://support.smtp2go.com/hc/en-gb/articles/223087467) and [Email Testing Tools](https://support.smtp2go.com/hc/en-gb/articles/360002482233).  
  
If you wish to give our service a trial run, or simply want to take advantage of our free plan, [sign up here](https://www.smtp2go.com/pricing).

Was this article helpful?

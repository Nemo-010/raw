- Shipping
  - ⚓ Ports
    - getList of ports
    - getPort capacity by operator
    - getContainer volumes
    - getDwell times
    - getTrade by partner
    - getVessel calls
    - getVessel schedule
  - 🚢 Vessels
    - getList of container vessels and AIS position
    - getHistorical port calls
    - getPort call schedule
  - 🌊 Global
    - getGlobal container trade
    - getLane capacity
  - ➡️ Point to point
    - getTrade between two partners
    - getBilateral transit time
- Macro
  - 🌐 Time series
    - getIndicator time series

[![redocly logo](https://cdn.redoc.ly/redoc/logo-mini.svg)API docs by Redocly](https://redocly.com/redoc/)

# Econdb API documentation

Released on July 29, 2025, the [Econdb](https://www.econdb.com/) API provides access to a wide range of shipping-related indicators and macroeconomic data.

For any questions or support, please contact us at [contact@econdb.com](mailto:contact@econdb.com).

This user guide is available in two style formats:

- [Documentation style Redoc](https://developers.econdb.com/docs/)
- [Documentation style Swagger](https://developers.econdb.com/swagger/)

## [tag/Ports](https://developers.econdb.com/docs/\#tag/Ports) ⚓ Ports

Port indicators such as container traffic as well as vessel call history.

## [tag/Ports/operation/ports_list](https://developers.econdb.com/docs/\#tag/Ports/operation/ports_list) List of ports

Returns a list of the top 400 ports by traffic.

##### Authorizations:

_tokenAuth_

### Responses

**200**

get/v1/ports/

Production API

https://api.econdb.com/v1/ports/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/ports/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)
```

### Response samples

- 200

Content type

application/json

Copy
Expand all  Collapse all

`[{"name": "Barcelona",\
\
"locode": "ES BCN",\
\
"iso2": "ES",\
\
"lat": 41.35,\
\
"lon": 2.16667,\
\
"timezone": "Europe/Madrid",\
\
"region": "West Mediterranean"\
\
}\
\
]`

## [tag/Ports/operation/ports_capacity_by_operator_retrieve](https://developers.econdb.com/docs/\#tag/Ports/operation/ports_capacity_by_operator_retrieve) Port capacity by operator

Returns the monthly time series of capacity by operator, aggregating over the TEU of all calling vessels in the period. The default keeps the eight largest operators and sums the rest as Others. Pass top=0 to return every operator. flow=import, flow=export, flow=transshipment, or flow=cargo switches from vessel capacity to container volume (TEU). Imports and exports are the gross volume series split by operator. Transshipment is the same port total as the container-volume endpoint, split by operator. operator=CMA CGM limits the volume series to that carrier; with flow=cargo it returns Imports, Exports, and Transshipment.

##### Authorizations:

_tokenAuth_

##### path Parameters

|     |     |
| --- | --- |
| locode<br>required | string |

##### query Parameters

|     |     |
| --- | --- |
| flow | string<br>throughput (default, vessel TEU), import, export, transshipment, or cargo (import, export, and transshipment together). |
| operator | string<br>Carrier name as it appears on the series, for example CMA CGM. Returns that carrier only. |
| top | string<br>Operators kept as their own series. The rest are summed as Others. 0 or all returns every operator. Default 8. Ignored when operator is set. |

### Responses

**200**

Capacity by operator

get/v1/ports/{locode}/capacity-by-operator/

Production API

https://api.econdb.com/v1/ports/{locode}/capacity-by-operator/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/ports/<locode>/capacity-by-operator/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)

import pandas as pd
df = pd.DataFrame(items['data']).set_index('Date')
df.plot()
```

### Response samples

- 200

Content type

application/json

One sample response of capacity by operator and date.

Copy
Expand all  Collapse all

`{"type": "timeseries",

"title": "Throughput by operator",

"series": [{"code": "Mediterranean Shipping",\
\
"name": "Mediterranean Shipping",\
\
"display": "stacked"\
\
},\
\
{"code": "Hapag-Lloyd",\
\
"name": "Hapag-Lloyd",\
\
"display": "stacked"\
\
},\
\
{"code": "CMA CGM",\
\
"name": "CMA CGM",\
\
"display": "stacked"\
\
},\
\
{"code": "Maersk",\
\
"name": "Maersk",\
\
"display": "stacked"\
\
},\
\
{"code": "Ocean Network Express",\
\
"name": "Ocean Network Express",\
\
"display": "stacked"\
\
},\
\
{"code": "Others",\
\
"name": "Others",\
\
"display": "stacked"\
\
}\
\
],

"data": [{"Date": "2022-02-01",\
\
"Mediterranean Shipping": 84622,\
\
"Hapag-Lloyd": 61658,\
\
"CMA CGM": 54621,\
\
"Maersk": 18385,\
\
"Ocean Network Express": 13918,\
\
"Others": 38394\
\
},\
\
{"Date": "2022-03-01",\
\
"Mediterranean Shipping": 156663,\
\
"Hapag-Lloyd": 95629,\
\
"CMA CGM": 74605,\
\
"Maersk": 29990,\
\
"Ocean Network Express": 235,\
\
"Others": 26042\
\
}\
\
]

}`

## [tag/Ports/operation/ports_container_traffic_retrieve](https://developers.econdb.com/docs/\#tag/Ports/operation/ports_container_traffic_retrieve) Container volumes

Returns a structured timeseries of container volumes by operation type.

##### Authorizations:

_tokenAuth_

##### path Parameters

|     |     |
| --- | --- |
| locode<br>required | string |

### Responses

**200**

A timeseries with import/export/transshipment container volumes.

get/v1/ports/{locode}/container-traffic/

Production API

https://api.econdb.com/v1/ports/{locode}/container-traffic/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/ports/<locode>/container-traffic/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)

import pandas as pd
df = pd.DataFrame(items['data']).set_index('Date')
df.plot()
```

### Response samples

- 200

Content type

application/json

One sample response of container volume by port and date.

Copy
Expand all  Collapse all

`{"type": "timeseries",

"title": "Container volume (TEU, full)",

"series": [{"code": "Imports",\
\
"name": "Gross imports",\
\
"axis": 0\
\
},\
\
{"code": "Exports",\
\
"name": "Gross exports",\
\
"axis": 0\
\
},\
\
{"code": "Transshipment",\
\
"name": "Transshipment",\
\
"axis": 0\
\
}\
\
],

"data": [{"Date": "2022-02-21",\
\
"Exports": 26635,\
\
"Imports": 34850,\
\
"Transshipment": null\
\
}\
\
]

}`

## [tag/Ports/operation/ports_dwell_times_retrieve](https://developers.econdb.com/docs/\#tag/Ports/operation/ports_dwell_times_retrieve) Dwell times

Returns a structured timeseries of dwell times by operation type.

##### Authorizations:

_tokenAuth_

##### path Parameters

|     |     |
| --- | --- |
| locode<br>required | string |

### Responses

**200**

A timeseries with import/export/transshipment/rail import dwell times.

get/v1/ports/{locode}/dwell-times/

Production API

https://api.econdb.com/v1/ports/{locode}/dwell-times/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/ports/<locode>/dwell-times/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)
```

### Response samples

- 200

Content type

application/json

One sample response of container dwell times by port and date.

Copy
Expand all  Collapse all

`{"type": "timeseries",

"title": "Container yard dwell (days)",

"tooltip": "Average period needed to process cargo",

"series": [{"code": "Imports",\
\
"name": "Imports",\
\
"axis": 0,\
\
"lbreak": true\
\
},\
\
{"code": "Exports",\
\
"name": "Exports",\
\
"axis": 0,\
\
"lbreak": true\
\
},\
\
{"code": "Transshipments",\
\
"name": "Transshipments",\
\
"axis": 0,\
\
"lbreak": true\
\
},\
\
{"code": "Rail imports",\
\
"name": "Rail imports",\
\
"axis": 0,\
\
"dashed": true,\
\
"lbreak": true\
\
}\
\
],

"data": [{"Date": "2022-03-01",\
\
"Imports": 7.238361111111112,\
\
"Exports": 12.079057054263567,\
\
"Transshipments": 8.403610210526317,\
\
"Rail imports": null\
\
}\
\
]

}`

## [tag/Ports/operation/ports_trade_by_partner_retrieve](https://developers.econdb.com/docs/\#tag/Ports/operation/ports_trade_by_partner_retrieve) Trade by partner

Returns the monthly time series of trade by partner region

##### Authorizations:

_tokenAuth_

##### path Parameters

|     |     |
| --- | --- |
| locode<br>required | string |

##### query Parameters

|     |     |
| --- | --- |
| is\_export | integer<br>Default: "1"<br>1 to display exports, 0 for imports |

### Responses

**200**

No response body

get/v1/ports/{locode}/trade-by-partner/

Production API

https://api.econdb.com/v1/ports/{locode}/trade-by-partner/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/ports/<locode>/trade-by-partner/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)

import pandas as pd
df = pd.DataFrame(items['data']).set_index('Date')
df.plot()
```

## [tag/Ports/operation/ports_vessel_calls_list](https://developers.econdb.com/docs/\#tag/Ports/operation/ports_vessel_calls_list) Vessel calls

Returns the historic container vessel calls of a port

##### Authorizations:

_tokenAuth_

##### path Parameters

|     |     |
| --- | --- |
| locode<br>required | string |

### Responses

**200**

get/v1/ports/{locode}/vessel-calls/

Production API

https://api.econdb.com/v1/ports/{locode}/vessel-calls/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/ports/<locode>/vessel-calls/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)
```

### Response samples

- 200

Content type

application/json

Copy
Expand all  Collapse all

`[{"start": "2021-01-11 10:09:12+00:00",\
\
"end": "2021-01-12 16:01:12+00:00",\
\
"ship_name": "EMMA MAERSK",\
\
"ship_imo": 9321483,\
\
"locode": "NL RTM",\
\
"port_name": "Rotterdam",\
\
"import_count": 2102,\
\
"export_count": 3615\
\
}\
\
]`

## [tag/Ports/operation/ports_vessel_schedule_list](https://developers.econdb.com/docs/\#tag/Ports/operation/ports_vessel_schedule_list) Vessel schedule

Returns the container vessel schedule for a given port

##### Authorizations:

_tokenAuth_

##### path Parameters

|     |     |
| --- | --- |
| locode<br>required | string |

### Responses

**200**

get/v1/ports/{locode}/vessel-schedule/

Production API

https://api.econdb.com/v1/ports/{locode}/vessel-schedule/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/ports/<locode>/vessel-schedule/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)
```

### Response samples

- 200

Content type

application/json

Copy
Expand all  Collapse all

`[{"start_date": "2025-12-18T09:00:00Z",\
\
"end_date": "2025-12-19T16:01:00Z",\
\
"voyage_code": "549W",\
\
"ship_name": "MSC IRINA",\
\
"ship_imo": 9929429,\
\
"ship_teu": 24346,\
\
"locode": "SG SIN",\
\
"port_name": "Singapore"\
\
}\
\
]`

## [tag/Vessels](https://developers.econdb.com/docs/\#tag/Vessels) 🚢 Vessels

Vessel indicators and ship tracking.

## [tag/Vessels/operation/vessels_list](https://developers.econdb.com/docs/\#tag/Vessels/operation/vessels_list) List of container vessels and AIS position

Returns a list of 7786 container vessels with their most recent location and AIS signal.

##### Authorizations:

_tokenAuth_

### Responses

**200**

get/v1/vessels/

Production API

https://api.econdb.com/v1/vessels/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/vessels/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)
```

### Response samples

- 200

Content type

application/json

Copy
Expand all  Collapse all

`[{"imo": -2147483648,\
\
"mmsi": -2147483648,\
\
"name": "string",\
\
"country_code": "st",\
\
"ship_type": "string",\
\
"callsign": "string",\
\
"owner": "string",\
\
"operator_name": "string",\
\
"last_lat": 0.1,\
\
"last_signal": "string",\
\
"last_lon": 0.1,\
\
"last_navstat": -2147483648,\
\
"last_heading": 0.1,\
\
"last_speed": 0.1,\
\
"last_draught": 0.1,\
\
"last_eta": "2019-08-24T14:15:22Z",\
\
"destination": "string",\
\
"previous_port": "string",\
\
"gross_tonnage": -2147483648,\
\
"deadweight": -2147483648\
\
}\
\
]`

## [tag/Vessels/operation/vessels_portcalls_list](https://developers.econdb.com/docs/\#tag/Vessels/operation/vessels_portcalls_list) Historical port calls

Returns historical port calls for a given vessel (MMSI). Defaults to the last 120 days when no date range is provided.

##### Authorizations:

_tokenAuth_

##### path Parameters

|     |     |
| --- | --- |
| mmsi<br>required | integer |

##### query Parameters

|     |     |
| --- | --- |
| date\_from | string <date> <br>Include calls with start on or after this date (YYYY-MM-DD). Default: today - 120 days. |
| date\_to | string <date> <br>Include calls with start on or before this date (YYYY-MM-DD). |

### Responses

**200**

get/v1/vessels/{mmsi}/portcalls/

Production API

https://api.econdb.com/v1/vessels/{mmsi}/portcalls/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/vessels/<mmsi>/portcalls/?date_from=2026-05-01&date_to=2026-07-31"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)
```

### Response samples

- 200

Content type

application/json

Copy
Expand all  Collapse all

`[{"start": "2021-01-11 10:09:12+00:00",\
\
"end": "2021-01-12 16:01:12+00:00",\
\
"ship_name": "EMMA MAERSK",\
\
"ship_imo": 9321483,\
\
"locode": "NL RTM",\
\
"port_name": "Rotterdam",\
\
"import_count": 2102,\
\
"export_count": 3615\
\
}\
\
]`

## [tag/Vessels/operation/vessels_schedule_list](https://developers.econdb.com/docs/\#tag/Vessels/operation/vessels_schedule_list) Port call schedule

Returns the port schedule for a given vessel

##### Authorizations:

_tokenAuth_

##### path Parameters

|     |     |
| --- | --- |
| mmsi<br>required | integer |

### Responses

**200**

get/v1/vessels/{mmsi}/schedule/

Production API

https://api.econdb.com/v1/vessels/{mmsi}/schedule/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/vessels/<mmsi>/schedule/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)
```

### Response samples

- 200

Content type

application/json

Copy
Expand all  Collapse all

`[{"start_date": "2025-12-18T09:00:00Z",\
\
"end_date": "2025-12-19T16:01:00Z",\
\
"voyage_code": "549W",\
\
"ship_name": "MSC IRINA",\
\
"ship_imo": 9929429,\
\
"ship_teu": 24346,\
\
"locode": "SG SIN",\
\
"port_name": "Singapore"\
\
}\
\
]`

## [tag/Global](https://developers.econdb.com/docs/\#tag/Global) 🌊 Global

Global shipping indicators

## [tag/Global/operation/shipping_indicators_container_trade_retrieve](https://developers.econdb.com/docs/\#tag/Global/operation/shipping_indicators_container_trade_retrieve) Global container trade

Returns the time series global container trade split by region

##### Authorizations:

_tokenAuth_

### Responses

**200**

Time series of deployed capacity by trade lane

get/v1/shipping-indicators/container-trade/

Production API

https://api.econdb.com/v1/shipping-indicators/container-trade/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/shipping-indicators/container-trade/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)

import pandas as pd
df = pd.DataFrame(items['data']).set_index('Date')
df.plot()
```

### Response samples

- 200

Content type

application/json

Copy
Expand all  Collapse all

`{"type": "timeseries",

"title": "Global imports (TEU by week)",

"series": [{"code": "Total",\
\
"name": "Total"\
\
},\
\
{"code": "Africa",\
\
"name": "Africa",\
\
"display": "stacked"\
\
},\
\
{"code": "East Asia",\
\
"name": "East Asia",\
\
"display": "stacked"\
\
},\
\
{"code": "Europe",\
\
"name": "Europe",\
\
"display": "stacked"\
\
},\
\
{"code": "Latin America",\
\
"name": "Latin America",\
\
"display": "stacked"\
\
},\
\
{"code": "Middle East",\
\
"name": "Middle East",\
\
"display": "stacked"\
\
},\
\
{"code": "North America",\
\
"name": "North America",\
\
"display": "stacked"\
\
},\
\
{"code": "Others",\
\
"name": "Others",\
\
"display": "stacked"\
\
},\
\
{"code": "South Asia",\
\
"name": "South Asia",\
\
"display": "stacked"\
\
},\
\
{"code": "Southeast Asia",\
\
"name": "Southeast Asia",\
\
"display": "stacked"\
\
}\
\
],

"data": [{"Date": "2022-01-17",\
\
"Total": 3985133.5,\
\
"Africa": 212110.5,\
\
"East Asia": 837476,\
\
"Europe": 974743,\
\
"Latin America": 194755.5,\
\
"Middle East": 189822.5,\
\
"North America": 637272.5,\
\
"Others": 204453.5,\
\
"South Asia": 119003.5,\
\
"Southeast Asia": 615496.5\
\
}\
\
]

}`

## [tag/Global/operation/shipping_indicators_lane_capacity_retrieve](https://developers.econdb.com/docs/\#tag/Global/operation/shipping_indicators_lane_capacity_retrieve) Lane capacity

Returns the time series of container vessel capacity deployed in each trade lane

##### Authorizations:

_tokenAuth_

### Responses

**200**

Time series of deployed capacity by trade lane

get/v1/shipping-indicators/lane-capacity/

Production API

https://api.econdb.com/v1/shipping-indicators/lane-capacity/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/shipping-indicators/lane-capacity/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)

import pandas as pd
df = pd.DataFrame(items['data']).set_index('Date')
df.plot()
```

### Response samples

- 200

Content type

application/json

Copy
Expand all  Collapse all

`{"type": "timeseries",

"title": "Capacity by lane",

"series": [{"code": "FEA/EUR",\
\
"name": "FEA/EUR",\
\
"display": "stacked"\
\
},\
\
{"code": "FEA/NAM",\
\
"name": "FEA/NAM",\
\
"display": "stacked"\
\
},\
\
{"code": "FEA/WSA",\
\
"name": "FEA/WSA",\
\
"display": "stacked"\
\
},\
\
{"code": "FEA/FEA",\
\
"name": "FEA/FEA",\
\
"display": "stacked"\
\
},\
\
{"code": "EUR/NAM",\
\
"name": "EUR/NAM",\
\
"display": "stacked"\
\
},\
\
{"code": "MEA/EUR",\
\
"name": "MEA/EUR",\
\
"display": "stacked"\
\
},\
\
{"code": "FEA/MEA",\
\
"name": "FEA/MEA",\
\
"display": "stacked"\
\
},\
\
{"code": "FEA/ESA",\
\
"name": "FEA/ESA",\
\
"display": "stacked"\
\
},\
\
{"code": "FEA/WAF",\
\
"name": "FEA/WAF",\
\
"display": "stacked"\
\
},\
\
{"code": "Others",\
\
"name": "Others",\
\
"display": "stacked"\
\
}\
\
],

"data": [{"Date": "2022-04-25",\
\
"FEA/EUR": 5214045,\
\
"FEA/NAM": 4524231,\
\
"FEA/WSA": 919602,\
\
"FEA/FEA": 999732,\
\
"EUR/NAM": 1013017,\
\
"MEA/EUR": 840719,\
\
"FEA/MEA": 730891,\
\
"FEA/ESA": 510815,\
\
"FEA/WAF": 538992,\
\
"Others": 4329644\
\
}\
\
]

}`

## [tag/Point-to-point](https://developers.econdb.com/docs/\#tag/Point-to-point) ➡️ Point to point

Origin <> destination indicators

## [tag/Point-to-point/operation/point2point_container_volume_retrieve](https://developers.econdb.com/docs/\#tag/Point-to-point/operation/point2point_container_volume_retrieve) Trade between two partners

Returns the monthly time series of trade between two partners

##### Authorizations:

_tokenAuth_

##### query Parameters

|     |     |
| --- | --- |
| is\_export | integer<br>Default: "1"<br>1 to display exports, 0 for imports |
| partner | string<br>Country of partner |
| port\_partner | string<br>Port of partner (locode) |
| port\_reference | string<br>Port of reference (locode) |
| reference | string<br>Country of reference |
| region\_partner | string<br>Region of partner |
| region\_reference | string<br>Region of reference |

### Responses

**200**

A timeseries showing container volumes between partners.

get/v1/point2point/container-volume/

Production API

https://api.econdb.com/v1/point2point/container-volume/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/point2point/container-volume/?port_reference=ES BCN&port_partner=CN SHA&is_export=0"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)

import pandas as pd
df = pd.DataFrame(items['data']).set_index('Date')
df.plot()
```

### Response samples

- 200

Content type

application/json

Copy
Expand all  Collapse all

`{"type": "timeseries",

"title": "Container trade - ES BCN < CN SHA (TEU)",

"series": [{"code": "ES BCN < CN SHA",\
\
"name": "ES BCN < CN SHA (TEU)",\
\
"axis": 0,\
\
"display": "bar"\
\
}\
\
],

"data": [{"Date": "2022-02-21",\
\
"ES BCN < CN SHA": 3320.8\
\
},\
\
{"Date": "2022-02-28",\
\
"ES BCN < CN SHA": 1810.5\
\
},\
\
{"Date": "2022-03-07",\
\
"ES BCN < CN SHA": 5762\
\
}\
\
]

}`

## [tag/Point-to-point/operation/point2point_transit_time_retrieve](https://developers.econdb.com/docs/\#tag/Point-to-point/operation/point2point_transit_time_retrieve) Bilateral transit time

Returns the monthly time series of average transit time between two partners

##### Authorizations:

_tokenAuth_

##### query Parameters

|     |     |
| --- | --- |
| is\_export | integer<br>Default: "1"<br>1 to display exports, 0 for imports |
| partner | string<br>Country of partner |
| port\_partner | string<br>Port of partner (locode) |
| port\_reference | string<br>Port of reference (locode) |
| reference | string<br>Country of reference |
| region\_partner | string<br>Region of partner |
| region\_reference | string<br>Region of reference |

### Responses

**200**

A timeseries showing transit time between partners.

get/v1/point2point/transit-time/

Production API

https://api.econdb.com/v1/point2point/transit-time/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/point2point/transit-time/?port_reference=ES BCN&port_partner=CN SHA&is_export=0"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)

import pandas as pd
df = pd.DataFrame(items['data']).set_index('Date')
df.plot()
```

### Response samples

- 200

Content type

application/json

Copy
Expand all  Collapse all

`{"type": "timeseries",

"title": "Voyage duration - ES BCN < CN SHA (days)",

"series": [{"code": "ES BCN < CN SHA",\
\
"name": "ES BCN < CN SHA (days)",\
\
"display": "line",\
\
"axis": 0\
\
},\
\
{"code": "range",\
\
"name": "Range",\
\
"display": "area",\
\
"axis": 0\
\
}\
\
],

"data": [{"Date": "2022-02-21",\
\
"ES BCN < CN SHA": 29.74,\
\
"range": [26,\
\
31.61\
\
]\
\
},\
\
{"Date": "2022-02-28",\
\
"ES BCN < CN SHA": 33.545,\
\
"range": [32.23,\
\
34.76\
\
]\
\
},\
\
{"Date": "2022-03-07",\
\
"ES BCN < CN SHA": 38,\
\
"range": [38,\
\
38\
\
]\
\
}\
\
]

}`

## [tag/Time-series](https://developers.econdb.com/docs/\#tag/Time-series) 🌐 Time series

Macroeconomic indicators time series data.

## [tag/Time-series/operation/series_retrieve](https://developers.econdb.com/docs/\#tag/Time-series/operation/series_retrieve) Indicator time series

Returns metadata and time series of an indicator

##### Authorizations:

_tokenAuth_

##### path Parameters

|     |     |
| --- | --- |
| id<br>required | string |

### Responses

**200**

get/v1/series/{id}/

Production API

https://api.econdb.com/v1/series/{id}/

### Request samples

- Python Requests
- cURL

Copy

```
import requests

url = "https://api.econdb.com/v1/series/<ticker>/"
headers = {"Authorization": "Token YOUR_API_KEY"}

response = requests.get(url, headers=headers)
items = response.json()
print(items)
```

### Response samples

- 200

Content type

application/json

Get time series and metadata for a particular indicator (identified by its ticker)

Copy
Expand all  Collapse all

`{"ticker": "CPIUS",

"description": "United States - Consumer price index",

"geography": "United States",

"frequency": "M",

"dataset": "BLS_CU",

"units": null,

"additional_metadata": { },

"data": {"values": [21.48,\
\
21.62\
\
],

"dates": ["1947-01-01",\
\
"1947-04-01"\
\
]

}

}`
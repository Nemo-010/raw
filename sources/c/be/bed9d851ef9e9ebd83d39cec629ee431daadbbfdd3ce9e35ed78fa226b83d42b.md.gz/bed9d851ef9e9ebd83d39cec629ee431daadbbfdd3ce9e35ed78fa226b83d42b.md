## Managed Apple Account

Like a Personal Apple Account, you can use a Managed Apple Account to sign in to a personal device, sign in to a shared device, or to access Apple services and portals (for example, iCloud, Apple School Manager, Schoolwork). Unlike a personal account, a Managed Apple Account is owned and controlled by a school or district. The organization can reset passwords, enable purchasing and communications, and set up role-based administration.

Teachers using a Managed Apple Account can use Schoolwork to share and receive content, collaborate with students, and view progress data for students at their school. Every Managed Apple Account is given 200 gigabytes (GB) of iCloud Drive storage.

See [Use Managed Apple Accounts in Apple School Manager](https://support.apple.com/guide/apple-school-manager/axm78b477c81) in Apple School Manager User Guide.

*Note:* A Managed Apple Account is referred to as a *school account* in the Schoolwork User Guide for students.

# Cheap Linux KVM VPS, ready in 60 seconds.

Linux VPS hosting with dedicated resources, NVMe storage and SSH root access from $2.09/month. Anti-DDoS 3 Tbps included and 4 datacenters to choose from: France, Germany, Netherlands, USA.

Browse the plans ↓Test my latency

**4.7/5**793 Google reviews

## Linux KVM VPS plans

Buy a Linux VPS in the USA (New York) or in Europe: prices including VAT, no commitment, full root access, anti-DDoS included. Compare all our ranges →

Perfect to start

### Linux VPS 04G

**$8.11**/month

delivered in 60 seconds

**RAM**:   4 GB DDR4 ECC

**CPU**:   2 vCores

**Storage**:   45 GB NVMe

**Network**:   1-10 Gbps

* 1 IPv4 + IPv6 (dual stack)
* KVM virtualization, reserved resources
* 3 Tbps anti-DDoS included
* Full root access
* 24/7 technical support

4 locations

Order →No commitment · cancel anytime

Most popular

Websites, Docker, databases

### Linux VPS 08G

**$11.11**/month

delivered in 60 seconds

**RAM**:   8 GB DDR4 ECC

**CPU**:   3 vCores

**Storage**:   50 GB NVMe

**Network**:   1-10 Gbps

* 1 IPv4 + IPv6 (dual stack)
* KVM virtualization, reserved resources
* 3 Tbps anti-DDoS included
* Full root access
* 24/7 technical support

4 locations

Order →No commitment · cancel anytime

Maximum performance

### Linux VPS 12G

**$19.69**/month

delivered in 60 seconds

**RAM**:   12 GB DDR4 ECC

**CPU**:   4 vCores

**Storage**:   70 GB NVMe

**Network**:   1-10 Gbps

* 1 IPv4 + IPv6 (dual stack)
* KVM virtualization, reserved resources
* 3 Tbps anti-DDoS included
* Full root access
* 24/7 technical support

4 locations

Order →No commitment · cancel anytime

Custom

### Custom VPS configuration

Build your custom Linux VPS server: the exact resources you need, no more, no less. Adjustable at any time without reinstalling.

**Memory (RAM)**:   2 to 128 GB

**Processor**:   2 to 24 vCores

**NVMe storage**:   20 to 400 GB

**Network**:   1-10 Gbps

* 1 IPv4 + IPv6 (dual stack)
* KVM virtualization, reserved resources
* 3 Tbps anti-DDoS included
* Full root access
* 24/7 technical support

4 locations

Configure my VPS →Xeon Platinum · KVM · root access · anti-DDoS

Datacenter of your choice at checkout: Marseille (France), Frankfurt (Germany), Amsterdam (Netherlands) or New York (USA).

IPv6 only

### Linux VPS 01G

1 GB of RAM, 1 Xeon Platinum vCore, 10 GB NVMe and 500 GB of traffic. For your bots, scripts and development environments. Native IPv6 connectivity, no IPv4 address.

**$2.09/month**Order →

Discover our Linux KVM VPS plans with dedicated resources, NVMe SSD storage, full root access and Anti-DDoS protection included. Deploy your Linux virtual server in seconds from France, Germany, the Netherlands or the United States.

**Up to 15% off when you pay 12 months upfront.** The prices shown on this page include all applicable taxes in France, including 20% VAT. Please note that the final amount may vary depending on the taxes applicable in the customer's country of residence.

Deployed in 60 seconds

## Choose your Linux distribution.

Ubuntu VPS, Debian VPS or AlmaLinux, preinstalled and optimized. Reinstall at any time from the client area, or mount your own ISO.

* ### Debian

  12 · 13

  StableSecure
* ### Ubuntu

  22.04 · 24.04 · 26.04

  LTSPopular
* ### AlmaLinux

  9 · 10

  EnterprisecPanel
* ### Arch Linux

  Rolling

  MinimalLatest
* ### MikroTik

  RouterOS

  NetworkBGP
* ### Custom ISO

  Your image

  FlexibleVNC console

Included in the client area

## The tools of a dedicated server, on a VPS.

Everything is managed from your Linux VPS panel, without opening a ticket.

* ### BackupsOptional

  Daily scheduling, configurable retention and one-click restore.
* ### BGP v4/v6 announcementOptional

  Announce your own IPv4 and IPv6 prefixes from your Linux VPS, over a BGP session with our AS208226 network.

  More about BGP VPS →
* ### Reverse DNS

  PTR records managed from the client area, essential for sending email.
* ### Upgrade without reinstalling

  Add RAM, CPU and storage from the client area, with no reinstallation and no data loss.
* ### Resource alerts

  Custom alerts on resource usage, with configurable thresholds.
* ### Usage graphs

  Network, CPU, RAM and disk I/O with history. VNC console and reinstallation from the same panel.

Infrastructure

## Your Linux VPS on infrastructure we operate ourselves

No white-label reselling: your Linux VPS server runs on our own network, servers and monitoring, managed in-house.

* ### AS208226 network

  Registered RIPE NCC operator: we announce our own IP ranges and control routing end to end.
* ### Tier 3+ datacenters

  Marseille, Frankfurt, Amsterdam and New York · redundant power and cooling, 99.99% electrical availability.
* ### 99.9% SLA

  Your Linux VPS availability is guaranteed by SLA, with infrastructure monitored 24/7/365 and immediate intervention.
* ### 100% NVMe

  U.2 PCIe NVMe Enterprise SSDs: minimal disk latency, consistent IOPS and endurance built for server workloads.
* ### KVM virtualization

  Strictly reserved resources: dedicated CPU, RAM and storage, full isolation between each Linux VPS.
* ### Anti-DDoS 3 Tbps

  Permanent L3/L4 filtering at the network edge, automatic mitigation with no service interruption.

Test my latencyLooking Glass

## Everything you need to know about our Linux VPS hosting

Answers to the questions we get before you buy a Linux VPS.

### Need help?

24/7 infrastructure support. System administration remains your responsibility, unless you add managed services.

Contact support →

A Linux VPS (Virtual Private Server) is a virtual server running a Linux operating system, with its own reserved resources (CPU, RAM, NVMe). It gives you the same freedom as a dedicated server at a fraction of the price, thanks to KVM virtualization.

Debian, Ubuntu, AlmaLinux, Arch Linux and MikroTik RouterOS can be preinstalled in one click. You can also mount your own ISO from the VNC console.

Yes, you can reinstall your Linux VPS at any time from the client area and choose the distribution you want.

Yes, you can install cPanel, Plesk or any other Linux-compatible panel, for example on AlmaLinux or Ubuntu, provided you have a valid license.

Yes, you get full root access over SSH as soon as the server is delivered, so you can administer it freely. We recommend SSH keys rather than a password.

Yes. Websites, applications, databases, bots: the only limit is the resources of your plan, which you can upgrade at any time.

Update the system, enable a firewall (ufw or firewalld), switch SSH to key authentication and install a monitoring tool. Our guides cover each step.

Infrastructure support is available 24/7: network, hardware, access to the VPS. System administration (software, configuration) remains your responsibility, unless you subscribe to a managed service option.

Yes, you can scale the RAM, CPU and storage of your VPS at any time with an upgrade from your client area, without reinstalling.

With a Linux VPS, you get dedicated resources and complete freedom of administration. Shared hosting is simpler, but it shares resources among several users and limits access. For a standard WordPress site, shared hosting is often enough.

In four datacenters, chosen at checkout: Marseille in France, Frankfurt in Germany, Amsterdam in the Netherlands and New York in the USA. Classic range prices are the same everywhere. Pick the datacenter closest to your users.

The Classic range runs on Intel Xeon Platinum with DDR4 ECC memory and a 1 to 10 Gbps port, in four locations. The Extreme range uses Ryzen 9 7950X processors and DDR5 for workloads that need high clock speeds. It is available in France, with 200 to 300 Mbps of bandwidth depending on the plan.

It is our cheapest Linux VPS, from $2.09/month, with 1 GB of RAM, 1 vCore, 10 GB NVMe and 500 GB of traffic per month. It has no IPv4 address and suits bots, scripts and test environments reachable over IPv6.
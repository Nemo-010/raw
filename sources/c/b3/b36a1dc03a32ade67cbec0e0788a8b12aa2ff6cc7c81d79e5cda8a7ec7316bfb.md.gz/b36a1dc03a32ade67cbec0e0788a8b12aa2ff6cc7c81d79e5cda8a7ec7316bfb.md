# Quick Start Guide to ScyllaDB Cloud

This guide takes you step by step through how to get your ScyllaDB Cloud
cluster up and running quickly.

## Prerequisites

Before you begin, go to [cloud.scylladb.com](https://cloud.scylladb.com) and
log in to your account, or sign up to create a new user account.

## Creating a Cluster

* If you’re a new user, you can click **Free Trial** to start a free cluster
  that will be available for a limited time. You get one free trial per account.
* If you’ve used your free trial before, you can create a regular ScyllaDB
  Cloud cluster.

Free Trial Cluster

1. Click **Free Trial** to open the cluster configuration page.
2. Configure your cluster options:
   * **Cluster Name**: Specify the cluster name.
   * **Choose Your Cloud Provider**: Choose **AWS** or **Google Cloud** as your
     cloud provider.
   * Choose the instance type for your cluster. Free trial clusters offer
     a limited selection of instance types.
   * Enable the **Vector and Text Search** option to create a cluster
     with
     [vector and full text search capabilities](https://cloud.docs.scylladb.com/stable/vector-search/index.md).
3. Click **Next** to proceed to [configuring cluster properties](#quickstart-cluster-properties).

Regular Cluster

1. Click **New Cluster** and select **Dedicated VM** to open the cluster
   configuration page.
2. Configure your cluster options:
   * **Cluster Name**: Specify the cluster name.
   * **Choose Your Cloud Provider**: Choose **AWS** or **GCP** as your cloud provider.
   * Leave the defaults for other options, especially:
     > * **Run Under Which Account**: ScyllaDB Account
   * You can enable the **Vector and Text Search** option to create a
     cluster with
     [vector and full text search capabilities](https://cloud.docs.scylladb.com/stable/vector-search/index.md).

   The wizard will display the initial costs for the cluster based on your selections.
3. Click **Next** to proceed to the next step.
4. Choose **Pay on Demand** as your billing method, and click **Next** to
   proceed to the next step.

   If not already provided, the wizard will prompt you to provide the required
   payment information.
5. Click **Next** to proceed to [configuring cluster properties](#quickstart-cluster-properties).

<a id="quickstart-cluster-properties"></a>

### Configuring Cluster Properties

> * Whitelist IP addresses that will be able to communicate with your cluster
>   on ScyllaDB Cloud to ensure the security of your data.
> * (Recommended) Under **Network Type**, enable the **Private Connection**
>   option to avoid routing your traffic over the open internet and ensure
>   that your cluster and the application layer connect via a private network.
>   Enabling this option will allow you to set up private network options
>   after you launch the cluster.

>   #### NOTE
>   You must enable this option when creating your cluster to be able
>   to configure private network. Private network connectivity
>   cannot be enabled for an existing cluster.

>   You can specify the desired IP range for the cluster other than the default.
>   See [AWS VPC Peering](https://cloud.docs.scylladb.com/stable/cluster-connections/vpc-peering/aws-vpc-peering.md#aws-vpc-create-cluster-cidr) or
>   [GCP VPC Peering](https://cloud.docs.scylladb.com/stable/cluster-connections/vpc-peering/gcp-vpc-peering.md#gcp-vpc-create-cluster-cidr)
>   for details about the default and the allowed ranges.

### Launch Your Cluster

1. Review your cluster configuration summary.
2. Click **Launch Cluster**. It will take a few minutes for your cluster to be
   deployed.
3. If you enabled *Private Connection* when configuring your cluster in the previous
   step, you need to now configure private network access. See
   [Configure Network Access](https://cloud.docs.scylladb.com/stable/cluster-connections/index.md) for details.

## Connect to Your Cluster

When your cluster is deployed, you can immediately connect to it.
ScyllaDB Cloud provides you with default credentials and detailed instructions
on how to connect to your cluster with different clients and drivers.

1. Go to **My Clusters** and open your cluster’s view.
2. Open the **Connect** tab.
3. Choose how you want to connect to your cluster. The *Connect* tab includes
   instructions on how to connect using the CQL shell command (Cqlsh) or Scylla
   CQL drivers.
4. Follow the instructions specified on the tab you selected.

## Useful Resources

Check out the following resources for hands-on experience with ScyllaDB Cloud:

* [Tablets, Elasticity, and X Cloud](https://university.scylladb.com/courses/scylla-essentials-overview/lessons/tablets-elasticity-and-xcloud/)
  on ScyllaDB University
  - Learn about ScyllaDB X Cloud, and the Tablets architecture. The lesson
  explains how the underlying Raft consensus algorithm enables strongly
  consistent operations. The database significantly improves Elasticity by
  using Tablets, allowing users to scale in and out within a few minutes,
  as you’ll see in the demo. The lesson concludes with a hands-on lab so that
  you can see it in action.
* The [Getting Started with ScyllaDB Cloud](https://cloud-getting-started.scylladb.com/)
  example project -  A step-by-step guide to building a Media Player project
  connected to ScyllaDB Cloud. It includes examples for Go, Java, Python, Rust,
  and more.

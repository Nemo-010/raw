Spotnews logo

Spotnews logo

## Selecteer jouw Premium Spotnews plan

Kies je niveau en schakel tussen maandelijks of jaarlijks factureren. De levering blijft automatisch, overzichtelijk en direct bruikbaar na betaling.

## Kies jouw betaalvorm

Kies eerst of je plan automatisch verlengd moet worden of dat je een keer betaalt. Daarna kies je maand of jaar en het plan dat bij je past.

Je betaalt een keer voor 12 maanden toegang. Daarna stopt het vanzelf.

Bespaar tot 24% met per jaar

Voor licht tot normaal gebruik

€ 4,49/maand

€ 3,41 /maand Totaal € 40,95 per jaar Dat is 24% voordeliger dan per maand.

Bespaar 24%

- Onbeperkte data
- Encryptie inbegrepen
- Retentie: ± 4000 dagen
- 10 Mbit/s (1.25 MB/s)
- 10 verbindingen
- Premium support

Voor intensief gebruik en maximale vrijheid

€ 8,35/maand

€ 6,67 /maand Totaal € 79,99 per jaar Dat is 20% voordeliger dan per maand.

Bespaar 20%

- Onbeperkte data
- Encryptie inbegrepen
- Retentie: ± 4000 dagen
- Onbeperkte snelheid
- Account delen
- Premium support

Voor dagelijks gebruik met extra ruimte

€ 7,55/maand

€ 6,04 /maand Totaal € 72,50 per jaar Dat is 20% voordeliger dan per maand.

Bespaar 20%

- Onbeperkte data
- Encryptie inbegrepen
- Retentie: ± 4000 dagen
- 50 Mbit/s (6.25 MB/s)
- 50 verbindingen
- Premium support

Betalen

## Rond je keuze direct af

Je ziet hieronder welk Premium Spotnews plan je hebt gekozen, hoe je betaalt en welk bedrag daarbij hoort.

Kies hierboven een Premium Spotnews plan om verder te gaan.

Je kunt betalen met

Je ziet vanzelf welke mogelijkheden voor jou beschikbaar zijn.

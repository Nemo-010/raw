# Tenant settings

New users who register for Logto Cloud are automatically onboarded to a free **Development** (Dev) environment tenant. You can explore all features in this tenant.

If you want to create a separate tenant for **Production** (Prod) env or a new project, click your current tenant name in the top-left corner of the top bar. In this menu, you can switch between tenants or create a new one.

Click "Create tenant", then:

- Name for the tenant
- Select a tenant data region
- Select the tenant type (environment)

For an existing tenant, go to [Console > Tenant settings > Settings](https://cloud.logto.io/to/settings). Here, you can:

- View the tenant ID
- Update the tenant name
- View the tenant region. This cannot be changed after creation.
- View the tenant type. You can convert a Dev tenant to a Prod tenant if needed.
- Leave the tenant
- Delete the tenant

## Tenant region​

When you create a tenant, you can choose the region where the tenant data is stored. It cannot be changed after the tenant is created. Here are the available regions:

- Europe (Netherlands)
- West US (Arizona)
- Australia (Australia East)
- Japan (Japan East)

Usually, you should choose the region closest to your customers to minimize latency and improve performance.

Logto leverages the global edge network to deliver the best performance and availability for your applications. The request routing is optimized to ensure that your users are always connected with the best-performing option.

note:

Looking for another region? [Get in touch with us](https://logto.io/contact) to:

- Request a new public cloud region
- Inquire about a Logto Private Cloud deployment in your preferred location

## Tenant types: Dev vs. Prod​

There are two types of tenants in Logto Cloud: Development (Dev) and Production (Prod). With this tenant differentiation, you can better manage your projects across different environments for efficiency and, at the same time, enjoy the full value of Logto.

You can choose your tenant type during creation. When you’re ready to go live for production, there are two options:

- **Create a new Production tenant**  
   Set up a fresh production tenant and configure it from scratch. This is ideal if you want to keep development and production environments separate.
- **Convert your current Dev tenant to Production**  
   If you prefer not to redo the configuration or migrate users, you can upgrade your existing Development tenant to a paid Production tenant.

    - **Convert to a Pro plan**: Go to [Console > Tenant settings > Settings](https://cloud.logto.io/to/tenant-settings/settings), then click "Convert" to upgrade by self-service. Any paid features you’ve used in the dev tenant will carry over to the Stripe checkout.
    - **Convert to an Enterprise plan**: [Contact us](https://logto.io/contact) and we’ll help you complete the upgrade.

  note:

  Once converted, the tenant cannot be reverted to a Dev environment; please confirm you’re ready before proceeding.

### Development​

The development tenant (dev tenant) is primarily intended for testing purposes and should not be utilized in a production environment. These tenants allow access to premium and paid features available in paid plans, free of charge and without requiring a subscription.

However, there are certain limitations that apply to development tenants:

- Dev tenant will automatically delete users over 90 days. Check the [Dev tenant data retention policy](https://docs.logto.io/logto-cloud/dev-tenant-data-retention) for details.
- A banner appears during the sign-in experience, indicating that the tenant is in development mode.
- Development tenants may have quota limits on specific features. These limits are explained on the feature details page, if applicable. For a complete list of Dev plan limitations, please refer to the [System limit](https://docs.logto.io/logto-cloud/system-limit) page.
- Logto may update the development tenant's quota limits, and we will try our best to notify you in advance.

### Production​

The production tenant is where end-users access the live app and you might need a [paid subscription](https://logto.io/pricing). You can subscribe to the Free plan or Pro plan to create a production tenant. If you subscribe to the Free plan, you can only create up to 10 tenants.

## Enable MFA​

Enhance your workspace security by requiring Multi-Factor Authentication (MFA) for all members in your Logto Pro/Enterprise tenant.

Since self-service is not yet available, please [contact us](https://logto.io/contact) to enable this feature.

## Enable Enterprise SSO​

Logto Cloud supports enterprise Single Sign-On integration for Enterprise Plan tenants, including providers like Google Workspace, Okta, Azure AD, and more.

To get started, please [contact us](https://logto.io/contact). We’ll help you set it up quickly.

## Leave tenant​

An admin can [invite additional members](https://docs.logto.io/logto-cloud/tenant-member-management) to this tenant.

If there is at least one other **admin** (role), or if you're a **collaborator** or **viewer** (role), you can choose to leave the tenant. After you leave, all resources in the tenant will remain, but you will no longer have access to them.

If you are the last admin, you must assign another member as an admin before you can leave.

## Delete tenant​

[Admins](https://docs.logto.io/logto-cloud/tenant-member-management#invite-collaborators) can delete a Logto tenant. Deleting a tenant permanently removes all associated user data and configurations. This action CANNOT be undone. Logto will ask you to enter the tenant name to confirm and help prevent accidental deletion.

If you need any help, please [contact us](https://logto.io/contact) by email.

## FAQs​

### How to migrate between Logto tenants or between Cloud and OSS, or export all user data?​

You can currently convert your **Development** tenant to a paid plan **Production** tenant by yourself. Learn more

However, self-service migration (all configurations and user data) between Logto Cloud and OSS version is not supported. If you need this service, please [contact the Logto team](https://logto.io/contact) to discuss your options.

If you plan to stop using Logto Cloud for a project, Logto can help you export all user data. Please [reach out to us](https://logto.io/contact).

## Related resources​

[Protect your identities in local regions and dedicated computing resources](https://blog.logto.io/data-region-resources)

Do you find this page helpful?

Yes

No

Help us improve the docs!

[Edit this page](https://github.com/logto-io/docs/tree/master/docs/logto-cloud/tenant-settings.mdx)

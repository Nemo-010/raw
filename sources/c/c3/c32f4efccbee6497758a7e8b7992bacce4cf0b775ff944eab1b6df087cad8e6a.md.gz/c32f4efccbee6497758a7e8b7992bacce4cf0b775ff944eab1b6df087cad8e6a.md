## Free to explore. Pay as you grow.

Operations-based pricing fits any usage profile, from static content delivery to complex UGC pipelines.

### [Free](https://app.uploadcare.com/accounts/signup/)

$0

Perfect for passion projects and simple websites

Features included:

- 1,000 operations per month
- 500 MB max file size
- Uploading widget, API
- Basic image transformations
- Adaptive bitrate streaming
- Delivery through a CDN
- Signed uploads
- Webhooks
- Personal use only

Popular

### [Pro](https://app.uploadcare.com/accounts/signup/)

$66/ mo

For production apps and websites with the option to scale

Everything in Free, plus…

- 5,000 operations per month
- 5,000 AI operations per month
- 1 GB max file size
- Auto-moderation on upload
- Malicious content filtering
- Automated image optimization
- Content-aware crop and resize
- Automated responsive images
- Document conversion
- Asynchronous video processing
- AI Image Editor
- Signed URLs
- 3 team members

### [Business](https://app.uploadcare.com/accounts/signup/)

$166/ mo

For large-scale applications managing tons of digital media

Everything in Pro, plus…

- 50,000 operations per month
- 25,000 AI operations per month
- 10 GB max file size
- Automated AVIF compression
- Uploading widget whitelabeling
- Custom Upload API domain
- Custom CDN CNAME
- Custom OAuth applications
- Dedicated solution engineer
- Performance & security review
- 4 team members

### [Enterprise](https://uploadcare.com/schedule-demo/)

Custom

For teams with more security, support, and performance needs

Everything in Business, with additional options:

- Custom plan limits
- File size up to 5 TB
- Traffic and storage price match
- Connect AWS S3 Storage
- Use Okta as SSO provider
- Project management API
- Free migration
- Enterprise-grade security
- Enterprise-grade support
- HIPAA and SOC2 compliant
- Dedicated solution architect
- Private Slack channel

## Compare plans

Feature

Free

Pro

Business

Enterprise

### Usage

Operations

5,000 / mo includedthen $1.6 per 1000

AI operations

5,000 / mo includedthen $0.80 per 1000

Traffic

25 GB / mo includedthen $0.35 per GB

Storage

10 GB includedthen $0.35 per GB

Max file size

1 GB

Team members

3 seats

### Uploading

File uploader

Upload API

Accelerated uploading

Malware protection

Signed uploads

Image editor

File size limiting

MIME type filtering

EXIF metadata removal

Copy uploads to custom S3 bucket

Backup to S3 bucket

Upload widget whitelabeling

—

Custom OAuth apps

—

Connect AWS S3 Storage

—

Project management API

—

Custom Upload API domain

—

### Optimization

URL API

Automatic responsive images

Automatic image optimization

Automatic format selection

Animated images optimization

WebP

AVIF

—

### Image transformations

URL API

Resize, crop, rotation, flip

Border radius and circle crop

Effects and enhancements

Overlays and watermarks

Face-detection based transformations

Color adjustments

Color profile management

Content-aware crop and resize

Background removal

AI Image Editor

### Delivery

Adaptive bitrate streaming

High performance CDN

Fetch and deliver remote files

Search engine indexing control

Signed URLs

Custom CDN / Proxy CNAME

$25 / month

### File management

API for everything

Access logs

Webhooks

Zapier integration

Make integration

Usage Info

Image auto-tagging

Unsafe content detection

Asynchronous video processing

Document conversion

Color recognition

## Frequently asked questions

What is Uploadcare?

Uploadcare is the complete file infrastructure behind your product: one integration that handles uploads, storage, processing, and delivery for images, video, and documents. It is built for products with real file volume, especially user-generated content, where file handling has to be reliable, secure, and fast at scale.

You get a drop-in uploader, a full API and CLI, and global CDN delivery, so your team ships the product and we run the file handling underneath it.

Who uses Uploadcare?

10,000+ engineering teams, including Zapier, L’Oréal, SoundCloud and Shogun. Read the [customer stories](https://uploadcare.com/customers/).

My volumes are in TBs or PBs. Is Uploadcare a fit?

Absolutely! We’ll price-match your current contracts with CDN and other vendors, and migrate you for free! [Get in touch](https://uploadcare.com/schedule-demo/) with our sales team to learn more.

How long will it take to integrate Uploadcare with my web or mobile app?

Anywhere from a few minutes to a few days, depending on your use case. We offer ready-made libraries for all popular frameworks and take an API-first approach, and our docs and CLI are built for AI-assisted coding, so a coding agent can wire most of it in for you. On top of that, everyone on our support team is an engineer, so you are talking to someone who can actually help you build.

What CDN do you use?

Uploadcare delivers through a global CDN with a 99.99% uptime SLA. If you have an existing CDN contract or need delivery through a specific provider, [get in touch](https://uploadcare.com/schedule-demo/).

Can I put a CDN or caching layer on top of Uploadcare?

Yes, but only with a custom plan. [Get in touch](https://uploadcare.com/schedule-demo/) with our team to discuss the details.

What types of files does Uploadcare support?

Uploadcare supports any file types: images, videos or documents, up to 5TB each.

Can my users upload files from Google Drive, Dropbox, Box and other cloud storage services?

Yes. Your users can upload from local files, camera, a link, Dropbox, Google Drive, Google Photos, OneDrive and more, all without you registering an OAuth app of your own. If you’d rather users see your name on the authorization screen, you can register your own app for the cloud sources.

What are Operations?

Operations are various actions associated with your files and API usage. Actions like uploading a file, making requests, or requesting transformations on your images are considered operations. Different actions have different operation costs, If you’re curious about more information on how operations are calculated you can read [this article](https://uploadcare.com/docs/billing/).

What are AI operations?

AI operations are a separate usage meter for the AI Image Editor. Generating, editing and upscaling images all use them. For generation and editing, the cost depends on the output image size you set for the project and on any reference images you add. Upscaling has a flat cost per request, whatever the size. The exact cost of each action is explained in the [billing docs](https://uploadcare.com/docs/billing/#ai-operations).

AI operations never share the pool with regular operations. Standard transformations like resize, crop and format conversion still count against your regular Operations. AI operations appear as their own line on your invoice.

How do I control AI usage and cost?

Each project has an AI toggle in Project settings, so you can turn the editor on or off per project and set the output image size in megapixels, which affects the cost of each generation or edit.

By default, only requests that carry a valid signed token are accepted. Your backend issues the token, and it sets which actions a user can run and how many.

The whole account also has a limit on AI requests in a rolling 24-hour window. Every account starts with a default limit, and members with billing access can raise it up to the plan maximum. A request over the limit is declined before it reaches the model, so it costs no AI operations.

What counts as Traffic?

In Uploadcare, “Traffic” refers to the data transferred both from Uploadcare CDN to your end-users and between Uploadcare CDN and Uploadcare’s servers.

Uploadcare offers image and video optimization tools, which are quite handy because they help you significantly reduce your traffic usage. By optimizing your files, you’re essentially reducing the file size without noticeably affecting the quality, meaning less data needs to be transferred, hence, less traffic used.

What counts as Storage?

When it comes to Storage in Uploadcare, it’s all about the total size of the original files stored in your account. This includes every single image, video, document, or other type of file that you’ve uploaded to Uploadcare. Unlike in some other systems, only the original versions of your files count towards your storage — not any transformations or alterations you might have made.

It’s important to note that this metric is cumulative, meaning it adds up over time. The storage counter doesn’t reset at the start of a new billing cycle.

Can I use Uploadcare for free?

Yes, we offer a Free plan designed for small-scale projects. It is designed to allow users to explore and experience the features and capabilities of Uploadcare without any cost. However, it’s important to note that the Free plan may have certain limitations compared to our paid subscription plans. If you require additional information about the specific features and limitations of the Free plan, feel free to contact Uploadcare’s [sales team](https://uploadcare.com/schedule-demo/).

What happens if my Free plan limit is reached?

The Free plan is designed for very small-scale projects, so exceeding its usage limits results in a temporary suspension until the start of the next month. Paid plans raise the limits and let you keep going past them, with the extra usage billed as overage. See [billing details](https://uploadcare.com/docs/billing/) for how that works.

How do you charge me? When will I get billed?

We charge for our services through a subscription model. There are two types of fees: Subscription Fees and Usage Fees. The Subscription Fee is paid upfront when you sign up and covers a certain amount of usage for the chosen monthly or annual period.

If you exceed the allowed usage limits in your subscription plan, we will charge Usage Fees at the end of each month.

For more detailed information on the terms and conditions, including the Order Form, taxes, and refund policies, please refer to the full [terms of service](https://uploadcare.com/about/terms/) provided by Uploadcare.

What happens if I exceed my plan limits?

Uploadcare limits are soft, and if you go above them, overage fees will apply automatically. Please [contact us](https://uploadcare.com/schedule-demo/) to discuss a plan which aligns best with your needs.

Which payment methods do you support?

Uploadcare currently accepts major credit and debit cards for payment. In addition, if you’re subscribed to the Enterprise plan, you also have the option to make payments via bank transfers.

Please note, alternatives like PayPal, Bitcoin, and similar methods are not currently supported. If you need further information or assistance with payment methods, feel free to get in touch with Uploadcare’s [sales team](https://uploadcare.com/schedule-demo/).

Who has ownership of the files and data uploaded to Uploadcare?

Uploadcare values your ownership rights and privacy. All files and data you upload to Uploadcare remain your property. You maintain ownership of your files and data, and Uploadcare merely acts as a service provider to store and handle your files based on your instructions.

Can Uploadcare store sensitive files and data?

Yes, Uploadcare is SOC2 and HIPAA-compliant, ensuring that industry-standard security measures are in place to protect your files and data. As a trusted file management service, Uploadcare prioritizes the security and integrity of your information.

Uploadcare provides a 99.9% Service Level Agreement (SLA) on all paid plans, ensuring high availability and reliability of the services. Additionally, Uploadcare systems maintain over 99.99% monthly uptime figures for most regions.

For more specific details about Uploadcare’s security certifications, compliance standards, and the SLA, check out the [Trust Center](https://trust.uploadcare.com/).

How is the cost of adaptive bitrate streaming calculated?

The cost is based on the resolutions and codecs you choose, and the duration of the video. Each rendition is billed separately.

- The base rate is 10 operations per 10 seconds, multiplied by a resolution factor (×1 for 240p–576p, ×2 for 720p–1080p, ×4 for 1440p–2160p) and a codec factor (×1 for H.264, ×2 for H.265).
- The duration is rounded up to the nearest 10 seconds.

For example, a 52-second video with three H.264 renditions (360p, 720p, 1080p) requires: 60 + 120 + 120 = 300 operations.

Which codec should I use, H.264 or H.265?

H.264 is the universal codec. It plays on every browser and device. Encoding cost is ×1, and it’s the safe default for any rendition you want all viewers to receive.

H.265 produces roughly half the file size at the same visual quality. Encoding cost is ×2, but the smaller file size means lower traffic costs every time the video is delivered, which usually offsets the higher encoding cost many times over.

What resolution options are available for videos?

Eight resolution options are available: 240p, 360p, 480p, 576p, 720p, 1080p, 1440p, and 2160p (4K). You also choose between H.264 and H.265 codecs.

- The resolution is based on the smaller side of the video.
- Videos are never upscaled; if the original video is 900p, the highest resolution will remain 900p.
- Selected resolutions larger than the source are skipped.

What happens if my video’s duration doesn’t align with 10-second intervals?

We round video durations up to the nearest 10-second increment, then bill from that rounded number.

- A 52-second video is rounded up to 60 seconds.
- Billing is then calculated based on this rounded duration.

Are all resolution options always generated?

No. Only the renditions you select are generated.

- Selected resolutions that exceed the original video’s resolution are automatically skipped (e.g., a 900p source will not generate 1080p, 1440p, or 2160p renditions).
- This ensures no unnecessary upscaling.

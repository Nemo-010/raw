Pricing · Gemfury Toggle navigation
News
Documentation
Pricing
Login
Sign up
14-day Free Trial
No credit card required. Switch or cancel anytime.
After your 14-day trial, we will notify you of the recommended plan. Being a collaborator is always free.
Sign Up For Free Login via Github
Plenty of Plans to Choose From
Select the one that suits for you, or your team
Public
free
$0/mo
Get started
Personal
starting at
$9/mo
Start a free trial
Team
starting at
$25/mo
Start a free trial
* All plans come with Unlimited versions, SSL Protection, and Free setup
Public Plans
PublicPLANS | Collaborators | Private Packages | Public Packages
Free | ∞ | - | ∞ | $0/mo
Personal Plans
PersonalPLANS | Collaborators | Private Packages | Public Packages
Personal 1C | 1 | ∞ | ∞ | $9/mo
Personal 5C | 5 | ∞ | ∞ | $14/mo
Personal 10C | 10 | ∞ | ∞ | $23/mo
Personal 25C | 25 | ∞ | ∞ | $50/mo
Personal 50C | 50 | ∞ | ∞ | $100/mo
Team
TeamPLANS | Collaborators | Private Packages | Public Packages
Team 10P | ∞ | 10 | ∞ | $25/mo
Team 20P | ∞ | 20 | ∞ | $50/mo
Team 50P | ∞ | 50 | ∞ | $100/mo
Team 125P | ∞ | 125 | ∞ | $200/mo
Team 200P | ∞ | 200 | ∞ | $300/mo
Team 300P | ∞ | 300 | ∞ | $450/mo
Team 450P | ∞ | 450 | ∞ | $650/mo
Enterprise
Email us any time at [email protected] to discuss your needs.
What is a collaborator?
A collaborator is another Gemfury user who is allowed access to a shared account — one who can upload packages to that account without it counting against one's plan quota.
Do I need a Business or Personal plan?
Business plans better serve the needs of organizations by providing separate billing, multi-ownership, and fine-grained permission control.
How does the trial work?
Use Gemfury without limits during the trial. We will let you know at the end of the trial if your usage requires a paid plan. Alternatively, you can start a paid plan at any time before that.
Need a larger plan? More questions?
Email us any time at [email protected] to discuss your needs.
All prices are in USD.
Ready to get started?
Gemfury works with RubyGems, Python packages, npm modules, and all compatible frameworks and services.
Try Gemfury, It's Free
Products
Private Gem server
Private npm registry
Private PyPI server
Private Go Modules hosting
Private Composer repository
Private Maven repository
Private DEB repository
Private RPM repository
Private Bower registry
Private NuGet hosting
Resources
News
Status
Security
Dev Center
Get Support
About
How It Works
Pricing
Terms
Privacy
Legal
Contact Us
[email protected]

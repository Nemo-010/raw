#!/usr/bin/env python3
"""text.py FILE [maxchars] -- strip a saved HTML page to readable text.

FetchURL returns empty text for some Chinese vendor pages and for every search
engine, so pages are fetched with curl into .tmp/ip-proxy/lane3/ and flattened
here. Stdout is forced to UTF-8: the Windows console default is cp1252 and
raises on CJK.
"""
import html
import re
import sys


def main() -> int:
    path = sys.argv[1]
    limit = int(sys.argv[2]) if len(sys.argv) > 2 else 12000
    raw = open(path, "rb").read()
    for enc in ("utf-8", "gb18030", "big5"):
        try:
            body = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        body = raw.decode("utf-8", "replace")

    body = re.sub(r"<script.*?</script>", " ", body, flags=re.S | re.I)
    body = re.sub(r"<style.*?</style>", " ", body, flags=re.S | re.I)
    body = re.sub(r"<!--.*?-->", " ", body, flags=re.S)
    body = re.sub(r"<br\s*/?>|</p>|</div>|</tr>|</li>|</h[1-6]>", "\n", body, flags=re.I)
    body = re.sub(r"</td>|</th>", " | ", body, flags=re.I)
    body = re.sub(r"<[^>]+>", "", body)
    body = html.unescape(body)
    lines = [re.sub(r"[ \t\u3000]+", " ", ln).strip() for ln in body.split("\n")]
    out = "\n".join(ln for ln in lines if ln)
    out = re.sub(r"\n{3,}", "\n\n", out)
    print(out[:limit])
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.exit(main())

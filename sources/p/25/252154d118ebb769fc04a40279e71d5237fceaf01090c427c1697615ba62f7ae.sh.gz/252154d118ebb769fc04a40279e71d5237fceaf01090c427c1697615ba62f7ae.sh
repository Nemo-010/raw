#!/bin/sh
# ddg.sh "<query>" [n] -- DuckDuckGo HTML endpoint, prints "title | url | snippet"
# Used because FetchURL returns empty for search-engine result pages on this host.
q=$(printf '%s' "$1" | sed 's/ /+/g')
n=${2:-12}
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
curl -q -s --max-time 25 -A "$UA" "https://html.duckduckgo.com/html/?q=$q" \
 | tr '\n' ' ' \
 | sed 's/<div class="result__body"/\n@@/g' \
 | sed -n 's/.*result__a[^>]*href="\([^"]*\)"[^>]*>\(.*\)/\2\t\1/p' \
 | sed 's/<[^>]*>//g' \
 | head -n "$n"

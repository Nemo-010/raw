"""Test free proxy lists: SOCKS5/HTTP-CONNECT handshake, then a real TLS payload.

Two stages per proxy, recorded separately:
  A. TCP connect + protocol handshake to the proxy succeeds
  B. a full HTTPS GET of https://[operator host removed]/json through the proxy returns
     a body that carries an "ip" field

Stage A alone is the number that overstates: the brief records that a public
pool gave 75% no identity echo and 87.5-100% no payload.
"""
import json
import socket
import ssl
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

TARGET_HOST = "[operator host removed]"
TARGET_PATH = "/json"
TARGET_PORT = 443
CONNECT_TIMEOUT = 6.0
READ_TIMEOUT = 10.0


def recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise OSError("eof")
        buf += chunk
    return buf


def socks5_handshake(sock, host, port):
    sock.sendall(b"\x05\x01\x00")
    ver, method = recv_exact(sock, 2)
    if ver != 0x05:
        raise OSError("not socks5")
    if method == 0x02:
        raise OSError("auth-required")
    if method != 0x00:
        raise OSError("no acceptable method")
    h = host.encode()
    req = b"\x05\x01\x00\x03" + bytes([len(h)]) + h + port.to_bytes(2, "big")
    sock.sendall(req)
    head = recv_exact(sock, 4)
    if head[1] != 0x00:
        raise OSError("connect-rep-%d" % head[1])
    atyp = head[3]
    if atyp == 0x01:
        recv_exact(sock, 4)
    elif atyp == 0x03:
        ln = recv_exact(sock, 1)[0]
        recv_exact(sock, ln)
    elif atyp == 0x04:
        recv_exact(sock, 16)
    recv_exact(sock, 2)


def http_connect_handshake(sock, host, port):
    req = (
        "CONNECT %s:%d HTTP/1.1\r\nHost: %s:%d\r\nProxy-Connection: keep-alive\r\n\r\n"
        % (host, port, host, port)
    )
    sock.sendall(req.encode())
    buf = b""
    while b"\r\n\r\n" not in buf:
        chunk = sock.recv(1)
        if not chunk:
            raise OSError("eof-in-connect")
        buf += chunk
        if len(buf) > 4096:
            raise OSError("connect-header-too-long")
    status_line = buf.split(b"\r\n", 1)[0].decode("latin-1")
    parts = status_line.split()
    if len(parts) < 2:
        raise OSError("bad-status-line")
    if parts[1] != "200":
        raise OSError("connect-status-" + parts[1])


def payload(sock):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    tls = ctx.wrap_socket(sock, server_hostname=TARGET_HOST)
    req = (
        "GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: curl/8.21.0\r\n"
        "Accept: */*\r\nConnection: close\r\n\r\n" % (TARGET_PATH, TARGET_HOST)
    )
    tls.sendall(req.encode())
    raw = b""
    while True:
        try:
            chunk = tls.recv(8192)
        except (socket.timeout, ssl.SSLError, OSError):
            break
        if not chunk:
            break
        raw += chunk
        if len(raw) > 65536:
            break
    try:
        tls.close()
    except OSError:
        pass
    if not raw:
        raise OSError("empty-body")
    head, _, body = raw.partition(b"\r\n\r\n")
    status_line = head.split(b"\r\n", 1)[0].decode("latin-1", "replace")
    if " 200" not in status_line:
        raise OSError("http-" + status_line.split(" ")[1] if " " in status_line else "http-bad")
    # chunked?
    if b"transfer-encoding: chunked" in head.lower():
        out = b""
        rest = body
        while True:
            line, _, rest = rest.partition(b"\r\n")
            try:
                n = int(line.strip().split(b";")[0], 16)
            except ValueError:
                break
            if n == 0:
                break
            out += rest[:n]
            rest = rest[n + 2:]
        body = out
    return body


def test_one(entry):
    proto, host, port = entry["proto"], entry["host"], int(entry["port"])
    res = {
        "proto": proto,
        "host": host,
        "port": port,
        "source": entry.get("source", ""),
        "handshake": False,
        "payload": False,
        "exit_ip": None,
        "error": None,
        "ms": None,
    }
    t0 = time.time()
    sock = None
    try:
        sock = socket.create_connection((host, port), timeout=CONNECT_TIMEOUT)
        sock.settimeout(READ_TIMEOUT)
        if proto == "socks5":
            socks5_handshake(sock, TARGET_HOST, TARGET_PORT)
        elif proto == "socks4":
            # SOCKS4a
            sock.sendall(b"\x04\x01" + TARGET_PORT.to_bytes(2, "big")
                         + b"\x00\x00\x00\x01" + b"\x00" + TARGET_HOST.encode() + b"\x00")
            rep = recv_exact(sock, 8)
            if rep[1] != 0x5A:
                raise OSError("socks4-rep-%d" % rep[1])
        elif proto == "http":
            http_connect_handshake(sock, TARGET_HOST, TARGET_PORT)
        else:
            raise OSError("unknown-proto")
        res["handshake"] = True
        body = payload(sock)
        try:
            j = json.loads(body.decode("utf-8", "replace"))
            res["exit_ip"] = j.get("ip")
            res["asn_org"] = j.get("org")
            res["country"] = j.get("country")
            res["payload"] = bool(res["exit_ip"])
        except ValueError:
            res["error"] = "body-not-json:" + body[:60].decode("utf-8", "replace")
    except Exception as e:  # noqa: BLE001 - every failure mode is data here
        res["error"] = "%s: %s" % (type(e).__name__, e)
    finally:
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass
    res["ms"] = int((time.time() - t0) * 1000)
    return res


def main():
    infile, outfile, workers = sys.argv[1], sys.argv[2], int(sys.argv[3])
    entries = json.load(open(infile, encoding="utf-8"))
    results = []
    done = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(test_one, e): e for e in entries}
        for f in as_completed(futs):
            results.append(f.result())
            done += 1
            if done % 25 == 0:
                print("  %d/%d" % (done, len(entries)), flush=True)
    json.dump(results, open(outfile, "w", encoding="utf-8"), indent=1)
    hs = sum(1 for r in results if r["handshake"])
    pl = sum(1 for r in results if r["payload"])
    print("%s: n=%d handshake=%d (%.1f%%) payload=%d (%.1f%%)"
          % (outfile, len(results), hs, 100.0 * hs / len(results),
             pl, 100.0 * pl / len(results)))


if __name__ == "__main__":
    main()

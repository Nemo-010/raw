import sys,io
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding="utf-8",errors="replace")
import re,html,sys
p=sys.argv[1]
h=open(p,encoding='utf-8',errors='replace').read()
h=re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>',' ',h)
t=html.unescape(re.sub(r'(?s)<[^>]+>','\n',h))
lines=[l.strip() for l in t.split('\n') if l.strip()]
txt='\n'.join(lines)
kws=sys.argv[2].split('|')
for kw in kws:
    for m in re.finditer(kw,txt,re.I):
        print('##',kw,'>>',txt[max(0,m.start()-300):m.start()+400].replace('\n',' | ')[:700]);print()
        break

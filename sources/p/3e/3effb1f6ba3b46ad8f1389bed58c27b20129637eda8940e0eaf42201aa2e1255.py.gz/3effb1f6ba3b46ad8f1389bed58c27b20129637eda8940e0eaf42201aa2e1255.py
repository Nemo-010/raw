import json, subprocess, time
from concurrent.futures import ThreadPoolExecutor

ECHO = "https://icanhazip.com"
d = json.load(open("survive-big250.json"))
alive = [r for r in d["results"] if r["ok"]]
print("survivors at T0:", len(alive))


def recheck(r):
    scheme = r["scheme"]
    proxy = f"{scheme}://{r['proxy']}"
    t0 = time.time()
    try:
        out = subprocess.run(["curl", "-qsS", "--max-time", "15", "--proxy", proxy, ECHO],
                             capture_output=True, text=True, timeout=20)
    except subprocess.TimeoutExpired:
        return dict(proxy=r["proxy"], src=r["src"], t0_exit=r["exit"], alive=False, err="timeout")
    body = (out.stdout or "").strip()
    if out.returncode != 0 or not body:
        return dict(proxy=r["proxy"], src=r["src"], t0_exit=r["exit"], alive=False,
                    err=f"curl-exit-{out.returncode}")
    ip = body.splitlines()[0].strip()
    return dict(proxy=r["proxy"], src=r["src"], t0_exit=r["exit"], alive=True,
                t1_exit=ip, same_exit=(ip == r["exit"]),
                secs=round(time.time() - t0, 2))


t0 = time.time()
with ThreadPoolExecutor(max_workers=30) as ex:
    res = list(ex.map(recheck, alive))
still = [r for r in res if r["alive"]]
same = [r for r in still if r.get("same_exit")]
print(json.dumps(dict(t0_survivors=len(alive), t1_alive=len(still),
                      t1_alive_pct_of_t0=round(100 * len(still) / len(alive), 1),
                      same_exit_address=len(same),
                      elapsed_s=round(time.time() - t0, 1))))
for r in res:
    print(json.dumps(r))
json.dump(res, open("survive-t1-recheck.json", "w"), indent=1)

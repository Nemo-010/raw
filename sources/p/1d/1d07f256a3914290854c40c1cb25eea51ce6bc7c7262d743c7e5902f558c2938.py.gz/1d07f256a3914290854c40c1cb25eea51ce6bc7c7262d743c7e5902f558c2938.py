#!/usr/bin/env python3
"""ddg.py "<query>" [n] -- DuckDuckGo HTML endpoint -> "url | title | snippet" lines.

FetchURL returns an empty result page for search engines on this host, so the
breadth pass needs its own search path. Decodes DDG's uddg= redirect wrapper.
"""
import html
import re
import sys
import urllib.parse
import urllib.request

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")


def main() -> int:
    query = sys.argv[1]
    limit = int(sys.argv[2]) if len(sys.argv) > 2 else 12
    url = "https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(query)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    body = urllib.request.urlopen(req, timeout=30).read().decode("utf-8", "replace")

    blocks = re.split(r'class="[^"]*result__body"', body)[1:]
    shown = 0
    for block in blocks:
        m = re.search(r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', block, re.S)
        if not m:
            continue
        href, title = m.group(1), m.group(2)
        if "uddg=" in href:
            href = urllib.parse.unquote(href.split("uddg=")[1].split("&")[0])
        title = html.unescape(re.sub(r"<[^>]+>", "", title)).strip()
        sn = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', block, re.S)
        snippet = ""
        if sn:
            snippet = html.unescape(re.sub(r"<[^>]+>", "", sn.group(1))).strip()
        print(f"{href}\n    {title}\n    {snippet[:300]}\n")
        shown += 1
        if shown >= limit:
            break
    if shown == 0:
        print("(no results parsed; page length %d)" % len(body))
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.exit(main())

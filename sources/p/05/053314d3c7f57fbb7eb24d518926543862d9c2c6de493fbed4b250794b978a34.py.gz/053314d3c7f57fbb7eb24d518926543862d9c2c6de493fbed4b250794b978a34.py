import sys, re, html

def to_text(path):
    b = open(path, 'rb').read()
    for enc in ('utf-8', 'cp1252', 'latin-1'):
        try:
            s = b.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        s = b.decode('utf-8', 'replace')
    # keep json-ish content readable
    s = re.sub(r'(?is)<(script|style|noscript|svg|head)\b.*?</\1>', ' ', s)
    s = re.sub(r'(?s)<!--.*?-->', ' ', s)
    s = re.sub(r'(?i)</(p|div|li|tr|h[1-6]|section|table|br)>', '\n', s)
    s = re.sub(r'(?i)<br\s*/?>', '\n', s)
    s = re.sub(r'(?i)</t[dh]>', ' | ', s)
    s = re.sub(r'(?s)<[^>]+>', ' ', s)
    s = html.unescape(s)
    s = s.replace('\u00a0', ' ')
    lines = []
    for ln in s.split('\n'):
        ln = re.sub(r'[ \t\x0b\x0c]+', ' ', ln).strip()
        if ln:
            lines.append(ln)
    out = []
    prev = None
    for ln in lines:
        if ln != prev:
            out.append(ln)
        prev = ln
    return '\n'.join(out)

if __name__ == '__main__':
    t = to_text(sys.argv[1])
    print(t)

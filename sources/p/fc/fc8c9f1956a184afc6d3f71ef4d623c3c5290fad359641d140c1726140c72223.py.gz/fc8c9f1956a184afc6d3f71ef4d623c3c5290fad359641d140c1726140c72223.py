import base64, csv, json, random, re, socket, time
from concurrent.futures import ThreadPoolExecutor

random.seed(20261024)
raw = open("vpngate.csv", encoding="utf-8", errors="replace").read().splitlines()
rows = [r for r in raw if r and r[0] not in "*#"]
recs = [r for r in csv.reader(rows) if len(r) > 14 and r[1].count(".") == 3]


def port_of(rec):
    try:
        cfg = base64.b64decode(rec[14] + "==").decode("utf-8", "replace")
    except Exception:
        return None, None
    proto = "udp"
    if re.search(r"^proto\s+tcp", cfg, re.M | re.I):
        proto = "tcp"
    m = re.search(r"^remote\s+\S+\s+(\d+)", cfg, re.M)
    return (int(m.group(1)) if m else None), proto


enriched = []
for r in recs:
    p, proto = port_of(r)
    if p and proto == "tcp":
        enriched.append((r, p))
print("servers with a TCP remote port:", len(enriched), "of", len(recs))

sample = random.sample(enriched, min(60, len(enriched)))


def tcp_open(item):
    rec, port = item
    ip = rec[1]
    s = socket.socket(); s.settimeout(5)
    t0 = time.time()
    try:
        s.connect((ip, port))
        return dict(ip=ip, port=port, country=rec[5], open=True,
                    ms=round((time.time() - t0) * 1000))
    except Exception as e:
        return dict(ip=ip, port=port, country=rec[5], open=False, err=type(e).__name__)
    finally:
        try: s.close()
        except Exception: pass


t0 = time.time()
with ThreadPoolExecutor(max_workers=40) as ex:
    res = list(ex.map(tcp_open, sample))
op = [r for r in res if r["open"]]
print(json.dumps(dict(sampled=len(res), tcp_reachable=len(op),
                      reach_pct=round(100 * len(op) / len(res), 1),
                      elapsed_s=round(time.time() - t0, 1))))
for r in sorted(res, key=lambda x: not x["open"])[:25]:
    print(json.dumps(r))
json.dump(res, open("vpngate-tcp2-2026-10-24.json", "w"), indent=1)

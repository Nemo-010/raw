import json, random, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

random.seed(20261024)

ECHO = "https://icanhazip.com"
ENRICH = "http://ip-api.com/json/{}?fields=status,query,country,as,asname,isp,org,proxy,hosting"
REAL_IP = "[probe-machine address removed]"
TIMEOUT = "15"


def sample(path, n):
    try:
        lines = [l.strip() for l in open(path, encoding="utf-8", errors="replace") if l.strip()]
    except FileNotFoundError:
        return []
    return random.sample(lines, min(n, len(lines)))


def probe(entry, scheme):
    hp, _, src = entry.partition("|")
    proxy = f"{scheme}://{hp}"
    t0 = time.time()
    try:
        out = subprocess.run(
            ["curl", "-qsS", "--max-time", TIMEOUT, "--proxy", proxy, ECHO],
            capture_output=True, text=True, timeout=14,
        )
    except subprocess.TimeoutExpired:
        return dict(proxy=hp, src=src, scheme=scheme, ok=False, err="hard-timeout", secs=14.0)
    dt = round(time.time() - t0, 2)
    body = (out.stdout or "").strip()
    if out.returncode != 0:
        return dict(proxy=hp, src=src, scheme=scheme, ok=False, err=f"curl-exit-{out.returncode}", secs=dt)
    if not body or len(body) > 64 or body.count(".") + body.count(":") == 0:
        return dict(proxy=hp, src=src, scheme=scheme, ok=False, err="non-ip-body", secs=dt, body=body[:80])
    ip = body.splitlines()[0].strip()
    if ip == REAL_IP:
        return dict(proxy=hp, src=src, scheme=scheme, ok=False, err="transparent-no-rotation", secs=dt, exit=ip)
    return dict(proxy=hp, src=src, scheme=scheme, ok=True, secs=dt, exit=ip)


def enrich(r):
    try:
        out = subprocess.run(["curl", "-qsS", "--max-time", "10", ENRICH.format(r["exit"])],
                             capture_output=True, text=True, timeout=14)
        j = json.loads((out.stdout or "{}").strip() or "{}")
    except Exception as e:
        r["enrich_err"] = str(e)[:60]
        return r
    if j.get("status") != "success":
        r["enrich_err"] = j.get("message", "no-status")
        return r
    r.update(country=j.get("country"), asn=j.get("as"), asname=j.get("asname"),
             isp=j.get("isp"), hosting=j.get("hosting"), proxied=j.get("proxy"))
    return r


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 25
    tag = sys.argv[2] if len(sys.argv) > 2 else "run"
    plan = []
    for src, path, k in [
        ("free-proxy-list.net", "pfl-parsed.txt", n),
        ("proxyscrape-api", "proxyscrape-api.txt", n),
        ("TheSpeedX", "speedx-http.txt", n),
        ("monosans", "monosans-http.txt", n),
        ("hookzof", "hookzof-socks5.txt", n),
    ]:
        for hp in sample(path, k):
            plan.append((hp + "|" + src, "socks5h" if src == "hookzof" else "http"))

    print(f"sample size: {len(plan)}", file=sys.stderr)
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=60) as ex:
        results = list(ex.map(lambda p: probe(*p), plan))
    elapsed = round(time.time() - t0, 1)

    alive = [r for r in results if r["ok"]]
    if alive:
        with ThreadPoolExecutor(max_workers=8) as ex:
            list(ex.map(enrich, alive))

    summary = dict(tag=tag, elapsed_s=elapsed, sampled=len(results), alive=len(alive),
                   survival_pct=round(100 * len(alive) / len(results), 1))
    print(json.dumps(summary))
    for r in sorted(results, key=lambda x: (not x["ok"], x["src"])):
        print(json.dumps(r))
    json.dump(dict(summary=summary, results=results), open(f"survive-{tag}.json", "w"), indent=1)

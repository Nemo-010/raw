import re,html,sys,io
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding='utf-8',errors='replace')
for f in sys.argv[1:]:
    s=open(f,encoding='utf-8',errors='replace').read()
    s=re.sub(r'<script.*?</script>','',s,flags=re.S)
    s=re.sub(r'<style.*?</style>','',s,flags=re.S)
    t=re.sub(r'<[^>]+>',' ',s)
    t=html.unescape(t); t=re.sub(r'[ \t]+',' ',t); t=re.sub(r'\n\s*\n+','\n',t)
    print("=====",f,len(t)); print(t[:7000])

import csv, socket, random, json, time
from concurrent.futures import ThreadPoolExecutor

random.seed(20261024)
raw = open("vpngate.csv", encoding="utf-8", errors="replace").read().splitlines()
rows = [r for r in raw if r and r[0] not in "*#"]
recs = [r for r in csv.reader(rows) if len(r) > 10 and r[1].count(".") == 3]
print("servers in CSV:", len(recs))

sample = random.sample(recs, 60)


def tcp_open(rec):
    ip = rec[1]
    # SoftEther SSL-VPN is advertised on TCP 443 or the listed port; test 443 and 992
    for port in (443, 992, 5555):
        s = socket.socket()
        s.settimeout(4)
        t0 = time.time()
        try:
            s.connect((ip, port))
            dt = round((time.time() - t0) * 1000)
            s.close()
            return dict(ip=ip, country=rec[5], port=port, open=True, ms=dt,
                        sessions=rec[7], uptime=rec[8])
        except Exception as e:
            err = type(e).__name__
        finally:
            try: s.close()
            except Exception: pass
    return dict(ip=ip, country=rec[5], port=None, open=False, err=err)


t0 = time.time()
with ThreadPoolExecutor(max_workers=40) as ex:
    res = list(ex.map(tcp_open, sample))
op = [r for r in res if r["open"]]
print(json.dumps(dict(sampled=len(res), tcp_reachable=len(op),
                      reach_pct=round(100 * len(op) / len(res), 1),
                      elapsed_s=round(time.time() - t0, 1))))
for r in res:
    print(json.dumps(r))
json.dump(res, open("vpngate-tcp-2026-10-24.json", "w"), indent=1)

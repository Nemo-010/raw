package main

// Sends a captured ClientHello body verbatim to a TLS server and reports the
// ServerHello it gets back. This is the technique the gateway uses over
// env.EGRESS.connect(): the ClientHello is a byte string, and the server's
// answer is the only proof it was accepted.

import (
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"time"
)

func main() {
	file := os.Args[1]
	host := os.Args[2]
	body, err := os.ReadFile(file)
	if err != nil {
		fmt.Println("read:", err)
		return
	}
	// The capture is a handshake body (type 0x01 + length); wrap it in a TLS record.
	rec := make([]byte, 0, len(body)+5)
	rec = append(rec, 0x16, 0x03, 0x01)
	n := len(body)
	rec = append(rec, byte(n>>8), byte(n))
	rec = append(rec, body...)

	c, err := net.DialTimeout("tcp", host, 15*time.Second)
	if err != nil {
		fmt.Println("dial:", err)
		return
	}
	defer c.Close()
	c.SetDeadline(time.Now().Add(15 * time.Second))
	if _, err := c.Write(rec); err != nil {
		fmt.Println("write:", err)
		return
	}
	buf := make([]byte, 4096)
	nr, err := c.Read(buf)
	if err != nil {
		fmt.Println("read:", err)
		return
	}
	got := buf[:nr]
	out := map[string]any{
		"hello_bytes":  len(body),
		"record_bytes": len(rec),
		"reply_bytes":  nr,
		"reply_head":   hex.EncodeToString(got[:min(16, len(got))]),
		"handshake":    got[5],
		"accepted":     got[0] == 0x16 && got[5] == 0x02,
	}
	if got[0] == 0x15 {
		out["alert_level"] = got[5]
		out["alert_desc"] = got[6]
	}
	j, _ := json.Marshal(out)
	fmt.Println(string(j))
}

func min(a, b int) int { if a < b { return a }; return b }

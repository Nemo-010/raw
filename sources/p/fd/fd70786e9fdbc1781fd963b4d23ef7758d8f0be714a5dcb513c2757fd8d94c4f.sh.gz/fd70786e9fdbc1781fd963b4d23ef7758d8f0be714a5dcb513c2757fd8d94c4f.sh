#!/usr/bin/env bash
# usage: fetch.sh <url> <outname>
u="$1"; n="$2"
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
curl -qfsSL --max-time 40 --compressed -A "$UA" \
  -H "Accept: text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8" \
  -H "Accept-Language: en-US,en;q=0.9" "$u" -o "raw-$n.html" 2>err-$n.txt
rc=$?
echo "rc=$rc bytes=$(stat -c%s raw-$n.html 2>/dev/null || echo 0) url=$u"

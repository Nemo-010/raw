#!/usr/bin/env bash
# usage: batch.sh <pairsfile>   where each line is:  name<TAB>url[<TAB>resolve_ip]
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
while IFS=$'\t' read -r name url ip; do
  [ -z "$name" ] && continue
  case "$name" in \#*) continue;; esac
  if [ -n "$ip" ]; then
    res=(--resolve "$(echo "$url" | sed -E 's#https?://([^/]+).*#\1#'):443:$ip")
  else
    res=()
  fi
  code=$(curl -sSL --max-time 45 --compressed -A "$UA" \
    -H "Accept: text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8" \
    -H "Accept-Language: en-US,en;q=0.9" "${res[@]}" \
    -o "raw-$name.html" -w "%{http_code}" "$url" 2>/dev/null)
  rc=$?
  sz=$(stat -c%s "raw-$name.html" 2>/dev/null || echo 0)
  printf "%-16s rc=%-3s http=%-4s bytes=%-8s %s\n" "$name" "$rc" "$code" "$sz" "$url"
done < "$1"

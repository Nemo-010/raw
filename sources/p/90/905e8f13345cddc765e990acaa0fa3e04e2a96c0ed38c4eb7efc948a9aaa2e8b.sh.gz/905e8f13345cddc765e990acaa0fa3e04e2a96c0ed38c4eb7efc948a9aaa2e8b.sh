#!/usr/bin/env bash
# DoH A-record lookup; local resolver is hijacked to 2a07:a8c0::2f:a8d9 on this host.
doh() {
  curl -s --max-time 20 -H 'accept: application/dns-json' \
    "https://cloudflare-dns.com/dns-query?name=$1&type=A" \
  | python -c "
import json,sys
d=json.load(sys.stdin)
a=[x['data'] for x in d.get('Answer',[]) if x.get('type')==1]
print(' '.join(a) if a else 'NO-A')
"
}
"$@"

#!/usr/bin/env bash
# ASN lookup helpers. whois and dig are absent on this host; RIPEstat + RDAP over HTTP instead.
# usage: asn.sh name <term>      -> ASNs whose holder matches <term>
#        asn.sh ip <address>     -> ASN, prefix, holder for an address
#        asn.sh asn <AS1234>     -> announced prefix count and holder
name() {
  curl -s --max-time 25 "https://stat.ripe.net/data/searchcomplete/data.json?resource=$1" \
  | python -c "
import json,sys
d=json.load(sys.stdin)['data'].get('categories',[])
for c in d:
    if c.get('category')!='ASNs': continue
    for s in c.get('suggestions',[])[:10]:
        print(' ',s.get('value'),'|',s.get('description',''))
"
}
ip() {
  curl -s --max-time 25 "https://stat.ripe.net/data/network-info/data.json?resource=$1" \
  | python -c "
import json,sys
d=json.load(sys.stdin)['data']
print('  prefix',d.get('prefix'),'asns',d.get('asns'))
"
  a=$(curl -s --max-time 25 "https://stat.ripe.net/data/network-info/data.json?resource=$1" | python -c "
import json,sys
a=json.load(sys.stdin)['data'].get('asns') or ['NA']
print(a[0])")
  [ "$a" = "NA" ] || curl -s --max-time 25 "https://stat.ripe.net/data/as-overview/data.json?resource=AS$a" \
  | python -c "
import json,sys
d=json.load(sys.stdin)['data']
print('  holder',d.get('holder'))
"
}
asn() {
  curl -s --max-time 25 "https://stat.ripe.net/data/as-overview/data.json?resource=$1" \
  | python -c "
import json,sys
d=json.load(sys.stdin)['data']
print('  holder',d.get('holder'),'| announced',d.get('announced'))
"
  curl -s --max-time 25 "https://stat.ripe.net/data/announced-prefixes/data.json?resource=$1" \
  | python -c "
import json,sys
p=json.load(sys.stdin)['data'].get('prefixes',[])
print('  prefixes',len(p),'v4',sum(1 for x in p if ':' not in x['prefix']),'v6',sum(1 for x in p if ':' in x['prefix']))
"
}
"$@"

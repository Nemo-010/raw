#!/usr/bin/env bash
# DuckDuckGo html search -> unique target URLs. An aggregator list is a LEAD only.
W='REPO/.tmp/ip-proxy/lane11/s/q.html'
mkdir -p 'REPO/.tmp/ip-proxy/lane11/s'
curl -s --max-time 25 -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36" \
  "https://html.duckduckgo.com/html/?q=$1" -o REPO/.tmp/ip-proxy/lane11/s/q.html
python -c "
import re,urllib.parse
h=open(r'$W',encoding='utf-8',errors='replace').read()
seen=set()
for m in re.findall(r'uddg=([^\"&]+)',h):
    u=urllib.parse.unquote(m)
    if u in seen: continue
    seen.add(u); print(u)
" | head -${2:-12}

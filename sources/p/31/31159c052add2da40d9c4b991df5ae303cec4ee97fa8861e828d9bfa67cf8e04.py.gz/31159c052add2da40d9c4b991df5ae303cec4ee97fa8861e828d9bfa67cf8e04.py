#!/usr/bin/env python3
"""Fetch a page and print its visible text, for a breadth pass.

The Bash tool on this host has no whois and no dig; curl and nslookup do exist.
FetchURL returns 403 on some vendor pages, so this uses curl with a desktop UA
and strips the markup itself. Output is bounded so a 500 KB page does not flood
the terminal.
"""
import re
import subprocess
import sys
import html

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")


def fetch(url: str, timeout: int = 25) -> tuple[int, bytes]:
    p = subprocess.run(
        ["curl", "-qfsSL", "--max-time", str(timeout), "-A", UA,
         "-H", "Accept-Language: en-US,en;q=0.9", url],
        capture_output=True,
    )
    return p.returncode, p.stdout


def text(raw: bytes) -> str:
    t = raw.decode("utf-8", errors="replace")
    t = re.sub(r"<script.*?</script>", " ", t, flags=re.S | re.I)
    t = re.sub(r"<style.*?</style>", " ", t, flags=re.S | re.I)
    t = re.sub(r"<br\s*/?>", "\n", t, flags=re.I)
    t = re.sub(r"</(p|div|tr|li|h[1-6]|td|th)>", "\n", t, flags=re.I)
    t = re.sub(r"<[^>]+>", " ", t)
    t = html.unescape(t)
    lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in t.split("\n")]
    out, prev = [], None
    for ln in lines:
        if not ln or ln == prev:
            continue
        out.append(ln)
        prev = ln
    return "\n".join(out)


if __name__ == "__main__":
    url = sys.argv[1]
    limit = int(sys.argv[2]) if len(sys.argv) > 2 else 4000
    grep = sys.argv[3] if len(sys.argv) > 3 else None
    rc, raw = fetch(url)
    if rc != 0:
        print(f"FETCH FAILED rc={rc} bytes={len(raw)} url={url}")
        sys.exit(1)
    body = text(raw)
    print(f"# {url}  bytes={len(raw)}  textlen={len(body)}")
    if grep:
        pat = re.compile(grep, re.I)
        for ln in body.split("\n"):
            if pat.search(ln):
                print(ln)
    else:
        print(body[:limit])

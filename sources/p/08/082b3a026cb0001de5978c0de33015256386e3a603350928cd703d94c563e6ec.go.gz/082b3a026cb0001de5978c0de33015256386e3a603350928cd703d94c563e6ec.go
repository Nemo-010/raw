package main

import (
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"os"
	"time"

	utls "github.com/refraction-networking/utls"
)

type out struct {
	Label  string `json:"label"`
	IP     string `json:"ip"`
	JA3    string `json:"ja3"`
	JA3H   string `json:"ja3_hash"`
	JA4    string `json:"ja4"`
	UA     string `json:"user_agent"`
	Err    string `json:"err,omitempty"`
}

func run(label string, spec *utls.ClientHelloSpec, profile utls.ClientHelloID) out {
	o := out{Label: label}
	conn, err := net.DialTimeout("tcp", "tls.peet.ws:443", 15*time.Second)
	if err != nil {
		o.Err = err.Error()
		return o
	}
	var cfg *utls.Config
	cfg = &utls.Config{ServerName: "tls.peet.ws"}
	var uconn *utls.UConn
	if spec != nil {
		uconn = utls.UClient(conn, cfg, utls.HelloCustom)
		if err := uconn.ApplyPreset(spec); err != nil {
			o.Err = "preset:" + err.Error()
			return o
		}
	} else {
		uconn = utls.UClient(conn, cfg, profile)
	}
	if err := uconn.Handshake(); err != nil {
		o.Err = "handshake:" + err.Error()
		return o
	}
	req := "GET /api/all HTTP/1.1\r\nHost: tls.peet.ws\r\nUser-Agent: " + label + "\r\nAccept: */*\r\nConnection: close\r\n\r\n"
	if _, err := uconn.Write([]byte(req)); err != nil {
		o.Err = "write:" + err.Error()
		return o
	}
	body, err := io.ReadAll(uconn)
	if err != nil && len(body) == 0 {
		o.Err = "read:" + err.Error()
		return o
	}
	// strip headers
	idx := -1
	for i := 0; i < len(body)-3; i++ {
		if body[i] == '\r' && body[i+1] == '\n' && body[i+2] == '\r' && body[i+3] == '\n' {
			idx = i + 4
			break
		}
	}
	if idx < 0 {
		o.Err = "no body"
		return o
	}
	var j struct {
		IP  string `json:"ip"`
		TLS struct {
			JA3    string `json:"ja3"`
			JA3H   string `json:"ja3_hash"`
			JA4    string `json:"ja4"`
		} `json:"tls"`
		UA string `json:"user_agent"`
	}
	if err := json.Unmarshal(body[idx:], &j); err != nil {
		o.Err = "json:" + err.Error() + " body:" + string(body[idx:min(idx+200, len(body))])
		return o
	}
	o.IP, o.JA3, o.JA3H, o.JA4, o.UA = j.IP, j.TLS.JA3, j.TLS.JA3H, j.TLS.JA4, j.UA
	return o
}

func min(a, b int) int { if a < b { return a }; return b }

func main() {
	res := []out{}
	// 1. Go's own default stack, via crypto/tls
	{
		o := out{Label: "go-stdlib-default"}
		d := &net.Dialer{Timeout: 15 * time.Second}
		c, err := tls.DialWithDialer(d, "tcp", "tls.peet.ws:443", &tls.Config{ServerName: "tls.peet.ws"})
		if err != nil { o.Err = err.Error() } else {
			fmt.Fprintf(c, "GET /api/all HTTP/1.1\r\nHost: tls.peet.ws\r\nUser-Agent: go-stdlib\r\nConnection: close\r\n\r\n")
			b, _ := io.ReadAll(c)
			c.Close()
			idx := -1
			for i := 0; i < len(b)-3; i++ { if b[i]=='\r'&&b[i+1]=='\n'&&b[i+2]=='\r'&&b[i+3]=='\n' { idx=i+4; break } }
			if idx > 0 {
				var j struct{ IP string `json:"ip"`; TLS struct{ JA3 string `json:"ja3"`; JA3H string `json:"ja3_hash"`; JA4 string `json:"ja4"` } `json:"tls"` }
				if json.Unmarshal(b[idx:], &j) == nil { o.IP, o.JA3, o.JA3H, o.JA4 = j.IP, j.TLS.JA3, j.TLS.JA3H, j.TLS.JA4 }
			}
		}
		res = append(res, o)
	}
	// 2. utls HelloChrome_Auto
	res = append(res, run("utls-HelloChrome_Auto", nil, utls.HelloChrome_Auto))
	// 3. utls HelloFirefox_Auto
	res = append(res, run("utls-HelloFirefox_Auto", nil, utls.HelloFirefox_Auto))
	// 4. utls HelloSafari_Auto
	res = append(res, run("utls-HelloSafari_Auto", nil, utls.HelloSafari_Auto))
	// 5. utls HelloIOS_Auto
	res = append(res, run("utls-HelloIOS_Auto", nil, utls.HelloIOS_Auto))
	// 6. utls HelloEdge_Auto if it exists
	func(){ defer func(){ recover() }(); res = append(res, run("utls-HelloEdge_Auto", nil, utls.HelloEdge_Auto)) }()

	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	enc.Encode(res)
}

import json,sys
p=sys.argv[1]
d=json.load(open(p,encoding='utf-8'))
print('keys:',list(d.keys()))
rs=d.get('results') or []
print('n=',len(rs))
lim=int(sys.argv[2]) if len(sys.argv)>2 else 20
for r in rs[:lim]:
    print('---',r.get('url'))
    print('   title:',(r.get('title') or '')[:160])
    print('   snip:',(r.get('snippet') or '')[:700].replace('\n',' '))

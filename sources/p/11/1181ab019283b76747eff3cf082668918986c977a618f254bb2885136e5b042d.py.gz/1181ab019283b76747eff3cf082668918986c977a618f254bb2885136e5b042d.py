"""How many requests does one free proxy serve before it stops?

Sequential GETs through one proxy, 1s apart, until 3 consecutive failures or a
cap. Records success count, distinct exit IPs seen, and where it stopped.
This is the number that converts a survival rate into a capacity.
"""
import json
import socket
import ssl
import sys
import time

TARGET_HOST = "[operator host removed]"
TARGET_PATH = "/json"
TARGET_PORT = 443


def recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise OSError("eof")
        buf += chunk
    return buf


def socks5(sock, host, port):
    sock.sendall(b"\x05\x01\x00")
    ver, method = recv_exact(sock, 2)
    if method != 0x00:
        raise OSError("auth/no-method")
    h = host.encode()
    sock.sendall(b"\x05\x01\x00\x03" + bytes([len(h)]) + h + port.to_bytes(2, "big"))
    head = recv_exact(sock, 4)
    if head[1] != 0x00:
        raise OSError("rep-%d" % head[1])
    atyp = head[3]
    if atyp == 0x01:
        recv_exact(sock, 4)
    elif atyp == 0x03:
        recv_exact(sock, recv_exact(sock, 1)[0])
    elif atyp == 0x04:
        recv_exact(sock, 16)
    recv_exact(sock, 2)


def http_connect(sock, host, port):
    sock.sendall(("CONNECT %s:%d HTTP/1.1\r\nHost: %s:%d\r\n\r\n" % (host, port, host, port)).encode())
    buf = b""
    while b"\r\n\r\n" not in buf:
        c = sock.recv(1)
        if not c:
            raise OSError("eof")
        buf += c
        if len(buf) > 4096:
            raise OSError("hdr-long")
    if buf.split(b"\r\n", 1)[0].split()[1] != b"200":
        raise OSError("connect-not-200")


def one(proto, host, port, timeout=8.0):
    s = socket.create_connection((host, port), timeout=timeout)
    s.settimeout(timeout)
    try:
        if proto == "socks5":
            socks5(s, TARGET_HOST, TARGET_PORT)
        elif proto == "socks4":
            s.sendall(b"\x04\x01" + TARGET_PORT.to_bytes(2, "big") + b"\x00\x00\x00\x01\x00"
                      + TARGET_HOST.encode() + b"\x00")
            if recv_exact(s, 8)[1] != 0x5A:
                raise OSError("socks4-rep")
        else:
            http_connect(s, TARGET_HOST, TARGET_PORT)
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        t = ctx.wrap_socket(s, server_hostname=TARGET_HOST)
        t.sendall(("GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: curl/8.21.0\r\n"
                   "Accept: */*\r\nConnection: close\r\n\r\n"
                   % (TARGET_PATH, TARGET_HOST)).encode())
        raw = b""
        while True:
            try:
                c = t.recv(8192)
            except (socket.timeout, ssl.SSLError, OSError):
                break
            if not c:
                break
            raw += c
            if len(raw) > 65536:
                break
        t.close()
        head, _, body = raw.partition(b"\r\n\r\n")
        if b" 200" not in head.split(b"\r\n", 1)[0]:
            raise OSError("http-not-200")
        if b"transfer-encoding: chunked" in head.lower():
            out, rest = b"", body
            while True:
                line, _, rest = rest.partition(b"\r\n")
                try:
                    n = int(line.strip().split(b";")[0], 16)
                except ValueError:
                    break
                if n == 0:
                    break
                out += rest[:n]
                rest = rest[n + 2:]
            body = out
        j = json.loads(body.decode("utf-8", "replace"))
        return j.get("ip")
    finally:
        try:
            s.close()
        except OSError:
            pass


def run(entry, cap):
    ok = 0
    fails = 0
    ips = []
    stop = "cap"
    t0 = time.time()
    for i in range(cap):
        try:
            ip = one(entry["proto"], entry["host"], int(entry["port"]))
            ok += 1
            fails = 0
            if ip not in ips:
                ips.append(ip)
        except Exception:
            fails += 1
            if fails >= 3:
                stop = "3-consecutive-failures"
                break
        time.sleep(1.0)
    return {
        "proto": entry["proto"], "host": entry["host"], "port": entry["port"],
        "ok": ok, "attempted": i + 1, "distinct_exit_ips": len(ips),
        "exit_ips": ips[:8], "stop": stop, "seconds": round(time.time() - t0, 1),
    }


if __name__ == "__main__":
    entries = json.load(open(sys.argv[1]))
    cap = int(sys.argv[2])
    out = []
    for e in entries:
        r = run(e, cap)
        out.append(r)
        print("%-40s ok=%2d/%2d exits=%d stop=%s"
              % (r["host"] + ":" + str(r["port"]), r["ok"], r["attempted"],
                 r["distinct_exit_ips"], r["stop"]), flush=True)
    json.dump(out, open(sys.argv[3], "w"), indent=1)
